#ifndef _CRT_SECURE_NO_WARNINGS
#define _CAT_SECURE_NO_WARNINGS
#endif // _CRT_SECURE_NO_WARNINGS

#include <stdio.h>

void init(int N);
int go(int second);
void addWire(int sx, int sy, int dir, int len);
void dropElec(int x, int y);

#define INIT 0
#define GO 1
#define ADD 2
#define DROP 3
#define END 4

bool run()
{
    int callCnt = 0;
    int answerCnt = 0;
    int param1, param2, param3, param4;
    int ret = 0;
    int cmd = 0;

    while(true)
    {
        scanf("%d", &cmd);

        if(cmd == END)
            break;

        switch (cmd)
        {
            case INIT:
                scanf("%d", &param1);
                init(param1);
                break;
            case GO:
                callCnt++;
                scanf("%d %d", &param1, &param2);
                ret = go(param1);
                if (ret == param2)
                    answerCnt++;
                break;
            case ADD:
                scanf("%d %d %d %d", &param1, &param2, &param3, &param4);
                addWire(param1, param2, param3, param4);
                break;
            case DROP:
                scanf("%d %d", &param1, &param2);
                dropElec(param1, param2);
                break;
        }
    }
    return (callCnt == answerCnt);
}

int main(void)
{
    setbuf(stdout, NULL);
    int test, T;

    scanf("%d", &T);

    for(test = 1; test <= T; test++)
    {
        if(run())
        {
            printf("#%d 100\n", test);
        }
        else
        {
            printf("#%d 0\n", test);
        }
    }

    return 0;
}
