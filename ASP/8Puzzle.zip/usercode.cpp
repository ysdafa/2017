#define INF 99999999
#define MAXN 1024

extern void Memset_bool(bool *Array, int a, int len);
extern void Memset_int(int *Array, int a, int len);
extern void Memset_char(char *Array, int a, int len);

struct
{
    int step, state;
}t, que1[1000000], que2[1000000];

class Stack
{
    private:
        int Size;
        int Stk[MAXN];

    public:
        Stack()
        {
            Size = 0;
        }

        void Clear()
        {
            Size = 0;
        }

        bool Empty()
        {
            return Size == 0;
        }

        void Push(int data)
        {
            Size ++;
            Stk[Size] = data;
        }

        int Top()
        {
            return Stk[Size];
        }

        void Pop()
        {
            Size--;
        }
};

Stack stk;

bool vis1[5000007], vis2[5000007];
int top1, top2, bottom1, bottom2, total;
int nxt[2][7] = {{0, 4, 6, 5, 1, 3, 2}, {0, 5, 3, 2, 6, 1, 4}};
int head[5000007], next[5000007], val[5000007], mp[9];

int hashval(int x)
{
    int t;

    t = x % 5000007;

    for (int i = head[t]; i != -1; i = next[i])
    {
        if (val[i] == x) return i;
    }

    val[total] = x;
    next[total] = head[t];
    head[t] = total;
    total++;

    return total - 1;
}

void pushtarget(int cnt, int state)
{
    if (cnt == -1)
    {
        vis2[hashval(state)] = 1;
        que2[bottom2].step = 0;
        que2[bottom2].state = state;
        bottom2++;

        return;
    }

    if (mp[cnt] % 2)
    {
        pushtarget(cnt - 1, state * 7 + mp[cnt]);
        pushtarget(cnt - 1, state * 7 + mp[cnt] + 1);
    }
    else pushtarget(cnt - 1, state * 7);
}

int getstate()
{
    int temp = 0;

    for (int i = 8; i >= 0; i--)
    {
        temp = temp * 7 + mp[i];
    }

    return temp;
}

void spread(int x)
{
    int i = 0, temp, cnt, old;

    while (i < 9)
    {
        if (x % 7 == 0) cnt = i;
        mp[i++] = x % 7;
        x /= 7;
    }


    cnt += 1;
    if (cnt >= 0 && cnt < 9 && cnt % 3 > 0)
    {

        old = mp[cnt];
        mp[cnt - 1] = nxt[0][mp[cnt]];
        mp[cnt] = 0;

        stk.Push(getstate());

        mp[cnt] = old;
        mp[cnt - 1] = 0;
    }
    cnt -= 1;



    cnt -= 1;
    if (cnt >= 0 && cnt < 9 && cnt % 3 < 2)
    {
        old = mp[cnt];
        mp[cnt + 1] = nxt[0][mp[cnt]];
        mp[cnt] = 0;

        stk.Push(getstate());

        mp[cnt] = old;
        mp[cnt + 1] = 0;
    }
    cnt += 1;


    cnt -= 3;
    if (cnt >= 0 && cnt < 9)
    {
        old = mp[cnt];
        mp[cnt + 3] = nxt[1][mp[cnt]];
        mp[cnt] = 0;

        stk.Push(getstate());

        mp[cnt] = old;
        mp[cnt + 3] = 0;
    }
    cnt += 3;


    cnt += 3;
    if (cnt >= 0 && cnt < 9)
    {
        old = mp[cnt];
        mp[cnt - 3] = nxt[1][mp[cnt]];
        mp[cnt] = 0;

        stk.Push(getstate());

        mp[cnt] = old;
        mp[cnt - 3] = 0;
    }
    cnt -= 3;
}

int bfs()
{
    int step1 = 0, step2 = 0, ans = INF, temp;

    for (step1 = 0; step1 <= 20; step1++)
    {

        while (top1 < bottom1 && que1[top1].step == step1)
        {
            spread(que1[top1].state);

            while (!stk.Empty())
            {
                temp = stk.Top();
                stk.Pop();

                if (vis2[hashval(temp)])
                {
                    return step1 + step2 + 1;
                }

                if (!vis1[hashval(temp)])
                {
                    vis1[hashval(temp)] = 1;
                    que1[bottom1].state = temp;
                    que1[bottom1].step = que1[top1].step + 1;

                    bottom1++;
                }
            }

            top1++;
        }


        while (top2 < bottom2 && que2[top2].step == step2 && step2 < 9)
        {
            spread(que2[top2].state);

            while (!stk.Empty())
            {
                temp = stk.Top();
                stk.Pop();

                if (vis1[hashval(temp)]) return step1 + step2 + 2;

                if (!vis2[hashval(temp)])
                {
                    vis2[hashval(temp)] = 1;
                    que2[bottom2].state = temp;
                    que2[bottom2].step = step2 + 1;

                    bottom2++;
                }
            }

            top2++;
        }

        if (step2 < 9) step2++;
    }

    return -1;
}

int Solve(int x, int y, char *str)
{
    int xx = y - 1;
    int yy = x - 1;

    int temp = 0;
    for (int i = 8; i >= 0; i--)
    {
        if (i != xx * 3 + yy) temp = temp * 7 + 1;
        else temp *= 7;
    }

    if(vis2[hashval(temp)])
    {
        return 0;
    }

    vis1[hashval(temp)] = 1;

    que1[bottom1].step = 0;
    que1[bottom1].state = temp;
    bottom1++;

    return bfs();
}

void init(int x, int y, char *str)
{
    top1 = top2 = bottom1 = bottom2 = 0;

    Memset_bool(vis1, 0, sizeof(vis1));
    Memset_bool(vis2, 0, sizeof(vis2));
    Memset_int(head, -1, sizeof(head));

    total = 0;

    stk.Clear();

    for (int i = 0; i < 9; i++)
    {
        if (str[i] == 'W') mp[i] = 1;
        else if (str[i] == 'B') mp[i] = 3;
        else if (str[i] == 'R') mp[i] = 5;
        else if (str[i] == 'E') mp[i] = 0;
    }

    pushtarget(8, 0);
}
