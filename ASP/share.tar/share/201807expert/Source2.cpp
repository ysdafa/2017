#include "pch.h"
void init()
{}

void read_file(char* filename, int offset, char* data, int size)
{}

void insert_file(char* filename, int offset, char* data, int size)
{}

void delete_file(char* filename, int offset, int size)
{}

