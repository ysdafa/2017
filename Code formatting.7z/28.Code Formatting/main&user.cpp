﻿#ifndef _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#endif

#include <stdio.h>
#include <conio.h>
#include <iostream>
using namespace std;
#define MAXN 1024

char str[MAXN];
void solve(char *s);

int main()
{
	int T;
	scanf("%d", &T);
	getchar();
	for (int cas = 1; cas <= T; cas++)
	{
		gets(str);
		printf("Case #%d:\n", cas);
		solve(str);
	}
	_getch();
	return 0;
}

bool strcmps(char *a, char *b)
{
	while (*a && *a == *b)
		a++, b++;

	return *a == *b;
}

void solve(char *s)
{
	int flag = 1;
	int tot = 0;
	int space_counter = 0;

	char last_word[MAXN];
	char this_line[MAXN];
	char word[5][MAXN] = { "int", "void", "double", "bool", "char" };

	int index_last = 0;
	int index_this = 0;

	for (int i = 0; s[i] != '\0'; i++)
	{
		if (s[i] == '#')
		{
			// #
			putchar(s[i]);
			i++;

			// include
			int sum = 0;
			for (;; i++)
			{
				if (s[i] == ' ') continue;
				putchar(s[i]);
				sum++;
				if (sum == 7) break;
			}
			putchar(' ');
			i++;

			// <XXX>
			for (;; i++)
			{
				if (s[i] == ' ') continue;
				putchar(s[i]);
				if (s[i] == '>') break;
			}
			printf("\n");
			flag = 0;
		}

		// 头文件意外的非空格字符
		else if (s[i] != ' ')
		{
			// 头文件后空一行
			if (!flag)
			{
				printf("\n");
				flag = 1;
			}

			// 双引号里面的内容不允许变动，注意转意字符: \"
			if (s[i] == '\"')
			{
				this_line[index_this++] = s[i];
				i++;
				for (;; i++)
				{
					this_line[index_this++] = s[i];
					if (flag == 2)
					{
						flag = 1;
						continue;
					}
					if (s[i] == '\\')
					{
						flag = 2;
					}
					if (s[i] == '\"')
					{
						break;
					}
				}
			}

			// 单引号里面的内容不允许变动，注意转意字符: \'
			else if (s[i] == '\'')
			{
				this_line[index_this++] = s[i];
				i++;
				for (;; i++)
				{
					this_line[index_this++] = s[i];
					if (flag == 2)
					{
						flag = 1;
						continue;
					}
					if (s[i] == '\\')
					{
						flag = 2;
					}
					if (s[i] == '\'')
					{
						break;
					}
				}
			}

			// 其他情况
			else
			{
				// 逗号后面加上空格
				if (s[i] == ',')
				{
					index_last = 0;
					this_line[index_this++] = s[i];
					this_line[index_this++] = ' ';
				}

				// 情况一： 空格 += (-=、!=、==、*=、/=、<=、>=) 空格
				// 情况二： 空格 + (-、*、/、<、>、!、=) 空格
				else if (s[i] == '<' || s[i] == '>' || s[i] == '=' || s[i] == '!' || s[i] == '+' || s[i] == '-' || s[i] == '*' || s[i] == '/')
				{
					index_last = 0;
					if (s[i + 1] == '=')
					{
						this_line[index_this++] = ' ';
						this_line[index_this++] = s[i];
						this_line[index_this++] = '=';
						this_line[index_this++] = ' ';
						i++;
					}
					else
					{
						this_line[index_this++] = ' ';
						this_line[index_this++] = s[i];
						this_line[index_this++] = ' ';
					}
				}

				// '{'、'}': 注意更新last_word, 注意缩进的增加或者减少两格(space_counter)
				else if (s[i] == '{' || s[i] == '}')
				{
					index_last = 0;
					
					// 比如if()，或者for(;;)之后的花括号
					if (index_this)
					{
						for (int j = 0; j < space_counter; j++) putchar(' ');
						for (int j = 0; j < index_this; j++) putchar(this_line[j]);
						printf("\n");
						index_this = 0;
					}
					// 注意：后花括号要先把缩进退两格
					if (s[i] == '}') space_counter -= 2;
					for (int j = 0; j < space_counter; j++) putchar(' ');
					putchar(s[i]);
					if (s[i] == '{') space_counter += 2;
					printf("\n");
				}

				// '(' 记录左右括号数，左+1，右-1
				else if (s[i] == '(')
				{
					index_last = 0;
					this_line[index_this++] = s[i];
					tot++;
				}

				// ')' 记录左右括号数，左+1，右-1
				else if (s[i] == ')')
				{
					index_last = 0;
					this_line[index_this++] = s[i];
					tot--;
				}

				// ';': 小心for循环里面的分号，考虑括号的数量，分号后面输出空行或者空格
				else if (s[i] == ';')
				{
					index_last = 0;
					this_line[index_this++] = s[i];
					if (!tot)
					{
						for (int j = 0; j < space_counter; j++) putchar(' ');
						for (int j = 0; j < index_this; j++) putchar(this_line[j]);
						printf("\n");
						index_this = 0;
					}
					else
					{
						this_line[index_this++] = ' ';
					}
				}
				
				// 正常，注意在切词上加上
				else if (s[i] != ' ')
				{
					this_line[index_this++] = s[i];
					last_word[index_last++] = s[i];
				}
			}
		}

		// 其他情况
		else
		{
			last_word [index_last] = 0;
			// int, void, double, bool, char
			if (strcmps(last_word, word[0]) || strcmps(last_word, word[1]) || strcmps(last_word, word[2]) || strcmps(last_word, word[3]) || strcmps(last_word, word[4]))
			{
				index_last = 0;
				this_line[index_this++] = ' ';
			}
		}
	}
}