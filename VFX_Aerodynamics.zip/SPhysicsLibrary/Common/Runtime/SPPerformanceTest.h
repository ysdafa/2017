/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPPerformanceTest.h
 * @brief  Performance Test
 * @author Arthur Yusupov (a.yusupov@samsung.com)
 */

#ifndef _SP_PERFORMANCETEST_H_
#define _SP_PERFORMANCETEST_H_

#ifndef DOXYGEN_SKIP

#include "SPException.h"
#include "SPParallelCalculation.h"
#include "SPTaskPool.h"
#include "SPDynamicTaskQueue.h"
#include "SPStaticTaskQueue.h"

#include <glm.hpp>
#include <gtc/epsilon.hpp>
//#include <omp.h>

#ifdef __ARM_NEON__
#include <arm_neon.h>
#endif

#define COMPLEXITY 0x10					//!< Complexity
#define ARRAY_SIZE COMPLEXITY * 0x10	//!< Array size
#define ITERATION_COUNT 0x100			//!< Iteration count
#define MIN_THREAD_COUNT 1				//!< Min thread count
#define MAX_THREAD_COUNT 4				//!< Max thread count

volatile SPInt ia = 1;
volatile SPInt ib = 1;
volatile SPInt ic = 1;
volatile SPFloat fa = 5;
volatile SPFloat fb = 5;
volatile SPFloat fc = 5;
volatile SPDouble da = 5;
volatile SPDouble db = 5;
volatile SPDouble dc = 5;
SPInt* a;
SPInt* b;
SPFloat* c;
SPFloat* d;

/**
 * Thread argument
 */
struct ThreadArgument
{
	SPUInt inc;
	SPUInt id;
	SPUInt size;
	SPUInt arr1[16];
	SPUInt arr2[16];
	SPUInt arr3[16];
}* gArgs;

//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
const SPChar* testName1 = "SPInt operation";
const SPChar* testName1_1 = "c = a";
/** @brief work */
SPVoid work1_1(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		ic = ia;
	}
} //!< work1_1
//--------------------------------------------------------------------------------------------------
const SPChar* testName1_2 = "c = a + b";
SPVoid work1_2(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		ic = ia + ib;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName1_3 = "c = a - b";
SPVoid work1_3(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		ic = ia - ib;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName1_4 = "c = a * b";
SPVoid work1_4(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		ic = ia * ib;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName1_5 = "c = a / b";
SPVoid work1_5(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		ic = ia / ib;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName1_6 = "c = a / 256.0";
SPVoid work1_6(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		ic = ia / 256.0;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName1_7 = "c = a >> 8";
SPVoid work1_7(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		ic = ia >> 8;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName1_8 = "c = a % b";
SPVoid work1_8(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		ic = ia % ib;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName1_9 = "i++";
SPVoid work1_9(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		ic = ia++;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName1_10 = "c = ++i";
SPVoid work1_10(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		ic = ++ia;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName1_11 = "c = a > b";
SPVoid work1_11(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		ic = (ia > ib);
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName1_12 = "c = (a > b) ? 0 : 1";
SPVoid work1_12(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		ic = (ia > ib) ? 0 : 1;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName1_13 = "c = (a > b) ? a : b";
SPVoid work1_13(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		ic = (ia > ib) ? ia : ib;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName1_14 = "if (ia > ib) c = a; else c = b";
SPVoid work1_14(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		if (ia > ib)
		{
			ic = ia;
		}
		else
		{
			ic = ib;
		}
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName1_15 = "c = a & b";
SPVoid work1_15(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		ic = ia & ib;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName1_16 = "c = a | b";
SPVoid work1_16(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		ic = ia | ib;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName1_17 = "c = a << b";
SPVoid work1_17(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		ic = ia << ib;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName1_18 = "c = a >> b";
SPVoid work1_18(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		ic = ia >> ib;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName1_19 = "c = a + b[i]";
SPVoid work1_19(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		ic = ia + (volatile SPInt) (b[i % ARRAY_SIZE]);
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName1_20 = "c = a[i] + b[i]";
SPVoid work1_20(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		ic = (volatile SPInt) (a[i % ARRAY_SIZE]) + (volatile SPInt) (b[i % ARRAY_SIZE]);
	}
}
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
const SPChar* testName2 = "SPFloat operation";
const SPChar* testName2_1 = "c = a";
SPVoid work2_1(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		fc = fa;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName2_2 = "c = a + b";
SPVoid work2_2(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		fc = fa + fb;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName2_3 = "c = a - b";
SPVoid work2_3(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		fc = fa - fb;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName2_4 = "c = a * b";
SPVoid work2_4(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		fc = fa * fb;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName2_5 = "c = a / b";
SPVoid work2_5(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		fc = fa / fb;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName2_6 = "c = a++";
SPVoid work2_6(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		fc = fa++;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName2_7 = "c = ++a";
SPVoid work2_7(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		fc = ++fa;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName2_8 = "c = a > b";
SPVoid work2_8(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		fc = (fa > fb);
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName2_9 = "c = (a > b) ? 0 : 1";
SPVoid work2_9(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		fc = (fa > fb) ? 0 : 1;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName2_10 = "c = (a > b) ? a : b";
SPVoid work2_10(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		fc = (fa > fb) ? fa : fb;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName2_11 = "if (a > b) c = a; else c = b";
SPVoid work2_11(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		if (fa > fb)
		{
			fc = fa;
		}
		else
		{
			fc = fb;
		}
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName2_12 = "rate 1/128 c = sin(a)";
SPVoid work2_12(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x2 * arg.size; i < size; i++)
	{
		fc = glm::sin(SPFloat(fa));
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName2_13 = "rate 1/128 c = cos(a)";
SPVoid work2_13(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x2 * arg.size; i < size; i++)
	{
		fc = glm::cos(SPFloat(fa));
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName2_14 = "rate 1/128 c = tan(a)";
SPVoid work2_14(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x2 * arg.size; i < size; i++)
	{
		fc = glm::tan(SPFloat(fa));
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName2_15 = "rate 1/128 c = asin(a)";
SPVoid work2_15(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x2 * arg.size; i < size; i++)
	{
		fc = glm::asin(SPFloat(fa));
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName2_16 = "rate 1/128 c = acos(a)";
SPVoid work2_16(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x2 * arg.size; i < size; i++)
	{
		fc = glm::acos(SPFloat(fa));
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName2_17 = "rate 1/128 c = atan(a)";
SPVoid work2_17(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x2 * arg.size; i < size; i++)
	{
		fc = glm::atan(SPFloat(fa));
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName2_18 = "c = sqrt(a)";
SPVoid work2_18(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		fc = glm::sqrt(SPFloat(fa));
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName2_19 = "c = pow(a, 2.0)";
SPVoid work2_19(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		fc = glm::pow(SPFloat(fa), 2.0f);
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName2_20 = "c = a * a";
SPVoid work2_20(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		fc = SPFloat(fa) * SPFloat(fa);
	}
}
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
const SPChar* testName3 = "SPDouble operation";
const SPChar* testName3_1 = "c = a";
SPVoid work3_1(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		dc = da;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName3_2 = "c = a + b";
SPVoid work3_2(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		dc = da + db;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName3_3 = "c = a - b";
SPVoid work3_3(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		dc = da - db;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName3_4 = "c = a * b";
SPVoid work3_4(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		dc = da * db;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName3_5 = "c = a / b";
SPVoid work3_5(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		dc = da / db;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName3_6 = "c = a++";
SPVoid work3_6(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		dc = da++;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName3_7 = "c = ++a";
SPVoid work3_7(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		dc = ++da;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName3_8 = "c = a > b";
SPVoid work3_8(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		dc = (da > db);
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName3_9 = "c = (a > b) ? 0 : 1";
SPVoid work3_9(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		dc = (da > db) ? 0 : 1;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName3_10 = "c = (a > b) ? a : b";
SPVoid work3_10(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		dc = (da > db) ? da : db;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName3_11 = "if (a > b) c = a; else c = b";
SPVoid work3_11(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		if (da > db)
		{
			dc = da;
		}
		else
		{
			dc = db;
		}
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName3_12 = "rate 1/128 c = sin(a)";
SPVoid work3_12(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x2 * arg.size; i < size; i++)
	{
		dc = glm::sin(SPDouble(da));
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName3_13 = "rate 1/128 c = cos(a)";
SPVoid work3_13(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x2 * arg.size; i < size; i++)
	{
		dc = glm::cos(SPDouble(da));
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName3_14 = "rate 1/128 c = tan(a)";
SPVoid work3_14(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x2 * arg.size; i < size; i++)
	{
		dc = glm::tan(SPDouble(da));
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName3_15 = "rate 1/128 c = asin(a)";
SPVoid work3_15(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x2 * arg.size; i < size; i++)
	{
		dc = glm::asin(SPDouble(da));
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName3_16 = "rate 1/128 c = acos(a)";
SPVoid work3_16(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x2 * arg.size; i < size; i++)
	{
		dc = glm::acos(SPDouble(da));
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName3_17 = "rate 1/128 c = atan(a)";
SPVoid work3_17(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x2 * arg.size; i < size; i++)
	{
		dc = glm::atan(SPDouble(da));
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName3_18 = "c = sqrt(a)";
SPVoid work3_18(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		dc = glm::sqrt(SPDouble(da));
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName3_19 = "c = pow(a, 2.0)";
SPVoid work3_19(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		dc = glm::pow(SPDouble(da), SPDouble(2.0));
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName3_20 = "c = a * a";
SPVoid work3_20(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		dc = SPDouble(da) * SPDouble(da);
	}
}
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
const SPChar* testName4 = "loops";
const SPChar* testName4_1 = "unrolled vc = va + vb";
SPVoid work4_1(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		(volatile SPInt&) aArg->arr1[0] = (volatile SPInt) aArg->arr2[0] + (volatile SPInt) aArg->arr3[0];
		(volatile SPInt&) aArg->arr1[1] = (volatile SPInt) aArg->arr2[1] + (volatile SPInt) aArg->arr3[1];
		(volatile SPInt&) aArg->arr1[2] = (volatile SPInt) aArg->arr2[2] + (volatile SPInt) aArg->arr3[2];
		(volatile SPInt&) aArg->arr1[3] = (volatile SPInt) aArg->arr2[3] + (volatile SPInt) aArg->arr3[3];
		(volatile SPInt&) aArg->arr1[4] = (volatile SPInt) aArg->arr2[4] + (volatile SPInt) aArg->arr3[4];
		(volatile SPInt&) aArg->arr1[5] = (volatile SPInt) aArg->arr2[5] + (volatile SPInt) aArg->arr3[5];
		(volatile SPInt&) aArg->arr1[6] = (volatile SPInt) aArg->arr2[6] + (volatile SPInt) aArg->arr3[6];
		(volatile SPInt&) aArg->arr1[7] = (volatile SPInt) aArg->arr2[7] + (volatile SPInt) aArg->arr3[7];
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName4_2 = "for vc = va + vb";
SPVoid work4_2(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		for (SPUInt j = 0; j < 8; j++)
		{
			(volatile SPInt&) aArg->arr1[j] = (volatile SPInt) aArg->arr2[j]
					+ (volatile SPInt) aArg->arr3[j];
		}
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName4_3 = "unrolled c = sum(va)";
SPVoid work4_3(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		(volatile SPInt&) aArg->arr1[0] = (volatile SPInt) aArg->arr2[0] + (volatile SPInt) aArg->arr2[1]
										+ (volatile SPInt) aArg->arr2[2]
										+ (volatile SPInt) aArg->arr2[3]
										+ (volatile SPInt) aArg->arr2[4]
										+ (volatile SPInt) aArg->arr2[5]
										+ (volatile SPInt) aArg->arr2[6]
										+ (volatile SPInt) aArg->arr2[7];
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName4_4 = "for c = sum(va)";
SPVoid work4_4(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * arg.size; i < size; i++)
	{
		SPUInt sum = (volatile SPInt) aArg->arr2[0];
		for (SPUInt j = 1; j < 8; j++)
		{
			sum += (volatile SPInt) aArg->arr2[j];
		}
		(volatile SPInt&) aArg->arr1[0] = sum;
	}
}
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
const SPChar* testName5 = "array indexing";
const SPChar* testName5_1 = "access by columns";
SPVoid work5_1(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = arg.size; i < size; i++)
	{
		for (SPUInt x = 0; x < ARRAY_SIZE / 4; x++)
		{
			for (SPUInt y = 0; y < ARRAY_SIZE / 4; y++)
			{
				a[y * ARRAY_SIZE / 4 + x] += b[y * ARRAY_SIZE / 4 + x];
			}
		}
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName5_2 = "access by rows";
SPVoid work5_2(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = arg.size; i < size; i++)
	{
		for (SPUInt y = 0; y < ARRAY_SIZE / 4; y++)
		{
			for (SPUInt x = 0; x < ARRAY_SIZE / 4; x++)
			{
				a[y * ARRAY_SIZE / 4 + x] += b[y * ARRAY_SIZE / 4 + x];
			}
		}
	}
}
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
const SPChar* testName6 = "function";
const SPChar* testName6_1 = "pass value [8]";
SPUInt func6_1(SPUInt a1,
					 SPUInt a2,
					 SPUInt a3,
					 SPUInt a4,
					 SPUInt a5,
					 SPUInt a6,
					 SPUInt a7,
					 SPUInt a8)
{
	return a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8;
}

SPVoid work6_1(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x20 * arg.size; i < size; i++)
	{
		aArg->arr1[0] = func6_1(aArg->arr1[0], aArg->arr1[1], aArg->arr1[2], aArg->arr1[3],
								aArg->arr1[4], aArg->arr1[5], aArg->arr1[6], aArg->arr1[7]);
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName6_2 = "pass array [8]";
SPUInt func6_2(SPUInt* a1)
{
	return a[0] + a[1] + a[2] + a[3] + a[4] + a[5] + a[6] + a[7] + a[0] + a[1] + a[2] + a[3] + a[4]
		   + a[5] + a[6] + a[7];
}

SPVoid work6_2(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x20 * arg.size; i < size; i++)
	{
		aArg->arr1[0] = func6_2((SPUInt*) aArg->arr1);
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName6_3 = "pass value [16]";
SPUInt func6_3(SPUInt a1,
					 SPUInt a2,
					 SPUInt a3,
					 SPUInt a4,
					 SPUInt a5,
					 SPUInt a6,
					 SPUInt a7,
					 SPUInt a8,
					 SPUInt a9,
					 SPUInt a10,
					 SPUInt a11,
					 SPUInt a12,
					 SPUInt a13,
					 SPUInt a14,
					 SPUInt a15,
					 SPUInt a16)
{
	return a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11 + a12 + a13 + a14 + a15 + a16;
}

SPVoid work6_3(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x20 * arg.size; i < size; i++)
	{
		aArg->arr1[0] = func6_3(aArg->arr1[0], aArg->arr1[1], aArg->arr1[2], aArg->arr1[3],
								aArg->arr1[4], aArg->arr1[5], aArg->arr1[6], aArg->arr1[7],
								aArg->arr1[8], aArg->arr1[9], aArg->arr1[10], aArg->arr1[11],
								aArg->arr1[12], aArg->arr1[13], aArg->arr1[14], aArg->arr1[15]);
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName6_4 = "pass array [16]";
SPUInt func6_4(SPUInt* a1)
{
	return a[0] + a[1] + a[2] + a[3] + a[4] + a[5] + a[6] + a[7] + a[8] + a[9] + a[10] + a[11]
		   + a[12] + a[13] + a[14] + a[15];
}

SPVoid work6_4(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x20 * arg.size; i < size; i++)
	{
		aArg->arr1[0] = func6_4((SPUInt*) aArg->arr1);
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName6_5 = "'inline' pass value [16]";
inline SPUInt func6_5(SPUInt a1,
							SPUInt a2,
							SPUInt a3,
							SPUInt a4,
							SPUInt a5,
							SPUInt a6,
							SPUInt a7,
							SPUInt a8,
							SPUInt a9,
							SPUInt a10,
							SPUInt a11,
							SPUInt a12,
							SPUInt a13,
							SPUInt a14,
							SPUInt a15,
							SPUInt a16)
{
	return a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11 + a12 + a13 + a14 + a15 + a16;
}

SPVoid work6_5(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x20 * arg.size; i < size; i++)
	{
		aArg->arr1[0] = func6_5(aArg->arr1[0], aArg->arr1[1], aArg->arr1[2], aArg->arr1[3],
								aArg->arr1[4], aArg->arr1[5], aArg->arr1[6], aArg->arr1[7],
								aArg->arr1[8], aArg->arr1[9], aArg->arr1[10], aArg->arr1[11],
								aArg->arr1[12], aArg->arr1[13], aArg->arr1[14], aArg->arr1[15]);
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName6_6 = "'inline' pass array [16]";
inline SPUInt func6_6(SPUInt* a1)
{
	return a[0] + a[1] + a[2] + a[3] + a[4] + a[5] + a[6] + a[7] + a[8] + a[9] + a[10] + a[11]
		   + a[12] + a[13] + a[14] + a[15];
}

SPVoid work6_6(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x20 * arg.size; i < size; i++)
	{
		aArg->arr1[0] = func6_6((SPUInt*) aArg->arr1);
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName6_7 = "pass const value [16]";
SPUInt func6_7(const SPUInt a1,
					 const SPUInt a2,
					 const SPUInt a3,
					 const SPUInt a4,
					 const SPUInt a5,
					 const SPUInt a6,
					 const SPUInt a7,
					 const SPUInt a8,
					 const SPUInt a9,
					 const SPUInt a10,
					 const SPUInt a11,
					 const SPUInt a12,
					 const SPUInt a13,
					 const SPUInt a14,
					 const SPUInt a15,
					 const SPUInt a16)
{
	return a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11 + a12 + a13 + a14 + a15 + a16;
}

SPVoid work6_7(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x20 * arg.size; i < size; i++)
	{
		aArg->arr1[0] = func6_7(aArg->arr1[0], aArg->arr1[1], aArg->arr1[2], aArg->arr1[3],
								aArg->arr1[4], aArg->arr1[5], aArg->arr1[6], aArg->arr1[7],
								aArg->arr1[8], aArg->arr1[9], aArg->arr1[10], aArg->arr1[11],
								aArg->arr1[12], aArg->arr1[13], aArg->arr1[14], aArg->arr1[15]);
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName6_8 = "pass ref [16]";
SPUInt func6_8(SPUInt& a1,
					 SPUInt& a2,
					 SPUInt& a3,
					 SPUInt& a4,
					 SPUInt& a5,
					 SPUInt& a6,
					 SPUInt& a7,
					 SPUInt& a8,
					 SPUInt& a9,
					 SPUInt& a10,
					 SPUInt& a11,
					 SPUInt& a12,
					 SPUInt& a13,
					 SPUInt& a14,
					 SPUInt& a15,
					 SPUInt& a16)
{
	return a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11 + a12 + a13 + a14 + a15 + a16;
}

SPVoid work6_8(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x20 * arg.size; i < size; i++)
	{
		aArg->arr1[0] = func6_8(aArg->arr1[0], aArg->arr1[1], aArg->arr1[2], aArg->arr1[3],
								aArg->arr1[4], aArg->arr1[5], aArg->arr1[6], aArg->arr1[7],
								aArg->arr1[8], aArg->arr1[9], aArg->arr1[10], aArg->arr1[11],
								aArg->arr1[12], aArg->arr1[13], aArg->arr1[14], aArg->arr1[15]);
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName6_9 = "pass const ref [16]";
SPUInt func6_9(const SPUInt a1,
					 const SPUInt& a2,
					 const SPUInt& a3,
					 const SPUInt& a4,
					 const SPUInt& a5,
					 const SPUInt& a6,
					 const SPUInt& a7,
					 const SPUInt& a8,
					 const SPUInt& a9,
					 const SPUInt& a10,
					 const SPUInt& a11,
					 const SPUInt& a12,
					 const SPUInt& a13,
					 const SPUInt& a14,
					 const SPUInt& a15,
					 const SPUInt& a16)
{
	return a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11 + a12 + a13 + a14 + a15 + a16;
}

SPVoid work6_9(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x20 * arg.size; i < size; i++)
	{
		aArg->arr1[0] = func6_9(aArg->arr1[0], aArg->arr1[1], aArg->arr1[2], aArg->arr1[3],
								aArg->arr1[4], aArg->arr1[5], aArg->arr1[6], aArg->arr1[7],
								aArg->arr1[8], aArg->arr1[9], aArg->arr1[10], aArg->arr1[11],
								aArg->arr1[12], aArg->arr1[13], aArg->arr1[14], aArg->arr1[15]);
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName6_10 = "'inline' pass const value [16]";
inline SPUInt func6_10(const SPUInt a1,
							 const SPUInt a2,
							 const SPUInt a3,
							 const SPUInt a4,
							 const SPUInt a5,
							 const SPUInt a6,
							 const SPUInt a7,
							 const SPUInt a8,
							 const SPUInt a9,
							 const SPUInt a10,
							 const SPUInt a11,
							 const SPUInt a12,
							 const SPUInt a13,
							 const SPUInt a14,
							 const SPUInt a15,
							 const SPUInt a16)
{
	return a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11 + a12 + a13 + a14 + a15 + a16;
}

SPVoid work6_10(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x20 * arg.size; i < size; i++)
	{
		aArg->arr1[0] = func6_10(aArg->arr1[0], aArg->arr1[1], aArg->arr1[2], aArg->arr1[3],
								 aArg->arr1[4], aArg->arr1[5], aArg->arr1[6], aArg->arr1[7],
								 aArg->arr1[8], aArg->arr1[9], aArg->arr1[10], aArg->arr1[11],
								 aArg->arr1[12], aArg->arr1[13], aArg->arr1[14], aArg->arr1[15]);
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName6_11 = "'inline' pass ref [16]";
inline SPUInt func6_11(SPUInt& a1,
							 SPUInt& a2,
							 SPUInt& a3,
							 SPUInt& a4,
							 SPUInt& a5,
							 SPUInt& a6,
							 SPUInt& a7,
							 SPUInt& a8,
							 SPUInt& a9,
							 SPUInt& a10,
							 SPUInt& a11,
							 SPUInt& a12,
							 SPUInt& a13,
							 SPUInt& a14,
							 SPUInt& a15,
							 SPUInt& a16)
{
	return a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11 + a12 + a13 + a14 + a15 + a16;
}

SPVoid work6_11(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x20 * arg.size; i < size; i++)
	{
		aArg->arr1[0] = func6_11(aArg->arr1[0], aArg->arr1[1], aArg->arr1[2], aArg->arr1[3],
								 aArg->arr1[4], aArg->arr1[5], aArg->arr1[6], aArg->arr1[7],
								 aArg->arr1[8], aArg->arr1[9], aArg->arr1[10], aArg->arr1[11],
								 aArg->arr1[12], aArg->arr1[13], aArg->arr1[14], aArg->arr1[15]);
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName6_12 = "'inline' pass const ref [16]";
inline SPUInt func6_12(const SPUInt& a1,
							 const SPUInt& a2,
							 const SPUInt& a3,
							 const SPUInt& a4,
							 const SPUInt& a5,
							 const SPUInt& a6,
							 const SPUInt& a7,
							 const SPUInt& a8,
							 const SPUInt& a9,
							 const SPUInt& a10,
							 const SPUInt& a11,
							 const SPUInt& a12,
							 const SPUInt& a13,
							 const SPUInt& a14,
							 const SPUInt& a15,
							 const SPUInt& a16)
{
	return a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11 + a12 + a13 + a14 + a15 + a16;
}

SPVoid work6_12(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x20 * arg.size; i < size; i++)
	{
		aArg->arr1[0] = func6_12(aArg->arr1[0], aArg->arr1[1], aArg->arr1[2], aArg->arr1[3],
								 aArg->arr1[4], aArg->arr1[5], aArg->arr1[6], aArg->arr1[7],
								 aArg->arr1[8], aArg->arr1[9], aArg->arr1[10], aArg->arr1[11],
								 aArg->arr1[12], aArg->arr1[13], aArg->arr1[14], aArg->arr1[15]);
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName6_13 = "call by 'if'";
SPUInt func6_13_1(SPUInt a1,
						SPUInt a2,
						SPUInt a3,
						SPUInt a4,
						SPUInt a5,
						SPUInt a6,
						SPUInt a7,
						SPUInt a8,
						SPUInt a9,
						SPUInt a10,
						SPUInt a11,
						SPUInt a12,
						SPUInt a13,
						SPUInt a14,
						SPUInt a15,
						SPUInt a16)
{
	return a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11 + a12 + a13 + a14 + a15 + a16;
}

SPUInt func6_13_2(SPUInt a1,
						SPUInt a2,
						SPUInt a3,
						SPUInt a4,
						SPUInt a5,
						SPUInt a6,
						SPUInt a7,
						SPUInt a8,
						SPUInt a9,
						SPUInt a10,
						SPUInt a11,
						SPUInt a12,
						SPUInt a13,
						SPUInt a14,
						SPUInt a15,
						SPUInt a16)
{
	return a1 - a2 - a3 - a4 - a5 - a6 - a7 - a8 - a9 - a10 - a11 - a12 - a13 - a14 - a15 - a16;
}

SPVoid work6_13(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x20 * arg.size; i < size; i++)
	{
		if (ia > ib)
		{
			aArg->arr1[0] = func6_13_1(aArg->arr1[0], aArg->arr1[1], aArg->arr1[2], aArg->arr1[3],
									   aArg->arr1[4], aArg->arr1[5], aArg->arr1[6], aArg->arr1[7],
									   aArg->arr1[8], aArg->arr1[9], aArg->arr1[10], aArg->arr1[11],
									   aArg->arr1[12], aArg->arr1[13], aArg->arr1[14],
									   aArg->arr1[15]);
		}
		else
		{
			aArg->arr1[0] = func6_13_2(aArg->arr1[0], aArg->arr1[1], aArg->arr1[2], aArg->arr1[3],
									   aArg->arr1[4], aArg->arr1[5], aArg->arr1[6], aArg->arr1[7],
									   aArg->arr1[8], aArg->arr1[9], aArg->arr1[10], aArg->arr1[11],
									   aArg->arr1[12], aArg->arr1[13], aArg->arr1[14],
									   aArg->arr1[15]);
		}
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName6_14 = "call virtual method";
/**
 * @brief Base
 */
class Base
{
public:

	virtual ~Base()
	{
	}

	virtual SPUInt func(SPUInt a1,
							  SPUInt a2,
							  SPUInt a3,
							  SPUInt a4,
							  SPUInt a5,
							  SPUInt a6,
							  SPUInt a7,
							  SPUInt a8,
							  SPUInt a9,
							  SPUInt a10,
							  SPUInt a11,
							  SPUInt a12,
							  SPUInt a13,
							  SPUInt a14,
							  SPUInt a15,
							  SPUInt a16) = 0;
};

/**
 * @brief Child1
 */
class Child1: public Base
{
public:

	virtual SPUInt func(SPUInt a1,
							  SPUInt a2,
							  SPUInt a3,
							  SPUInt a4,
							  SPUInt a5,
							  SPUInt a6,
							  SPUInt a7,
							  SPUInt a8,
							  SPUInt a9,
							  SPUInt a10,
							  SPUInt a11,
							  SPUInt a12,
							  SPUInt a13,
							  SPUInt a14,
							  SPUInt a15,
							  SPUInt a16)
	{
		return a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11 + a12 + a13 + a14 + a15 + a16;
	}

};

/**
 * @brief Child2
 */
class Child2: public Base
{
public:

	virtual SPUInt func(SPUInt a1,
							  SPUInt a2,
							  SPUInt a3,
							  SPUInt a4,
							  SPUInt a5,
							  SPUInt a6,
							  SPUInt a7,
							  SPUInt a8,
							  SPUInt a9,
							  SPUInt a10,
							  SPUInt a11,
							  SPUInt a12,
							  SPUInt a13,
							  SPUInt a14,
							  SPUInt a15,
							  SPUInt a16)
	{
		return a1 - a2 - a3 - a4 - a5 - a6 - a7 - a8 - a9 - a10 - a11 - a12 - a13 - a14 - a15 - a16;
	}

};

SPVoid work6_14(ThreadArgument* aArg)
{
	Base* base;
	ThreadArgument arg = *aArg;

	if (ia > ib)
	{
		base = new Child1();
	}
	else
	{
		base = new Child2();
	}

	for (SPUInt i = 0, size = COMPLEXITY * 0x20 * arg.size; i < size; i++)
	{
		aArg->arr1[0] = base->func(aArg->arr1[0], aArg->arr1[1], aArg->arr1[2], aArg->arr1[3],
								   aArg->arr1[4], aArg->arr1[5], aArg->arr1[6], aArg->arr1[7],
								   aArg->arr1[8], aArg->arr1[9], aArg->arr1[10], aArg->arr1[11],
								   aArg->arr1[12], aArg->arr1[13], aArg->arr1[14], aArg->arr1[15]);
	}

	delete base;
}
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
const SPChar* testName7 = "function argument usage";
const SPChar* testName7_1 = "use arg";
SPVoid work7_1(ThreadArgument* aArg)
{
	for (SPUInt i = 0, size = COMPLEXITY * 0x40 * aArg->size; i < size; i++)
	{
		(volatile SPInt&) a[(i % ARRAY_SIZE) * aArg->id] += aArg->inc
				+ b[(i % ARRAY_SIZE) * aArg->id];
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName7_2 = "use copy";
SPVoid work7_2(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x40 * arg.size; i < size; i++)
	{
		(volatile SPInt&) a[(i % ARRAY_SIZE) * arg.id] += arg.inc + b[(i % ARRAY_SIZE) * arg.id];
	}
}
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
const SPChar* testName8 = "SPInt vs SPFloat";
const SPChar* testName8_1 = "SPFloat complexity[1]";
SPVoid work8_1(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = arg.size; i < size; i++)
	{
		volatile SPFloat sum = c[arg.id];
		volatile SPFloat inc = fa + arg.inc;
		for (SPUInt j = 0; j < COMPLEXITY * 0x80; j++)
		{
			sum += inc * j;
		}
		(volatile SPFloat&) c[arg.id] = sum;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName8_2 = "SPFloat complexity[2]";
SPVoid work8_2(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = arg.size; i < size; i++)
	{
		SPFloat sum = c[arg.id];
		SPFloat inc = fa + arg.inc;
		for (SPUInt j = 0; j < COMPLEXITY * 0x80; j++)
		{
			SPFloat dj = fa;
			sum += dj + inc + dj * inc * (dj + inc);
		}
		(volatile SPFloat&) c[arg.id] = sum;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName8_3 = "SPFloat complexity[3]";
SPVoid work8_3(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = arg.size; i < size; i++)
	{
		SPFloat sum = c[arg.id];
		SPFloat inc = fa + arg.inc;
		for (SPUInt j = 0; j < COMPLEXITY * 0x80; j++)
		{
			SPFloat dj = fa;
			sum += dj + inc + dj * inc * (dj - inc);
		}
		(volatile SPFloat&) c[arg.id] = sum;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName8_4 = "SPFloat complexity[4]";
SPVoid work8_4(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = arg.size; i < size; i++)
	{
		SPFloat sum = c[arg.id];
		SPFloat inc = fa + arg.inc;
		for (SPUInt j = 0; j < COMPLEXITY * 0x80; j++)
		{
			SPFloat dj = fa;
			sum += dj + inc + dj * inc * (dj - inc) / (dj + 1) / (inc + 1);
		}
		(volatile SPFloat&) c[arg.id] = sum;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName8_5 = "SPInt complexity[1]";
SPVoid work8_5(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = arg.size; i < size; i++)
	{
		volatile SPInt iSum = c[arg.id] * 256.0;
		volatile SPInt iInc = (fa) * 256.0 + (arg.inc << 8);
		for (SPUInt j = 0; j < COMPLEXITY * 0x80; j++)
		{
			iSum += iInc * j;
		}
		(volatile SPFloat&) c[arg.id] = SPFloat(iSum) / 256.0;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName8_6 = "SPInt complexity[2]";
SPVoid work8_6(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = arg.size; i < size; i++)
	{
		SPInt iSum = c[arg.id] * 256.0;
		SPInt iInc = (fa) * 256.0 + (arg.inc << 8);
		for (SPUInt j = 0; j < COMPLEXITY * 0x80; j++)
		{
			SPFloat iDj = fa * 256.0f;
			iSum += iDj + iInc + iDj * iInc * (iDj + iInc);
		}
		(volatile SPFloat&) c[arg.id] = SPFloat(iSum) / 256.0;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName8_7 = "SPInt complexity[3]";
SPVoid work8_7(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = arg.size; i < size; i++)
	{
		SPInt iSum = c[arg.id] * 256.0;
		SPInt iInc = (fa) * 256.0 + (arg.inc << 8);
		for (SPUInt j = 0; j < COMPLEXITY * 0x80; j++)
		{
			SPFloat iDj = fa * 256.0f;
			iSum += iDj + iInc + iDj * iInc * (iDj - iInc);
		}
		(volatile SPFloat&) c[arg.id] = SPFloat(iSum) / 256.0;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName8_8 = "SPInt complexity[4]";
SPVoid work8_8(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = arg.size; i < size; i++)
	{
		SPInt iSum = c[arg.id] * 256.0;
		SPInt iInc = (fa) * 256.0 + (arg.inc << 8);
		for (SPUInt j = 0; j < COMPLEXITY * 0x80; j++)
		{
			SPFloat iDj = fa * 256.0f;
			iSum += iDj + iInc + iDj * iInc * (iDj - iInc) / (iDj + 256) / (iInc + 256);
		}
		(volatile SPFloat&) c[arg.id] = SPFloat(iSum) / 256.0;
	}
}
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
#ifdef __ARM_NEON__
const SPChar* testName9 = "NEON";
const SPChar* testName9_1 = "no NEON";
SPVoid work9_1(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * arg.size; i < size; i++)
	{
		float32_t* src = (float32_t*) a + arg.id * ARRAY_SIZE;
		float32_t* dst = (float32_t*) b + arg.id * ARRAY_SIZE;

		for (SPUInt j = 0; j < ARRAY_SIZE; j++, src++, dst++)
		{
			*dst = *src + *dst + *src * *dst;
		}
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName9_2 = "intrinsics";
SPVoid work9_2(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * arg.size; i < size; i++)
	{
		float32_t * src = (float32_t *) a + arg.id * ARRAY_SIZE;
		float32_t * dst = (float32_t *) b + arg.id * ARRAY_SIZE;

		for (SPUInt j = 0; j < ARRAY_SIZE / 4; j++, src += 4, dst += 4)
		{
			float32x4_t src_a = vld1q_f32(src);
			float32x4_t src_b = vld1q_f32(dst);
			float32x4_t dst_c = vaddq_f32(src_a, src_b);
			dst_c = vmlaq_f32(dst_c, src_a, src_b);
			vst1q_f32(dst, dst_c);
		}
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName9_3 = "asm";
SPVoid work9_3(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * arg.size; i < size; i++)
	{
		uint8_t * src = (uint8_t *) a + arg.id * ARRAY_SIZE;
		uint8_t * dst = (uint8_t *) b + arg.id * ARRAY_SIZE;

		__asm__ __volatile__
		(
				"mov r0, %0\n\t"
				"mov r1, %1\n\t"
				"mov r2, %0\n\t"
				"add r2, r2, %2\n\t"
				"mov r3, %1\n\t"
				"loop%=:\n\t"
				"vld1.f32 {d0, d1}, [r0]!\n\t"
				"vld1.f32 {d2, d3}, [r1]!\n\t"
				"vaddq.f32 q2, q0, q1\n\t"
				"vmlaq.f32 q2, q0, q1\n\t"
				"vst1.f32 {d4, d5}, [r3]!\n\t"
				"cmp r0, r2\n\t"
				"ble loop%=\n\t"
				:
				:"r"(src), "r"(dst), "r" (ARRAY_SIZE * 4)
				:"r0", "r1", "r2", "r3"
		);
	}
}
#endif
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
const SPChar* testName10 = "operator =";
const SPChar* testName10_1 = "default";
/**
 * Class10_1
 */
class Class10_1
{
public:
	SPInt mA[1024 * 64 * COMPLEXITY];
};

Class10_1* c10_1_1 = new Class10_1();
Class10_1* c10_1_2 = new Class10_1();

SPVoid work10_1(ThreadArgument* aArg)
{
	*c10_1_1 = *c10_1_2;
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName10_2 = "memcpy";
/**
 * Class10_1
 */
class Class10_2: public Class10_1
{
public:
	Class10_2& operator=(Class10_2& aVal)
	{
		memcpy(this, &aVal, sizeof(Class10_2));
		return *this;
	}
};

Class10_2* c10_2_1 = new Class10_2();
Class10_2* c10_2_2 = new Class10_2();

SPVoid work10_2(ThreadArgument* aArg)
{
	*c10_2_1 = *c10_2_2;
}

//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
const SPChar* testName11 = "OpenMP";
const SPChar* testName11_1 = "SPhysics";
SPVoid work11_1(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	SPUInt size = COMPLEXITY * 0x200 * aArg->size;
	for (SPUInt i = 0; i < size; i++)
	{
		(volatile SPFloat&) c[arg.id] = fa + fb;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName11_2 = "OMP";
SPVoid work11_2(ThreadArgument* aArg)
{
	SPUInt size = COMPLEXITY * 0x200 * aArg->size;
#pragma omp parallel shared(fa, fb)
	{
		ThreadArgument arg = *aArg;
//		arg.id = omp_get_thread_num();
#pragma omp for
		for (SPUInt i = 0; i < size; i++)
		{
			(volatile SPFloat&) c[arg.id] = fa + fb;
		}
	}
}
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
const SPChar* testName12 = "'for' iterator";
const SPChar* testName12_1 = "SPUInt";
SPVoid work12_1(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * aArg->size; i < size; i++)
	{
		(volatile SPFloat&) c[arg.id] = fa + fb;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName12_2 = "SPInt";
SPVoid work12_2(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPInt i = 0, size = COMPLEXITY * 0x100 * aArg->size; i < size; i++)
	{
		(volatile SPFloat&) c[arg.id] = fa + fb;
	}
}
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
const SPChar* testName13 = "shared variables";
const SPChar* testName13_1 = "read";
SPVoid work13_1(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	volatile SPFloat res = 0;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * aArg->size; i < size; i++)
	{
		res = fa + fa * fa;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName13_2 = "write";
SPVoid work13_2(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	volatile SPFloat res = 0;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * aArg->size; i < size; i++)
	{
		fa = res + res * res;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName13_3 = "read, write";
SPVoid work13_3(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * aArg->size; i < size; i++)
	{
		fa = fb + fb * fb;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName13_4 = "read copy";
SPVoid work13_4(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	volatile SPFloat res = 0;
	volatile SPFloat cp = fb;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * aArg->size; i < size; i++)
	{
		res = cp + cp * cp;
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName13_5 = "write once";
SPVoid work13_5(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	volatile SPFloat res = 0;
	volatile SPFloat res2 = 0;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * aArg->size; i < size; i++)
	{
		res2 = res + res * res;
	}
	fa = res2;
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName13_6 = "read copy, write once";
SPVoid work13_6(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	volatile SPFloat cp = fb;
	volatile SPFloat res2 = 0;
	for (SPUInt i = 0, size = COMPLEXITY * 0x100 * aArg->size; i < size; i++)
	{
		res2 = cp + cp * cp;
	}
	fa = res2;
}
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
const SPChar* testName14 = "SPTask*";

SPhysics::SPTaskPool pool14_1(1);
SPhysics::SPTaskPool pool14_2(2);
SPhysics::SPTaskPool pool14_3(3);
SPhysics::SPTaskPool pool14_4(4);
SPhysics::SPTaskPool pool14_8(8);
SPhysics::SPTaskPool pool14_16(16);
SPhysics::SPTaskPool pool14_32(32);
SPhysics::SPDynamicTaskQueue dynamicQueue14_4(4);
SPhysics::SPDynamicTaskQueue dynamicQueue14_8(8);
SPhysics::SPStaticTaskQueue staticQueue14_4(4);
SPhysics::SPStaticTaskQueue staticQueue14_8(8);
SPhysics::SPStaticTaskQueue staticQueue14_16(16);
SPhysics::SPStaticTaskQueue staticQueue14_32(32);
SPUInt argSize = 256;

/**
 * Class14
 */
class Class14
{
public:
	SPVoid work(SPUInt aSize)
	{
		volatile SPFloat la = 0;
		volatile SPFloat lb = 0;
		for (SPUInt i = 0, size = COMPLEXITY * aSize; i < size; i++)
		{
			la = lb + lb * lb;
		}
	}

	static SPVoid work2(SPUInt aSize)
	{
		volatile SPFloat la = 0;
		volatile SPFloat lb = 0;
		for (SPUInt i = 0, size = COMPLEXITY * aSize; i < size; i++)
		{
			la = lb + lb * lb;
		}
	}

	static SPVoid work3(SPUInt* aSize)
	{
		volatile SPFloat la = 0;
		volatile SPFloat lb = 0;
		for (SPUInt i = 0, size = COMPLEXITY * *aSize; i < size; i++)
		{
			la = lb + lb * lb;
		}
	}
} obj14;

typedef SPVoid (*wk)(SPUInt);	//!< wk

wk fnc14 = Class14::work2;

const SPChar* testName14_1 = "PC";
SPVoid work14_1(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;

	for (SPUInt i = 0, size = aArg->size; i < size; i++)
	{
		fnc14(argSize);
	}
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName14_2 = "pool [1]";
SPVoid work14_2(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;

	for (SPUInt i = 0, size = aArg->size; i < size; i++)
	{
		pool14_1.execute(obj14, &Class14::work, argSize);
	}

	pool14_1.waitAll();
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName14_3 = "pool [2]";
SPVoid work14_3(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;

	for (SPUInt i = 0, size = aArg->size; i < size; i++)
	{
		pool14_2.execute(obj14, &Class14::work, argSize);
	}

	pool14_2.waitAll();
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName14_4 = "pool [3]";
SPVoid work14_4(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;

	for (SPUInt i = 0, size = aArg->size; i < size; i++)
	{
		pool14_3.execute(obj14, &Class14::work, argSize);
	}

	pool14_3.waitAll();
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName14_5 = "pool [4]";
SPVoid work14_5(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;

	for (SPUInt i = 0, size = aArg->size; i < size; i++)
	{
		pool14_4.execute(obj14, &Class14::work, argSize);
	}

	pool14_4.waitAll();
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName14_6 = "pool [8]";
SPVoid work14_6(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;

	for (SPUInt i = 0, size = aArg->size; i < size; i++)
	{
		pool14_8.execute(obj14, &Class14::work, argSize);
	}

	pool14_8.waitAll();
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName14_7 = "pool [16]";
SPVoid work14_7(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;

	for (SPUInt i = 0, size = aArg->size; i < size; i++)
	{
		pool14_16.execute(obj14, &Class14::work, argSize);
	}

	pool14_16.waitAll();
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName14_8 = "pool [32]";
SPVoid work14_8(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;

	for (SPUInt i = 0, size = aArg->size; i < size; i++)
	{
		pool14_32.execute(obj14, &Class14::work, argSize);
	}

	pool14_32.waitAll();
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName14_9 = "dynamic queue [4]";
SPVoid work14_9(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;

	for (SPUInt i = 0, size = aArg->size; i < size; i++)
	{
		dynamicQueue14_4.addTask(obj14, &Class14::work, argSize);
	}

	dynamicQueue14_4.sync();
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName14_10 = "dynamic queue [8]";
SPVoid work14_10(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;

	for (SPUInt i = 0, size = aArg->size; i < size; i++)
	{
		dynamicQueue14_8.addTask(obj14, &Class14::work, argSize);
	}

	dynamicQueue14_8.sync();
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName14_11 = "static queue [4]";
SPVoid work14_11(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;

	for (SPUInt i = 0, size = aArg->size; i < size; i++)
	{
		staticQueue14_4.addTask(obj14, &Class14::work, argSize);
	}

	staticQueue14_4.sync();
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName14_12 = "static queue [8]";
SPVoid work14_12(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;

	for (SPUInt i = 0, size = aArg->size; i < size; i++)
	{
		staticQueue14_8.addTask(obj14, &Class14::work, argSize);
	}

	staticQueue14_8.sync();
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName14_13 = "static queue [16]";
SPVoid work14_13(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;

	for (SPUInt i = 0, size = aArg->size; i < size; i++)
	{
		staticQueue14_16.addTask(obj14, &Class14::work, argSize);
	}

	staticQueue14_16.sync();
}
//--------------------------------------------------------------------------------------------------
const SPChar* testName14_14 = "static queue [32]";
SPVoid work14_14(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;

	for (SPUInt i = 0, size = aArg->size; i < size; i++)
	{
		staticQueue14_32.addTask(obj14, &Class14::work, argSize);
	}

	staticQueue14_32.sync();
}
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
//==================================================================================================
const SPChar* testName15 = "random vs predef array";
const SPChar* testName15_1 = "rand()";
SPVoid work15_1(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = aArg->size; i < size; i++)
	{

		for (SPUInt y = 0; y < ARRAY_SIZE / 8; y++)
		{
			for (SPUInt x = 0; x < ARRAY_SIZE / 8; x++)
			{
				SPFloat rnd = SPFloat(rand() % (8192 + 1)) / SPFloat(8192);
				a[y * ARRAY_SIZE / 8 + x] += b[y * ARRAY_SIZE / 8 + x] + rnd;
			}
		}
	}
}
//--------------------------------------------------------------------------------------------------

/**
 * @brief RandomFloat15
 */
template<SPUInt aCapacity>
class RandomFloat15
{
public:

	inline RandomFloat15() :
			mNumber(0)
	{
		for (SPUInt i = 0; i < aCapacity; i++)
		{
			mValue[i] = SPFloat(rand() % (8192 + 1)) / SPFloat(8192);
		}
	}

	inline SPFloat get()
	{
		if (++mNumber == aCapacity)
		{
			mNumber = 0;
		}
		return mValue[mNumber];
	}

private:

	SPFloat mValue[aCapacity];
	SPUInt mNumber;
};

RandomFloat15<8192> rnd15;

const SPChar* testName15_2 = "array";
SPVoid work15_2(ThreadArgument* aArg)
{
	ThreadArgument arg = *aArg;
	for (SPUInt i = 0, size = aArg->size; i < size; i++)
	{

		for (SPUInt y = 0; y < ARRAY_SIZE / 8; y++)
		{
			for (SPUInt x = 0; x < ARRAY_SIZE / 8; x++)
			{
				SPFloat rnd = rnd15.get();
				a[y * ARRAY_SIZE / 8 + x] += b[y * ARRAY_SIZE / 8 + x] + rnd;
			}
		}
	}
}
//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------

SPVoid prof(SPVoid (*aFunc)(ThreadArgument*),
		  SPInt aMajorVersion,
		  SPInt aMinorVersion,
		  const SPChar* aMajorName,
		  const SPChar* aMinorName,
		  SPBool aIsParallel,
		  SPUInt aMinThread)
{
	SP_LOGE("Test: (%d.%d) %s: \"%s;\"", aMajorVersion, aMinorVersion, aMajorName, aMinorName);
	SPUInt minThread;
	SPUInt maxThread;
	if (aIsParallel)
	{
		minThread = aMinThread;
		maxThread = MAX_THREAD_COUNT;
	}
	else
	{
		minThread = maxThread = 1;
	}

	for (SPUInt threads = minThread; threads <= maxThread; threads++)
	{
		a = new SPInt[ARRAY_SIZE * ARRAY_SIZE];
		b = new SPInt[ARRAY_SIZE * ARRAY_SIZE];
		c = new SPFloat[ARRAY_SIZE];
		d = new SPFloat[ARRAY_SIZE];
		gArgs = new ThreadArgument[threads];
		for (SPInt i = 0; i < threads; i++)
		{
			gArgs[i].id = i;
			gArgs[i].size = 2 * 3 * 4 * 5 * 6 / threads;
		}
		SPhysics::ParallelCalculation pc(aFunc, gArgs, threads);
		SPUInt start = SPhysics::SPThread::getTickCount();
		for (SPInt i = 0; i < ITERATION_COUNT; i++)
		{
			pc.calculate();
		}
		SPUInt time = SPhysics::SPThread::getTickCount() - start;
		SP_LOGE("Threads: %d; Time: %d", threads, time);
		delete[] a;
		delete[] b;
		delete[] c;
		delete[] d;
		delete[] gArgs;
	}

}

#define PROF(MAJ, MIN)		prof(work##MAJ##_##MIN, MAJ, MIN, testName##MAJ, testName##MAJ##_##MIN, true,	MIN_THREAD_COUNT)	//!< Prof
#define PROF_NP(MAJ, MIN)	prof(work##MAJ##_##MIN, MAJ, MIN, testName##MAJ, testName##MAJ##_##MIN, false,	MIN_THREAD_COUNT)	//!< Prof NP
#define PROF_MT(MAJ, MIN)	prof(work##MAJ##_##MIN, MAJ, MIN, testName##MAJ, testName##MAJ##_##MIN, true,	MAX_THREAD_COUNT)	//!< Prof MT

SPVoid test()
{
	RUNTIME_VALUE_CHECK(MAX_THREAD_COUNT >= ARRAY_SIZE);

//	omp_set_dynamic(false);				// disallow dynamic changing of thread count
//	omp_set_nested(false);				// disallow separate threads for nested loops
//	omp_set_num_threads(4);
//
//	PROF_NP(1, 1);
//	PROF_NP(1, 2);
//	PROF_NP(1, 3);
//	PROF_NP(1, 4);
//	PROF_NP(1, 5);
//	PROF_NP(1, 6);
//	PROF_NP(1, 7);
//	PROF_NP(1, 8);
//	PROF_NP(1, 9);
//	PROF_NP(1, 10);
//	PROF_NP(1, 11);
//	PROF_NP(1, 12);
//	PROF_NP(1, 13);
//	PROF_NP(1, 14);
//	PROF_NP(1, 15);
//	PROF_NP(1, 16);
//	PROF_NP(1, 17);
//	PROF_NP(1, 18);
//	PROF_NP(1, 19);
//	PROF_NP(1, 20);
//	PROF_NP(2, 1);
//	PROF_NP(2, 2);
//	PROF_NP(2, 3);
//	PROF_NP(2, 4);
//	PROF_NP(2, 5);
//	PROF_NP(2, 6);
//	PROF_NP(2, 7);
//	PROF_NP(2, 8);
//	PROF_NP(2, 9);
//	PROF_NP(2, 10);
//	PROF_NP(2, 11);
//	PROF_NP(2, 12);
//	PROF_NP(2, 13);
//	PROF_NP(2, 14);
//	PROF_NP(2, 15);
//	PROF_NP(2, 16);
//	PROF_NP(2, 17);
//	PROF_NP(2, 18);
//	PROF_NP(2, 19);
//	PROF_NP(2, 20);
//	PROF_NP(3, 1);
//	PROF_NP(3, 2);
//	PROF_NP(3, 3);
//	PROF_NP(3, 4);
//	PROF_NP(3, 5);
//	PROF_NP(3, 6);
//	PROF_NP(3, 7);
//	PROF_NP(3, 8);
//	PROF_NP(3, 9);
//	PROF_NP(3, 10);
//	PROF_NP(3, 11);
//	PROF_NP(3, 12);
//	PROF_NP(3, 13);
//	PROF_NP(3, 14);
//	PROF_NP(3, 15);
//	PROF_NP(3, 16);
//	PROF_NP(3, 17);
//	PROF_NP(3, 18);
//	PROF_NP(3, 19);
//	PROF_NP(3, 20);
//
//	PROF(4, 1);
//	PROF(4, 2);
//	PROF(4, 3);
//	PROF(4, 4);
//
//	PROF(5, 1);
//	PROF(5, 2);
//
//	PROF(6, 1);
//	PROF(6, 2);
//	PROF(6, 3);
//	PROF(6, 4);
//	PROF(6, 5);
//	PROF(6, 6);
//	PROF(6, 7);
//	PROF(6, 8);
//	PROF(6, 9);
//	PROF(6, 10);
//	PROF(6, 11);
//	PROF(6, 12);
//	PROF(6, 13);
//	PROF(6, 14);
//
//	PROF(7, 1);
//	PROF(7, 2);
//
//	PROF(8, 1);
//	PROF(8, 2);
//	PROF(8, 3);
//	PROF(8, 4);
//	PROF(8, 5);
//	PROF(8, 6);
//	PROF(8, 7);
//	PROF(8, 8);
//
//#ifdef __ARM_NEON__
//	PROF(9, 1);
//	PROF(9, 2);
//	PROF(9, 3);
//#endif
//
//	PROF_NP(10, 1);
//	PROF_NP(10, 2);
//
//	PROF(11, 1);
//	PROF_NP(11, 2);
//
//	PROF_NP(12, 1);
//	PROF_NP(12, 2);
//
//	PROF(13, 1);
//	PROF(13, 2);
//	PROF(13, 3);
//	PROF(13, 4);
//	PROF(13, 5);
//	PROF(13, 6);

//	PROF(14, 1);
//	PROF_NP(14, 2);
//	PROF_NP(14, 2);
//	PROF_NP(14, 3);
//	PROF_NP(14, 3);
//	PROF_NP(14, 4);
//	PROF_NP(14, 4);
//	PROF_NP(14, 5);
//	PROF_NP(14, 5);
//	PROF_NP(14, 6);
//	PROF_NP(14, 6);
//	PROF_NP(14, 7);
//	PROF_NP(14, 7);
//	PROF_NP(14, 8);
//	PROF_NP(14, 8);
//	PROF_NP(14, 9);
//	PROF_NP(14, 9);
//	PROF_NP(14, 10);
//	PROF_NP(14, 10);
//	PROF_NP(14, 11);
//	PROF_NP(14, 11);
//	PROF_NP(14, 12);
//	PROF_NP(14, 12);
//	PROF_NP(14, 13);
//	PROF_NP(14, 13);
//	PROF_NP(14, 14);
//	PROF_NP(14, 14);
//	PROF_MT(14, 1);

	PROF_NP(15, 1);
	PROF_NP(15, 1);
	PROF_NP(15, 2);
	PROF_NP(15, 2);
}

#endif // DOXYGEN_SKIP

#endif /* _SP_PERFORMANCETEST_H_ */
