/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPTask.h
 * @brief  File SPTask
 * @author Author Arthur Yusupov (a.yusupov@samsung.com)
 */

#ifndef _SP_TASK_H_
#define _SP_TASK_H_

#include "SPThread.h"
#include "SPEvent.h"
#include "SPRunnable.h"

namespace SPhysics
{

class SPTaskPool;

/**
 * @class SPTask
 * @brief Task
 */
class SPTask: NonCopyable
{

public:

	friend class SPTaskPool;

	/**
	 * Constructor.
	 */
	inline SPTask();

	/**
	 * Destructor.
	 */
	inline ~SPTask();

	/**
	 * @brief Start SPTask.
	 * Invoke 'aFunction' of 'mObject' with 'aArgument' in separated thread.
	 *
	 * @param aObject Object.
	 * @param aFunction Function of 'aObject'.
	 * @param aArgument Argument for 'aFunction'.
	 * @param aIsAutoRelease Indicate is SPTask return to SPTaskPool after ending of 'aFunction'.
	 */
	template<typename ClassType, typename FunctionArgumentType>
	inline void start(ClassType& aObject, void (ClassType::*aFunction)(FunctionArgumentType),
					  FunctionArgumentType& aArgument, const bool aIsAutoRelease = true);

	/**
	 * Determine is SPTask active.
	 *
	 * @return true if SPTask is active, otherwise false.
	 */
	inline bool isActive();

	/**
	 * Wait until SPTask is active.
	 */
	inline void wait();

	/**
	 * @brief Release SPTask, ant mark as free to 'ThreadPool'.
	 * Only inactive SPTask can be released.
	 */
	inline void release();

private:

	/**
	 * Determine is SPTask busy.
	 *
	 * @return true if SPTask is busy, otherwise false.
	 */
	inline bool isBusy();

	/**
	 * Set SPTask state as busy for SPTask pool.
	 */
	inline void setBusy();

	/**
	 * Work function that invoked in new thread.
	 *
	 * @param aTask Pointer to 'this'.
	 */
	inline static void* work(SPTask* aTask);

	SPEvent mStartEvent; /**<Start event.*/
	SPEvent mEndEvent; /**<End event.*/
	SPEvent* mSelectEvent; /**< SPTask pools select event.*/
	SPCriticalSection mCriticalSection;
	SPThread mThread; /**<SPThread.*/
	SPRunnable mRunnable; /**<*/
	volatile bool mIsNotTerminated; /**<Is SPTask not terminated*/
	volatile bool mIsAutoRelease; /**<Is SPTask auto release after work.*/
	volatile bool mIsActive; /**<Is SPTask active.*/
	volatile bool mIsBusy; /**<Is SPTask busy.*/
};

} /* namespace SPhysics */

#include "SPTask.inl"

#endif /* _SP_TASK_H_ */

