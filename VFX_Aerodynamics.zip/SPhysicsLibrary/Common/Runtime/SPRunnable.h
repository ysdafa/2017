/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPRunnable.h
 * @brief  File SPRunnable
 * @author Author Arthur Yusupov (a.yusupov@samsung.com)
 */

#ifndef _SP_RUNNABLE_H_
#define _SP_RUNNABLE_H_

namespace SPhysics
{

/**
 * @class SPRunnable
 * @brief Runnable
 */
class SPRunnable
{
public:

	/**
	 * Constructor.
	 */
	inline SPRunnable();

	/**
	 * Initialize.
	 *
	 * @param aObject Object
	 * @param aFunction Function of 'aObject'.
	 * @param aArgument Argument for 'aFunction'.
	 */
	template<typename ClassType, typename FunctionArgumentType>
	inline void init(ClassType& aObject, void (ClassType::*aFunction)(FunctionArgumentType),
					 FunctionArgumentType& aArgument);

	/**
	 * Initialize.
	 *
	 * @param aObject Object
	 * @param aFunction Function of 'aObject'.
	 */
	template<typename ClassType>
	inline void init(ClassType& aObject, void (ClassType::*aFunction)());

	/**
	 * Execute user function.
	 */
	inline void run();

private:

	typedef void (*UserFunction)(SPRunnable* aThis);

	struct Function
	{
		Function()
		{
			for (unsigned int i = 0; i < sizeof(aData) / sizeof(void*); ++i)
			{
				aData[i] = NULL;
			}
		}

		void* aData[8];
	};

	template<typename ClassType, typename FunctionArgumentType = int>
	class SPJobMaker
	{
	private:

		friend class SPRunnable;

		/**
		 * @brief Just do nothing.
		 * This method is needed for generating template class.
		 */
		inline static void nop();

		/**
		 * User function executer.
		 * @param aThis Pointer to 'this'.
		 */
		inline static void make(SPRunnable* aThis);

		/**
		 * User function executer.
		 * @param aThis Pointer to 'this'.
		 */
		inline static void makeNoArg(SPRunnable* aThis);
	};

	void* mObject; /**<Object*/
	void* mArgument; /**<Argument for 'mFunction'*/
	Function mFunction; /**<Function of 'mObject'*/
	UserFunction mUserFunction; /**<User function*/
};

} /* namespace SPhysics */

#include "SPRunnable.inl"

#endif /* _SP_RUNNABLE_H_ */

