/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPParallelCalculation.h
 * @brief  Parallel Calculation
 * @author Arthur Yusupov (a.yusupov@samsung.com)
 */

#ifndef _SP_PARALLELCALCULATION_H_
#define _SP_PARALLELCALCULATION_H_

#include "SPEvent.h"

#include <vector>

namespace SPhysics
{

class SPThread;

/**
 * Parallel calculation
 */
class SPParallelCalculation: NonCopyable
{
public:

	typedef void (*ThreadFunction)(void*); //!< Pointer to function

	/**
	 * @brief Constructor.
	 * @tparam aFunction Function that will be called in new threads.
	 * @param aArgument Array of arguments that will be passed to 'aFunction'.
	 * @param aThreadCount Count of thread to parallel. (size of 'aArgument' array).
	 */
	template<typename FunctionArgumentType>
	inline SPParallelCalculation(void (aFunction)(FunctionArgumentType), FunctionArgumentType const aArgument,
							   unsigned int aThreadCount);

	/**
	 * Destructor.
	 */
	inline ~SPParallelCalculation();

	/**
	 * @brief Perform calculation.
	 * Invoke 'user function' in separated threads with one of argument.
	 */
	inline void calculate();

	/**
	 * @brief Change user function.
	 * @tparam aFunction Function that will be called in new threads.
	 * @param aArgument Array of arguments that will be passed to 'aFunction'.
	 */
	template<typename FunctionArgumentType>
	inline void changeFunction(void (aFunction)(FunctionArgumentType), FunctionArgumentType const aArgument);

private:

	/**
	 * Function agrument.
	 */
	template<typename FunctionArgumentType>
	struct SPCalculateFunctionArgument
	{
		SPParallelCalculation* mCalculator; /**<Instance of 'ParallelCalculation' that called this function*/
		FunctionArgumentType mArgument; /**<Agrument that will passed to 'user function'.*/
	};

	/**
	 * Function that will be called in new thread, and will manage calculation starting.
	 * @param aArgument Function argument.
	 */
	template<typename FunctionArgumentType>
	inline static void* calculateFunction(SPCalculateFunctionArgument<FunctionArgumentType>* aArgument);

	std::vector<SPThread*> mThreads; /**<Array of threads*/
	std::vector<SPCalculateFunctionArgument<void*> > mArguments; /**<Array of argument*/
	unsigned int mLocalStartEventIndex; /**<Index of start event. Value range: 0 ~ 1.*/
	SPEvent mStartEvent[2]; /**<Array of SPEvent that indicate start of calculations for one of threads.*/
	SPEvent mEndEvent; /**<SPEvent that indicate end of calculations in all threads.*/
	SPCriticalSection mCriticalSection; /**<Critical section.*/
	ThreadFunction mFunction; /**<User function that will invoked in separated thread.*/
	void* mSelfArgument; /**Argument that will passed to function called in current thread.*/
	bool mIsTerminated; /**< Indicate is calculation was terminated.*/
	unsigned int mIncompleteTasks; /**<Count of incomplete tasks.*/

};

} /* namespace SPhysics */

#include "SPParallelCalculation.inl"

#endif /* _SP_PARALLELCALCULATION_H_ */
