/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPEvent.h
 * @brief  File SPEvent
 * @author Author Arthur Yusupov (a.yusupov@samsung.com)
 */

#ifndef _SP_EVENT_H_
#define _SP_EVENT_H_

#include "SPCriticalSection.h"

namespace SPhysics
{

/**
 * SPEvent.
 * For suspending thread and waiting signal for resume.
 */
class SPEvent: protected SPCriticalSection
{

public:

	/**
	 * Constructor.
	 */
	inline SPEvent();

	/**
	 * Destructor.
	 */
	inline ~SPEvent();

	/**
	 * Suspend current thread, and wait for 'signal' from another thread.
	 */
	inline void wait();

	/**
	 * Determine is event locked.
	 *
	 * @return true if event locked, otherwise false.
	 */
	inline bool isLocked() const;

	/**
	 * Resume suspended thread.
	 */
	inline void signal();

	/**
	 * Resume all suspended threads.
	 */
	inline void broadcast(const unsigned int aCount);

	/**
	 * Reset event counter.
	 */
	inline void reset();

private:

	pthread_cond_t mCondition; /**< Condition variable for suspending and resuming thread.*/
	int mCount; /**<Counf of signals*/
};

} /* namespace SPhysics */

#include "SPEvent.inl"

#endif /* _SP_EVENT_H_ */
