/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPStaticTaskQueue.h
 * @brief  File Static task Queue
 * @author Author Arthur Yusupov (a.yusupov@samsung.com)
 */

#ifndef _SP_STATICTASKQUEUE_H_
#define _SP_STATICTASKQUEUE_H_

#include "SPEvent.h"
#include "SPRunnable.h"

#include <vector>

namespace SPhysics
{

class SPThread;

/**
 * @class SPStaticTaskQueue
 * @brief Static task queue
 */
class SPStaticTaskQueue: NonCopyable
{

public:

	/**
	 * Constructor.
	 */
	inline SPStaticTaskQueue(unsigned int aThreadCount);

	/**
	 * Destructor.
	 */
	inline ~SPStaticTaskQueue();

	/**
	 * @brief Execute 'ClassType' 'aObject' method ('aFunction') with given argument ('aArgument').
	 * If all tasks is busy, then method will be executed in current thread.
	 * @param aObject Object.
	 * @param aFunction Function of 'aObject'.
	 * @param aArgument Argument that passed to 'aFunction'.
	 */
	template<typename ClassType, typename FunctionArgumentType>
	inline void addTask(ClassType& aObject, void (ClassType::*aFunction)(FunctionArgumentType),
						FunctionArgumentType& aArgument);

	/**
	 * @brief Execute 'ClassType' 'aObject' method ('aFunction') with given argument ('aArgument').
	 * If all tasks is busy, then method will be executed in current thread.
	 * @param aObject Object.
	 * @param aFunction Function of 'aObject'.
	 */
	template<typename ClassType>
	inline void addTask(ClassType& aObject, void (ClassType::*aFunction)());

	/**
	 * Wait till the end of all tasks.
	 */
	inline void sync();

private:

	struct SPArgument
	{
		SPStaticTaskQueue* mThis;
		std::vector<SPRunnable>* mQueue;
	};

	/**
	 * Work function that invoked in new thread.
	 *
	 * @param aArg work function argument.
	 */
	inline static void* work(SPArgument* aArg);

	/**
	 * Make all assigned jobs.
	 * @param aQueue Queue of all assigned jobs.
	 */
	inline void makeAllJobs(std::vector<SPRunnable>& aQueue);

	std::vector<SPThread*> mThreads; /**< SPTask list.*/
	std::vector<SPArgument> mArguments; /**< SPTask list.*/
	std::vector<std::vector<SPRunnable> > mQueue;
	SPCriticalSection mCriticalSection;
	SPEvent mStartEvent[2]; /**<Array of SPEvent that indicate start of calculations for one of threads.*/
	SPEvent mEndEvent; /**<End event.*/
	unsigned int mLocalStartEventIndex; /**< Index of start ecent. Value range: 0 ~ 1.*/
	unsigned int mIncompleteTasks; /**<Count of incomplete tasks.*/
	volatile bool mIsNotTerminated; /**<Indicate is threads not terminated.*/
	unsigned int mCurrentTask; /**<Current task.*/
};

} /* namespace SPhysics */

#include "SPStaticTaskQueue.inl"

#endif /* _SP_STATICTASKQUEUE_H_ */

