/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPNonCopyable.h
 * @brief  File NonCopyable
 * @author Author (a.yusupov@samsung.com)
 */

#ifndef _NONCOPYABLE_H_
#define _NONCOPYABLE_H_

namespace SPhysics
{

/**
 *  Object to disable copy and assignment.
 */
class NonCopyable
{
public:

	/**
	 * Constructor.
	 */
	NonCopyable()
	{
	}

	/**
	 * Destructor.
	 */
	~NonCopyable()
	{
	}

private:

	/**
	 * Copy constructor.
	 *
	 * @param aNonCopyable Object to copy.
	 */
	NonCopyable(const NonCopyable& aNonCopyable);

	/**
	 * Assignment operator
	 *
	 * @param aNonCopyable Object to assignment.
	 * @return this object.
	 */
	NonCopyable& operator=(const NonCopyable& aNonCopyable);

};

} /* namespace SPhysics */

#endif /* _NONCOPYABLE_H_ */

