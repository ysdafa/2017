/**
* @file SPFile.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.

*/
#ifndef _SP_FILE_H_
#define _SP_FILE_H_

#include "SPDefines.h"

#include <fcntl.h>
#include <direct.h>
#include <fstream>

namespace SPhysics
{

	/**
	* @brief     Check whether a file exits
	* @param     [IN] @b  input file path 
	* @return     SPBool
	*/
	inline SPBool isFileExists( const std::string& input )
	{
		return std::ifstream( input.c_str() )!=0;
	}

	/**
	* @brief     Create the directory
	* @param     [IN] @b  path file path
	* @return     SPBool
	*/
	inline SPBool createDirectory( const std::string& path )
	{
		if( _mkdir( path.c_str() ) ) {
			perror( "createDirectory(): error!" );
			return SPFALSE;
		}
		return SPTRUE;
	}

}
#endif //_SP_FILE_H_
