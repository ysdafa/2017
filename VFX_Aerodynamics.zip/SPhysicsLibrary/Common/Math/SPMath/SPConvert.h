/**
* @file SPConvert.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_CONVERT_H_
#define _SP_CONVERT_H_

#include "SPConstant.h"

namespace SPhysics
{

	/**
	* @brief     Convert degrees to the radians
	* @param     [IN] @b  x input radian 
	* @return    T
	 */
	template <typename T>
	inline T radian( const T& x )
	{
		return x*(T)DEGREE_TO_RADIAN;
	}

	/**
	* @brief     Convert degrees to the radians
	* @param     [IN] @b  x input degree
	* @return    T
	 */
	template <typename T>
	inline T degree( const T& x )
	{
		return x*(T)RADIAN_TO_DEGREE;
	}
}
#endif //_SP_CONVERT_H_

