/**
* @file SPCurl.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_CURL_H_
#define _SP_CURL_H_

#include "SPDefines.h"

#include "SPScalarField2D.h"
#include "SPVectorField2D.h"

/**
 * @brief Compute curl
 */
SPVoid computeCurl( SPField2DTemplate<SPVec2d >& curl, SPField2DTemplate<SPDouble>& scalar ) 
{

}

/**
 * @brief Compute curl
 */
SPVoid computeCurl( SPField2DTemplate<SPDouble>& curl, SPField2DTemplate<SPVec2d ><SPDouble>& vector ) 
{
}

#endif //_SP_CURL_H_