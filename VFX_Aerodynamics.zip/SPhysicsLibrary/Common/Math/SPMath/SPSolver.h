/**
* @file SPSolver.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_SOLVER_H_
#define _SP_SOLVER_H_

#include "SPDefines.h"

namespace SPhysics
{

	/**
	* @brief     =determinantMatrix(A|B|C) , The volume of the parallelepiped spanned by three indepenrhot vectors
	* @param     [IN] @b  A vector1
	* @param     [IN] @b  B vector2
	* @param     [IN] @b  C vector3
	* @return     T
	*/
	template <typename T>
	inline T determinantMatrix( const SPVec3t& A, const SPVec3t& B, const SPVec3t& C )
	{
		return ( A.x*(B.y*C.z-C.y*B.z )
			   - B.x*(A.y*C.z-C.y*A.z )
			   + C.x*(A.y*B.z-B.y*A.z ) );
	}

	/**
	* @brief     |A|
	* @param     [IN] @b  matrix2x2 which user want to calculate.
	* @return     T
	*/
	template <typename T>
	inline T determinantMatrix( const SPMat2x2t& A )
	{
		return ( A._00*A._11 - A._01*A._10 );
	}

	/**
	* @brief     |A|
	* @param     [IN] @b  A matrix3x3 which user want to calculate determinant.
	* @return     T
	*/
	template <typename T>
	inline T determinantMatrix( const SPMat3x3t& A )
	{
		return ( A._00*( A._11*A._22 - A._12*A._21 )
			   - A._01*( A._10*A._22 - A._12*A._20 )
			   + A._02*( A._10*A._21 - A._11*A._20 ) );
	}

	/**
	* @brief     |A|
	* @param     [IN] @b  A A matrix4x4 which user want to calculate determinant.
	* @return     T
	*/
	template <typename T>
	inline T determinantMatrix( const SPMat4x4t& A )
	{
		return ( A._00*(A._11*(A._22*A._33-A._23*A._32)
				- A._12*(A._21*A._33-A._23*A._31)
				+ A._13*(A._21*A._32-A._22*A._31) )
				- A._01*(A._10*(A._22*A._33-A._23*A._32)
				- A._12*(A._20*A._33-A._23*A._30)
				+ A._13*(A._20*A._32-A._22*A._30) )
				+ A._02*(A._10*(A._21*A._33-A._23*A._32)
				- A._11*(A._20*A._33-A._23*A._30)
				+ A._13*(A._20*A._32-A._21*A._30) )
				- A._03*(A._10*(A._21*A._32-A._22*A._31)
				- A._11*(A._20*A._32-A._22*A._30)
				+ A._12*(A._20*A._31-A._21*A._30) ) );
	}

	/**
	* @brief     Calculate inverse of Matrix2X2 'A'
	* @param     [OUT] @b  Inverse matrix 
	* @param     [IN] @b  source matrix
	* @return     T
	*/
	template <typename T>
	inline T inverseMatrix( SPMat2x2t& Inv, const SPMat2x2t& A )
	{
		T det = determinantMatrix(A);
		if( isAlmostZero(det) ) { // if not exists
			ZERO(Inv);
			return 0;
		}

		Inv._00= A._11/det;
		Inv._01=-A._01/det;

		Inv._10=-A._10/det;
		Inv._11= A._00/det;

		return det;
	}

	/**
	* @brief     Calculate inverse of Matrix3X3 'A'
	* @param     [OUT] @b  Inverse matrix
	* @param     [IN] @b  A source matrix
	* @return     T
	*/
	template <typename T>
	inline T inverseMatrix( SPMat3x3t& Inv, const SPMat3x3t& A )
	{
		T det = determinantMatrix(A);
		if( isAlmostZero(det) ) { // if not exists
			ZERO(Inv);
			return 0;
		}

		Inv._00=( A._11*A._22-A._12*A._21)/det;
		Inv._01=(-A._01*A._22+A._02*A._21)/det;
		Inv._02=( A._01*A._12-A._02*A._11)/det;

		Inv._10=(-A._10*A._22+A._12*A._20)/det;
		Inv._11=( A._00*A._22-A._02*A._20)/det;
		Inv._12=(-A._00*A._12+A._02*A._10)/det;

		Inv._20=( A._10*A._21-A._11*A._20)/det;
		Inv._21=(-A._00*A._21+A._01*A._20)/det;
		Inv._22=( A._00*A._11-A._01*A._10)/det;

		return det;
	}

	/**
	* @brief     Calculate inverse of Matrix4X4 'A'
	* @param     [OUT] @b  inverse matrix
	* @param     [IN] @b  A source matrix
	* @return     T
	*/
	template <typename T>
	inline T inverseMatrix( SPMat4x4t& Inv, const SPMat4x4t& A )
	{
		T det = determinantMatrix(A);
		if( isAlmostZero(det) ) { // if not exists
			ZERO(Inv);
			return 0;
		}

		Inv._00= (A._11*(A._22*A._33-A._23*A._32)
					-A._12*(A._21*A._33-A._23*A._31)
					+A._13*(A._21*A._32-A._22*A._31))/det;
		Inv._01=-(A._01*(A._22*A._33-A._23*A._32)
					-A._02*(A._21*A._33-A._23*A._31)
					+A._03*(A._21*A._32-A._22*A._31))/det;
		Inv._02= (A._01*(A._12*A._33-A._13*A._32)
					-A._02*(A._11*A._33-A._13*A._31)
					+A._03*(A._11*A._32-A._12*A._31))/det;
		Inv._03=-(A._01*(A._12*A._23-A._13*A._22)
					-A._02*(A._11*A._23-A._13*A._21)
						+A._03*(A._11*A._22-A._12*A._21))/det;

		Inv._10=-(A._10*(A._22*A._33-A._23*A._32)
					-A._12*(A._20*A._33-A._23*A._30)
					+A._13*(A._20*A._32-A._22*A._30))/det;
		Inv._11= (A._00*(A._22*A._33-A._23*A._32)
					-A._02*(A._20*A._33-A._23*A._30)
					+A._03*(A._20*A._32-A._22*A._30))/det;
		Inv._12=-(A._00*(A._12*A._33-A._13*A._32)
					-A._02*(A._10*A._33-A._13*A._30)
					+A._03*(A._10*A._32-A._12*A._30))/det;
		Inv._13= (A._00*(A._12*A._23-A._13*A._22)
					-A._02*(A._10*A._23-A._13*A._20)
					+A._03*(A._10*A._22-A._12*A._20))/det;

		Inv._20= (A._10*(A._21*A._33-A._23*A._31)
					-A._11*(A._20*A._33-A._23*A._30)
					+A._13*(A._20*A._31-A._21*A._30))/det;
		Inv._21=-(A._00*(A._21*A._33-A._23*A._31)
					-A._01*(A._20*A._33-A._23*A._30)
					+A._03*(A._20*A._31-A._21*A._30))/det;
		Inv._22= (A._00*(A._11*A._33-A._13*A._31)
					-A._01*(A._10*A._33-A._13*A._30)
					+A._03*(A._10*A._31-A._11*A._30))/det;
		Inv._23=-(A._00*(A._11*A._23-A._13*A._21)
					-A._01*(A._10*A._23-A._13*A._20)
					+A._03*(A._10*A._21-A._11*A._20))/det;

		Inv._30=-(A._10*(A._21*A._32-A._22*A._31)
					-A._11*(A._20*A._32-A._22*A._30)
					+A._12*(A._20*A._31-A._21*A._30))/det;
		Inv._31= (A._00*(A._21*A._32-A._22*A._31)
					-A._01*(A._20*A._32-A._22*A._30)
					+A._02*(A._20*A._31-A._21*A._30))/det;
		Inv._32=-(A._00*(A._11*A._32-A._12*A._31)
					-A._01*(A._10*A._32-A._12*A._30)
					+A._02*(A._10*A._31-A._11*A._30))/det;
		Inv._33= (A._00*(A._11*A._22-A._12*A._21)
					-A._01*(A._10*A._22-A._12*A._20)
					+A._02*(A._10*A._21-A._11*A._20))/det;

		return det;
	}

	/**
	* @brief     linear system solver , Ax=b: x=(A^-1)b
	* @param     [OUT] @b  x output vector
	* @param     [IN] @b  A source matrix 1
	* @param     [IN] @b  b source vector 2
	* @return     T
	*/
	template <typename T>
	inline T solveLinearSystem( SPVec2t& x, const SPMat2x2t& A, const SPVec2t& b )
	{
		T d = A._00*A._11-A._01*A._10;
		if( isAlmostZero(d) ) { x.x=x.y=0; return d; }
		x.x = (A._11*b.x-A._01*b.y)/d;
		x.y = (A._00*b.y-A._10*b.x)/d;
		return d;
	}

	/**
	* @brief     linear system solver , Ax=b: x=(A^-1)b
	* @param     [OUT] @b  x output vector
	* @param     [IN] @b  A source matrix
	* @param     [IN] @b  b source vector
	* @return     T
	*/
	template <typename T>
	inline T solveLinearSystem( SPVec3t& x, const SPMat3x3t& A, const SPVec3t& b )
	{
		SPMat3x3t Ainv;
		T det = inverseMatrix( Ainv, A );
		if( isAlmostZero(det) ) { ZERO(x); return det; }
		multiply( x, Ainv, b );
		return det;
	}

	/**
	* @brief     linear system solver , Ax=b: x=(A^-1)b
	* @param     [OUT] @b  x  output vector
	* @param     [IN] @b  A source matrix
	* @param     [IN] @b  b source vector
	* @return     T
	*/
	template <typename T>
	inline T solveLinearSystem( SPVec4t& x, const SPMat4x4t& A, const SPVec4t& b )
	{
		SPMat4x4t Ainv;
		T det = inverseMatrix( Ainv, A );
		if( isAlmostZero(det) ) { ZERO(x); return det; }
		multiply( x, Ainv, b );
		return det;
	}


	/**
	* @brief     Solve the Quadratic system solver , (a*a)*x^2 + (b)*x + (c) = 0
	* @param     [IN] @b  a
	* @param     [IN] @b  b
	* @param     [IN] @b  c
	* @param     [IN] @b  [2] x
	* @return     SPBool
	*/
	template <typename T>
	inline SPBool solveQuadratic( const T a, const T b, const T c, T x[2] ) // (a*a)*x^2 + (b)*x + (c) = 0
	{
		T deter = b*b - 4*a*c;

		if( deter < 0 ) {

			return SPFALSE;

		} else if( deter < EPSILON ) {

			x[0] = x[1] = -b / (2*a);
			return SPTRUE;

		}

		T denom = 1 / ( 2*a );
		T sq = (T)sqrt( deter );

		x[0] = ( -b - sq ) * denom;
		x[1] = ( -b + sq ) * denom;

		return SPTRUE;
	}

	/**
	* @brief     Solve the Even Quadratic system , (a*a)*x^2 + (2*b)*x + (c) = 0
	* @param     [IN] @b  a parameter
	* @param     [IN] @b  b parameter
	* @param     [IN] @b  c parameter
	* @param     [INOUT] @b  [2] x output
	* @return     SPBool
	*/
	template <typename T>
	inline SPBool solveQuadraticEven( const T a, const T b, const T c, T x[2] ) // (a*a)*x^2 + (2*b)*x + (c) = 0
	{
		T deter = b*b - a*c;

		if( deter < 0 ) {

			return SPFALSE;

		} else if( deter < EPSILON ) {

			x[0] = x[1] = -b / a;
			return SPTRUE;

		}

		T sq = (T)sqrt( deter );

		x[0] = ( -b - sq ) / a;
		x[1] = ( -b + sq ) / a;

		return SPTRUE;
	}

}

#endif //_SP_SOLVER_H_

