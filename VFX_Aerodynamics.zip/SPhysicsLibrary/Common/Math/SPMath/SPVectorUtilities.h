/**
* @file SPMatrix2x2.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_VECTOR_UTILITIES_H_
#define _SP_VECTOR_UTILITIES_H_

#include "SPDefines.h"
#include <glm.hpp>

namespace SPhysics
{
	/**
	* @class SPMatrixUtilities
	* @brief utilities for matrix
	*/
	template <typename T>
	class SPVectorUtilities
	{
	public:

		/**
		* @brief     Return the Dot Product of perpendicular
		* @param     [IN] @b A perpendicular dot product vector 2D value 1
		* @param     [IN] @b B perpendicular dot product vector 2D value 2
		* @return    T
		*/
		static T perpendicularDot( const SPVec2t& A, const SPVec2t& B )
		{
			return ( A.x*B.y - A.y*B.x );
		}

		/**
		* @brief     Return the Perpendicular Vector
		* @param     [IN] @b A Perpendicular vector 2D value 1
		* @param     [IN] @b B Perpendicular T value 2
		* @return     Perpendicular Vector
		*/
		static SPVec2t perpendicularVector( const SPVec2t& A, const T& B )
		{
			return SPVec2t(B * A.y, -B * A.x);
		}

		/**
		* @brief     Return the Perpendicular Vector
		* @param     [IN] @b A perpendicularVector T value 1
		* @param     [IN] @b B A Perpendicular vector 2D value 2
		* @return     Perpendicular Vector
		*/
		static SPVec2t perpendicularVector(const T& A, const SPVec2t& B)
		{
			return SPVec2t(-A * B.y, A * B.x);
		}
	};// class
}

#endif //_SP_MATRIX_UTILITIES_H_

