/**
* @file SPIntersection.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_INTERSECTION_H_
#define _SP_INTERSECTION_H_

#include "SPDefines.h"

namespace SPhysics
{
	/**
	* @brief     check the intersect of line and plane 
	* @param     P of line PQ
	* @param     Q of line PQ
	* @param     O of plane: one point(O), normal(N)
	* @param     N of plane: one point(O), normal(N)
	* @param     result: intersection point
	* @param     [IN] @b  epsilon tolerance (=accuracy)
	* @return     SPBool
	*/
	template <typename T>
	inline SPBool intersectLinePlane( SPVec3t& P, SPVec3t& Q,
									SPVec3t& O, SPVec3t& N,
									SPVec3t& X,					 
									const T& epsilon )					
	{
		SPVec3t OP;   SUB( OP, P, O );
		SPVec3t OQ;   SUB( OP, Q, O );

		T d0 = DOT( OP, N );
		T d1 = DOT( OQ, N );

		// if both are in the same side
		if( d0 < -epsilon ) { ZERO(X); return SPFALSE; }
		if( d1 < -epsilon ) { ZERO(X); return SPFALSE; }
		if( d0 >  epsilon ) { ZERO(X); return SPFALSE; }
		if( d1 >  epsilon ) { ZERO(X); return SPFALSE; }

		// if either is enough near
		if( isAlmostSame( d0, epsilon ) ) { CPY(X,P); return SPTRUE; }
		if( isAlmostSame( d1, epsilon ) ) { CPY(X,Q); return SPTRUE; }

		T denom = (T)1 / ( d1 - d0 );

		X.x = ( d1*P.x - d0*Q.x ) * denom;
		X.y = ( d1*P.y - d0*Q.y ) * denom;
		X.z = ( d1*P.z - d0*Q.z ) * denom;

		return SPTRUE;
	}

	/**
	* @brief     Check whether point exist inside Triangle
	* @param     test point P
	* @param     A of triangle ABC
	* @param     B of triangle ABC
	* @param     C of triangle ABC
	* @param     [IN] @b  0 ~ 1 tolerance
	* @return     SPBool
	*/
	template <typename T>
	inline SPBool InsidePointTriangle( SPVec2t& P,									 
									 SPVec2t& A, SPVec2t& B, SPVec2t& C, 
									 const T& tolerance )
	{
		T ABC = AREA(A,B,C);

		T ratio = ABS( (T)1 - ( AREA(P,A,B) + AREA(P,B,C) + AREA(P,C,A) ) / ABC );

		if( ratio < tolerance ) { return SPTRUE; }

		return SPFALSE;
	}

	/**
	* @brief     check the intersect of line and triangle 
	Caution) dir must be unit vector
	Solve AO + t*dir = a*AB + b*AC

	* @param     O : a ray (a point & direction)
	* @param     dir : a ray (a point & direction)
	* @param     A of a triangle ABC
	* @param     B of a triangle ABC
	* @param     C of a triangle ABC
	* @param     uvw  : two return values (barycentric coordinate, ratio on the ray)
	* @param     t : two return values (barycentric coordinate, ratio on the ray)
	* @return     SPBool
	*/
	template <typename T>
	inline SPBool intersectLineTriangle( SPVec3t& O, SPVec3t& dir,		
									   SPVec3t& A, SPVec3t& B, SPVec3t& C,
									   T uvw[0], T& t )
	{
		// compute the offset origin, edges, and normal
		SPVec3t AO;   SUB( AO, O, A );
		SPVec3t AB;   SUB( AB, B, A );
		SPVec3t AC;   SUB( AC, C, A );
		SPVec3t N;    CROSS( N, AB, AC );

		T dist = DOT( dir, N );
		T sign;

		if( dist > EPSILON ) {

			sign = 1;

		} else if( dist < -EPSILON ) {

			sign = -1;
			dist = -dist;

		} else { // no intersection: ray and triangle are parallel

			return SPFALSE;

		}

		SPVec3t AO_AC;   CROSS( AO_AC, AO, AC );
		T alpha = sign * DOT( dir, AO_AC );

		if( alpha >= 0 ) {

			SPVec3t AB_AO;   CROSS( AB_AO, AB, AO );
			T beta = sign * DOT( dir, AB_AO );

			if( beta >= 0 ) {

				if( alpha + beta <= dist ) {

					// line intersects triangle, check if ray does
					T gamma = -sign * DOT( AO, N );

					// ray intersects triangle!
					if( gamma >= 0 ) {

						uvw[1] = alpha / dist;
						uvw[2] = beta / dist;
						uvw[0] = 1 - uvw[1] - uvw[2];
						t      = gamma / dist;

						return SPTRUE;

					} // else: t < 0, no intersection

				} // else: a+b > 1, no intersection

			} // else: b < 0, no intersection

		} // else: a < 0, no intersection

		return SPFALSE;
	}
}

#endif //_SP_INTERSECTION_H_

