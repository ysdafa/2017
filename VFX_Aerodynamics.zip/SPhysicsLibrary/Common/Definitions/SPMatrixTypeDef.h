/**
* @file SPMatrixTypeDef.h
* @brief The header file for Defines.
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/


#ifndef _SP_MATRIX_TYPE_DEF_H_
#define _SP_MATRIX_TYPE_DEF_H_


namespace SPhysics
{
#if 0
#define SPMat2x2f		SPMatrix2x2<float>			//!< 2D float matrix
#define	SPMat2x2i		SPMatrix2x2<int>			//!< 2D int matrix
#define	SPMat2x2u		SPMatrix2x2<unsigned int>	//!< 2D unsigned int matrix
#define	SPMat2x2t		SPMatrix2x2<T>				//!< 2D tamplate matrix

#define SPMat3x3f		SPMatrix3x3<float>			//!< 3D float matrix
#define	SPMat3x3i		SPMatrix3x3<int>			//!< 3D int matrix
#define	SPMat3x3u		SPMatrix3x3<unsigned int>	//!< 3D unsigned matrix
#define	SPMat3x3t		SPMatrix3x3<T>				//!< 3D tamplate matrix

#define SPMat4x4f		SPMatrix4x4<float>			//!< 4D float matrix
#define	SPMat4x4i		SPMatrix4x4<int>			//!< 4D int matrix
#define	SPMat4x4u		SPMatrix4x4<unsigned int>	//!< 4D unsigned matrix
#define	SPMat4x4t		SPMatrix4x4<T>				//!< 4D unsigned matrix
#endif

#define SPMat2x2f		glm::mat2x2			        //!< 2D float matrix
#define	SPMat2x2i		glm::imat2x2			    //!< 2D int matrix
#define	SPMat2x2u		glm::umat2x2	            //!< 2D unsigned int matrix
#define	SPMat2x2t		glm::tmat2x2<T>				//!< 2D tamplate matrix

#define SPMat3x3f		glm::mat3x3			        //!< 3D float matrix
#define	SPMat3x3i		glm::imat3x3			    //!< 3D int matrix
#define	SPMat3x3u		glm::umat3x3	            //!< 3D unsigned int matrix
#define	SPMat3x3t		glm::tmat3x3<T>				//!< 3D tamplate matrix

#define SPMat4x4f		glm::mat4x4			        //!< 4D float matrix
#define	SPMat4x4i		glm::imat4x4			    //!< 4D int matrix
#define	SPMat4x4u		glm::umat4x4	            //!< 4D unsigned int matrix
#define	SPMat4x4t		glm::tmat4x4<T>				//!< 4D tamplate matrix

}  //namespace SPhysics

#endif // _SP_MATRIX_TYPE_DEF_H_

