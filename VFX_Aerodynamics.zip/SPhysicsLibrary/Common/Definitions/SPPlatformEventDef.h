/**
* @file SPPlatformEventDef.h
* @brief The header file for Defines.
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/


#ifndef _SP_PLATFORM_EVENT_DEF_H_
#define _SP_PLATFORM_EVENT_DEF_H_

namespace SPhysics
{

	/**
	 * @enum _TOUCH_TYPE
	 * @brief Touch type
	 */
	typedef enum _TOUCH_TYPE
	{
		TOUCH_DOWN,		//!< Touch down
		TOUCH_UP,		//!< Touch up
		TOUCH_MOVE		//!< Touch move
#ifdef _WIN32
		,MOUSE_RDOWN,	//!< Mouse right down
		MOUSE_RUP,		//!< Mouse right up
		MOUSE_WHEEL		//!< Mouse wheel
#endif
	}TOUCH_TYPE;	//!< Touch type

	/**
	 * @enum _SENSOR_TYPE
	 * @brief Sensor type
	 */
	typedef enum _SENSOR_TYPE
	{
		SENSOR_TYPE_ACCELEROMETER = 1,	//!< Accelerometer
		SENSOR_TYPE_MAGNETIC_FIELD,		//!< Magnetic field
		SENSOR_TYPE_ORIENTATION,		//!< Orientation
		SENSOR_TYPE_GYROSCOPE,			//!< Gyroscope
		SENSOR_TYPE_LIGHT,				//!< Light
		SENSOR_TYPE_PRESSURE,			//!< Pressure
		SENSOR_TYPE_TEMPERATURE,		//!< Temperature
		SENSOR_TYPE_PROXIMITY,			//!< Proximity
		SENSOR_TYPE_GRAVITY,			//!< Gravity
		SENSOR_TYPE_LINEAR_ACCELERATION,//!< Linear acceleration
		SENSOR_TYPE_ROTATION_VECTOR,	//!< Rotation vector
		SENSOR_TYPE_RELATIVE_HUMIDITY,	//!< Relative humidity
		SENSOR_TYPE_AMBIENT_TEMPERATURE	//!< Ambient temperature	
	}SENSOR_TYPE;	//!< Sensor type


	/**
	 * @enum _KEY_TYPE
	 * @brief Key type
	 */
	typedef enum _KEY_TYPE
	{
		KEY_TYPE_VOLUME_UP = 24,	//!< Volume up
		KEY_TYPE_VOLUME_DOWN = 25	//!< Volume down
	}KEY_TYPE;	//!< Key type

	/**
	 * @enum _HOVER_TYPE
	 * @brief Hover type
	 */
	typedef enum _HOVER_TYPE
	{
		HOVER_ENTER = 9,	//!< Hover enter
		HOVER_MOVE = 7,		//!< Hover move
		HOVER_EXIT = 10		//!< Hover exit
	}HOVER_TYPE;	//!< Hover type

}  //namespace SPhysics

#endif // _SP_PLATFORM_EVENT_DEF_H_
