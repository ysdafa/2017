/**
* @file SPTriangleMesh.cpp
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPTriangleMesh.h"

namespace SPhysics
{
	template <typename T>
	SPTriangleMesh<T>::SPTriangleMesh()
	{
		init();
	}

	template <typename T>
	SPTriangleMesh<T>::SPTriangleMesh(const SPTriangleMesh<T> &t): SPObject()
	{
		m_ChannelBits = t.m_ChannelBits;

		//m_bbox = t.m_bbox;

		m_Triangles = t.m_Triangles;
		m_Positions = t.m_Positions;
		m_Velocities = t.m_Velocities;
		m_Normals = t.m_Normals;	
	}

	template <typename T>
	SPTriangleMesh<T>::~SPTriangleMesh()
	{
	}


	template <typename T>
	SPVoid SPTriangleMesh<T>::init()
	{
		m_ChannelBits = 0;

		//m_bbox.init();

		m_Triangles.clear();
		m_Positions.clear();
		m_Velocities.clear();
		m_Normals.clear();	
	}

	// template <typename T>
	// const BoundingBox<T>& SPTriangleMesh<T>::getBoundingBox() const
	// {
	// 	return m_bbox;
	// }
	// 
	// template <typename T>
	// BoundingBox<T>& SPTriangleMesh<T>::computeBoundingBox()
	// {
	// 	m_bbox.init();
	// 	for(typename std::vector<SPVec3t >::const_iterator it=m_Positions.begin(); it<m_Positions.end();it++) m_bbox.add(*it);
	// 	return m_bbox;
	// }

		
	template <typename T>
	SPUInt SPTriangleMesh<T>::getNumVertices() const
	{
		return m_Positions.size();
	}

	
	template <typename T>
	SPUInt SPTriangleMesh<T>::getNumTriangles() const
	{
		return m_Triangles.size();
	}


	template <typename T>
	SPUInt SPTriangleMesh<T>::addTriangleMesh(const SPTriangleMesh<T> &t)
	{
		if(m_ChannelBits != t.m_ChannelBits) return m_Positions.size();

		const SPUInt numVertices = getNumVertices();
		const SPVec3u num(numVertices, numVertices, numVertices);
		const SPUInt source_mesh_numTriangles = t.getNumTriangles();

		for(SPUInt i=0; i<source_mesh_numTriangles; ++i) {
			const SPVec3u new_triangle_index = num + t.getTriangle(i);
			addTriangle( new_triangle_index ); 
		}

		typename std::vector<SPVec3t >::const_iterator it;
		if(m_ChannelBits & SPE_POSITION) for(it=t.m_Positions.begin();it<t.m_Positions.end();it++) m_Positions.push_back(*it);
		if(m_ChannelBits & SPE_VELOCITY) for(it=t.m_Velocities.begin();it<t.m_Velocities.end();it++) m_Velocities.push_back(*it);
		if(m_ChannelBits & SPE_NORMAL) for(it=t.m_Normals.begin();it<t.m_Normals.end();it++) m_Normals.push_back(*it);

		return m_Positions.size();
	}

	
	template <typename T>
	SPInt SPTriangleMesh<T>::addChannel(const SPInt bits) 
	{
		const SPInt xor_channel_bit = m_ChannelBits^bits;

		if( (xor_channel_bit & SPE_POSITION )	&& (bits & SPE_POSITION)	) m_Positions.resize(m_Positions.size());
		if( (xor_channel_bit & SPE_VELOCITY )	&& (bits & SPE_VELOCITY)	) m_Velocities.resize(m_Positions.size());
		if( (xor_channel_bit & SPE_NORMAL )		&& (bits & SPE_NORMAL)		) m_Normals.resize(m_Positions.size());

		m_ChannelBits |= bits;

		return m_ChannelBits;
	}

	
	template <typename T>
	SPUInt SPTriangleMesh<T>::addTriangle(const SPVec3u &tri)
	{
		m_Triangles.push_back(tri);
		return m_Triangles.size();
	}

	
	template <typename T>
	SPUInt SPTriangleMesh<T>::addVertex(const SPVec3t &vert)
	{
		m_Positions.push_back(vert);
		return m_Positions.size();
	}

	
	template <typename T>
	SPUInt SPTriangleMesh<T>::addVelocity(const SPVec3t &vel)
	{
		m_Velocities.push_back(vel);
		return m_Velocities.size();
	}

	
	template <typename T>
	SPUInt SPTriangleMesh<T>::addNormal(const SPVec3t &normal)
	{
		m_Normals.push_back(normal);
		return m_Normals.size();
	}

	
	template <typename T>
	SPVoid SPTriangleMesh<T>::setTriangles(const std::vector<SPVec3u >& tris)
	{
		m_Triangles = tris;
	}

	
	template <typename T>
	SPVoid SPTriangleMesh<T>::setVertices(const std::vector<SPVec3t > &verts)
	{
		m_Positions = verts;
		m_ChannelBits |= SPE_POSITION;
	}

	
	template <typename T>
	SPVoid SPTriangleMesh<T>::setVelocities(const std::vector<SPVec3t > &vels)
	{
		m_Velocities = vels;
		m_ChannelBits |= SPE_VELOCITY;
	}

	
	template <typename T>
	SPVoid SPTriangleMesh<T>::setNormals(const std::vector<SPVec3t > &norms)
	{
		m_Normals = norms;
		m_ChannelBits |= SPE_NORMAL;
	}

	
	template <typename T>
	SPInt SPTriangleMesh<T>::getChannel() const
	{
		return m_ChannelBits;
	}

	
	template <typename T>
	const SPVec3u& SPTriangleMesh<T>::getTriangle(const SPUInt i) const
	{
		return m_Triangles[i];
	}

	
	template <typename T>
	const std::vector<SPVec3t >& SPTriangleMesh<T>::getVertices() const
	{
		return m_Positions;
	}

	template <typename T>
	const SPVec3t& SPTriangleMesh<T>::getVertex(const SPUInt i) const
	{
		return m_Positions[i];
	}

	template <typename T>
	const SPVec3t& SPTriangleMesh<T>::getVelocity(const SPUInt i) const
	{
		return m_Velocities[i];
	}

	template <typename T>
	const SPVec3t& SPTriangleMesh<T>::getNormal(const SPUInt i) const
	{
		return m_Normals[i];
	}


	template <typename T>
	SPVoid SPTriangleMesh<T>::computeVertexNormal()
	{
		if(hasNormal()==SPFALSE) {
			addChannel( SPE_NORMAL );
			for(SPUInt i=0; i<getNumVertices(); ++i) addNormal( SPVec3t(0,0,0) );
		}

		SPVec3u triangle;
		SPVec3t p1, p2, p3, v1, v2, v3;
		for(SPUInt i=0; i<m_Triangles.size(); ++i) {

			triangle = m_Triangles[i];

			p1 = m_Positions[triangle[0]];
			p2 = m_Positions[triangle[1]];
			p3 = m_Positions[triangle[2]];

			v1 = p2-p1, v2 = p3-p1, v3 = glm::cross(v1,v2); v3 = glm::normalize(v3);

			m_Normals[triangle[0]] += v3;
			m_Normals[triangle[1]] += v3;
			m_Normals[triangle[2]] += v3; 
		}

		for(SPUInt i=0; i<getNumVertices(); ++i) { m_Normals[i] = glm::normalize(m_Normals[i]); }

	}

	template class SPTriangleMesh<SPFloat>;
	template class SPTriangleMesh<SPDouble>;

}