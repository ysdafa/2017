/**
* @file SPGrid2D.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_GRID_2D_H_
#define _SP_GRID_2D_H_

#include "SPDefines.h"

#include "../SPObject.h"
#include <glm.hpp>

namespace SPhysics
{
	/**
	* @class     SPGrid2D
	* @brief     2D grid
	*/
	class SPGrid2D : public SPObject
	{
	protected:
		SPInt m_Nx;					//!< resolution per each direction (Nx)
		SPInt m_Ny;					//!< resolution per each direction (Ny)
		SPDouble m_Lx;				//!< domain length per each direction (Lx)
		SPDouble m_Ly;				//!< domain length per each direction (Ly)
		SPDouble m_Dx;				//!< cell size per each direction (Dx) (recommendation: m_Dx=m_Dy=Dz)
		SPDouble m_Dy;				//!< cell size per each direction (Dy) (recommendation: m_Dx=m_Dy=Dz)

		SPInt   m_NumCells;				//!< total # of cells
		SPInt   m_NumUFaces;			//!< total # of faces perpendicular to x-direction
		SPInt   m_NumVFaces;			//!< total # of faces perpendicular to y-direction
		SPInt   m_NumXEdges;			//!< total # of edges parallel to x-direction
		SPInt   m_NumYEdges;			//!< total # of edges parallel to y-direction
		SPInt   m_NumNodes;				//!< total # of nodes

		// frequently asked values
		SPInt   m_NxPlus1;				//!< = m_Nx+1
		SPInt   m_NyPlus1;				//!< = m_Ny+1
		SPInt   m_NxMinus1;				//!< = m_Nx-1
		SPInt   m_NyMinus1;				//!< = m_Ny-1
		SPInt   m_NxNy;					//!< = m_Nx*m_Ny

		SPDouble m_DxHalf;		//!< = 0.5*( m_Dx, m_Dy ) (Dx)
		SPDouble m_DyHalf;		//!< = 0.5*( m_Dx, m_Dy ) (Dy)
		SPDouble m_Dx2;			//!< = ( m_Dx^2, m_Dy^2 ) (Dx2)
		SPDouble m_Dy2;			//!< = ( m_Dx^2, m_Dy^2 ) (Dy2)
		SPDouble m_Dx2Dy2;				//!< = m_Dx^2*m_Dy^2
		SPDouble m_MinDxDy;				//!< = min(m_Dx,m_Dy)
		SPDouble m_MaxDxDy;				//!< = max(m_Dx,m_Dy)
		SPDouble m_DiagonalLength;		//!< = sqrt(m_Dx*m_Dx+m_Dy*m_Dy)

		SPDouble m_Epsilon;				//!< very small number for this grid
		SPDouble m_LxMinusEps;			//!< m_Lx - m_Epsilon
		SPDouble m_LyMinusEps;			//!< m_Ly - m_Epsilon

	public:
		/**
		* @brief	Get the Nx ( resolution )     
		* @return     SPInt
		*/
		SPInt nx() const { return m_Nx; }
		
		/**
		* @brief     Get the Ny ( resolution )     
		* @return     SPInt
		*/
		SPInt ny() const { return m_Ny; }

		/**
		* @brief     Get the Lx ( dimension )     
		* @return     SPDouble
		*/
		SPDouble lx() const { return m_Lx; }
		
		/**
		* @brief     Get the Ly ( dimension )     
		* @return     SPDouble
		*/
		SPDouble ly() const { return m_Ly; }

		/**
		* @brief     Get the Dx ( location )
		* @return     SPDouble
		*/
		SPDouble dx() const { return m_Dx; }
		
		/**
		* @brief     Get the Dy ( location )
		* @return     SPDouble
		*/
		SPDouble dy() const { return m_Dy; }

		/**
		* @brief     Get the square of dx
		* @return     SPDouble
		*/
		SPDouble dx2() const { return m_Dx2; }
		
		/**
		* @brief     Get the square of dy
		* @return     SPDouble
		*/
		SPDouble dy2() const { return m_Dy2; }

		/**
		* @brief     Get the square of dxdy
		* @return     SPDouble
		*/
		SPDouble dx2dy2() { return m_Dx2Dy2; }

		/**
		* @brief     Transfer index i,j to cell
		* @param     [IN] @b i index i
		* @param     [IN] @b j index j
		* @return     SPInt
		*/
		SPInt cell( const SPInt& i, const SPInt& j )	const { return (i + m_Nx*j); }
		
		/**
		* @brief     Transfer index i,j to cell
		* @param     [IN] @b idx index
		* @return     SPInt
		*/
		SPInt cell( const SPVec2i& idx )	const { return cell(idx.x,idx.y); }

		/**
		* @brief     Get the wCell ( idx-1 )
		* @param     [IN] @b idx index
		* @return     SPInt
		*/
		SPInt wCell( const SPInt& idx )				const { return idx-1; }
		
		/**
		* @brief     Get the wCell ( idx-1 )
		* @param     [IN] @b i index i
		* @param     [IN] @b j index j
		* @return     SPInt
		*/
		SPInt wCell( const SPInt& i, const SPInt& j )	const { return wCell(cell(i,j)); }
		
		/**
		* @brief     Get the wCell ( idx-1 )
		* @param     [IN] @b idx index
		* @return     SPInt
		*/
		SPInt wCell( const SPVec2i& idx )	const { return wCell(idx.x,idx.y); }

		/**
		* @brief     Get the eCell ( idx+1 )
		* @param     [IN] @b idx index
		* @return     SPInt
		*/
		SPInt eCell( const SPInt& idx )				const { return idx+1; }
		
		/**
		* @brief     Get the eCell ( idx+1 )
		* @param     [IN] @b i index i
		* @param     [IN] @b j index j
		* @return     SPInt
		*/
		SPInt eCell( const SPInt& i, const SPInt& j )	const { return eCell(cell(i,j)); }
		
		/**
		* @brief     Get the eCell ( idx+1 )
		* @param     [IN] @b  idx index
		* @return     SPInt
		*/
		SPInt eCell( const SPVec2i& idx )	const { return eCell(idx.x,idx.y); }

		/**
		* @brief     Get the sCell ( idx-Nx )
		* @param     [IN] @b idx index 
		* @return     SPInt
		*/
		SPInt sCell( const SPInt& idx )				const { return idx-m_Nx; }	
		
		/**
		* @brief      Get the sCell ( idx-Nx )
		* @param     [IN] @b i index i
		* @param     [IN] @b j index j
		* @return     SPInt
		*/
		SPInt sCell( const SPInt& i, const SPInt& j )	const { return sCell(cell(i,j)); }
		
		/**
		* @brief      Get the sCell ( idx-Nx )
		* @param     [IN] @b idx index 
		* @return     SPInt
		*/
		SPInt sCell( const SPVec2i& idx )	const { return sCell(idx.x,idx.y); }

		/**
		* @brief      Get the nCell ( idx+Nx )
		* @param     [IN] @b idx index 
		* @return     SPInt
		*/
		SPInt nCell( const SPInt& idx )				const { return idx+m_Nx; }
		
		/**
		* @brief     Get the nCell ( idx+Nx )
		* @param     [IN] @b i index i
		* @param     [IN] @b j index j 
		* @return     SPInt
		*/
		SPInt nCell( const SPInt& i, const SPInt& j )	const { return nCell(cell(i,j)); }
		
		/**
		* @brief     Get the nCell ( idx+Nx )
		* @param     [IN] @b idx index 
		* @return     SPInt
		*/
		SPInt nCell( const SPVec2i& idx )	const { return nCell(idx.x,idx.y); }


		/**
		* @brief     Get the node
		* @param     [IN] @b i index i
		* @param     [IN] @b j index j
		* @return     SPInt
		*/
		SPInt node( const SPInt& i, const SPInt& j )	const { return (i + m_NxPlus1 * j); }
		
		/**
		* @brief     Get the node
		* @param     [IN] @b  idx index
		* @return     SPInt
		*/
		SPInt node( const SPVec2i& idx )	const { return node(idx.x, idx.y); }

		/**
		* @brief     Get the wNode (idx-1)
		* @param     [IN] @b idx index 
		* @return     SPInt
		*/
		SPInt wNode( const SPInt& idx )				const { return idx-1; }
		
		/**
		* @brief     Get the wNode (idx-1)
		* @param     [IN] @b i index i
		* @param     [IN] @b j index j
		* @return     SPInt
		*/
		SPInt wNode( const SPInt& i, const SPInt& j )	const { return wNode(node(i,j)); }
		
		/**
		* @brief     Get the wNode (idx-1)
		* @param     [IN] @b idx index 
		* @return     SPInt
		*/
		SPInt wNode( const SPVec2i& idx )	const { return wNode(idx.x,idx.y); }

		/**
		* @brief     Get the wNode (idx+1)
		* @param     [IN] @b idx index 
		* @return     SPInt
		*/
		SPInt eNode( const SPInt& idx )				const { return idx+1; }
		
		/**
		* @brief     Get the wNode (idx+1)
		* @param     [IN] @b i index i
		* @param     [IN] @b j index j
		* @return     SPInt
		*/
		SPInt eNode( const SPInt& i, const SPInt& j )	const { return eNode(node(i,j)); }
		
		/**
		* @brief     Get the wNode (idx+1)
		* @param     [IN] @b idx index 
		* @return     SPInt
		*/
		SPInt eNode( const SPVec2i& idx )	const { return eNode(idx.x,idx.y); }

		/**
		* @brief     Get the sNode (idx+1)
		* @param     [IN] @b idx index 
		* @return     SPInt
		*/
		SPInt sNode( const SPInt& idx )				const { return idx-m_NxPlus1; }
		
		/**
		* @brief     Get the sNode (idx+1)
		* @param     [IN] @b i index i
		* @param     [IN] @b j index j
		* @return     SPInt
		*/
		SPInt sNode( const SPInt& i, const SPInt& j )	const { return sNode(node(i,j)); }
		
		/**
		* @brief     Get the sNode (idx+1)
		* @param     [IN] @b idx index 
		* @return     SPInt
		*/
		SPInt sNode( const SPVec2i& idx )	const { return sNode(idx.x,idx.y); }

		/**
		* @brief     Get the sNode (idx+1)
		* @param     [IN] @b idx index 
		* @return     SPInt
		*/
		SPInt nNode( const SPInt& idx )				const { return idx+m_NxPlus1; }
		
		/**
		* @brief     Get the sNode (idx+1)
		* @param     [IN] @b i index i
		* @param     [IN] @b j index j
		* @return     SPInt
		*/
		SPInt nNode( const SPInt& i, const SPInt& j )	const { return nNode(node(i,j)); }
		
		/**
		* @brief     Get the sNode (idx+1)
		* @param     [IN] @b idx index 
		* @return     SPInt
		*/
		SPInt nNode( const SPVec2i& idx )	const { return nNode(idx.x,idx.y); }

		/**
		* @brief     Get the epsilon
		* @return     SPDouble
		*/
		SPDouble getEpsilon() const { return m_Epsilon; }
		
		/**
		* @brief     Get the minimum dxdy
		* @return     SPDouble
		*/
		SPDouble getMinDxDy() const { return m_MinDxDy; }
		
		/**
		* @brief     Get the maximum dxdy
		* @return     SPDouble
		*/
		SPDouble getMaxDxDy() const { return m_MaxDxDy; }

	public:

		/**
		* @brief     Constructor
		*/
		SPGrid2D(){ reset(); }
		/**
		* @brief     Constructor
		* @param     [IN] @b nx grid resolution x
		* @param     [IN] @b ny grid resolution y
		* @param     [IN] @b lx grid dimension x
		* @param     [IN] @b ly grid dimension y
		*/
		SPGrid2D( const SPInt& nx, const SPInt& ny, const SPDouble& lx, const SPDouble& ly ) { setGrid( nx,ny, lx,ly ); }
		/**
		* @brief     Constructor
		* @param     [IN] @b g grid
		*/
		SPGrid2D( const SPGrid2D& g ) : SPObject(g) { copy( g ); }
		// destructor. It's virtual!
		/**
		* @brief     Destructor
		*/
		virtual ~SPGrid2D(){}

		/**
		* @brief	Reset all data sets     
		* @return     SPVoid
		*/
		SPVoid reset();								// reinitialize
		
		/**
		* @brief     Set data of grid ( nx, ny, lx, ly )
		* @param     [IN] @b nx grid resolution x
		* @param     [IN] @b ny grid resolution y
		* @param     [IN] @b lx grid dimension x
		* @param     [IN] @b ly grid dimension y
		* @return     SPVoid
		*/
		SPVoid setGrid( const SPInt& nx, const SPInt& ny, const SPDouble& lx, const SPDouble& ly );
		
		/**
		* @brief     Set data of grid ( nx, ny, lx, ly )
		* @param     [IN] @b nx_ny grid resolution xy
		* @param     [IN] @b lx_ly grid dimension xy
		* @return     SPVoid
		*/
		SPVoid setGrid( const SPVec2i& nx_ny, const SPVec2d& lx_ly );

		/**
		* @brief     Copy data 
		* @param     [IN] @b grid copy data
		* @return     SPVoid
		*/
		SPVoid copy( const SPGrid2D& grid);

		/**
		 * @brief Assign value from other instance
		 */
		SPGrid2D& operator=( const SPGrid2D& g ) {
			if(this != &g) { copy( g ); }
			return *this;
		}

		/**
		* @brief     Get the number of cells
		* @return     SPInt
		*/
		SPInt getNumCells() const { return m_NumCells; }
		
		/**
		* @brief     Get the number of U faces
		* @return     SPInt
		*/
		SPInt getNumUFaces() const { return m_NumUFaces; }
		
		/**
		* @brief     Get the number of V faces
		* @return     SPInt
		*/
		SPInt getNumVFaces() const { return m_NumVFaces; }
		
		/**
		* @brief     Get the number of X Edges
		* @return     SPInt
		*/
		SPInt getNumXEdges() const { return m_NumXEdges; }
		
		/**
		* @brief     Get the number of Y Edges
		* @return     SPInt
		*/
		SPInt getNumYEdges() const { return m_NumYEdges; }
		
		/**
		* @brief     Get the number of Nodes
		* @return     SPInt
		*/
		SPInt getNumNodes() const { return m_NumNodes; }

		/**
		* @brief     Get the grid resolution ( nx, ny )
		* @param     [IN] @b nx grid resolution x
		* @param     [IN] @b ny grid resolution y
		* @return     SPVoid
		*/
		virtual SPVoid getResolution( SPInt& nx, SPInt& ny ) const { nx = m_Nx; ny = m_Ny; }
		
		/**
		* @brief     Get the dimension ( lx, ly )
		* @param     [IN] @b lx grid dimension x
		* @param     [IN] @b ly grid dimension y
		* @return     SPVoid
		*/
		virtual SPVoid getDimension( SPDouble& lx, SPDouble& ly ) const { lx = m_Lx; ly = m_Ly; }
		
		/**
		* @brief     Get the cell size ( dx, dy )
		* @param     [IN] @b dx grid cell size x
		* @param     [IN] @b dy grid cell size y
		* @return     SPVoid
		*/
		virtual SPVoid getCellSize( SPDouble& dx, SPDouble& dy ) const { dx = m_Dx; dy = m_Dy; }

		/**
		* @brief     Get tue resolution
		* @return     SPVec2i
		*/
		virtual SPVec2i getResolution() const { return SPVec2i(m_Nx,m_Ny); }
		
		/**
		* @brief     Get the dimention
		* @return     SPVec2d
		*/
		virtual SPVec2d getDimension() const { return SPVec2d(m_Lx,m_Ly); }
		
		/**
		* @brief     Get the cell size
		* @return     SPVec2d
		*/
		virtual SPVec2d getCellSize() const { return SPVec2d(m_Dx,m_Dy); }

		//TODO - pass by value
		/**
		* @brief     Get nodes of cell
		* @param     [IN] @b i index i
		* @param     [IN] @b j index j
		* @param     [IN] @b node[4] corner point indices
		* @return     SPVoid
		*/
		virtual SPVoid getNodesOfCell( const SPInt& i, const SPInt& j, SPInt node[4] );
		
	};

}

#endif //_SP_GRID_2D_H_

