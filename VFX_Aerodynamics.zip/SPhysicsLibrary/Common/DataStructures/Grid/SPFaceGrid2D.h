/**
* @file SPFaceGrid2D.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/


#ifndef _SP_FACE_GRID_2D_H_
#define _SP_FACE_GRID_2D_H_

#include "SPDefines.h"

#include "SPGrid2D.h"
#include "SPComparison.h"
#include <vector>
#include <iostream>

namespace SPhysics
{
	/**
	* @class     SPFaces2D
	* @brief     2D face
	*/
	template <typename T>
	class SPFaces2D : public SPObject
	{
	public:
		SPVec2t m_Upper;	//!< Upper
		SPVec2t m_Lower;	//!< Lower

	public:
		/**
		* @brief	Constructor     
		*/
		SPFaces2D(){}
		
		/**
		* @brief    Constructor 
		* @param     [IN] @b u upper face sampling position
		* @param     [IN] @b l lower face sampling position
		*/
		SPFaces2D(const SPVec2t& u, const SPVec2t& l) {
			m_Upper = u;
			m_Lower = l;
		}
		
		/**
		* @brief     Destructor
		*/
		~SPFaces2D(){}
	};

	/**
	* @class     SPFaceGrid2D
	* @brief     make SPFaceGrid2D
	*/
	template <typename T>
	class SPFaceGrid2D : public SPGrid2D
	{
	private:
		SPInt m_WhichSideOpened;

	private:
 		std::vector<T> m_UFace, m_VFace;

	public:		
		/**
		* @brief     Constructor
		*/
		SPFaceGrid2D(){ reset(); }
		
		/**
		* @brief     Constructor
		* @param     [IN] @b fg face grid for copy constructor
		*/
		SPFaceGrid2D( const SPFaceGrid2D<T>& fg ){ copy(fg); }
		
		/**
		* @brief     Constructor
		* @param     [IN] @b nx grid resolution x
		* @param     [IN] @b ny grid resolution y
		* @param     [IN] @b lx grid dimension(size) x
		* @param     [IN] @b ly	grid dimension(size) y
		*/
		SPFaceGrid2D( const SPInt& nx,const SPInt& ny, const SPDouble& lx,const SPDouble& ly ){ reset(); set(nx,ny, lx,ly); }
		
		/**
		* @brief     Constructor
		* @param     [IN] @b resolution resolution x,y
		* @param     [IN] @b gridSize  size of grid
		*/
		SPFaceGrid2D( const SPVec2i& resolution, const SPVec2d& gridSize ){ reset(); set( resolution, gridSize ); }
				
		/**
		* @brief     Destructor
		*/
		virtual ~SPFaceGrid2D(){ reset(); }

		/**
		 * @brief Copy
		 */
		SPVoid copy( const SPFaceGrid2D<T>& vectorField);

		/**
		 * @brief Assign value from other instance
		 */
		SPFaceGrid2D<T>& operator=( const SPFaceGrid2D<T>& vf ) {
			if(this != &vf) { copy( vf ); }
			return *this;
		}

		// set		
		/**
		* @brief     Reset 	data of grid	
		* @return     SPVoid
		*/
		SPVoid reset();
		
		/**
		* @brief     Set data ( resolution, dimension )
		* @param     [IN] @b grid_resolution_x grid resolution x
		* @param     [IN] @b grid_resolution_y grid resolution y
		* @param     [IN] @b grid_dimension_x  grid dimension x
		* @param     [IN] @b grid_dimension_y  grid dimension y
		* @return     SPBool
		*/
		SPBool set( const SPInt& grid_resolution_x,const SPInt& grid_resolution_y, const SPDouble& grid_dimension_x,const SPDouble& grid_dimension_y); // resolution, dimension
		
		/**
		* @brief     Set data ( resolution , dimension )
		* @param     [IN] @b resolution grid resolution  
		* @param     [IN] @b dimension grid dimension
		* @return     SPBool
		*/
		SPBool set( const SPVec2i& resolution, const SPVec2d& dimension);

		/**
		* @brief     Set data to Zero
		* @return     SPVoid
		*/
		SPVoid setZero();

		/**
		* @brief     Set face value with input
		* @param     [IN] @b x face x
		* @param     [IN] @b y face y
		* @return     SPVoid
		*/
 		SPVoid setValue( const T& x, const T& y );
	// 	SPVoid setValue( const SPInt& index, const T& x, const T& y );

		/**
		* @brief     Get U face data
		* @param     [IN] @b i index x 
		* @param     [IN] @b j index y
		* @return     T
		*/
		T getUFace( const SPInt& i, const SPInt& j ) const { return m_UFace[m_NxPlus1*j + i]; }
		
		/**
		* @brief     Get U face data
		* @param     [IN] @b idx index
		* @return     T
		*/
		T getUFace( const SPVec2i& idx ) const   { return m_UFace[m_NxPlus1*idx.y + idx.x]; }
 		
		/**
		* @brief     Get V face data
		* @param     [IN] @b i index i
		* @param     [IN] @b j index j
		* @return     T
		*/
		T getVFace( const SPInt& i, const SPInt& j ) const { return m_VFace[m_Nx*j + i]; }
		
		/**
		* @brief     Get V face data
		* @param     [IN] @b idx index
		* @return     T
		*/
		T getVFace( const SPVec2i& idx ) const   { return m_VFace[m_Nx*idx.y + idx.x]; }

		/**
		* @brief     Set U face data
		* @param     [IN] @b i input index i
		* @param     [IN] @b j input index j
		* @param     [IN] @b v input u value
		* @return     SPVoid
		*/
		SPVoid setUFace( const SPInt& i, const SPInt& j, const T& v ) { m_UFace[m_NxPlus1*j + i] = v; }
		
		/**
		* @brief     Set U face data
		* @param     [IN] @b idx input index
		* @param     [IN] @b v input u value
		* @return     SPVoid
		*/
		SPVoid setUFace( const SPVec2i& idx, const T& v ) { m_UFace[m_NxPlus1*idx.y + idx.x] = v; }
		
		/**
		* @brief     Set V face data
		* @param     [IN] @b i input index i
		* @param     [IN] @b j input index j
		* @param     [IN] @b v input v value
		* @return     SPVoid
		*/
		SPVoid setVFace( const SPInt& i, const SPInt& j, const T& v ) { m_VFace[m_Nx*j + i] = v; }
		
		/**
		* @brief     Set V face data
		* @param     [IN] @b idx input index
		* @param     [IN] @b v input v value
		* @return     SPVoid
		*/
		SPVoid setVFace( const SPVec2i& idx, const T& v ) { m_VFace[m_Nx*idx.y + idx.x] = v; }


		// get
		/**
		* @brief     Get face data ( Upper , Lower )
		* @param     [IN] @b i index i
		* @param     [IN] @b j index j
		* @return     SPFaces2D<T>
		*/
		SPFaces2D<T> getFaces( const SPInt& i, const SPInt& j ) const;
		
		/**
		* @brief     Get face value ( Upper , Lower )
		* @param     [IN] @b idx index		
		* @return     SPFaces2D<T>
		*/
		SPFaces2D<T> getFaces( const SPVec2i& idx ) const;
		
		/**
		* @brief     Get the center value of Faces ( Upper + Lower ) / 2 
		* @param     [IN] @b i index i
		* @param     [IN] @b j index j
		* @return     SPFaces2D<T>
		*/
		SPVec2t getCenterValue( const SPInt& i, const SPInt& j ) const;
		
		/**
		* @brief     Get the center value of Faces ( Upper + Lower ) / 2 
		* @param     [IN] @b idx index		
		* @return     SPFaces2D<T>
		*/
		SPVec2t getCenterValue( const SPVec2i& idx ) const;
		
		/**
		* @brief     Get the corner value of Faces
		* @param     [IN] @b i index i
		* @param     [IN] @b j index j
		* @return     SPFaces2D<T>
		*/
		SPVec2t getCornerValue( const SPInt& i, const SPInt& j ) const;
		
		/**
		* @brief     Get the corner value of Faces
		* @param     [IN] @b idx index		
		* @return     SPFaces2D<T>
		*/
		SPVec2t getCornerValue( const SPVec2i& idx ) const;
		
		/**
		* @brief     Transfer position to index U face
		* @param     [IN] @b pos input position 		
		* @return     SPFaces2D<T>
		*/
		SPVec2t positionToIndexUFace(const SPVec2t &pos) const;
		
		/**
		* @brief     Transfer position to index V face
		* @param     [IN] @b pos input position	
		* @return     SPFaces2D<T>
		*/
		SPVec2t positionToIndexVFace(const SPVec2t &pos) const;
		
		/**
		* @brief     Get the interpolated value
		* @param     [IN] @b pos input position
		* @return     SPFaces2D<T>
		*/
		SPVec2t getInterpolatedValue( const SPVec2t& pos ) const;

		// file
		/**
		* @brief     Save the data to file
		* @param     [IN] @b filePathName input file name		
		* @return     SPBool
		*/
		SPBool save( const SPChar* filePathName );
		
		/**
		* @brief     Load the data from file
		* @param     [IN] @b filePathName input file name		
		* @return     SPBool
		*/
		SPBool load( const SPChar* filePathName );

	};

	template <typename T>
	SPVoid SPFaceGrid2D<T>::copy( const SPFaceGrid2D<T>& vf )
	{
		reset();
		set( vf.getResolution(), vf.getDimension() );
		this->m_UFace = vf.m_UFace;
		this->m_VFace = vf.m_VFace;
	}

	template <typename T>
	inline SPVoid SPFaceGrid2D<T>::reset()
	{
		m_WhichSideOpened=0;
		SPGrid2D::reset();
		m_UFace.clear();
		m_VFace.clear();
	}

	template <typename T>
	inline SPBool SPFaceGrid2D<T>::set( const SPInt& nx,const SPInt& ny, const SPDouble& lx,const SPDouble& ly )
	{
		if( nx <= 0 || ny <= 0 ) {
			std::cout<<"Error@SPFaceGrid2D::set(): Invalid resolution."<<std::endl;;
			return SPFALSE;
		}

		if( lx <= 0 || ly <= 0 ) {
			std::cout<<"Error@SPFaceGrid2D::set(): Invalid dimension."<<std::endl;;
			return SPFALSE;
		}

		SPGrid2D::setGrid(nx,ny, lx,ly);

		m_UFace.resize( m_NumUFaces );
		m_VFace.resize( m_NumVFaces );

		setZero();

		return SPTRUE;
	}

	template <typename T>
	inline SPBool SPFaceGrid2D<T>::set( const SPVec2i& resolution, const SPVec2d& dimension )
	{
		return set( resolution.x,resolution.y, dimension.x,dimension.y );
	}

	template <typename T>
	inline SPVoid SPFaceGrid2D<T>::setZero()
	{
		for(SPUInt i=0;i<m_UFace.size(); ++i ) m_UFace[i]=(T)0;
		for(SPUInt i=0;i<m_VFace.size(); ++i ) m_VFace[i]=(T)0;
	}

	template <typename T>
	SPVoid SPFaceGrid2D<T>::setValue( const T& x, const T& y )
	{
		for(SPUInt i=0;i<m_UFace.size(); ++i ) m_UFace[i]=x;
		for(SPUInt i=0;i<m_VFace.size(); ++i ) m_VFace[i]=y;
	}
	// 
	// template <typename T>
	// inline SPVoid SPFaceGrid2D<T>::setValue( const SPInt& idx, const T& x, const T& y )
	// {
	// 	#ifdef DEBUGGING
	// 	 VERIFY(0<=idx&&idx<size);
	// 	#endif
	// 
	// 	data[idx].set( x, y );
	// }
	// 
	// template <typename T>
	// SPVoid SPFaceGrid2D<T>::setValue( const SPVec2t& v )
	// {
	// 	for( SPInt i=0; i<size; ++i )	{
	// 		data[i].set( v );
	// 	}
	// }
	// 
	// template <typename T>
	// inline SPVoid SPFaceGrid2D<T>::setValue( const SPInt& idx, const SPVec2t& v )
	// {
	// 	#ifdef DEBUGGING
	// 	 VERIFY(0<=idx&&idx<size);
	// 	#endif
	// 
	// 	data[idx].set( v );
	// }

	template <typename T>
	SPFaces2D<T> SPFaceGrid2D<T>::getFaces( const SPInt& i, const SPInt& j ) const
	{
		SPVec2t m_Upper( getUFace(i+1,j),getVFace(i,j+1) );
		SPVec2t m_Lower( getUFace(i,j),getVFace(i,j) );
		return SPFaces2D<T>(m_Upper,m_Lower);
	}

	template <typename T>
	SPFaces2D<T> SPFaceGrid2D<T>::getFaces( const SPVec2i& idx ) const
	{
		return getFaces(idx.x,idx.y);
	}

	template <typename T>
	SPVec2t SPFaceGrid2D<T>::getCenterValue( const SPInt& i, const SPInt& j ) const
	{
		SPVec2t m_Upper( getUFace(i+1,j),getVFace(i,j+1) );
		SPVec2t m_Lower( getUFace(i,j),getVFace(i,j) );
		return (T)0.5*(m_Upper+m_Lower);
	}

	template <typename T>
	SPVec2t SPFaceGrid2D<T>::getCenterValue( const SPVec2i& idx ) const
	{
		return getCenterValue(idx.x,idx.y);
	}

	template <typename T>
	SPVec2t SPFaceGrid2D<T>::getCornerValue( const SPInt& i, const SPInt& j ) const
	{
		const SPInt xface_y0 = clamp<SPInt>(j-1,0,m_Ny-1);
		const SPInt xface_y1 = clamp<SPInt>(j  ,0,m_Ny-1);

		const SPInt yface_x0 = clamp<SPInt>(i-1,0,m_Nx-1);
		const SPInt yface_x1 = clamp<SPInt>(i  ,0,m_Nx-1);

		const T u = (T)0.5*( getUFace(i,xface_y0) + getUFace(i,xface_y1) );
		const T v = (T)0.5*( getVFace(yface_x0,j) + getVFace(yface_x1,j) );

		return SPVec2t(u,v);
	}

	template <typename T>
	SPVec2t SPFaceGrid2D<T>::getCornerValue( const SPVec2i& cornerIndex ) const
	{
		return getCornerValue(cornerIndex.x,cornerIndex.y);
	}

	template <typename T>
	SPVec2t SPFaceGrid2D<T>::positionToIndexUFace(const SPVec2t &pos) const
	{
		SPVec2t t_index;
		t_index.x = pos.x;
		t_index.y = pos.y - m_Dy*0.5;

		t_index.x /= m_Dx;
		t_index.y /= m_Dy;

		return t_index;
	}
	template <typename T>
	SPVec2t SPFaceGrid2D<T>::positionToIndexVFace(const SPVec2t &pos) const
	{
		SPVec2t t_index;
		t_index.x = pos.x - m_Dx*0.5;
		t_index.y = pos.y;

		t_index.x /= m_Dx;
		t_index.y /= m_Dy;

		return t_index;
	}

	template <typename T>
	SPVec2t SPFaceGrid2D<T>::getInterpolatedValue( const SPVec2t& pos ) const
	{
		SPVec2t float_index = positionToIndexUFace(pos);

		SPVec2i int_index;
		int_index.x = clamp<SPInt>( (SPInt)floor(float_index.x), 0, m_NxPlus1-2 );
		int_index.y = clamp<SPInt>( (SPInt)floor(float_index.y), 0, m_Ny-2 );

		SPVec2d factor;
		factor = float_index - (SPVec2d)int_index;

		const T u_value = BiLinearInterpolation( 
			getUFace(int_index.x  ,int_index.y  ), 
			getUFace(int_index.x+1,int_index.y  ), 
			getUFace(int_index.x+1,int_index.y+1), 
			getUFace(int_index.x  ,int_index.y+1),
			factor.x, factor.y );



		float_index = positionToIndexVFace(pos);

		int_index.x = clamp<SPInt>( (SPInt)floor(float_index.x), 0, m_Nx-2 );
		int_index.y = clamp<SPInt>( (SPInt)floor(float_index.y), 0, m_NyPlus1-2 );

		factor = float_index - (SPVec2d)int_index;

		const T v_value = BiLinearInterpolation( 
			getVFace(int_index.x  ,int_index.y  ), 
			getVFace(int_index.x+1,int_index.y  ), 
			getVFace(int_index.x+1,int_index.y+1), 
			getVFace(int_index.x  ,int_index.y+1),
			factor.x, factor.y );

		return SPVec2t (u_value,v_value);

	}

	template <typename T>
	SPBool SPFaceGrid2D<T>::save( const SPChar* filePathName )
	{
	//	ofstream fout;
	//	fout.open( filePathName, ios::binary );
	//	if( fout.fail() ) return SPFALSE;
	//
	//	fout.close();
		return SPTRUE;
	}

	template <typename T>
	SPBool SPFaceGrid2D<T>::load( const SPChar* filePathName )
	{
	//	reset();
	//
	//	ifstream fin;
	//	fin.open( filePathName, ios::binary );
	//	if( fin.fail() ) return SPFALSE;
	//
	//	fin.close();
		return SPTRUE;
	}

}

#endif //_SP_FACE_GRID_2D_H_

