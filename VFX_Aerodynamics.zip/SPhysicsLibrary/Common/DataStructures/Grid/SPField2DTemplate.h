/**
* @file SPField2DTemplate.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_FIELD_2D_TEMPLATE_H_
#define _SP_FIELD_2D_TEMPLATE_H_

#include "SPDefines.h"

#include "SPField2DBase.h"
#include <vector>

namespace SPhysics
{

	/**
	* @class     SPField2DTemplate
	* @brief     2D field template
	*/
	template <typename T>
	class SPField2DTemplate : public SPField2DBase
	{
	public:
		std::vector<T> m_Data;	//!< Data

	public:
		/**
		* @brief     Constructor
		*/
		SPField2DTemplate() { reset(); } // default constructor
		/**
		* @brief     Constructor
		* @param     [IN] @b sf Copy Constructor
		*/
		SPField2DTemplate( const SPField2DTemplate<T>& sf ) : SPField2DBase(sf) { copy( sf ); }
		/**
		* @brief     Constructor
		* @param     [IN] @b nx grid resolution x
		* @param     [IN] @b ny grid resolution y
		* @param     [IN] @b lx grid dimension x
		* @param     [IN] @b ly grid dimension y
		* @param     [IN] @b loc sampling point location 
		*/
		SPField2DTemplate( const SPInt& nx,const SPInt& ny, const SPDouble& lx,const SPDouble& ly, const SPInt& loc ) { set( nx,ny, lx,ly, loc ); }
		/**
		* @brief     Constructor
		* @param     [IN] @b resolution grid resolution
		* @param     [IN] @b m_Size grid dimension
		* @param     [IN] @b loc sampling point location 
		*/
		SPField2DTemplate( const SPVec2i& resolution, const SPVec2d& m_Size, const SPInt& loc ) { set( resolution, m_Size, loc ); }

		/**
		* @brief      Destructor
		*/
		virtual ~SPField2DTemplate() { reset(); }

		/**
		* @brief     Copy data
		* @param     [IN] @b sf	 copy object
		* @return     SPVoid
		*/
		SPVoid copy( const SPField2DTemplate<T>& sf);
		
		/**
		* @brief     Assign data from other instance
		*/
		SPField2DTemplate<T>& operator=( const SPField2DTemplate<T>& sf)
		{
			if(this != &sf) { copy( sf ); }
			return *this;
		}

		/**
		* @brief     Reset the data sets
		* @return     SPVoid
		*/
		SPVoid reset()
		{	
			m_Data.clear();
			SPField2DBase::reset();
		}

		/**
		* @brief     Set a Field
		* @param     [IN] @b nx grid resolution x
		* @param     [IN] @b ny grid resolution y
		* @param     [IN] @b lx grid dimension x
		* @param     [IN] @b ly grid dimension y
		* @param     [IN] @b loc sampling point location 
		* @return     SPBool
		*/
		SPBool set( const SPInt& nx,const SPInt& ny, const SPDouble& lx,const SPDouble& ly, const SPInt& loc ); // resolution, dimension, location
		
		/**
		* @brief     Set the data sets
		* @param     [IN] @b res grid resolution
		* @param     [IN] @b dim grid dimension
		* @param     [IN] @b loc sampling point location 
		* @return     SPBool
		*/
		SPBool set( const SPVec2i& res, const SPVec2d& dim, const SPInt& loc ) { return set( res.x,res.y, dim.x,dim.y, loc ); }

		/**
		* @brief	Set the data sets to Zero    		
		* @return     SPVoid
		*/
		SPVoid setZero();

		/**
		* @brief     Set value to scalar		
		* @param     [IN] @b scalar scalar value
		* @return     SPVoid
		*/
		SPVoid setValue( const T& scalar );
		
		/**
		* @brief     Set value to scalar		
		* @param     [IN] @b idx index
		* @param     [IN] @b scalar scalar value
		* @return     SPVoid
		*/
		SPVoid setValue( const SPInt& idx, const T& scalar ) { m_Data[idx] = scalar; }

		// get
		/**
		* @brief	Get the resolution     				
		* @return     SPVec2i
		*/
		virtual SPVec2i getResolution() const { return SPVec2i(m_NX,m_NY); }
		
		/**
		* @brief	Get the dimension     				
		* @return     SPVec2i
		*/
		virtual SPVec2d getDimension() const { return SPVec2d(m_Lx,m_Ly); }
		
		/**
		* @brief	Get the cell size     				
		* @return     SPVec2i
		*/
		virtual SPVec2d getCellSize() const { return SPVec2d(m_Dx,m_Dy); }

		/**
		* @brief	Get cell data by plane index
		*/
		T&       operator[]( const SPInt& idx ) { return m_Data[idx]; }
		/**
		* @brief	Get cell data by plane index
		*/
		const T& operator[]( const SPInt& idx ) const { return m_Data[idx]; }
		/**
		* @brief	Get cell data by 2d indices
		*/
		T&       operator()( const SPInt& i, const SPInt& j ) { return m_Data[index(i,j)]; }
		/**
		* @brief	Get cell data by 2d indices
		*/
		const T& operator()( const SPInt& i, const SPInt& j ) const { return m_Data[index(i,j)]; }
		/**
		* @brief	Get cell data by 2d indices stored in vector
		*/
		T&       operator()( const SPVec2i& idx ) { return this->operator()(idx.x,idx.y); }
		/**
		* @brief	Get cell data by 2d indices stored in vector
		*/
		const T& operator()( const SPVec2i& idx ) const { return this->operator()(idx.x,idx.y); }

		/**
		* @brief	Get the value
		* @param     [IN] @b idx index
		* @return     T
		*/
		T getValue( const SPInt& idx ) const { return m_Data[idx]; }


		/**
		* @brief     Get the pointer of data
		* @return     T *
		*/
		T* pointer() { return &m_Data[0]; }

		// file
		/**
		* @brief     Save data file
		* @param     [IN] @b file_name file name
		* @return     SPVoid
		*/
		SPVoid save( const std::string& file_name );
		
		/**
		* @brief     Load data file
		* @param     [IN] @b file_name file name
		* @return     SPBool
		*/
		SPBool load( const std::string& file_name );

		/**
		* @brief     Swap data
		* @param     [IN] @b other other
		* @return     SPBool
		*/
		SPBool swap( SPField2DTemplate<T>& other );
		
		/**
		* @brief     Change the reverse sign 				
		* @return     SPVoid
		*/
		SPVoid reverseSign();

		/**
		* @brief     Get sum of elements		
		* @return     T
		*/
		T getSumOfElements() const;

	protected:
		/**
		* @brief     Allocate
		*/
		SPBool allocate();
	};

	template <typename T>
	SPVoid SPField2DTemplate<T>::copy( const SPField2DTemplate<T>& sf )
	{
		reset();
		SPField2DBase::copy( sf );
		set( sf.m_Nx,sf.m_Ny, sf.m_Lx,sf.m_Ly, sf.m_Location );
		m_Data = sf.m_Data;
	}

	template <typename T>
	inline SPBool SPField2DTemplate<T>::allocate()
	{
		m_Data.clear();
		m_Data.resize(m_Size);

		return SPTRUE;
	}

	template <typename T>
	inline SPBool SPField2DTemplate<T>::set( const SPInt& nx,const SPInt& ny, const SPDouble& lx,const SPDouble& ly, const SPInt& loc )
	{
		if( nx <= 0 || ny <= 0 )
		{
			std::cout<<"Error@SPField2DTemplate::set(): Invalid resolution."<<std::endl;
			return SPFALSE;
		}

		if( lx <= 0 || ly <= 0 )
		{
			std::cout<<"Error@SPField2DTemplate::set(): Invalid dimension."<<std::endl;
			return SPFALSE;
		}

		SPField2DBase::set( nx,ny, lx,ly, loc );

		switch( loc )
		{
			case atCELL:
			{
				m_Offset = m_Nx;
				m_NX = m_Nx;
				m_NY = m_Ny;
				m_Size = m_NumCells;
				if(!allocate()) { return SPFALSE; }
				break;
			}

			case atUFACE:
			{
				m_Offset = m_NxPlus1;
				m_NX = m_NxPlus1;
				m_NY = m_Ny;
				m_Size = m_NumUFaces;
				if(!allocate()) { return SPFALSE; }
				break;
			}

			case atVFACE:
			{
				m_Offset = m_Nx;
				m_NX = m_Nx;
				m_NY = m_NyPlus1;
				m_Size = m_NumVFaces;
				if(!allocate()) { return SPFALSE; }
				break;
			}

			case atXEDGE:
			{
				m_Offset = m_Nx;
				m_NX = m_Nx;
				m_NY = m_NyPlus1;
				m_Size = m_NumXEdges;
				if(!allocate()) { return SPFALSE; }
				break;
			}

			case atYEDGE:
			{
				m_Offset = m_NxPlus1;
				m_NX = m_NxPlus1;
				m_NY = m_Ny;
				m_Size = m_NumYEdges;
				if(!allocate()) { return SPFALSE; }
				break;
			}

			case atNODE:
			{
				m_Offset = m_NxPlus1;
				m_NX = m_NxPlus1;
				m_NY = m_NyPlus1;
				m_Size = m_NumNodes;
				if(!allocate()) { return SPFALSE; }
				break;
			}

			default:
			{
				std::cout<<"Error@SPField2DTemplate::set(): Invalid m_Location."<<std::endl;
				return SPFALSE;
			}

		}

		setZero();

		return SPTRUE;
	}

	template<typename T>
	inline SPVoid SPField2DTemplate<T>::setZero()
	{
		const T zero = T();
		#pragma omp parallel for
		for( SPInt i=0; i<m_Size; ++i ) m_Data[i]=zero;
	}

	template<typename T>
	inline SPVoid SPField2DTemplate<T>::setValue( const T& scalar )
	{
		#pragma omp parallel for
		for( SPInt i=0; i<m_Size; ++i ) m_Data[i]=scalar;
	}

	template<typename T>
	inline SPVoid SPField2DTemplate<T>::reverseSign()
	{
		#pragma omp parallel for
		for( SPInt i=0; i<m_Size; ++i ) m_Data[i] *= (T)-1;
	}

	template<typename T>
	inline T SPField2DTemplate<T>::getSumOfElements() const
	{
		T sum = 0;
		#pragma omp parallel for reduction(+:sum)
		for( SPInt i=0; i<m_Size; ++i ) sum += m_Data[i];
		return sum;
	}

	template <typename T>
	SPVoid SPField2DTemplate<T>::save( const std::string& file_name )
	{
	//	ofstream fout;
	//	fout.open( file_name, ios::binary );

	//	fout.close();
	}

	template <typename T>
	SPBool SPField2DTemplate<T>::load( const std::string& file_name )
	{
	//	reset();
	//
	//	ifstream fin;
	//	fin.open( file_name, ios::binary );
	//	if( fin.fail() ) return SPFALSE;
	//
	//	fin.close();

		return SPTRUE;
	}

	template <typename T>
	inline SPBool SPField2DTemplate<T>::swap( SPField2DTemplate<T>& other )
	{
		if( m_Size != other.getSize() ) {
			std::cout<<"Error@SPField2DTemplate::swap(): Different m_Size."<<std::endl;
			return SPFALSE;
		}

		if( m_Location != other.getLocation() ) {
			std::cout<<"Error@SPField2DTemplate::swap(): Different m_Location."<<std::endl;
			return SPFALSE;
		}

		m_Data.swap( other.m_Data );

		return SPTRUE;
	}

}

#endif //_SP_FIELD_2D_TEMPLATE_H_

