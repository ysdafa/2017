/**
* @file SPField2DBase.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_FIELD_2D_BASE_H_
#define _SP_FIELD_2D_BASE_H_

#include "SPDefines.h"

#include "SPGlobal.h"
#include "SPGrid2D.h"
#include "SPComparison.h"

// inheritance:
// SPObject -> SPGrid2D -> Field2DBase -> SPField2DTemplate

namespace SPhysics
{
	/**
	* @class     SPField2DBase
	* @brief     2D field base class
	*/
	class SPField2DBase : public SPGrid2D
	{
	protected:
		SPInt m_Size;		//!< Size
		SPInt m_Location;	//!< Location

		// for FFT
		SPInt m_Offset;	//!< Offset
		SPInt m_NX;		//!< NX
		SPInt m_NY;		//!< NY
 
	public:
		/**
		* @brief	Constructor     
		*/
		SPField2DBase() { reset(); }
		/**
		* @brief     Constructor
		* @param     [IN] @b f Copy Constructor
		*/
		SPField2DBase( const SPField2DBase& f ): SPGrid2D(f) { copy( f ); }

		/**
		* @brief     Copy data of Grid Field
		* @param     [IN] @b f SPField2DBase
		* @return     SPVoid
		*/
		SPVoid copy( const SPField2DBase& f )
		{
			SPGrid2D::copy( f );
			m_Size   = f.m_Size;
			m_Offset = f.m_Offset;
			m_NX     = f.m_NX;
			m_NY     = f.m_NY;
		}

		/**
		* @brief	Assign Operator
		* @param	[IN] @b f SPField2DBase
		* @return	SPField2DBase&
		*/
		SPField2DBase& operator=( const SPField2DBase& f )
		{
			if(this != &f) { copy( f ); }
			return *this;
		}

		/**
		* @brief     Destructor
		*/
		virtual ~SPField2DBase() {}
		
		/**
		* @brief     Reset data of Grid Field
		* @return     SPVoid
		*/
		virtual SPVoid reset() {
			m_Size = 0;
			m_Location = SPE_NONE;
			m_Offset = 0;
			m_NX = m_NY = 0;
			SPGrid2D::reset();
		}
		
		/**
		* @brief     Set data of Grid Field
		* @param     [IN] @b nx grid resolution x
		* @param     [IN] @b ny grid resolution y
		* @param     [IN] @b lx grid dimension x
		* @param     [IN] @b ly grid dimension y
		* @param     [IN] @b loc sampling point location
		* @return     SPBool
		*/
		virtual SPBool set( const SPInt& nx,const SPInt& ny, const SPDouble& lx,const SPDouble& ly, const SPInt& loc )
		{
			if( nx <= 0 || ny <= 0 )
			{
				std::cout<<"Error@SPField2DBase::set(): Invalid resolution."<<std::endl;
				return SPFALSE;
			}

			if( lx <= 0 || ly <= 0 )
			{
				std::cout<<"Error@SPField2DBase::set(): Invalid dimension."<<std::endl;
				return SPFALSE;
			}

			SPGrid2D::setGrid( nx,ny, lx,ly );

			switch( loc )
			{
				case atCELL:
					m_Offset = m_Nx;
					m_NX = m_Nx;
					m_NY = m_Ny;
					m_Size = m_NumCells;
					break;

				case atNODE:
					m_Offset = m_NxPlus1;
					m_NX = m_NxPlus1;
					m_NY = m_NyPlus1;
					m_Size = m_NumNodes;
					break;

				default:
					std::cout<<"Error@SPField2DBase::set(): Invalid m_Location."<<std::endl;
					return SPFALSE;
			}

			m_Location = loc;

			return SPTRUE;
		}

		/**
		* @brief     Set data of Field
		* @param     [IN] @b res grid resolution
		* @param     [IN] @b dim grid dimension
		* @param     [IN] @b loc sampling point location 
		* @return     SPBool
		*/
		virtual SPBool set( const SPVec2i& res, const SPVec2d& dim, const SPInt& loc )
		{ 
			return set( res.x,res.y, dim.x,dim.y, loc ); 
		}

		/**
		* @brief     Return the sampling point location
		* @return     SPInt
		*/
		SPInt getLocation() const { return m_Location; }
		
		/**
		* @brief     Return the Size
		* @return     SPInt
		*/
		SPInt getSize() const{ return m_Size; }

		/**
		* @brief     i + Offset * j
		* @param     [IN] @b i index i
		* @param     [IN] @b j index j
		* @return     SPInt
		*/
		SPInt index( const SPInt& i, const SPInt& j ) const { return ( i + m_Offset*j ); }
		
		/**
		* @brief     idx.x + Offset * idx.y
		* @param     [IN] @b idx  index
		* @return     SPInt
		*/
		SPInt index( const SPVec2i& idx ) const { return ( idx.x + m_Offset*idx.y ); }
		
		/**
		* @brief     Return the NX
		* @return     SPInt
		*/
		SPInt getNX() const { return m_NX; }
		
		/**
		* @brief     Return the NY
		* @return     SPInt
		*/
		SPInt getNY() const { return m_NY; }

		/**
		* @brief     Convert index to position
		* @param     [IN] @b i index i
		* @param     [IN] @b j index j
		* @return     SPVec2d
		*/
		SPVec2d indexToPosition(const SPInt& i, const SPInt& j) const
		{
			if(m_Location==atNODE) return SPVec2d(i*m_Dx,j*m_Dy);
			else return SPVec2d( (i+0.5)*m_Dx, (j+0.5)*m_Dy); //atCELL
		}
		
		/**
		* @brief     Convert index to position
		* @param     [IN] @b idx index
		* @return     SPVec2d
		*/
		SPVec2d indexToPosition(const SPVec2i& idx) const
		{
			if(m_Location==atNODE) return SPVec2d(idx.x*m_Dx,idx.y*m_Dy);
			else return SPVec2d( (idx.x+0.5)*m_Dx, (idx.y+0.5)*m_Dy); //atCELL
		}
		
		/**
		* @brief     Convert position to index
		* @param     [IN] @b pos position 
		* @return     SPVec2i
		*/
		SPVec2i positionToIndex(const SPVec2d& pos) const
		{ 
			if(m_Location==atNODE)
			{
				SPVec2i int_index;
				int_index.x = clamp<SPInt>( (SPInt)(pos.x/m_Dx), 0, m_NxMinus1 );
				int_index.y = clamp<SPInt>( (SPInt)(pos.y/m_Dy), 0, m_NyMinus1 );
				return int_index; 
			}
			else  //atCELL
			{
				SPVec2d newPosition;
				newPosition.x = pos.x - m_Dx*0.5;
				newPosition.y = pos.y - m_Dy*0.5;

				SPVec2i int_index;
				int_index.x = clamp<SPInt>( (SPInt)floor(newPosition.x/m_Dx), 0, m_Nx-1 );
				int_index.y = clamp<SPInt>( (SPInt)floor(newPosition.y/m_Dy), 0, m_Ny-1 );
				return int_index; 
			}
		}
	};
}

#endif

