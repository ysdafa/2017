/**
* @file SPObject.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.

*/
#ifndef _SP_OBJECT_H_
#define _SP_OBJECT_H_

#include "SPDefines.h"

#include <iostream>


namespace SPhysics
{

	/**
	* @class     SPObject
	* @brief     This class for Physics objects
	*/
	class SPObject
	{
	private:
		std::string description;

	public:
		/**
		* @brief     Constructor
		*/
		SPObject() : description("") {}
		
		/**
		* @brief     Copy Constructor
		*/
		SPObject( const SPObject& input ) { copy( input ); }
		
		/**
		* @brief     Destructor
		*/
		virtual ~SPObject() {}

		/**
		* @brief     Copy the description
		* @param     [IN] @b input SPObject
		* @return     SPVoid
		*/
		SPVoid copy( const SPObject& input ) { this->description = input.description; }

		/**
		 * @brief Assign value from other instance
		 */
		SPObject& operator=( const SPObject& input )
		{
			if(this != &input) { copy( input ); }
			return *this;
		}

	};

}

#endif //_SP_OBJECT_H_

