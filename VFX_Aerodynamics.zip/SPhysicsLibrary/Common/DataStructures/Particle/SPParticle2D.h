/**
* @file SPParticle2D.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_PARTICLE_2D_H_
#define _SP_PARTICLE_2D_H_

#include "SPDefines.h"

#include "SPObject.h"
#include "SPOperations.h"
#include <vector>
#include <list>

namespace SPhysics
{
	/**
	* @class     SPParticle2D
	* @brief     2D particle
	*/
	template<typename T>
	class SPParticle2D : SPObject
	{

	public:
		SPInt id;					//!< ID
		SPVec2t position;		//!< position
		SPVec2t velocity;		//!< velocity
		SPVec2t normal;		//!< normal
		SPVec2t force;		//!< force (x,y)
		SPVec2t orientation;	//!< orientation
		SPVec4t color;		//!< color

		T mass;				//!< mass
		T radius;			//!< radius
		T opacity;			//!< opacity
		T density;			//!< density
		T temperature;		//!< temperature
		T vorticity;		//!< vorticity
		T phi;				//!< level-set
		T checkPIC;			//!< PIC

		SPInt lifespan;		//!< lifespan
		SPChar type;		//!< type

	public:
		/**
		* @brief	Constructor     
		*/
		SPParticle2D(): id(0), mass((T)1), radius((T)0), opacity((T)0), density((T)0), temperature((T)0), vorticity((T)0), lifespan(0), type(0), phi((T)0), checkPIC((T)0)
		{
			orientation = SPVec2t( 1, 0 );
			color = SPVec4t(1, 1, 1, 1);
		}

		/**
		* @brief	Copy Constructor     
		*/
		SPParticle2D( const SPParticle2D& p ): SPObject()
		{
			copy( p );
			checkPIC = (T)0;
		}

		/**
		* @brief	Assign Operator     
		* @return     SPParticle2D &
		*/
		SPParticle2D& operator=( const SPParticle2D& p )
		{
			if(this != &p) { copy( p ); }
			return *this;
		}

		/**
		* @brief     Copy 
		* @param     [IN] @b p input Particle 
		* @return     SPVoid
		*/
		SPVoid copy( const SPParticle2D& p )
		{
			id          = p.id;
			position    = p.position;
			velocity    = p.velocity;
			normal      = p.normal;
			force		= p.force;
			orientation = p.orientation;
			mass		= p.mass;
			radius      = p.radius;
			opacity     = p.opacity;
			density     = p.density;
			temperature = p.temperature;
			vorticity   = p.vorticity;
			lifespan    = p.lifespan;
			type	    = p.type;
			color		= p.color;
			phi			= p.phi;
		}

		/**
		* @brief     Get the particle attribute (ID)
		* @return     SPInt
		*/
		SPInt getID() const { return id; }
		
		/**
		* @brief     Get the particle attribute (position)
		* @return     SPVec2t
		*/
		SPVec2t getPosition() const { return position; }
		
		/**
		* @brief     Get the particle attribute (velocity)
		* @return     SPVec2t
		*/
		SPVec2t getVelocity() const { return velocity; }
		
		/**
		* @brief     Get the particle attribute (normal vector)
		* @return     SPVec2t
		*/
		SPVec2t getNormal() const { return normal; }
		
		/**
		* @brief     Get the particle attribute (position)
		* @return     SPVec2t
		*/
		SPVec2t getForce() const { return force; }
		
		/**
		* @brief     Get the particle attribute (orientation)
		* @return     SPVec2t
		*/
		SPVec2t getOrientation() const { return orientation; }

				/**
		* @brief     Get the particle attribute (color)
		* @return     SPVec3t
		*/
		SPVec4t getColor() const { return color; }
		
		/**
		* @brief     Get the particle attribute (mass)
		* @return     T
		*/
		T getMass() const { return mass; }
		
		/**
		* @brief     Get the particle attribute (radius)
		* @return     T
		*/
		T getRadius() const { return radius; }
		
		/**
		* @brief     Get the particle attribute (opacity)
		* @return     T
		*/
		T getOpacity() const { return opacity; }
		
		/**
		* @brief     Get the particle attribute (density)
		* @return     T
		*/
		T getDensity() const { return density; }
		
		/**
		* @brief     Get the particle attribute (temperature)
		* @return     T
		*/
		T getTemperature() const { return temperature; }
		
		/**
		* @brief     Get the particle attribute (vorticity)
		* @return     T
		*/
		T getVorticity() const { return vorticity; }
		
		/**
		* @brief     Get the particle attribute (lifespan)
		* @return     SPInt
		*/
		SPInt getLifespan() const { return lifespan; }
		
		/**
		* @brief     Get the particle attribute (type)
		* @return     SPChar
		*/
		SPChar getType() const { return type; }

		/**
		* @brief     Set the particle attribute (ID)
		* @param     [IN] @b _id attribute id
		* @return     SPVoid
		*/
		SPVoid setID( const SPInt _id ) { id = _id; }

		/**
		* @brief     Set the particle attribute (position)
		* @param     [IN] @b p position 
		* @return     SPVoid
		*/
		SPVoid setPosition( const SPVec2t& p ) { position = p; }
		
		/**
		* @brief     Set the particle attribute (position)
		* @param     [IN] @b p particle 
		* @return     SPVoid
		*/
		SPVoid setPosition( const SPParticle2D& p ) { position = p.position; }
		
		/**
		* @brief     Set the particle attribute (position)
		* @param     [IN] @b x  position x
		* @param     [IN] @b y position y
		* @return     SPVoid
		*/
		SPVoid setPosition( const T& x, const T& y ) { position = SPVec2t( x, y ); }

		/**
		* @brief     Set the particle attribute (velocity)
		* @param     [IN] @b v velocity
		* @return     SPVoid
		*/
		SPVoid setVelocity( const SPVec2t& v ) { velocity = v; }
		
		/**
		* @brief     Set the particle attribute (velocity)
		* @param     [IN] @b p particle
		* @return     SPVoid
		*/
		SPVoid setVelocity( const SPParticle2D& p ) { velocity = p.velocity; }
		
		/**
		* @brief     Set the particle attribute (velocity)
		* @param     [IN] @b x velocity 
		* @param     [IN] @b y velocity 
		* @return     SPVoid
		*/
		SPVoid setVelocity( const T& x, const T& y ) { velocity = SPVec2t( x, y ); }

		/**
		* @brief     Set the particle attribute (normal)
		* @param     [IN] @b n normal 
		* @return     SPVoid
		*/
		SPVoid setNormal( const SPVec2t& n ) { normal = n; }
		
		/**
		* @brief     Set the particle attribute (normal)
		* @param     [IN] @b p particle 
		* @return     SPVoid
		*/
		SPVoid setNormal( const SPParticle2D& p ) { normal = p.normal; }
		
		/**
		* @brief     Set the particle attribute (normal)
		* @param     [IN] @b x normal x
		* @param     [IN] @b y normal y
		* @return     SPVoid
		*/
		SPVoid setNormal( const T& x, const T& y ) { normal = SPVec2t( x, y ); }

		/**
		* @brief     Set the particle attribute (force)
		* @param     [IN] @b f force 
		* @return     SPVoid
		*/
		SPVoid setForce( const SPVec2t& f ) { force = f; }
		
		/**
		* @brief     Set the particle attribute (force)
		* @param     [IN] @b p particle 
		* @return     SPVoid
		*/
		SPVoid setForce( const SPParticle2D& p ) { force = p.force; }
		
		/**
		* @brief     Set the particle attribute (force)
		* @param     [IN] @b x force x
		* @param     [IN] @b y force y
		* @return     SPVoid
		*/
		SPVoid setForce( const T& x, const T& y ) { force = SPVec2t( x, y ); }

		/**
		* @brief     Set the particle attribute (vorticity)
		* @param     [IN] @b w vorticity 
		* @return     SPVoid
		*/
		SPVoid setVorticity( const T& w ) { vorticity = w; }
		
		/**
		* @brief     Set the particle attribute (vorticity)
		* @param     [IN] @b p particle 
		* @return     SPVoid
		*/
		SPVoid setVorticity( const SPParticle2D& p ) { vorticity = p.vorticity; }

		/**
		* @brief     Set the particle attribute (orientation)
		* @param     [IN] @b q orientation 
		* @return     SPVoid
		*/
		SPVoid setOrientation( const SPVec2t& q ) { orientation = q; normalize( orientation ); }
		
		/**
		* @brief     Set the particle attribute (orientation)
		* @param     [IN] @b p particle 
		* @return     SPVoid
		*/
		SPVoid setOrientation( const SPParticle2D& p ) { orientation = p.orientation; normalize( orientation ); }

		/**
		* @brief     Set the particle attribute (color)
		* @param     [IN] @b c color
		* @return     SPVoid
		*/
		SPVoid setColor( const SPVec4t& c ) { color = c; }
		
		/**
		* @brief     Set the particle attribute (color)
		* @param     [IN] @b r color
		* @param     [IN] @b g color
		* @param     [IN] @b b color
		* @param     [IN] @b a color
		* @return     SPVoid
		*/
		SPVoid setColor( const T& r, const T& g, const T& b, const T& a ) { color = SPVec4t(r,g,b,a); }

		/**
		* @brief     Set the particle attribute (mass)
		* @param     [IN] @b m mass 
		* @return     SPVoid
		*/
		SPVoid setMass( const T& m ) { mass = m; }
		
		/**
		* @brief     Set the particle attribute (mass)
		* @param     [IN] @b p particle 
		* @return     SPVoid
		*/
		SPVoid setMass( const SPParticle2D& p ) { mass = p.mass; }

		/**
		* @brief     Set the particle attribute (radius)
		* @param     [IN] @b r radius
		* @return     SPVoid
		*/
		SPVoid setRadius( const T& r ) { radius = r; }
		
		/**
		* @brief     Set the particle attribute (radius)
		* @param     [IN] @b p particle 
		* @return     SPVoid
		*/
		SPVoid setRadius( const SPParticle2D& p ) { radius = p.radius; }

		/**
		* @brief     Set the particle attribute (opacity)
		* @param     [IN] @b o opacity 
		* @return     SPVoid
		*/
		SPVoid setOpacity( const T& o ) { opacity = o; }
		
		/**
		* @brief     Set the particle attribute (opacity)
		* @param     [IN] @b p particle 
		* @return     SPVoid
		*/
		SPVoid setOpacity( const SPParticle2D& p ) { opacity = p.opacity; }

		/**
		* @brief     Set the particle attribute (density)
		* @param     [IN] @b d density
		* @return     SPVoid
		*/
		SPVoid setDensity( const T& d ) { density = d; }
		
		/**
		* @brief     Set the particle attribute (density)
		* @param     [IN] @b p particle
		* @return     SPVoid
		*/
		SPVoid setDensity( const SPParticle2D& p ) { density = p.density; }

		/**
		* @brief     Set the particle attribute (temperature)
		* @param     [IN] @b t temperature
		* @return     SPVoid
		*/
		SPVoid setTemperature ( const T& t ) { temperature = t; }
		
		/**
		* @brief     Set the particle attribute (temperature)
		* @param     [IN] @b p particle 
		* @return     SPVoid
		*/
		SPVoid setTemperature ( const SPParticle2D& p ) { temperature = p.temperature; }

		/**
		* @brief     Set the particle attribute (lifespan)
		* @param     [IN] @b l lifespan
		* @return     SPVoid
		*/
		SPVoid setLifespan( const SPInt l ) { lifespan = l; }
		
		/**
		* @brief     Set the particle attribute (lifespan)
		* @param     [IN] @b p particle
		* @return     SPVoid
		*/
		SPVoid setLifespan( const SPParticle2D& p ) { lifespan = p.lifespan; }

		/**
		* @brief     Set the particle attribute (type)
		* @param     [IN] @b t type 
		* @return     SPVoid
		*/
		SPVoid setType( const SPChar t ) { type = t; }
		
		/**
		* @brief     Set the particle attribute (type)
		* @param     [IN] @b p particle
		* @return     SPVoid
		*/
		SPVoid setType( const SPParticle2D& p ) { type = p.type; }

	};

}

#endif //_SP_PARTICLE_2D_H_

