/**
* @file SPParticleset2D.cpp
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/
#include "SPParticleSet2D.h"
#include "SPComparison.h"
#include "SPGlobal.h"
#include "SPRandom.h"
namespace SPhysics
{
	template<typename T>
	SPParticleset2D<T>::SPParticleset2D() 
	{
		reset();
	}
	template<typename T>
	SPParticleset2D<T>::~SPParticleset2D() 
	{
		reset();
	}
	template<typename T>
	SPParticleset2D<T>::SPParticleset2D( const SPParticleset2D<T>& ptc ): SPObject(ptc) 
	{
		copy( ptc );
	}
	template<typename T>
	SPVoid SPParticleset2D<T>::copy( const SPParticleset2D<T>& ptc ) 
	{
		reset();

		SPObject::copy( ptc );

		numParticles = ptc.numParticles;
		attributeBitMask  = ptc.attributeBitMask;

		//TODO How about to make a structure - and assign structures instead of multiple assign operator
		existID          = ptc.existID;
		existPOSITION    = ptc.existPOSITION;
		existVELOCITY    = ptc.existVELOCITY;
		existNORMAL      = ptc.existNORMAL;
		existFORCE		 = ptc.existFORCE;
		existVORTICITY   = ptc.existVORTICITY;
		existORIENTATION = ptc.existORIENTATION;
		existMASS        = ptc.existMASS;
		existRADIUS      = ptc.existRADIUS;
		existOPACITY     = ptc.existOPACITY;
		existDENSITY     = ptc.existDENSITY;
		existTEMPERATURE = ptc.existTEMPERATURE;
		existLIFESPAN    = ptc.existLIFESPAN;
		existTYPE		 = ptc.existTYPE;

		id          = ptc.id;
		position    = ptc.position;
		velocity    = ptc.velocity;
		normal      = ptc.normal;
		force     = ptc.force;
		vorticity   = ptc.vorticity;
		orientation = ptc.orientation;
		mass		= ptc.mass;
		radius      = ptc.radius;
		opacity     = ptc.opacity;
		density     = ptc.density;
		temperature = ptc.temperature;
		lifespan    = ptc.lifespan;
		type		= ptc.type;

		minPt = ptc.minPt;
		maxPt = ptc.maxPt;

	}


	template<typename T>
	SPVoid SPParticleset2D<T>::reset() 
	{
		//sprintf_s( description.c_str(), "%s", "" );
		attributeBitMask = 0;

		existID          = SPFALSE;
		existPOSITION    = SPFALSE;
		existVELOCITY    = SPFALSE;
		existNORMAL      = SPFALSE;
		existFORCE	     = SPFALSE;
		existVORTICITY   = SPFALSE;
		existORIENTATION = SPFALSE;
		existMASS		 = SPFALSE;
		existRADIUS      = SPFALSE;
		existOPACITY     = SPFALSE;
		existDENSITY     = SPFALSE;
		existTEMPERATURE = SPFALSE;
		existLIFESPAN    = SPFALSE;
		existTYPE	     = SPFALSE;

		clear();
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::clear() 
	{
		numParticles = 0;
		nextID = 0;

		id.clear();
		position.clear();
		velocity.clear();
		normal.clear();
		force.clear();
		vorticity.clear();
		orientation.clear();
		mass.clear();
		radius.clear();
		opacity.clear();
		density.clear();
		temperature.clear();
		lifespan.clear();
		type.clear();

		zero( minPt );
		zero( maxPt );
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::resize( const SPInt num )
	{
		clear();
		numParticles = num;
		if( existID          ) { id.resize          ( numParticles ); }
		if( existPOSITION    ) { position.resize    ( numParticles ); }
		if( existVELOCITY    ) { velocity.resize    ( numParticles ); }
		if( existNORMAL      ) { normal.resize      ( numParticles ); }
		if( existFORCE       ) { force.resize     ( numParticles ); }
		if( existVORTICITY   ) { vorticity.resize   ( numParticles ); }
		if( existORIENTATION ) { orientation.resize ( numParticles ); }
		if( existMASS        ) { mass.resize        ( numParticles ); }
		if( existRADIUS      ) { radius.resize      ( numParticles ); }
		if( existOPACITY     ) { opacity.resize     ( numParticles ); }
		if( existDENSITY     ) { density.resize     ( numParticles ); }
		if( existTEMPERATURE ) { temperature.resize ( numParticles ); }
		if( existLIFESPAN    ) { lifespan.resize    ( numParticles ); }
		if( existTYPE        ) { type.resize    ( numParticles ); }
		rebuildID();
	}

	template<typename T>
	SPParticle2D<T> SPParticleset2D<T>::get( const SPInt i ) const 
	{
		SPParticle2D<T> p;
		get( i, p );
		return p;
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::get( const SPInt i, SPParticle2D<T>& p ) const 
	{
		if( existID          ) { p.id          = id[i];       }
		if( existPOSITION    ) { p.position    = position[i];    }
		if( existVELOCITY    ) { p.velocity    = velocity[i];    }
		if( existNORMAL      ) { p.normal      = normal[i];      }
		if( existFORCE       ) { p.force       = force[i];       }
		if( existVORTICITY   ) { p.vorticity   = vorticity[i];   }
		if( existORIENTATION ) { p.orientation = orientation[i]; }
		if( existRADIUS      ) { p.radius      = radius[i];      }
		if( existOPACITY     ) { p.opacity     = opacity[i];     }
		if( existDENSITY     ) { p.density     = density[i];     }
		if( existTEMPERATURE ) { p.temperature = temperature[i]; }
		if( existLIFESPAN    ) { p.lifespan    = lifespan[i];    }
		if( existTYPE        ) { p.type    = type[i];    }
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::append( const SPParticle2D<T>& p ) 
	{
		if( existID ) { // automatic assign
			//if( numParticles == 0 ) { id.push_back( 0 );                    }
			//else                    { id.push_back( ++id[numParticles-1] ); }
			id.push_back( nextID++ );
		}
		if( existPOSITION ) { position.push_back( p.position );
		minPt.x = minimum( minPt.x, p.position.x );
		minPt.y = minimum( minPt.y, p.position.y );
		maxPt.x = maximum( maxPt.x, p.position.x );
		maxPt.y = maximum( maxPt.y, p.position.y );
		}
		if( existVELOCITY    ) { velocity.push_back    ( p.velocity    ); }
		if( existNORMAL      ) { normal.push_back      ( p.normal      ); }
		if( existFORCE		 ) { force.push_back       ( p.force       ); }
		if( existVORTICITY   ) { vorticity.push_back   ( p.vorticity   ); }
		if( existORIENTATION ) { orientation.push_back ( p.orientation ); }
		if( existMASS        ) { mass.push_back        ( p.mass        ); }
		if( existRADIUS      ) { radius.push_back      ( p.radius      ); }
		if( existOPACITY     ) { opacity.push_back     ( p.opacity     ); }
		if( existDENSITY     ) { density.push_back     ( p.density     ); }
		if( existTEMPERATURE ) { temperature.push_back ( p.temperature ); }
		if( existLIFESPAN    ) { lifespan.push_back    ( p.lifespan    ); }
		if( existTYPE        ) { type.push_back    ( p.type    ); }

		++numParticles;
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::append( const SPParticleset2D<T>& ptc ) 
	{
		SPInt num = ptc.getNumParticles();

		if( existID ) {
			for( SPInt i=0; i<num; ++i ) {
				id.push_back( nextID++ );
			}
		}

		if( existPOSITION ) {
			if( ptc.hasPosition() ) { SPVec2t pos;
			for( SPInt i=0; i<num; ++i ) {
				pos = ptc.position[i];
				position.push_back( pos );
				minPt.x = minimum( minPt.x, pos.x );
				minPt.y = minimum( minPt.y, pos.y );
				maxPt.x = maximum( minPt.x, pos.x );
				maxPt.y = maximum( minPt.y, pos.y );
			}
			} else {
				for( SPInt i=0; i<num; ++i ) {
					position.push_back( SPVec2t() );
				}
			}
		}

		if( existVELOCITY ) {
			if( ptc.hasVelocity() ) {
				for( SPInt i=0; i<num; ++i ) {
					velocity.push_back( ptc.velocity[i] );
				}
			} else {
				for( SPInt i=0; i<num; ++i ) {
					velocity.push_back( SPVec2t() );
				}
			}
		}

		if( existNORMAL ) {
			if( ptc.hasNormal() ) {
				for( SPInt i=0; i<num; ++i ) {
					normal.push_back( ptc.normal[i] );
				}
			} else {
				for( SPInt i=0; i<num; ++i ) {
					normal.push_back( SPVec2t() );
				}
			}
		}

		if( existFORCE ) {
			if( ptc.hasForce() ) {
				for( SPInt i=0; i<num; ++i ) {
					force.push_back( ptc.force[i] );
				}
			} else {
				for( SPInt i=0; i<num; ++i ) {
					force.push_back( SPVec2t() );
				}
			}
		}

		if( existVORTICITY ) {
			if( ptc.hasVorticity() ) {
				for( SPInt i=0; i<num; ++i ) {
					vorticity.push_back( ptc.vorticity[i] );
				}
			} else {
				for( SPInt i=0; i<num; ++i ) {
					vorticity.push_back( 0 );
				}
			}
		}

		if( existORIENTATION ) {
			if( ptc.hasOrientation() ) {
				for( SPInt i=0; i<num; ++i ) {
					orientation.push_back( ptc.orientation[i] );
				}
			} else {
				for( SPInt i=0; i<num; ++i ) {
					orientation.push_back( SPVec2t() );
				}
			}
		}

		if( existMASS ) {
			if( ptc.hasMass() ) {
				for( SPInt i=0; i<num; ++i ) {
					mass.push_back( ptc.mass[i] );
				}
			} else {
				for( SPInt i=0; i<num; ++i ) {
					mass.push_back( 1 );
				}
			}
		}

		if( existRADIUS ) {
			if( ptc.hasRadius() ) {
				for( SPInt i=0; i<num; ++i ) {
					radius.push_back( ptc.radius[i] );
				}
			} else {
				for( SPInt i=0; i<num; ++i ) {
					radius.push_back( 0 );
				}
			}
		}

		if( existOPACITY ) {
			if( ptc.hasOpacity() ) {
				for( SPInt i=0; i<num; ++i ) {
					opacity.push_back( ptc.opacity[i] );
				}
			} else {
				for( SPInt i=0; i<num; ++i ) {
					opacity.push_back( 0 );
				}
			}
		}

		if( existDENSITY ) {
			if( ptc.hasDensity() ) {
				for( SPInt i=0; i<num; ++i ) {
					density.push_back( ptc.density[i] );
				}
			} else {
				for( SPInt i=0; i<num; ++i ) {
					density.push_back( 0 );
				}
			}
		}

		if( existTEMPERATURE ) {
			if( ptc.hasTemperature() ) {
				for( SPInt i=0; i<num; ++i ) {
					temperature.push_back( ptc.temperature[i] );
				}
			} else {
				for( SPInt i=0; i<num; ++i ) {
					temperature.push_back( 0 );
				}
			}
		}

		if( existLIFESPAN ) {
			if( ptc.hasLifespan() ) {
				for( SPInt i=0; i<num; ++i ) {
					lifespan.push_back( ptc.lifespan[i] );
				}
			} else {
				for( SPInt i=0; i<num; ++i ) {
					lifespan.push_back( 0 );
				}
			}
		}

		if( existTYPE ) {
			if( ptc.hasType() ) {
				for( SPInt i=0; i<num; ++i ) {
					type.push_back( ptc.type[i] );
				}
			} else {
				for( SPInt i=0; i<num; ++i ) {
					type.push_back( 0 );
				}
			}
		}

		numParticles += num;
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::remove( const std::vector<SPInt>& list ) 
	{
		SPInt listSize = (SPInt)list.size();
		if( listSize == 0 ) { return; }

		std::vector<SPBool> mask( numParticles, SPFALSE );

		SPInt deleteSize = 0;
		for( SPInt i=0; i<listSize; ++i ) {
			if( list[i] >= numParticles ) { continue; }
			mask[list[i]] = SPTRUE;
			++deleteSize;
		}

		if( deleteSize == numParticles ) { clear(); return; }

		SPInt finalSize = numParticles - deleteSize;

		if( existID ) {
			std::vector<SPInt> tmp( finalSize );
			for( SPInt i=0, count=0; i<numParticles; ++i ) {
				if( mask[i] ) { continue; }
				tmp[count++] = id[i];
			}
			id.swap( tmp );
		}

		if( existPOSITION ) {
			std::vector<SPVec2t > tmp( finalSize );
			for( SPInt i=0, count=0; i<numParticles; ++i ) {
				if( mask[i] ) { continue; }
				tmp[count++] = position[i];
			}
			position.swap( tmp );
		}

		if( existVELOCITY ) {
			std::vector<SPVec2t > tmp( finalSize );
			for( SPInt i=0, count=0; i<numParticles; ++i ) {
				if( mask[i] ) { continue; }
				tmp[count++] = velocity[i];
			}
			velocity.swap( tmp );
		}

		if( existNORMAL ) {
			std::vector<SPVec2t > tmp( finalSize );
			for( SPInt i=0, count=0; i<numParticles; ++i ) {
				if( mask[i] ) { continue; }
				tmp[count++] = normal[i];
			}
			normal.swap( tmp );
		}

		if( existFORCE ) {
			std::vector<SPVec2t > tmp( finalSize );
			for( SPInt i=0, count=0; i<numParticles; ++i ) {
				if( mask[i] ) { continue; }
				tmp[count++] = force[i];
			}
			force.swap( tmp );
		}

		if( existVORTICITY ) {
			std::vector<T> tmp( finalSize );
			for( SPInt i=0, count=0; i<numParticles; ++i ) {
				if( mask[i] ) { continue; }
				tmp[count++] = vorticity[i];
			}
			vorticity.swap( tmp );
		}

		if( existORIENTATION ) {
			std::vector<SPVec2t > tmp( finalSize );
			for( SPInt i=0, count=0; i<numParticles; ++i ) {
				if( mask[i] ) { continue; }
				tmp[count++] = orientation[i];
			}
			orientation.swap( tmp );
		}

		if( existMASS ) {
			std::vector<T> tmp( finalSize );
			for( SPInt i=0, count=0; i<numParticles; ++i ) {
				if( mask[i] ) { continue; }
				tmp[count++] = mass[i];
			}
			mass.swap( tmp );
		}

		if( existRADIUS ) {
			std::vector<T> tmp( finalSize );
			for( SPInt i=0, count=0; i<numParticles; ++i ) {
				if( mask[i] ) { continue; }
				tmp[count++] = radius[i];
			}
			radius.swap( tmp );
		}

		if( existOPACITY ) {
			std::vector<T> tmp( finalSize );
			for( SPInt i=0, count=0; i<numParticles; ++i ) {
				if( mask[i] ) { continue; }
				tmp[count++] = opacity[i];
			}
			opacity.swap( tmp );
		}

		if( existDENSITY ) {
			std::vector<T> tmp( finalSize );
			for( SPInt i=0, count=0; i<numParticles; ++i ) {
				if( mask[i] ) { continue; }
				tmp[count++] = density[i];
			}
			density.swap( tmp );
		}

		if( existTEMPERATURE ) {
			std::vector<T> tmp( finalSize );
			for( SPInt i=0, count=0; i<numParticles; ++i ) {
				if( mask[i] ) { continue; }
				tmp[count++] = temperature[i];
			}
			temperature.swap( tmp );
		}

		if( existLIFESPAN ) {
			std::vector<SPInt> tmp( finalSize );
			for( SPInt i=0, count=0; i<numParticles; ++i ) {
				if( mask[i] ) { continue; }
				tmp[count++] = lifespan[i];
			}
			lifespan.swap( tmp );
		}

		if( existTYPE ) {
			std::vector<SPChar> tmp( finalSize );
			for( SPInt i=0, count=0; i<numParticles; ++i ) {
				if( mask[i] ) { continue; }
				tmp[count++] = type[i];
			}
			type.swap( tmp );
		}
		numParticles = finalSize;
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::enable( const SPInt attributes ) 
	{
		SPBool existType = SPFALSE;

		if( attributes & SPE_ID          ) { enableID();          existType=SPTRUE; }
		if( attributes & SPE_POSITION    ) { enablePosition();    existType=SPTRUE; }
		if( attributes & SPE_VELOCITY    ) { enableVelocity();    existType=SPTRUE; }
		if( attributes & SPE_NORMAL      ) { enableNormal();      existType=SPTRUE; }
		if( attributes & SPE_FORCE       ) { enableForce();		  existType=SPTRUE; }
		if( attributes & SPE_VORTICITY   ) { enableVorticity();   existType=SPTRUE; }
		if( attributes & SPE_ORIENTATION ) { enableOrientation(); existType=SPTRUE; }
		if( attributes & SPE_MASS        ) { enableMass();		  existType=SPTRUE; }
		if( attributes & SPE_RADIUS      ) { enableRadius();      existType=SPTRUE; }
		if( attributes & SPE_OPACITY     ) { enableOpacity();     existType=SPTRUE; }
		if( attributes & SPE_DENSITY     ) { enableDensity();     existType=SPTRUE; }
		if( attributes & SPE_TEMPERATURE ) { enableTemperature(); existType=SPTRUE; }
		if( attributes & SPE_LIFESPAN    ) { enableLifespan();    existType=SPTRUE; }
		if( attributes & SPE_TYPE        ) { enableType();    existType=SPTRUE; }

		if( !existType ) {
			std::cout<<"Error@SPParticleset2D<T>::enable(): Invalid attribute."<<std::endl;
		}
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::disable( const SPInt attributes ) 
	{
		SPBool existType = SPFALSE;

		if( attributes & SPE_ID          ) { disableID();          existType=SPTRUE; }
		if( attributes & SPE_POSITION    ) { disablePosition();    existType=SPTRUE; }
		if( attributes & SPE_VELOCITY    ) { disableVelocity();    existType=SPTRUE; }
		if( attributes & SPE_NORMAL      ) { disableNormal();      existType=SPTRUE; }
		if( attributes & SPE_FORCE       ) { disableForce();     existType=SPTRUE; }
		if( attributes & SPE_VORTICITY   ) { disableVorticity();   existType=SPTRUE; }
		if( attributes & SPE_ORIENTATION ) { disableOrientation(); existType=SPTRUE; }
		if( attributes & SPE_MASS        ) { disableMass();        existType=SPTRUE; }
		if( attributes & SPE_RADIUS      ) { disableRadius();      existType=SPTRUE; }
		if( attributes & SPE_OPACITY     ) { disableOpacity();     existType=SPTRUE; }
		if( attributes & SPE_DENSITY     ) { disableDensity();     existType=SPTRUE; }
		if( attributes & SPE_TEMPERATURE ) { disableTemperature(); existType=SPTRUE; }
		if( attributes & SPE_LIFESPAN    ) { disableLifespan();    existType=SPTRUE; }
		if( attributes & SPE_TYPE        ) { disableType();    existType=SPTRUE; }

		if( !existType ) {
			std::cout<<"Error@SPParticleset2D<T>::disable(): Invalid attribute."<<std::endl;
		}
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::enableSameAs( const SPParticleset2D<T>& ptc ) 
	{
		if( ptc.hasID()          ) { enableID();          }
		if( ptc.hasPosition()    ) { enablePosition();    }
		if( ptc.hasVelocity()    ) { enableVelocity();    }
		if( ptc.hasNormal()      ) { enableNormal();      }
		if( ptc.hasForce()       ) { enableForce();       }
		if( ptc.hasVorticity()   ) { enableVorticity();   }
		if( ptc.hasOrientation() ) { enableOrientation(); }
		if( ptc.hasMass()        ) { enableMass();        }
		if( ptc.hasRadius()      ) { enableRadius();      }
		if( ptc.hasOpacity()     ) { enableOpacity();     }
		if( ptc.hasDensity()     ) { enableDensity();     }
		if( ptc.hasTemperature() ) { enableTemperature(); }
		if( ptc.hasLifespan()    ) { enableLifespan();    }
		if( ptc.hasType()        ) { enableType();    }
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::enableID() 
	{
		attributeBitMask |= SPE_ID;
		existID = SPTRUE;

		if( numParticles == 0 ) { return; }

		SPInt size = (SPInt)id.size();

		if( size == numParticles ) { return; }

		std::vector<SPInt> tmp( numParticles );
		for( SPInt i=0; i<size; ++i ) { tmp[i] = id[i]; }
		id.swap( tmp );

		for( SPInt i=size; i<numParticles; ++i ) { id[i] = nextID++; }
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::enablePosition() 
	{
		attributeBitMask |= SPE_POSITION;
		existPOSITION = SPTRUE;

		if( numParticles == 0 ) { return; }

		SPInt size = (SPInt)position.size();

		if( size == numParticles ) { return; }

		std::vector<SPVec2t > tmp( numParticles );
		for( SPInt i=0; i<size; ++i ) { tmp[i] = position[i]; }
		position.swap( tmp );
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::enableVelocity() 
	{
		attributeBitMask |= SPE_VELOCITY;
		existVELOCITY = SPTRUE;

		if( numParticles == 0 ) { return; }

		SPInt size = (SPInt)velocity.size();

		if( size == numParticles ) { return; }

		std::vector<SPVec2t > tmp( numParticles );
		for( SPInt i=0; i<size; ++i ) { tmp[i] = velocity[i]; }
		velocity.swap( tmp );
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::enableNormal() 
	{
		attributeBitMask |= SPE_NORMAL;
		existNORMAL = SPTRUE;

		if( numParticles == 0 ) { return; }

		SPInt size = (SPInt)normal.size();

		if( size == numParticles ) { return; }

		std::vector<SPVec2t > tmp( numParticles );
		for( SPInt i=0; i<size; ++i ) { tmp[i] = normal[i]; }
		normal.swap( tmp );
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::enableForce() 
	{
		attributeBitMask |= SPE_FORCE;
		existFORCE = SPTRUE;

		if( numParticles == 0 ) { return; }

		SPInt size = (SPInt)force.size();

		if( size == numParticles ) { return; }

		std::vector<SPVec2t > tmp( numParticles );
		for( SPInt i=0; i<size; ++i ) { tmp[i] = force[i]; }
		force.swap( tmp );
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::enableVorticity() 
	{
		attributeBitMask |= SPE_VORTICITY;
		existVORTICITY = SPTRUE;

		if( numParticles == 0 ) { return; }

		SPInt size = (SPInt)vorticity.size();

		if( size == numParticles ) { return; }

		std::vector<T> tmp( numParticles );
		for( SPInt i=0; i<size; ++i ) { tmp[i] = vorticity[i]; }
		vorticity.swap( tmp );
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::enableOrientation() 
	{
		attributeBitMask |= SPE_ORIENTATION;
		existORIENTATION = SPTRUE;

		if( numParticles == 0 ) { return; }

		SPInt size = (SPInt)orientation.size();

		if( size == numParticles ) { return; }

		std::vector<SPVec2t > tmp( numParticles );
		for( SPInt i=0; i<size; ++i ) { tmp[i] = orientation[i]; }
		orientation.swap( tmp );
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::enableMass() 
	{
		attributeBitMask |= SPE_MASS;
		existMASS = SPTRUE;

		if( numParticles == 0 ) { return; }

		SPInt size = (SPInt)mass.size();

		if( size == numParticles ) { return; }

		std::vector<T> tmp( numParticles );
		for( SPInt i=0; i<size; ++i ) { tmp[i] = mass[i]; }
		mass.swap( tmp );
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::enableRadius() 
	{
		attributeBitMask |= SPE_RADIUS;
		existRADIUS = SPTRUE;

		if( numParticles == 0 ) { return; }

		SPInt size = (SPInt)radius.size();

		if( size == numParticles ) { return; }

		std::vector<T> tmp( numParticles );
		for( SPInt i=0; i<size; ++i ) { tmp[i] = radius[i]; }
		radius.swap( tmp );
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::enableOpacity() 
	{
		attributeBitMask |= SPE_OPACITY;
		existOPACITY = SPTRUE;

		if( numParticles == 0 ) { return; }

		SPInt size = (SPInt)opacity.size();

		if( size == numParticles ) { return; }

		std::vector<T> tmp( numParticles );
		for( SPInt i=0; i<size; ++i ) { tmp[i] = opacity[i]; }
		opacity.swap( tmp );
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::enableDensity() 
	{
		attributeBitMask |= SPE_DENSITY;
		existDENSITY = SPTRUE;

		if( numParticles == 0 ) { return; }

		SPInt size = (SPInt)density.size();

		if( size == numParticles ) { return; }

		std::vector<T> tmp( numParticles );
		for( SPInt i=0; i<size; ++i ) { tmp[i] = density[i]; }
		density.swap( tmp );
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::enableTemperature() 
	{
		attributeBitMask |= SPE_TEMPERATURE;
		existTEMPERATURE = SPTRUE;

		if( numParticles == 0 ) { return; }

		SPInt size = (SPInt)temperature.size();

		if( size == numParticles ) { return; }

		std::vector<T> tmp( numParticles );
		for( SPInt i=0; i<size; ++i ) { tmp[i] = temperature[i]; }
		temperature.swap( tmp );
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::enableLifespan() 
	{
		attributeBitMask |= SPE_LIFESPAN;
		existLIFESPAN = SPTRUE;

		if( numParticles == 0 ) { return; }

		SPInt size = (SPInt)lifespan.size();

		if( size == numParticles ) { return; }

		std::vector<SPInt> tmp( numParticles );
		for( SPInt i=0; i<size; ++i ) { tmp[i] = lifespan[i]; }
		lifespan.swap( tmp );
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::enableType() 
	{
		attributeBitMask |= SPE_TYPE;
		existTYPE = SPTRUE;

		if( numParticles == 0 ) { return; }

		SPInt size = (SPInt)type.size();

		if( size == numParticles ) { return; }

		std::vector<SPChar> tmp( numParticles );
		for( SPInt i=0; i<size; ++i ) { tmp[i] = type[i]; }
		type.swap( tmp );
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::disableID() 
	{
		attributeBitMask &= ~SPE_ID;
		existID = SPFALSE;
		id.clear();

		if( attributeBitMask == 0 ) { numParticles = 0; }
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::disablePosition() 
	{
		attributeBitMask &= ~SPE_POSITION;
		existPOSITION = SPFALSE;
		position.clear();

		if( attributeBitMask == 0 ) { numParticles = 0; }
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::disableVelocity() 
	{
		attributeBitMask &= ~SPE_VELOCITY;
		existVELOCITY = SPFALSE;
		velocity.clear();

		if( attributeBitMask == 0 ) { numParticles = 0; }
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::disableNormal() 
	{
		attributeBitMask &= ~SPE_NORMAL;
		existNORMAL = SPFALSE;
		normal.clear();

		if( attributeBitMask == 0 ) { numParticles = 0; }
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::disableForce() 
	{
		attributeBitMask &= ~SPE_FORCE;
		existFORCE = SPFALSE;
		force.clear();

		if( attributeBitMask == 0 ) { numParticles = 0; }
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::disableVorticity() 
	{
		attributeBitMask &= ~SPE_VORTICITY;
		existVORTICITY = SPFALSE;
		vorticity.clear();

		if( attributeBitMask == 0 ) { numParticles = 0; }
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::disableOrientation() 
	{
		attributeBitMask &= ~SPE_ORIENTATION;
		existORIENTATION = SPFALSE;
		orientation.clear();

		if( attributeBitMask == 0 ) { numParticles = 0; }
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::disableMass() 
	{
		attributeBitMask &= ~SPE_MASS;
		existMASS = SPFALSE;
		mass.clear();

		if( attributeBitMask == 0 ) { numParticles = 0; }
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::disableRadius() 
	{
		attributeBitMask &= ~SPE_RADIUS;
		existRADIUS = SPFALSE;
		radius.clear();

		if( attributeBitMask == 0 ) { numParticles = 0; }
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::disableOpacity() 
	{
		attributeBitMask &= ~SPE_OPACITY;
		existOPACITY = SPFALSE;
		opacity.clear();

		if( attributeBitMask == 0 ) { numParticles = 0; }
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::disableDensity() 
	{
		attributeBitMask &= ~SPE_DENSITY;
		existDENSITY = SPFALSE;
		density.clear();

		if( attributeBitMask == 0 ) { numParticles = 0; }
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::disableTemperature() 
	{
		attributeBitMask &= ~SPE_TEMPERATURE;
		existTEMPERATURE = SPFALSE;
		temperature.clear();

		if( attributeBitMask == 0 ) { numParticles = 0; }
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::disableLifespan() 
	{
		attributeBitMask &= ~SPE_LIFESPAN;
		existLIFESPAN = SPFALSE;
		lifespan.clear();

		if( attributeBitMask == 0 ) { numParticles = 0; }
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::disableType()
	{
		attributeBitMask &= ~SPE_TYPE;
		existTYPE = SPFALSE;
		type.clear();

		if( attributeBitMask == 0 ) { numParticles = 0; }
	}


	template<typename T>
	SPVoid SPParticleset2D<T>::rebuildID()
	{
		if( !existID ) return;

		SPInt idx = 0;
		for( SPInt i=0; i<numParticles; ++i, ++idx ) {
			id[i] = idx;
		}
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::setID( const SPInt _id )
	{
		enableID();
#pragma omp parallel for
		for( SPInt i=0; i<numParticles; ++i ) {
			id[i] = _id;
		}
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::setPosition( const T& x, const T& y )
	{
		enablePosition();
#pragma omp parallel for
		for( SPInt i=0; i<numParticles; ++i ) {
			position[i] = SPVec2t( x, y );
		}
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::setPosition( const SPVec2t& p )
	{
		enablePosition();
#pragma omp parallel for
		for( SPInt i=0; i<numParticles; ++i ) {
			position[i] = p;
		}
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::setVelocity( const T& x, const T& y )
	{
		enableVelocity();
#pragma omp parallel for
		for( SPInt i=0; i<numParticles; ++i ) {
			velocity[i] = SPVec2t( x, y );
		}
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::setVelocity( const SPVec2t& p )
	{
		enableVelocity();
#pragma omp parallel for
		for( SPInt i=0; i<numParticles; ++i ) {
			velocity[i] =  p;
		}
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::setNormal( const T& x, const T& y )
	{
		enableNormal();
#pragma omp parallel for
		for( SPInt i=0; i<numParticles; ++i ) {
			normal[i] = SPVec2t( x, y );
		}
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::setNormal( const SPVec2t& n )
	{
		enableNormal();
#pragma omp parallel for
		for( SPInt i=0; i<numParticles; ++i ) {
			normal[i] = n;
		}
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::setForce( const T& u, const T& v )
	{
		enableForce();
#pragma omp parallel for
		for( SPInt i=0; i<numParticles; ++i ) {
			force[i]= SPVec2t( u, v );
		}
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::setForce( const SPVec2t& t )
	{
		enableForce();
#pragma omp parallel for
		for( SPInt i=0; i<numParticles; ++i ) {
			force[i] = t;
		}
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::setVorticity( const T& w )
	{
		enableVorticity();
#pragma omp parallel for
		for( SPInt i=0; i<numParticles; ++i ) {
			vorticity[i] = w;
		}
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::setOrientation( const SPVec2t& o ) 
	{
		enableOrientation();
#pragma omp parallel for
		for( SPInt i=0; i<numParticles; ++i ) {
			orientation[i] = o;
		}
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::setMass( const T& m ) 
	{
		enableMass();
#pragma omp parallel for
		for( SPInt i=0; i<numParticles; ++i ) {
			mass[i] = m;
		}
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::setMass( const T& min_mass, const T& max_mass )
	{
		if( min_mass >= max_mass ) {
			std::cout<<"Error@SPParticleset2D<T>::setMass(): Invalid mass."<<std::endl;
			return;
		}
		enableMass();
#pragma omp parallel for
		for( SPInt i=0; i<numParticles; ++i ) {
			mass[i] = random( min_mass, max_mass );
		}
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::setRadius( const T& r )
	{
		enableRadius();
#pragma omp parallel for
		for( SPInt i=0; i<numParticles; ++i ) { radius[i] = r; }
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::setRadius( const T& minRadius, const T& maxRadius )
	{
		if( minRadius >= maxRadius ) {
			std::cout<<"Error@SPParticleset2D<T>::setRadius(): Invalid radius."<<std::endl;
			return;
		}
		enableRadius();
#pragma omp parallel for
		for( SPInt i=0; i<numParticles; ++i ) {
			radius[i] = random( minRadius, maxRadius );
		}
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::setOpacity( const T& r )
	{
		enableOpacity();
#pragma omp parallel for
		for( SPInt i=0; i<numParticles; ++i ) {
			opacity[i] = r;
		}
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::setDensity( const T& d )
	{
		enableDensity();
#pragma omp parallel for
		for( SPInt i=0; i<numParticles; ++i ) {
			density[i] = d;
		}
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::setTemperature( const T& t )
	{
		enableTemperature();
#pragma omp parallel for
		for( SPInt i=0; i<numParticles; ++i ) {
			temperature[i] = t;
		}
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::setLifespan( const SPInt l )
	{
		enableLifespan();
#pragma omp parallel for
		for( SPInt i=0; i<numParticles; ++i ) {
			lifespan[i] = l;
		}
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::setLifespan( const SPInt min, const SPInt max )
	{
#pragma omp parallel for
		for( SPInt i=0; i<numParticles; ++i ) {
			lifespan[i] = random(min,max);
		}
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::setType( const SPChar t )
	{
		enableType();
#pragma omp parallel for
		for( SPInt i=0; i<numParticles; ++i ) {
			type[i] = t;
		}
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::addAcceleration( const T& ax, const T& ay, const T& dt )
	{
		if( !existVELOCITY ) {
			std::cout<<"Error@SPParticleset2D<T>::addAcceleration(): No velocity."<<std::endl;
			return;
		}
		T axDt = ax * dt;
		T ayDt = ay * dt;

#pragma omp parallel for
		for( SPInt i=0; i<numParticles; ++i ) {
			velocity[i].x += axDt;
			velocity[i].y += ayDt;
		}
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::addAcceleration( const SPVec2t& acc, const T& dt )
	{
		if( !existVELOCITY ) {
			std::cout<<"Error@SPParticleset2D<T>::addAcceleration(): No velocity."<<std::endl;
			return;
		}
		SPVec2t accDt;
		addMultiply( accDt, dt, acc );

#pragma omp parallel for
		for( SPInt i=0; i<numParticles; ++i ) {
			increase( velocity[i], accDt );
		}
	}

	template<typename T>
	SPVoid SPParticleset2D<T>::calculateMinMaxPt()
	{
		minPt = SPVec2t(  LARGE,  LARGE );
		maxPt = SPVec2t( -LARGE, -LARGE );

		for( SPInt i=0; i<numParticles; ++i ) {
			minPt.x = minimum( minPt.x, position[i].x );
			minPt.y = minimum( minPt.y, position[i].y );
			maxPt.x = maximum( maxPt.x, position[i].x );
			maxPt.y = maximum( maxPt.y, position[i].y );
		}
	}
	/*
	template<typename T>
	SPVoid SPParticleset2D<T>::print( SPInt index, SPInt attribute )
	{
	index = CLAMP( index, 0, numParticles-1 );
		std::cout.precision( 3 );
	std::cout.setf( std::ios::showpoint | std::ios::showpos );
		switch( attribute ) {
			case SPE_ID:

	if( !existID ) { std::cout<<"Not exist"<<std::endl; return; }
	std::cout<<index<<": "<<id[index]<<std::endl;
	break;

	case SPE_POSITION:

	if( !existPOSITION ) { std::cout<<"Not exist"<<std::endl; return; }
	std::cout<<index<<": "<<position[index]<<std::endl;
	break;

	case SPE_VELOCITY:

	if( !existVELOCITY ) { std::cout<<"Not exist"<<std::endl; return; }
	std::cout<<index<<": "<<velocity[index]<<std::endl;
	break;

	case SPE_NORMAL:

	if( !existNORMAL ) { std::cout<<"Not exist"<<std::endl; return; }
	std::cout<<index<<": "<<normal[index]<<std::endl;
	break;

	case TEXTURE:

	if( !existTEXTURE ) { std::cout<<"Not exist"<<std::endl; return; }
	std::cout<<index<<": "<<texture[index]<<std::endl;
	break;

	case SPE_VORTICITY:

	if( !existVORTICITY ) { std::cout<<"Not exist"<<std::endl; return; }
	std::cout<<index<<": "<<vorticity[index]<<std::endl;
	break;

	case SPE_ORIENTATION:

	if( !existORIENTATION ) { std::cout<<"Not exist"<<std::endl; return; }
	std::cout<<index<<": "<<orientation[index]<<std::endl;
	break;

	case SPE_RADIUS:

	if( !existRADIUS ) { std::cout<<"Not exist"<<std::endl; return; }
	std::cout<<index<<": "<<radius[index]<<std::endl;
	break;

	case SPE_OPACITY:

	if( !existOPACITY ) { std::cout<<"Not exist"<<std::endl; return; }
	std::cout<<index<<": "<<opacity[index]<<std::endl;
	break;

	case SPE_DENSITY:

	if( !existDENSITY ) { std::cout<<"Not exist"<<std::endl; return; }
	std::cout<<index<<": "<<density[index]<<std::endl;
	break;

	case SPE_TEMPERATURE:

	if( !existTEMPERATURE ) { std::cout<<"Not exist"<<std::endl; return; }
	std::cout<<index<<": "<<temperature[index]<<std::endl;
	break;

	case SPE_LIFESPAN:

	if( !existLIFESPAN ) { std::cout<<"Not exist"<<std::endl; return; }
	std::cout<<index<<": "<<lifespan[index]<<std::endl;
	break;

	default:

	std::cout<<"Error@SPParticleset2D<T>::print(): Invalid attribute."<<std::endl;
	return;

	}

	}

	template<typename T>
	SPVoid SPParticleset2D<T>::print( SPInt start, SPInt end, SPInt attribute )
	{

	// 	start = CLAMP( start, 0, numParticles-1 );
	// 	end = CLAMP( end,   0, numParticles-1 );
	// 	if( start > end ) swap( start, end );
	// 
	// 	std::cout.precision( 3 );
	// 	std::cout.setf( std::ios::showpoint | std::ios::showpos );
	// 
	// 	switch( attribute ) {
	// 
	// 		case SPE_ID:
	// 
	// 			if( !existID ) { std::cout<<"Not exist"<<std::endl; return; }
	// 			for( SPInt i=start; i<=end; ++i ) { std::cout<<i<<": "<<id[i]<<std::endl; }
	// 			break;
	// 
	// 		case SPE_POSITION:
	// 
	// 			if( !existPOSITION ) { std::cout<<"Not exist"<<std::endl; return; }
	// 			for( SPInt i=start; i<=end; ++i ) { std::cout<<i<<": "<<position[i]<<std::endl; }
	// 			break;
	// 
	// 		case SPE_VELOCITY:
	// 
	// 			if( !existVELOCITY ) { std::cout<<"Not exist"<<std::endl; return; }
	// 			for( SPInt i=start; i<=end; ++i ) { std::cout<<i<<": "<<velocity[i]<<std::endl; }
	// 			break;
	// 
	// 		case SPE_NORMAL:
	// 
	// 			if( !existNORMAL ) { std::cout<<"Not exist"<<std::endl; return; }
	// 			for( SPInt i=start; i<=end; ++i ) { std::cout<<i<<": "<<normal[i]<<std::endl; }
	// 			break;
	// 
	// 		case TEXTURE:
	// 
	// 			if( !existTEXTURE ) { std::cout<<"Not exist"<<std::endl; return; }
	// 			for( SPInt i=start; i<=end; ++i ) { std::cout<<i<<": "<<texture[i]<<std::endl; }
	// 			break;
	// 
	// 		case SPE_VORTICITY:
	// 
	// 			if( !existVORTICITY ) { std::cout<<"Not exist"<<std::endl; return; }
	// 			for( SPInt i=start; i<=end; ++i ) { std::cout<<i<<": "<<vorticity[i]<<std::endl; }
	// 			break;
	// 
	// 		case SPE_ORIENTATION:
	// 
	// 			if( !existORIENTATION ) { std::cout<<"Not exist"<<std::endl; return; }
	// 			for( SPInt i=start; i<=end; ++i ) { std::cout<<i<<": "<<orientation[i]<<std::endl; }
	// 			break;
	// 
	// 		case SPE_RADIUS:
	// 
	// 			if( !existRADIUS ) { std::cout<<"Not exist"<<std::endl; return; }
	// 			for( SPInt i=start; i<=end; ++i ) { std::cout<<i<<": "<<radius[i]<<std::endl; }
	// 			break;
	// 
	// 		case SPE_OPACITY:
	// 
	// 			if( !existOPACITY ) { std::cout<<"Not exist"<<std::endl; return; }
	// 			for( SPInt i=start; i<=end; ++i ) { std::cout<<i<<": "<<opacity[i]<<std::endl; }
	// 			break;
	// 
	// 		case SPE_DENSITY:
	// 
	// 			if( !existDENSITY ) { std::cout<<"Not exist"<<std::endl; return; }
	// 			for( SPInt i=start; i<=end; ++i ) { std::cout<<i<<": "<<density[i]<<std::endl; }
	// 			break;
	// 
	// 		case SPE_TEMPERATURE:
	// 
	// 			if( !existTEMPERATURE ) { std::cout<<"Not exist"<<std::endl; return; }
	// 			for( SPInt i=start; i<=end; ++i ) { std::cout<<i<<": "<<temperature[i]<<std::endl; }
	// 			break;
	// 
	// 		case SPE_LIFESPAN:
	// 
	// 			if( !existLIFESPAN ) { std::cout<<"Not exist"<<std::endl; return; }
	// 			for( SPInt i=start; i<=end; ++i ) { std::cout<<i<<": "<<lifespan[i]<<std::endl; }
	// 			break;
	// 
	// 		default:
	// 
	// 			std::cout<<"Error@SPParticleset2D<T>::print(): Invalid attribute."<<std::endl;
	// 			return;
	// 
	// 	}
	}
	*/
	template class SPParticleset2D<SPFloat>;
	template class SPParticleset2D<SPDouble>;
}