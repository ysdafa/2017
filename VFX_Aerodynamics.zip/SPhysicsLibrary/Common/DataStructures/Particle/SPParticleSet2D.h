/**
* @file SPParticleset2D.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/
#ifndef _SP_PARTICLE_SET_2D_H_
#define _SP_PARTICLE_SET_2D_H_

#include "SPDefines.h"
#include "SPObject.h"
#include "SPParticle2D.h"
#include <vector>
#include <glm.hpp>


namespace SPhysics
{
	/**
	* @class     SPParticleset2D
	* @brief     Set of 2D particles
	*/
	template<typename T>
	class SPParticleset2D : public SPObject
	{
	private:
		SPInt numParticles;			// num particles
		SPInt attributeBitMask;			// attribute bit mask
		SPInt nextID;
		SPBool existID;
		SPBool existPOSITION;
		SPBool existVELOCITY;
		SPBool existNORMAL;
		SPBool existFORCE;
		SPBool existVORTICITY;
		SPBool existORIENTATION;
		SPBool existMASS;
		SPBool existRADIUS;
		SPBool existOPACITY;
		SPBool existDENSITY;
		SPBool existTEMPERATURE;
		SPBool existLIFESPAN;
		SPBool existTYPE;

	public: // these attributes are declared as 'public' for the efficient usage
		std::vector<SPInt> id;						//!< ID
		std::vector<SPVec2t > position;		//!< position  (x,y)
		std::vector<SPVec2t > velocity;		//!< velocity  (x,y)
		std::vector<SPVec2t > normal;			//!< normal    (x,y)
		std::vector<SPVec2t > force;			//!< force   (x,y)
		std::vector<SPVec2t > orientation;	//!< orientation (q)
		std::vector<T> mass;						//!< mass
		std::vector<T> radius;						//!< radius
		std::vector<T> opacity;						//!< opacity
		std::vector<T> density;						//!< density
		std::vector<T> temperature;					//!< temperature
		std::vector<T> vorticity;					//!< vorticity (w)
		std::vector<SPInt> lifespan;				//!< lifespan
		std::vector<SPChar> type;					//!< type

		// extra attributes
		std::vector<SPVec2t > position0;		//!< old (or temporary) position
		std::vector<SPVec2t > velocity0;		//!< old (or temporary) velocity

		SPVec2t minPt;	//!< minPt
		SPVec2t maxPt;	//!< maxPt

	public:
		/**
		* @brief     Constructor
		*/
		SPParticleset2D();
		/**
		* @brief     Destructor
		*/	
		~SPParticleset2D();
		/**
		* @brief     Copy Constructor
		*/
		SPParticleset2D( const SPParticleset2D& );

		/**
		* @brief     Assign data from other instance
		*/
		SPParticleset2D& operator=( const SPParticleset2D& ptc )
		{
			if(this != &ptc) { copy( ptc ); }
			return *this;	
		}

		/**
		* @brief     Copy data of particle
		* @param     [IN] @b p ParticleSet
		* @return     SPVoid
		*/
		SPVoid copy( const SPParticleset2D& p);

		/**
		* @brief     Get the attribute bit mask
		* @return     SPInt
		*/
		SPInt getAttrBitMask() { return attributeBitMask; }

		/**
		* @brief     Reset all data sets
		* @return     SPVoid
		*/
		SPVoid reset();

		/**
		* @brief     Clear all data sets
		* @return     SPVoid
		*/
		SPVoid clear();

		/**
		* @brief     Resize attribute from the number of particles
		* @param     [IN] @b num number of particles
		* @return     SPVoid
		*/
		SPVoid resize(const SPInt num);

		/**
		* @brief     Get the number of particles
		* @return     SPInt
		*/
		SPInt getNumParticles() const { return numParticles; }

		/**
		* @brief     Return true if particle has ID
		* @return     SPBool
		*/
		SPBool hasID() const { return existID; }

		/**
		* @brief     Return true if particle has position
		* @return     SPBool
		*/
		SPBool hasPosition() const { return existPOSITION; }

		/**
		* @brief     Return true if particle has velocity
		* @return     SPBool
		*/
		SPBool hasVelocity() const { return existVELOCITY; }

		/**
		* @brief     Return true if particle has normal
		* @return     SPBool
		*/
		SPBool hasNormal() const { return existNORMAL; }

		/**
		* @brief     Return true if particle has force
		* @return     SPBool
		*/
		SPBool hasForce() const { return existFORCE; }

		/**
		* @brief     Return true if particle has vorticity
		* @return     SPBool
		*/
		SPBool hasVorticity() const { return existVORTICITY; }

		/**
		* @brief     Return true if particle has orientation
		* @return     SPBool
		*/
		SPBool hasOrientation() const { return existORIENTATION; }

		/**
		* @brief     Return true if particle has mass
		* @return     SPBool
		*/
		SPBool hasMass() const { return existMASS; }
		/**
		* @brief     Return true if particle has radius
		* @return     SPBool
		*/
		SPBool hasRadius() const { return existRADIUS; }
		/**
		* @brief     Return true if particle has opacity
		* @return     SPBool
		*/
		SPBool hasOpacity() const { return existOPACITY; }
		/**
		* @brief     Return true if particle has density
		* @return     SPBool
		*/
		SPBool hasDensity() const { return existDENSITY; }
		/**
		* @brief     Return true if particle has temperature
		* @return     SPBool
		*/
		SPBool hasTemperature() const { return existTEMPERATURE; }
		/**
		* @brief     Return true if particle has lifespan
		* @return     SPBool
		*/
		SPBool hasLifespan() const { return existLIFESPAN; }
		/**
		* @brief     Return true if particle has type
		* @return     SPBool
		*/
		SPBool hasType() const { return existTYPE; }

		/**
		* @brief     Get the attribute of particles ( ID )
		* @param     [IN] @b i index
		* @return     SPInt
		*/
		SPInt getID( const SPInt i ) const { return id[i]; }
		
		/**
		@brief     Get the attribute of particles ( ID )
		* @param     [IN] @b i index
		* @return     SPVec2t
		*/
		SPVec2t getPosition( const SPInt i ) const { return position[i]; }
		
		/**
		* @brief     Get the attribute of particles ( velocity )
		* @param     [IN] @b i index
		* @return     SPVec2t
		*/
		SPVec2t getVelocity( const SPInt i ) const { return velocity[i]; }
		
		/**
		@brief     Get the attribute of particles ( normal )
		* @param     [IN] @b i index
		* @return     SPVec2t
		*/
		SPVec2t getNormal( const SPInt i ) const { return normal[i]; }
		
		/**
		* @brief     Get the attribute of particles ( force )
		* @param     [IN] @b i index
		* @return     SPVec2t
		*/
		SPVec2t getForce( const SPInt i ) const { return force[i]; }
		
		/**
		* @brief     Get the attribute of particles ( orientation )
		* @param     [IN] @b i index
		* @return     SPVec2t
		*/
		SPVec2t getOrientation( const SPInt i ) { return orientation[i]; }
		
		/**
		* @brief     Get the attribute of particles ( mass )
		* @param     [IN] @b i index
		* @return     T
		*/
		T getMass( const SPInt i ) const { return mass[i]; }
		
		/**
		* @brief     Get the attribute of particles ( radius )
		* @param     [IN] @b i index
		* @return     T
		*/
		T getRadius( const SPInt i ) const { return radius[i]; }
		
		/**
		* @brief     Get the attribute of particles ( opacity )
		* @param     [IN] @b i index
		* @return     T
		*/
		T getOpacity( const SPInt i ) const { return opacity[i]; }
		
		/**
		* @brief     Get the attribute of particles ( density )
		* @param     [IN] @b i index
		* @return     T
		*/
		T getDensity( const SPInt i ) const { return density[i]; }
		
		/**
		* @brief     Get the attribute of particles ( temperature )
		* @param     [IN] @b i index
		* @return     T
		*/
		T getTemperature( const SPInt i ) const { return temperature[i]; }
		
		/**
		* @brief     Get the attribute of particles ( vorticity )
		* @param     [IN] @b i index
		* @return     T
		*/
		T getVorticity( const SPInt i ) const { return vorticity[i]; }
		
		/**
		* @brief     Get the attribute of particles ( lifespan )
		* @param     [IN] @b i index
		* @return     SPInt
		*/
		SPInt getLifespan( const SPInt i ) const { return lifespan[i]; }
		
		/**
		* @brief     Get the attribute of particles ( type )
		* @param     [IN] @b i index
		* @return     SPChar
		*/
		SPChar getType( const SPInt i ) const { return type[i]; }

		/**
		* @brief     Get all attributes of particles 
		* @param     [IN] @b i index
		* @return     SPParticle2D<T>
		*/
		SPParticle2D<T> get( const SPInt i ) const;

		/**
		* @brief     Get all attributes of particles 
		* @param     [IN] @b i index
		* @param     [IN] @b p Particle
		* @return     SPVoid
		*/
		SPVoid get( const SPInt i , SPParticle2D<T>& p) const;

		/**
		* @brief     Get the minimum point
		* @return     SPVec2t
		*/
		SPVec2t getMinPoint() const { return minPt; }
		
		/**
		* @brief     Get the maximum point
		* @return     SPVec2t
		*/
		SPVec2t getMaxPoint() const { return maxPt; }

		/**
		* @brief     Append new particle
		* @param     [IN] @b p ParticleSet
		* @return     SPVoid
		*/
		SPVoid append( const SPParticle2D<T>& p);

		/**
		* @brief     Append ParticleSet
		* @param     [IN] @b p ParticleSet
		* @return     SPVoid
		*/
		SPVoid append( const SPParticleset2D& p);

		/**
		* @brief     Remove particles
		* @param     [IN] @b i indices
		* @return     SPVoid
		*/
		SPVoid remove( const std::vector<SPInt>& i);

		/**
		* @brief	Enable all attributes     
		* @param     [IN] @b a attribute channel
		* @return     SPVoid
		*/
		SPVoid enable( const SPInt a);

		/**
		* @brief     Disable all attributes
		* @param     [IN] @b a attribute channel
		* @return     SPVoid
		*/
		SPVoid disable( const SPInt a );

		/**
		* @brief	If particle has attribute, it enable     
		* @param     [IN] @b ptc ParticleSet
		* @return     SPVoid
		*/
		SPVoid enableSameAs( const SPParticleset2D& ptc);

		/**
		* @brief	Rebuild particle ID     
		* @return     SPVoid
		*/
		SPVoid rebuildID();


		/**
		* @brief	Set the ID of particles
		* @param     [IN] @b _id id
		* @return     SPVoid
		*/
		SPVoid setID( const SPInt _id);

		/**
		* @brief     Set the position of particles
		* @param     [IN] @b x position x
		* @param     [IN] @b y position y
		* @return     SPVoid
		*/
		SPVoid setPosition( const T& x,const T& y);

		/**
		* @brief     Set the position of particles
		* @param     [IN] @b p position p
		* @return     SPVoid
		*/
		SPVoid setPosition( const SPVec2t& p);

		/**
		* @brief     Set the velocity of particles
		* @param     [IN] @b x velocity x
		* @param     [IN] @b y velocity y
		* @return     SPVoid
		*/
		SPVoid setVelocity( const T& x,const T& y);

		/**
		* @brief     Set the velocity of particles
		* @param     [IN] @b p velocity
		* @return     SPVoid
		*/
		SPVoid setVelocity( const SPVec2t& p);

		/**
		* @brief     Set the normal vector of particles
		* @param     [IN] @b x normal x
		* @param     [IN] @b y normal y
		* @return     SPVoid
		*/
		SPVoid setNormal( const T& x,const T& y);
		
		/**
		* @brief     Set the normal vector of particles
		* @param     [IN] @b n normal
		* @return     SPVoid
		*/
		SPVoid setNormal( const SPVec2t& n);

		/**
		* @brief     Set the force of particles
		* @param     [IN] @b x force x
		* @param     [IN] @b y force y
		* @return     SPVoid
		*/
		SPVoid setForce( const T& x,const T& y);

		/**
		* @brief     Set the force of particles
		* @param     [IN] @b f force 
		* @return     SPVoid
		*/
		SPVoid setForce( const SPVec2t& f);
		
		/**
		* @brief     Set the vorticity of particles
		* @param     [IN] @b w vorticity
		* @return     SPVoid
		*/
		SPVoid setVorticity( const T& w);

		/**
		* @brief     Set the orientation of particles
		* @param     [IN] @b o orientation
		* @return     SPVoid
		*/
		SPVoid setOrientation( const SPVec2t& o);
		
		/**
		* @brief     Set the mass of particles
		* @param     [IN] @b m mass
		* @return     SPVoid
		*/
		SPVoid setMass( const T& m);
		
		/**
		* @brief     Set the mass of particles
		* @param     [IN] @b min_mass min mass
		* @param     [IN] @b max_mass max mass
		* @return     SPVoid
		*/
		SPVoid setMass( const T& min_mass, const T& max_mass);

		/**
		* @brief     Set the radius of particles
		* @param     [IN] @b r radius 
		* @return     SPVoid
		*/
		SPVoid setRadius( const T& r);

		/**
		* @brief     Set the radius of particles
		* @param     [IN] @b minRadius minRadius
		* @param     [IN] @b maxRadius maxRadius
		* @return     SPVoid
		*/
		SPVoid setRadius( const T& minRadius, const T& maxRadius);
		
		/**
		* @brief     Set the opacity of particles
		* @param     [IN] @b o opacity 
		* @return     SPVoid
		*/
		SPVoid setOpacity( const T& o);
		
		/**
		* @brief     Set the density of particles
		* @param     [IN] @b d density 
		* @return     SPVoid
		*/
		SPVoid setDensity( const T& d);
		
		/**
		* @brief     Set the temperature of particles
		* @param     [IN] @b t temperature
		* @return     SPVoid
		*/
		SPVoid setTemperature( const T& t);
		
		/**
		* @brief     Set the lifespan of particles
		* @param     [IN] @b lifespan lifespan
		* @return     SPVoid
		*/
		SPVoid setLifespan( const SPInt lifespan );
		
		/**
		* @brief     Set the lifespan of particles
		* @param     [IN] @b min min
		* @param     [IN] @b max min
		* @return     SPVoid
		*/
		SPVoid setLifespan( const SPInt min, const SPInt max );
		
		/**
		* @brief     Set the type of particles
		* @param     [IN] @b type type of particle
		* @return     SPVoid
		*/
		SPVoid setType( const SPChar type );
		
		/**
		* @brief     Add acceleration to particle 
		* @param     [IN] @b ax acceleration x
		* @param     [IN] @b ay acceleration y
		* @param     [IN] @b dt delta time
		* @return     SPVoid
		*/
		SPVoid addAcceleration( const T& ax,const T& ay, const T& dt);
		
		/**
		* @brief     Add acceleration to particle 
		* @param     [IN] @b acc acceleration acc
		* @param     [IN] @b dt delta time
		* @return     SPVoid
		*/
		SPVoid addAcceleration( const SPVec2t& acc, const T& dt);
		
		/**
		* @brief     Calculate the minmum and maximum point
		* @return     SPVoid
		*/
		SPVoid calculateMinMaxPt();

		// 	SPVoid print( SPInt index, SPInt attribute );
		// 	SPVoid print( SPInt startIdx, SPInt endIdx, SPInt attribute );

	private:
		/**
		* @brief	Enable the attribute particles ( ID )     
		* @return     SPVoid
		*/
		SPVoid enableID();

		/**
		* @brief     Enable the attribute particles ( position )     
		* @return     SPVoid
		*/
		SPVoid enablePosition();

		/**
		* @brief     Enable the attribute particles ( velocity )
		* @return     SPVoid
		*/
		SPVoid enableVelocity();

		/**
		* @brief     Enable the attribute particles ( normal vector )
		* @return     SPVoid
		*/
		SPVoid enableNormal();

		/**
		* @brief     Enable the attribute particles ( force )
		* @return     SPVoid
		*/
		SPVoid enableForce();

		/**
		* @brief     Enable the attribute particles ( vorticity )
		* @return     SPVoid
		*/
		SPVoid enableVorticity();

		/**
		* @brief     Enable the attribute particles ( orientation )
		* @return     SPVoid
		*/
		SPVoid enableOrientation();

		/**
		* @brief     Enable the attribute particles ( mass )
		* @return     SPVoid
		*/
		SPVoid enableMass();

		/**
		* @brief     Enable the attribute particles ( radius )
		* @return     SPVoid
		*/
		SPVoid enableRadius();

		/**
		* @brief     Enable the attribute particles ( opacity )
		* @return     SPVoid
		*/
		SPVoid enableOpacity();

		/**
		* @brief     Enable the attribute particles ( density )
		* @return     SPVoid
		*/
		SPVoid enableDensity();

		/**
		* @brief     Enable the attribute particles ( temperature )
		* @return     SPVoid
		*/
		SPVoid enableTemperature();

		/**
		* @brief     Enable the attribute particles ( lifesapn )
		* @return     SPVoid
		*/
		SPVoid enableLifespan();

		/**
		* @brief     Enable the attribute particles ( type )
		* @return     SPVoid
		*/
		SPVoid enableType();

		/**
		* @brief     Disable the attribute particles ( ID )
		* @return     SPVoid
		*/
		SPVoid disableID();

		/**
		* @brief     Disable the attribute particles ( position )
		* @return     SPVoid
		*/
		SPVoid disablePosition();

		/**
		* @brief     Disable the attribute particles ( velocity )
		* @return     SPVoid
		*/
		SPVoid disableVelocity();

		/**
		* @brief     Disable the attribute particles ( normal )
		* @return     SPVoid
		*/
		SPVoid disableNormal();

		/**
		* @brief     Disable the attribute particles ( force )
		* @return     SPVoid
		*/
		SPVoid disableForce();

		/**
		* @brief     Disable the attribute particles ( vorticity )
		* @return     SPVoid
		*/
		SPVoid disableVorticity();

		/**
		* @brief     Disable the attribute particles ( orientation )
		* @return     SPVoid
		*/
		SPVoid disableOrientation();

		/**
		* @brief     Disable the attribute particles ( mass )
		* @return     SPVoid
		*/
		SPVoid disableMass();

		/**
		* @brief     Disable the attribute particles ( radius )
		* @return     SPVoid
		*/
		SPVoid disableRadius();

		/**
		* @brief     Disable the attribute particles ( opacity )
		* @return     SPVoid
		*/SPVoid disableOpacity();

		/**
		* @brief     Disable the attribute particles ( density )
		* @return     SPVoid
		*/
		SPVoid disableDensity();

		/**
		* @brief     Disable the attribute particles ( temperature )
		* @return     SPVoid
		*/
		SPVoid disableTemperature();

		/**
		* @brief     Disable the attribute particles ( lifespan )
		* @return     SPVoid
		*/
		SPVoid disableLifespan();

		/**
		* @brief     Disable the attribute particles ( type )
		* @return     SPVoid
		*/
		SPVoid disableType();
	};
}

#endif //_SP_PARTICLE_SET_2D_H_

