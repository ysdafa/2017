/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPObserver.h
 * @brief  Declaration of simple observer class
 * @author Author (a.vysotskyi@samsung.com)
 */

#ifndef _SPOBSERVER_H_
#define _SPOBSERVER_H_

#include <vector>

namespace SPhysics
{

/**
 * @class SPObserver
 * @brief Observer
 */
template <class T>
class SPObserver
{
public:
	void Advise(T* aListener);		//!< Advise
	void Unadvise(T* aListener);	//!< Unadvise

	void Dispatch(void (T::*aFunc)());	//!< Dispatch

	template <class P1>
	void Dispatch(void (T::*aFunc)(P1), P1 aParam1);	//!< Dispatch

	template <class P1, class P2>
	void Dispatch(void (T::*aFunc)(P1, P2), P1 aParam1, P2 aParam2);	//!< Dispatch

	template <class P1, class P2, class P3>
	void Dispatch(void (T::*aFunc)(P1, P2, P3), P1 aParam1, P2 aParam2, P3 aParam3);	//!< Dispatch
private:
	std::vector<T*> mListeners;
};

/**
 * @class EventSource
 * @brief Event source
 */
template <class T>
class EventSource
{
public:
	void Advise(T* aHendler);	//!< Advise
	void Unadvise(T* aHandler);	//!< Unadvise
protected:
	SPObserver<T> mObserver;	//!< Observer
};

#include "SPObserver.inl"
}
#endif // _SPOBSERVER_H_
