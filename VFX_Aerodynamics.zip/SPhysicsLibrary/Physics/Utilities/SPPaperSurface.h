/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * TODO
 * @file   SPPaperSurface.h
 * @brief
 * @author
 */

#ifndef _PAPERSURFACE_H_
#define _PAPERSURFACE_H_

#include <cmath>

namespace SPhysics
{

const float pi = 3.1415926535897932384626433832795f;	//!< Pi (3.14...)
const float halfPi = 0.5f * pi;							//!< Pi/2

//#define GAUSSIAN_APPROXIMATION( argumentSquared, curvature ) ((curvature) / (2.0f * (argumentSquared) + (curvature)))
//#define GAUSSIAN_APPROXIMATION_INVERSE( argumentSquared, curvature ) ((argumentSquared) / ((argumentSquared) + 0.5f * (curvature)))

double GaussianRand(double aMean, double aVariance);
double SPPGaussianRandA(double aMean, double aVariance);

/**
 * @struct SurfaceCell
 * @brief a cell in the lattice, representing paper surface
 */
struct SurfaceCell
{
	float height;	//!< Height of the paper in the cell

	float coeffsSum;	//!< Sum coefficient
	/**
	 * @brief default constructor
	 */
	SurfaceCell();
};

/**
 * @struct BellPoint
 * @brief an entity, a set of which is used for random paper surface generation.
 *        It represents a point on the paper with specified height
 */
struct BellPoint
{
	/// x coordinate of point
	int x;
	/// y coordinate of point
	int y;
	/// whether the point is a maximum (true) or minimum (false)
	bool isDirect;
	/// point height
	float height;
	/// curvature of the area around point
	float curvature;
};

/**
 * @class PointsMediumStructure
 * @brief class, representing the paper surface
 */
class PointsMediumStructure
{
public:
	/**
	 * @brief default constructor
	 */
	PointsMediumStructure();

	/**
	 * @brief destructor
	 */
	~PointsMediumStructure();

	/**
	 * @brief parameter initialization
	 * @param aWidth                width of the paper surface
	 * @param aHeight               height of the paper surface
	 * @param aNumberOfBellPoints   number of fiber ridges
	 */
	void initSurfaceSize(int aWidth, int aHeight, int aNumberOfBellPoints);

	/**
	 * @brief randomly generate the paper surface, based on the fiber ridges
	 */
	void createSurface(int bellImpactRadius = 20, float curvatureMean = 2.0f, float curvatureDeviation = 0.5f,
					   float heightMean = 0.5f, float heightDeviation = 0.5f);

	/**
	 * @brief get the paper surface lattice
	 * @return      reference to the paper surface lattice
	 */
	SurfaceCell* getSurfaceLattice();

	/**
	 * @brief get the minimal value of the paper height
	 * @return      minimal height value
	 */
	float minValue() const;

	/**
	 * @brief get the maximal value of the paper height
	 * @return      maximal height value
	 */
	float maxValue() const;

private:
	/**
	 * @brief randomly generate fibers
	 * @param aCurvatureMean            mean value of the ridge curvature
	 * @param aCurvatureDeviation       deviation of the ridge curvature
	 * @param aHeightMean               mean value of the ridge height
	 * @param aHeightDeviation          deviation of the ridge height
	 */
	void fillRandom(float aCurvatureMean, float aCurvatureDeviation, float aHeightMean, float aHeightDeviation);
	/// width of the paper surface
	int mWidth;
	/// height of the paper surface
	int mHeight;
	/// maximal paper height value
	float mMaxValue;
	/// minimal paper height value
	float mMinValue;
	/// paper surface lattice
	SurfaceCell* mSurfaceLattice;

	/// number of fiber ridges for random surface generation
	int mNumberOfBellPoints;
	/// array of fiber ridges
	BellPoint* mBellPoints;
};

/**
 * @struct BellFiber
 * @brief an entity, a set of which is used for random paper surface generation.
 *        It represents a fiber of the paper in form of a ridge
 */
struct BellFiber
{
	/// x coordinate of the fiber extremum
	int x;
	/// y coordinate of the fiber extremum
	int y;
	/// angle, formed by the fiber ridge and the lattice borders
	float angle;
	/// whether the ridge extremum is a maximum (true) or minimum (false)
	bool isDirect;
	/// absolute value of the ridge extremum
	float height;
	/// curvature of the ridge
	float curvature;
};

/**
 * @class FibersMediumStructure
 * @brief class, representing the paper surface
 */
class FibersMediumStructure
{
public:
	/**
	 * @brief default constructor
	 */
	FibersMediumStructure();

	/**
	 * @brief destructor
	 */
	~FibersMediumStructure();

	/**
	 * @brief parameter initialization
	 * @param aWidth                width of the paper surface
	 * @param aHeight               height of the paper surface
	 * @param aNumberOfBellFibers   number of fiber ridges
	 */
	void initSurfaceSize(int aWidth, int aHeight, int aNumberOfBellFibers);

	/**
	 * @brief randomly generate the paper surface, based on the fiber ridges
	 */
	void createSurface(int bellImpactRadius = 20, float curvatureMean = 2.0f, float curvatureDeviation = 0.5f,
					   float heightMean = 0.5f, float heightDeviation = 0.5f);

	/**
	 * @brief get the paper surface lattice
	 * @return      reference to the paper surface lattice
	 */
	SurfaceCell* getSurfaceLattice();

	/**
	 * @brief get the minimal value of the paper height
	 * @return      minimal height value
	 */
	float minValue() const;

	/**
	 * @brief get the maximal value of the paper height
	 * @return      maximal height value
	 */
	float maxValue() const;

private:
	/**
	 * @brief randomly generate fibers
	 * @param aCurvatureMean            mean value of the ridge curvature
	 * @param aCurvatureDeviation       deviation of the ridge curvature
	 * @param aHeightMean               mean value of the ridge height
	 * @param aHeightDeviation          deviation of the ridge height
	 */
	void fillRandom(float aCurvatureMean, float aCurvatureDeviation, float aHeightMean, float aHeightDeviation);
	/// width of the paper surface
	int mWidth;
	/// height of the paper surface
	int mHeight;
	/// maximal paper height value
	float mMaxValue;
	/// minimal paper height value
	float mMinValue;
	/// paper surface lattice
	SurfaceCell* mSurfaceLattice;

	/// number of fiber ridges for random surface generation
	int mNumberOfBellFibers;
	/// array of fiber ridges
	BellFiber* mBellFibers;
};

//TODO - check usage - currently not used
/**
 * @brief generate random numbers
 * @param aCoefficients         array for storing the random numbers
 * @param aN                    nubmer of the random numbers to generate
 */
void CalculateRandomCoefficients(int* aCoefficients, int aN);

/**
 * @brief calculate Binomial coefficients
 * @param aCoefficients         array for storing the Binomial coefficients
 * @param aN                    number of coefficients to calculate
 */
void CalculateBinomialCoefficients(int* aCoefficients, int aN);

}

#endif // _PAPERSURFACE_H_
