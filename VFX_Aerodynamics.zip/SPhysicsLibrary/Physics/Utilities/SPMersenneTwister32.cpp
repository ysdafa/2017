/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

#include "SPMersenneTwister32.h"

namespace SPhysics
{

SPMersenneTwister32::SPMersenneTwister32() :
	mti(0)
{
}

void SPMersenneTwister32::init(uint32_t s)
{
	mt[0] = s;

	for (mti = 1; mti < _MT32_N; ++mti)
	{
		mt[mti] = (1812433253UL * (mt[mti - 1] ^ (mt[mti - 1] >> 30)) + mti);
	}
}

uint32_t SPMersenneTwister32::getValue()
{
	if (mti >= _MT32_N)
	{
		uintptr_t kk;

		for (kk = 0; kk < _MT32_N - _MT32_M; ++kk)
		{
			uint32_t x = (mt[kk] & _MT32_UPPER_MASK) | (mt[kk + 1] & _MT32_LOWER_MASK);
			mt[kk] = mt[kk + _MT32_M] ^ (x >> 1) ^ ((x & 1) * _MT32_MATRIX_A);
		}

		for (; kk < _MT32_N - 1; ++kk)
		{
			uint32_t x = (mt[kk] & _MT32_UPPER_MASK) | (mt[kk + 1] & _MT32_LOWER_MASK);
			mt[kk] = mt[kk + (_MT32_M - _MT32_N)] ^ (x >> 1) ^ ((x & 1) * _MT32_MATRIX_A);
		}

		uint32_t x = (mt[_MT32_N - 1] & _MT32_UPPER_MASK) | (mt[0] & _MT32_LOWER_MASK);
		mt[_MT32_N - 1] = mt[_MT32_M - 1] ^ (x >> 1) ^ ((x & 1) * _MT32_MATRIX_A);
		mti = 0;
	}

	uint32_t y = mt[mti++];
	y ^= (y >> 11);
	y ^= (y << 7) & 0x9d2c5680UL;
	y ^= (y << 15) & 0xefc60000UL;
	y ^= (y >> 18);
	return y;
}

}    // namespace SPhysics
