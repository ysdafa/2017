/**
* @file SPFSM2D.cpp
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPFSM2D.h"
#include "SPTest.h"

namespace SPhysics
{

	
	template<typename T>
	SPVoid SPFSM2D<T>::checkInterface(std::vector<SPChar>& state, SPField2DTemplate<T>& sdf)
	{
		for(SPUInt i=0;i<state.size();++i) state[i] = SPhysics::FMM_STATE_FAR;

		T val;
		for( SPInt j=0; j<resolution.y; ++j )
		{
			const SPInt iBase = resolution.x*j; 
			for( SPInt i=0; i<resolution.x; ++i )
			{
				SPInt idx = i+iBase;

				val = sdf[idx];

				if( val > (T)0 )
				{

					T nVal, h=0, info = (T)-LARGE;
					SPBool existInfo = SPFALSE;

					if( i > 0  )
					{ 
						nVal = sdf(i-1,j);
						if( nVal <= 0 ) { existInfo=SPTRUE; h=cellSize.x; info=maximum(info,nVal); }
					}

					if( i < resolution.x-1 )
					{ 
						nVal = sdf(i+1,j);
						if( nVal <= 0 ) { existInfo=SPTRUE; h=cellSize.x; info=maximum(info,nVal); }
					}

					if( j > 0  )
					{ 
						nVal = sdf(i,j-1);
						if( nVal <= 0 ) { existInfo=SPTRUE; h=cellSize.y; info=maximum(info,nVal); }
					}

					if( j < resolution.y-1 )
					{ 
						nVal = sdf(i,j+1);
						if( nVal <= 0 ) { existInfo=SPTRUE; h=cellSize.y; info=maximum(info,nVal); }
					}

					if( existInfo )
					{
						sdf[idx] = minimum<T>( val, info+h );
						if( sdf[idx] <= (T)0 ) { sdf[idx] = (T)EPSILON; }
						state[idx] = SPhysics::FMM_STATE_INTERFACE;
					}

				}
				else
				{
					SPBool switchSign = SPFALSE;

					if( i > 1			   ) { if( sdf[sdf.wCell(idx)] > 0 ) switchSign = SPTRUE; }
					if( i < resolution.x-1 ) { if( sdf[sdf.eCell(idx)] > 0 ) switchSign = SPTRUE; }
					if( j > 1			   ) { if( sdf[sdf.sCell(idx)] > 0 ) switchSign = SPTRUE; }
					if( j < resolution.y-1 ) { if( sdf[sdf.nCell(idx)] > 0 ) switchSign = SPTRUE; }

					if( switchSign )
					{ 
						state[idx] = SPhysics::FMM_STATE_INTERFACE; 
						//if( i > 0			   && sdf[sdf.wCell(idx)] < 0 ) { if(state[sdf.wCell(idx)] != SPhysics::FMM_STATE_INTERFACE) state[sdf.wCell(idx)] = SPhysics::FMM_STATE_UPDATED; }
						//if( i < resolution.x-1 && sdf[sdf.eCell(idx)] < 0 ) { if(state[sdf.eCell(idx)] != SPhysics::FMM_STATE_INTERFACE) state[sdf.eCell(idx)] = SPhysics::FMM_STATE_UPDATED; }
						//if( j > 0			   && sdf[sdf.sCell(idx)] < 0 ) { if(state[sdf.sCell(idx)] != SPhysics::FMM_STATE_INTERFACE) state[sdf.sCell(idx)] = SPhysics::FMM_STATE_UPDATED; }
						//if( j < resolution.y-1 && sdf[sdf.nCell(idx)] < 0 ) { if(state[sdf.nCell(idx)] != SPhysics::FMM_STATE_INTERFACE) state[sdf.nCell(idx)] = SPhysics::FMM_STATE_UPDATED; }

					}
					else
					{
						sdf[idx] = (T)-LARGE;
					}
				}
			}//for
		}//for

	}

	
	template<typename T>
	SPVoid SPFSM2D<T>::updatePhi(T& phi, T infoX, T infoY, const SPVec2t& D, const T& maxDist, const SPChar state)
	{
		SPBool hasInfoX = SPFALSE;
		SPBool hasInfoY = SPFALSE;

		SPInt newSign = 0;

		if( abs(infoX) < maxDist )
		{ 
			hasInfoX = SPTRUE; 
			newSign = sign( infoX );
		}
		if( abs(infoY) < maxDist )
		{ 
			hasInfoY = SPTRUE; 
			newSign = sign( infoY );
		}

		if( !( hasInfoX || hasInfoY ) ) { return; }

		infoX = abs(infoX);
		infoY = abs(infoY);

	//	newSign = sign( phi );

		T phiEst = abs( phi );

		if( hasInfoX ) 
		{
			if(state == SPhysics::FMM_STATE_UPDATED) phiEst = minimum<T>( phiEst, infoX + D.x*alpha );
			else phiEst = minimum<T>( phiEst, infoX + (D.x/infoX)*beta );
		}
		
		if( hasInfoY )
		{
			if(state == SPhysics::FMM_STATE_UPDATED) phiEst = minimum<T>( phiEst, infoY + D.y*alpha );
			else phiEst = minimum<T>( phiEst, infoY + (D.y/infoY)*beta );
		}

		if( hasInfoX && hasInfoY )
		{
			if(state == SPhysics::FMM_STATE_UPDATED)
			{
				T A = cellSizeSquard.x + cellSizeSquard.y;
				T B = ( cellSizeSquard.y * infoX ) + ( cellSizeSquard.x * infoY );
				T C = glm::pow( D.x   * infoX, 2 ) + glm::pow( D.y   * infoY, 2 ) - cellSizeSquard.x*cellSizeSquard.y;

				T deter = B*B - A*C;

				if( deter >= (T)0 ) {
					T tmp = minimum<T>( phiEst, ( B + sqrt(deter) ) / A );
					if( tmp > (T)0 ) { phiEst = tmp; }
				}
			}
			else
			{
				T A = cellSizeSquard.x + cellSizeSquard.y;
				T B = ( cellSizeSquard.y * infoX ) + ( cellSizeSquard.x * infoY );
				T C = glm::pow( (D.x/infoX)*beta*infoX, 2 ) + glm::pow( (D.y/infoY)*beta*infoY, 2 ) - cellSizeSquard.x*cellSizeSquard.y;

				T deter = B*B - A*C;

				if( deter >= (T)0 )
				{
					T tmp = minimum<T>( phiEst, ( B + sqrt(deter) ) / A );
					if( tmp > (T)0 ) { phiEst = tmp; }

				}
			}
		}

		phi = newSign * phiEst;

		//phi = 0.8;

	}


	template<typename T>
	SPVoid SPFSM2D<T>::recalculateDistance(SPField2DTemplate<T>& sdf)
	{
		const SPVec2i res = sdf.getResolution();

		std::vector<SPChar> state;
		state.resize( sdf.getNumCells() );

		checkInterface(state, sdf);

		const T maxDist = (T)glm::sqrt(glm::pow((T)sdf.lx(), 2) +  glm::pow((T)sdf.ly(), 2));

		#pragma omp parallel
		{
			#pragma omp sections
			{
				#pragma omp section
				{
					for( SPInt j=1; j<res.y; ++j )
					{
						SPInt iBase=res.x*j;
						for( SPInt i=1; i<res.x; ++i )
						{
							SPInt idx=i+iBase;
							if( state[idx] != SPhysics::FMM_STATE_INTERFACE )
							{
								updatePhi( sdf[idx], sdf[sdf.wCell(idx)], sdf[sdf.sCell(idx)], cellSize, maxDist, state[idx] );
							}
						}//for
					}//for
				}

				#pragma omp section
				{
					for( SPInt j=1;       j<res.y; ++j )
					{
						SPInt iBase=res.x*j;
						for( SPInt i=res.x-2; i>=0;  --i )
						{
							SPInt idx=i+iBase;
							if( state[idx] != SPhysics::FMM_STATE_INTERFACE )
							{
								updatePhi( sdf[idx], sdf[sdf.eCell(idx)], sdf[sdf.sCell(idx)], cellSize, maxDist, state[idx] );
							}
						}//for
					}//for
				}

				#pragma omp section
				{
					for( SPInt j=res.y-2; j>=0;  --j )
					{
						SPInt iBase=res.x*j;
						for( SPInt i=1;       i<res.x; ++i )
						{
							SPInt idx=i+iBase;
							if( state[idx] != SPhysics::FMM_STATE_INTERFACE ){
								updatePhi( sdf[idx], sdf[sdf.wCell(idx)], sdf[sdf.nCell(idx)], cellSize, maxDist, state[idx] );
							}
						}//for
					}//for
				}

				#pragma omp section
				{
					for( SPInt j=res.y-2; j>=0; --j )
					{
						SPInt iBase=res.x*j;
						for( SPInt i=res.x-2; i>=0; --i )
						{
							SPInt idx=i+iBase;
							if( state[idx] != SPhysics::FMM_STATE_INTERFACE )
							{
								updatePhi( sdf[idx], sdf[sdf.eCell(idx)], sdf[sdf.nCell(idx)], cellSize, maxDist, state[idx] );
							}
						}//for
					}//for
				}
			}
		}

	}

	template class SPFSM2D<SPFloat>;
	template class SPFSM2D<SPDouble>;

}