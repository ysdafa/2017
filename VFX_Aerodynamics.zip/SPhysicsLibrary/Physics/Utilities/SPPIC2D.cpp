/**
* @file      SPPIC2D.cpp
* @brief

* @date 2014-05-13
* @see
* * Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPPIC2D.h"
#include "SPComparison.h"

namespace SPhysics
{
	SPPIC2D::SPPIC2D():
		m_bVelocity(false)
	{
	}

	SPPIC2D::~SPPIC2D()
	{
	}

	SPhysics::SPVoid SPPIC2D::initialize(const SPFloat& screenSizeX, const SPFloat& screenSizeY, const SPFloat& gridSizeX, const SPFloat& gridSizeY)
	{
		this->initialize(glm::ivec2(screenSizeX, screenSizeY), glm::ivec2(gridSizeX, gridSizeY));
	}

	SPVoid SPPIC2D::initialize(const glm::ivec2& screenSize, const glm::ivec2& gridSize)
	{
		m_vScreenSize = screenSize;
		m_vGridSize = gridSize;
		m_vSimRes = glm::ivec2(gridSize.x + 2, gridSize.y + 2);

		m_u0.resize(m_vSimRes.x * m_vSimRes.y, glm::vec2());
		m_u.resize(m_vSimRes.x * m_vSimRes.y, glm::vec2());

		//m_vIndexingGrid.resize(gridSize.x * gridSize.y);
		m_vParticlesCount.resize(m_vSimRes.x* m_vSimRes.y);
	}

	SPVoid SPPIC2D::reset()
	{
		std::fill(m_u.begin(), m_u.end(), glm::vec2());
		std::fill(m_u0.begin(), m_u0.end(), glm::vec2());

		m_vParticles.clear();
	}

	SPVoid SPPIC2D::update()
	{	
		updateVelocity();
		if (m_vParticles.empty() == SPTRUE)
			return;

		updateParticles();
	}

	SPVoid SPPIC2D::updateVelocity()
	{
		std::fill(m_u0.begin(), m_u0.end(), glm::vec2());
		if (m_bVelocity == SPTRUE) {
			SPInt i = (SPInt)((SPFloat)m_vCurrentMousePos.x / m_vScreenSize.x * m_vGridSize.x) + 1;
			SPInt j = (SPInt)((SPFloat)m_vCurrentMousePos.y / m_vScreenSize.y * m_vGridSize.y) + 1;

			if (i > 0 && i < (m_vGridSize.x + 1) && j > 0 && j < (m_vGridSize.y + 1)) {
				m_u[idx(i, j)].x = (m_vCurrentMousePos.x - m_vPreviousMousePos.x);
				m_u[idx(i, j)].y = (m_vCurrentMousePos.y - m_vPreviousMousePos.y);

				m_vPreviousMousePos.x = m_vCurrentMousePos.x;
				m_vPreviousMousePos.y = m_vCurrentMousePos.y;
			}

			m_bVelocity = SPFALSE;
		}
		//setBoundaryVector(m_u);


		//projectVector(m_u, m_u0);

		 		projectVector(m_u, m_u0);
				m_u0.swap(m_u);
		 		advectVector(m_u, m_u0);
		 		advectVector(m_u, m_u0);
		projectVector(m_u, m_u0);
	}

	SPVoid SPPIC2D::updateParticles()
	{
		// delete the particle which is out of boundary
		// 		for (auto itr = m_vParticles.begin(); itr != m_vParticles.end();)
		// 		{
		// 			if (itr->position.x < 0 || itr->position.x > m_vGridSize.x ||
		// 				itr->position.y < 0 || itr->position.y > m_vGridSize.y)
		// 			{
		// 				itr = m_vParticles.erase(itr);
		// 			}
		// 			else
		// 			{
		// 				++itr;
		// 			}
		// 		}

		std::fill(m_vParticlesCount.begin(), m_vParticlesCount.end(), 0);
		for (SPUInt i = 0; i < m_vParticles.size(); ++i)
		{
			SPParticle2Df& ptc = m_vParticles[i];

			SPFloat xPos = ptc.position.x;
			SPFloat yPos = ptc.position.y;
			if (xPos > m_vGridSize.x)
				xPos = m_vGridSize.x;
			if (yPos > m_vGridSize.y)
				yPos = m_vGridSize.y;
			if (xPos < 1.0f)
				xPos = 1.0f;
			if (yPos < 1.0f)
				yPos = 1.0f;

			SPInt i0 = xPos;
			SPInt i1 = xPos + 1;
			SPInt j0 = yPos;
			SPInt j1 = yPos + 1;

			SPFloat s1 = xPos - i0;
			SPFloat s0 = 1.0f - s1;

			SPFloat t1 = yPos - j0;
			SPFloat t0 = 1.0f - t1;

			glm::vec2 velocity = (m_u[idx(i0, j0)] * s0 + m_u[idx(i1, j0)] * s1) * t0 +
				(m_u[idx(i0, j1)] * s0 + m_u[idx(i1, j1)] * s1) * t1;

			// 			m_u[idx(i0, j0)] -= m_u[idx(i0, j0)] * s0 * t0;
			// 			m_u[idx(i1, j0)] -= m_u[idx(i1, j0)] * s1 * t0;
			// 			m_u[idx(i0, j1)] -= m_u[idx(i0, j1)] * s0 * t1;
			// 			m_u[idx(i1, j1)] -= m_u[idx(i1, j1)] * s1 * t1;

			ptc.velocity.x = velocity.x;
			ptc.velocity.y = velocity.y;
		}

		for (SPUInt i = 0; i < m_vParticles.size(); ++i)
		{
			SPParticle2Df& ptc = m_vParticles[i];
			ptc.velocity = clamp(ptc.velocity, SPVec2f(-0.5, -0.5), SPVec2f(0.5, 0.5));

			ptc.position += ptc.velocity;

			m_cCollision.checkForWall(ptc.position, ptc.velocity, 1.01f, SPVec2f(1.0f, 1.0f), SPVec2f(m_vGridSize.x, m_vGridSize.y));
		}

		return;

		std::fill(m_u.begin(), m_u.end(), glm::vec2());
		// Indexing
		for (SPUInt i = 0; i < m_vParticles.size(); ++i)
		{
			SPParticle2Df& ptc = m_vParticles[i];

			SPFloat xPos = ptc.position.x;
			SPFloat yPos = ptc.position.y;
			if (xPos > m_vGridSize.x)
				xPos = m_vGridSize.x;
			if (yPos > m_vGridSize.y)
				yPos = m_vGridSize.y;
			if (xPos < 1.0f)
				xPos = 1.0f;
			if (yPos < 1.0f)
				yPos = 1.0f;

			SPInt i0 = xPos;
			SPInt i1 = xPos + 1;
			SPInt j0 = yPos;
			SPInt j1 = yPos + 1;

			++m_vParticlesCount[idx(i0, j0)];
			++m_vParticlesCount[idx(i1, j0)];
			++m_vParticlesCount[idx(i0, j1)];
			++m_vParticlesCount[idx(i1, j1)];

			////////////////////////////////////////////// Inverse ingerpolation

			// 			if (ptc.velocity.y != 0.0f)
			// 				int b = 0;
			//
			// 			SPFloat s1 = xPos - i0;
			// 			SPFloat s0 = 1.0f - s1;
			//
			// 			SPFloat t1 = yPos - j0;
			// 			SPFloat t0 = 1.0f - t1;
			//
			// 			SPVec2f ss0 = s0 * ptc.velocity;
			// 			SPVec2f ss1 = s1 * ptc.velocity;
			//
			// 			SPVec2f tt00 = t0 * ss0;
			// 			SPVec2f tt10 = t1 * ss0;
			// 			SPVec2f tt01 = t0 * ss1;
			// 			SPVec2f tt11 = t1 * ss1;
			//
			// 			SPFloat xx = tt00.x + tt10.x + tt01.x + tt11.x;
			// 			SPFloat yy = tt00.y + tt10.y + tt01.y + tt11.y;
			// 			const SPFloat K = 4.0f;
			// 			m_u[idx(i0, j0)].x += tt00.x * K;
			// 			m_u[idx(i1, j0)].x += tt10.x * K;
			// 			m_u[idx(i0, j1)].x += tt01.x * K;
			// 			m_u[idx(i1, j1)].x += tt11.x * K;
			//
			// 			m_u[idx(i0, j0)].y += tt00.y * K;
			// 			m_u[idx(i1, j0)].y += tt10.y * K;
			// 			m_u[idx(i0, j1)].y += tt01.y * K;
			// 			m_u[idx(i1, j1)].y += tt11.y * K;

			/////////////////////////////////////////////// Multiply the length
			// 			 			if (ptc.velocity.y != 0.0f)
			// 			 				int b = 0;
			// 			 			SPVec2f l1 = SPVec2f(i0, j0) - ptc.position;
			// 			 			SPVec2f l2 = SPVec2f(i1, j0) - ptc.position;
			// 			 			SPVec2f l3 = SPVec2f(i0, j1) - ptc.position;
			// 			 			SPVec2f l4 = SPVec2f(i1, j1) - ptc.position;
			//
			// 			 			const SPFloat K = 1.236067961;
			// 			 			const SPVec2f sum = ptc.velocity * (glm::length(l1) + glm::length(l2) + glm::length(l3) + glm::length(l4));
			// 			 			const SPVec2f sum1 = ptc.velocity * (glm::length(l1) + glm::length(l2) + glm::length(l3) + glm::length(l4)) * K;
			//
			// 			 			m_u[idx(i0, j0)].x += (1.0 - glm::length(l1)) * ptc.velocity.x * K;
			// 			 			m_u[idx(i1, j0)].x += (1.0 - glm::length(l2)) * ptc.velocity.x * K;
			// 			 			m_u[idx(i0, j1)].x += (1.0 - glm::length(l3)) * ptc.velocity.x * K;
			// 			 			m_u[idx(i1, j1)].x += (1.0 - glm::length(l4)) * ptc.velocity.x * K;
			//													 
			// 			 			m_u[idx(i0, j0)].y += (1.0 - glm::length(l1)) * ptc.velocity.y * K;
			// 			 			m_u[idx(i1, j0)].y += (1.0 - glm::length(l2)) * ptc.velocity.y * K;
			// 			 			m_u[idx(i0, j1)].y += (1.0 - glm::length(l3)) * ptc.velocity.y * K;
			// 			 			m_u[idx(i1, j1)].y += (1.0 - glm::length(l4)) * ptc.velocity.y * K;

			////////////////// add directly

			m_u[idx(i0, j0)] += glm::vec2(ptc.velocity.x, ptc.velocity.y);
			m_u[idx(i1, j0)] += glm::vec2(ptc.velocity.x, ptc.velocity.y);
			m_u[idx(i0, j1)] += glm::vec2(ptc.velocity.x, ptc.velocity.y);
			m_u[idx(i1, j1)] += glm::vec2(ptc.velocity.x, ptc.velocity.y);

			///////////////////// 1 - dist / H
			//  			if (ptc.velocity.y != 0.0f)
			//  				int b = 0;
			//  			const SPFloat K = 2.336783935;
			//  			const SPFloat InvH = 1.0 / 1.4142135623730950488016887242097;
			//
			//  			SPFloat a1=glm::length(SPVec2f(i0, j0) - ptc.position);
			//  			SPFloat a2=glm::length(SPVec2f(i1, j0) - ptc.position);
			//  			SPFloat a3=glm::length(SPVec2f(i0, j1) - ptc.position);
			//  			SPFloat a4=glm::length(SPVec2f(i1, j1) - ptc.position);
			//
			//  			SPFloat l1 = (1.0f - glm::length(SPVec2f(i0, j0) - ptc.position) * InvH) * K;
			//  			SPFloat l2 = (1.0f - glm::length(SPVec2f(i1, j0) - ptc.position) * InvH) * K;
			//  			SPFloat l3 = (1.0f - glm::length(SPVec2f(i0, j1) - ptc.position) * InvH) * K;
			//  			SPFloat l4 = (1.0f - glm::length(SPVec2f(i1, j1) - ptc.position) * InvH) * K;
			//
			//  			glm::vec2 test = glm::vec2(ptc.velocity.x, ptc.velocity.y) * l1 +
			//  				glm::vec2(ptc.velocity.x, ptc.velocity.y) * l2 +
			//  				glm::vec2(ptc.velocity.x, ptc.velocity.y) * l3 +
			//  				glm::vec2(ptc.velocity.x, ptc.velocity.y) * l4;
			//
			//  			m_u[idx(i0, j0)] += glm::vec2(ptc.velocity.x, ptc.velocity.y) * l1;
			//  			m_u[idx(i1, j0)] += glm::vec2(ptc.velocity.x, ptc.velocity.y) * l2;
			//  			m_u[idx(i0, j1)] += glm::vec2(ptc.velocity.x, ptc.velocity.y) * l3;
			//  			m_u[idx(i1, j1)] += glm::vec2(ptc.velocity.x, ptc.velocity.y) * l4;
		}

		for (SPUInt i = 1; i <= (SPUInt)m_vGridSize.x; ++i)
		{
			for (SPUInt j = 1; j <= (SPUInt)m_vGridSize.y; ++j)
			{
				SPInt div = (SPFloat)m_vParticlesCount[idx(i, j)];
				if (div == 0)
					continue;
				m_u[idx(i, j)] /= (SPFloat)div;
// 				m_u[idx(i, j)].x += 0.005f;
// 				m_u[idx(i, j)].y += 0.005f;
			}
		}
	}

	SPVoid SPPIC2D::addVelocity(const SPUInt& x, const SPUInt& y, const SPBool& bFirstTouch)
	{
		if (bFirstTouch == SPTRUE)
		{
			m_vPreviousMousePos.x = x;
			m_vPreviousMousePos.y = y;
		}

		m_vCurrentMousePos.x = x;
		m_vCurrentMousePos.y = y;

		m_bVelocity = SPTRUE;
	}

	std::vector<glm::vec2> SPPIC2D::getVelocityGrid()
	{
		return m_u;
	}

	std::vector<SPParticle2Df>* SPPIC2D::getParticlesPtr()
	{
		return &m_vParticles;
	}

	SPVoid SPPIC2D::addParticle(const SPFloat& xPos, const SPFloat& yPos)
	{
		SPParticle2Df ptc;
		ptc.setPosition(xPos, yPos);
		// 		ptc.velocity.x = 0.5f;
		// 		ptc.velocity.y = 0.25f;
		m_vParticles.push_back(ptc);
	}

	SPVoid SPPIC2D::setBoundary(std::vector<glm::vec2>& x, const SPInt& bType)
	{
		if (bType == 0)
		{
			for (SPInt i = 1; i <= m_vGridSize.y; i++)
			{
				x[idx(0, i)] = x[idx(1, i)];
				x[idx(m_vGridSize.x + 1, i)] = x[idx(m_vGridSize.x, i)];
			}

			for (SPInt i = 1; i <= m_vGridSize.x; i++)
			{
				x[idx(i, 0)] = x[idx(i, 1)];
				x[idx(i, m_vGridSize.y + 1)] = x[idx(i, m_vGridSize.y)];
			}
		}
		else if (bType == 1) // x
		{
			for (SPInt i = 1; i <= m_vGridSize.y; i++)
			{
				x[idx(0, i)] = -x[idx(1, i)];
				x[idx(m_vGridSize.x + 1, i)] = -x[idx(m_vGridSize.x, i)];
			}

			for (SPInt i = 1; i <= m_vGridSize.x; i++)
			{
				x[idx(i, 0)] = x[idx(i, 1)];
				x[idx(i, m_vGridSize.y + 1)] = x[idx(i, m_vGridSize.y)];
			}
		}
		else if (bType == 2) // y ceiling
		{
			for (SPInt i = 1; i <= m_vGridSize.y; i++)
			{
				x[idx(0, i)] = x[idx(1, i)];
				x[idx(m_vGridSize.x + 1, i)] = x[idx(m_vGridSize.x, i)];
			}

			for (SPInt i = 1; i <= m_vGridSize.x; i++)
			{
				x[idx(i, 0)] = -x[idx(i, 1)];

				x[idx(i, m_vGridSize.y + 1)] = -x[idx(i, m_vGridSize.y)];
			}
		}

		// Left-Top
		x[idx(0, 0)] = 0.5f * (x[idx(1, 0)] + x[idx(0, 1)]);
		// Left-Bottom
		x[idx(0, m_vGridSize.y + 1)] = 0.5f * (x[idx(1, m_vGridSize.y + 1)] + x[idx(0, m_vGridSize.y)]);
		// Right-Top
		x[idx(m_vGridSize.x + 1, 0)] = 0.5f * (x[idx(m_vGridSize.x, 0)] + x[idx(m_vGridSize.x + 1, 1)]);
		// Right-Bottom
		x[idx(m_vGridSize.x + 1, m_vGridSize.y + 1)] = 0.5f * (x[idx(m_vGridSize.x, m_vGridSize.y + 1)] + x[idx(m_vGridSize.x + 1, m_vGridSize.y)]);

		// 		int i;
		//
		// 		for (i = 1; i <= N; i++) {
		// 			x[IX(0, i)] = b == 1 ? -x[IX(1, i)] : x[IX(1, i)];
		// 			x[IX(N + 1, i)] = b == 1 ? -x[IX(N, i)] : x[IX(N, i)];

		// 			x[IX(i, 0)] = b == 2 ? -x[IX(i, 1)] : x[IX(i, 1)];
		// 			x[IX(i, N + 1)] = b == 2 ? -x[IX(i, N)] : x[IX(i, N)];
		// 		}
		// 		x[IX(0, 0)] = 0.5f*(x[IX(1, 0)] + x[IX(0, 1)]);
		// 		x[IX(0, N + 1)] = 0.5f*(x[IX(1, N + 1)] + x[IX(0, N)]);
		// 		x[IX(N + 1, 0)] = 0.5f*(x[IX(N, 0)] + x[IX(N + 1, 1)]);
		// 		x[IX(N + 1, N + 1)] = 0.5f*(x[IX(N, N + 1)] + x[IX(N + 1, N)]);
	}

	SPVoid SPPIC2D::setBoundaryVector(std::vector<glm::vec2>& x)
	{
		glm::vec2 min(1.0f, 1.0f);
		glm::vec2 max(m_vGridSize.x, m_vGridSize.y);

		{// ux
			for (SPInt i = 1; i <= m_vGridSize.y; i++)
			{
				x[idx(0, i)].x = -x[idx(1, i)].x;
				x[idx(m_vGridSize.x + 1, i)].x = -x[idx(m_vGridSize.x, i)].x;
			}

			for (SPInt i = 1; i <= m_vGridSize.x; i++)
			{
				x[idx(i, 0)].x = x[idx(i, 1)].x;
				x[idx(i, m_vGridSize.y + 1)].x = x[idx(i, m_vGridSize.y)].x;
			}
		}

		{// uy
			for (SPInt i = 1; i <= m_vGridSize.y; i++)
			{
				x[idx(0, i)].y = x[idx(1, i)].y;
				x[idx(m_vGridSize.x + 1, i)].y = x[idx(m_vGridSize.x, i)].y;
			}

			for (SPInt i = 1; i <= m_vGridSize.x; i++)
			{
				x[idx(i, 0)].y = -x[idx(i, 1)].y;
				x[idx(i, m_vGridSize.y + 1)].y = -x[idx(i, m_vGridSize.y)].y;
			}
		}

		// Left-Top
		x[idx(0, 0)] = 0.5f * (x[idx(1, 0)] + x[idx(0, 1)]);
		// Left-Bottom
		x[idx(0, m_vGridSize.y + 1)] = 0.5f * (x[idx(1, m_vGridSize.y + 1)] + x[idx(0, m_vGridSize.y)]);
		// Right-Top
		x[idx(m_vGridSize.x + 1, 0)] = 0.5f * (x[idx(m_vGridSize.x, 0)] + x[idx(m_vGridSize.x + 1, 1)]);
		// Right-Bottom
		x[idx(m_vGridSize.x + 1, m_vGridSize.y + 1)] = 0.5f * (x[idx(m_vGridSize.x, m_vGridSize.y + 1)] + x[idx(m_vGridSize.x + 1, m_vGridSize.y)]);
	}

	SPVoid SPPIC2D::linearSolverVector(std::vector<glm::vec2>& x, const SPInt& alpha, const SPInt& beta, const SPInt& bType, const SPInt& iTimes)
	{
		for (SPInt k = 0; k < iTimes; k++)
		{
			for (SPInt i = 1; i <= m_vGridSize.x; i++)
			{
				for (SPInt j = 1; j <= m_vGridSize.y; j++)
				{
// 					if (m_vParticlesCount[idx(i, j)] == 0)
// 						continue;
// 
// 					SPFloat sum = 0.0f;
// 					SPInt count = 0;
// 
// 					if (m_vParticlesCount[idx(i - 1, j)] != 0)
// 					{
// 						sum += x[idx(i - 1, j)].x;
// 						++count;
// 					}
// 
// 					if (m_vParticlesCount[idx(i + 1, j)] != 0)
// 					{
// 						sum += x[idx(i + 1, j)].x;
// 						++count;
// 					}
// 
// 					if (m_vParticlesCount[idx(i, j - 1)] != 0)
// 					{
// 						sum += x[idx(i, j - 1)].x;
// 						++count;
// 					}
// 
// 					if (m_vParticlesCount[idx(i, j + 1)] != 0)
// 					{
// 						sum += x[idx(i, j + 1)].x;
// 						++count;
// 					}
// 
// 					x[idx(i, j)].x = (x[idx(i, j)].y + alpha * sum) / (SPFloat)count;
					x[idx(i, j)].x = (x[idx(i, j)].y + alpha * (x[idx(i - 1, j)].x + x[idx(i + 1, j)].x + x[idx(i, j - 1)].x + x[idx(i, j + 1)].x)) / beta;
				}
			}
			setBoundaryVector(x);
		}
	}

	SPVoid SPPIC2D::projectVector(std::vector<glm::vec2>& x, std::vector<glm::vec2>& x0)
	{
		for (SPInt i = 1; i <= m_vGridSize.x; i++)
		{
			for (SPInt j = 1; j <= m_vGridSize.y; j++)
			{
				x0[idx(i, j)].y = -0.5f * (x[idx(i + 1, j)].x - x[idx(i - 1, j)].x + x[idx(i, j + 1)].y - x[idx(i, j - 1)].y) / ((m_vGridSize.x + m_vGridSize.y) * 0.5);
				x0[idx(i, j)].x = 0;
			}
		}

		setBoundary(x0, 0);

		linearSolverVector(x0, 1.0f, 4.0f, 0, 5);

		for (SPInt i = 1; i <= m_vGridSize.x; i++)
		{
			for (SPInt j = 1; j <= m_vGridSize.y; j++)
			{
				x[idx(i, j)].x -= 0.5f * m_vGridSize.x * (x0[idx(i + 1, j)].x - x0[idx(i - 1, j)].x);
				x[idx(i, j)].y -= 0.5f * m_vGridSize.y * (x0[idx(i, j + 1)].x - x0[idx(i, j - 1)].x);
			}
		}
		setBoundaryVector(x);

	}

	SPVoid SPPIC2D::advectVector(std::vector<glm::vec2>& u, std::vector<glm::vec2>& u0)
	{
		SPInt i, j, i0, j0, i1, j1;
		SPFloat x, y, s0, t0, s1, t1;
		SPFloat h0x, h0y;

		h0x = 0.01666666666666666666666666666667 * m_vGridSize.x;
		h0y = 0.01666666666666666666666666666667 * m_vGridSize.y;

		for (i = 1; i <= m_vGridSize.x; i++)
		{
			for (j = 1; j <= m_vGridSize.y; j++)
			{
				x = i - h0x * u0[idx(i, j)].x;
				y = j - h0y * u0[idx(i, j)].y;
				if (x < 0.5f)
					x = 0.5f;

				if (x > m_vGridSize.x + 0.5f)

					x = m_vGridSize.x + 0.5f;

				i0 = (SPInt)x;
				i1 = i0 + 1;

				if (y < 0.5f)
					y = 0.5f;

				if (y > m_vGridSize.y + 0.5f)
					y = m_vGridSize.y + 0.5f;

				j0 = (SPInt)y;
				j1 = j0 + 1;

				s1 = x - i0;
				s0 = 1 - s1;

				t1 = y - j0;
				t0 = 1 - t1;

				u[idx(i, j)].x = s0 * (t0 * u0[idx(i0, j0)].x + t1 * u0[idx(i0, j1)].x) + s1 * (t0 * u0[idx(i1, j0)].x + t1 * u0[idx(i1, j1)].x);
				u[idx(i, j)].y = s0 * (t0 * u0[idx(i0, j0)].y + t1 * u0[idx(i0, j1)].y) + s1 * (t0 * u0[idx(i1, j0)].y + t1 * u0[idx(i1, j1)].y);
			}
		}

		setBoundaryVector(u);
	}
}//namespace SPhysics