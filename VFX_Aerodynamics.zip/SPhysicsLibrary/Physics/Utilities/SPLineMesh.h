/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPLineMesh.h
 * @brief  Class SPLineMesh
 * @author Author Andrii Krenevych (a.krenevych@samsung.com) (base version)
 * @author Author Yevgeniy Volkov (y.volkov@samsung.com) (improvements)
 */

#ifndef _SP_LINE_MESH_H_
#define _SP_LINE_MESH_H_

#include <glm.hpp>
#include <vector>

#include "SPMesh.h"

namespace SPhysics
{

/**
 *  Class SPLineMesh
 */
class SPLineMesh
{
public:

	/**
	 * Constructor.
	 *
	 * @param aCapacity Numbers of boundary points of shaving.
	 * @param aWidth Width od drawing area
	 * @param aHeight Height od drawing area
	 * @param aRatio Ratio of X to Y in model.
	 * @param aMult Width multiplier.
	 */
	SPLineMesh(const unsigned int aCapacity, const unsigned int aWidth, const unsigned int aHeight, const float aRatio, const float aMult);

	/**
	 * Destructor.
	 */
	~SPLineMesh();

	/**
	 * Define line start point
	 *
	 * @param aPosition Line starting point
	 */
	void start(glm::vec2 aPosition);
	/**
	 * Add new point to the line
	 *
	 * @param aPosition New point
	 */
	void moveTo(glm::vec2 aPosition);
	/**
	 * Finish building the line
	 */
	void finalize();
	/**
	 * Clear the line
	 *
	 * @param controlPointsLeft How many points (counting from end of line) to keep in the line
	 */
	void clear(unsigned controlPointsLeft=0);
	/**
	 * Clear the line
	 *
	 * @param sectionsLeft How many sections (counting from end of line) to keep in the line
	 * (Section is part of line added after each moveTo, usualy consists of several points)
	 */
	void clearSections(unsigned sectionsLeft);

	/**
	 * Create mesh from scratch by copying all the points
	 * (useful when points have been deleted, but not optimal when points are continuously being added)
	 */
	void createMesh();

	/**
	 * Update mesh with recently added points (optimized for countinuous adding of points)
	 */
	void updateMesh();

	/**
	 * Get mesh
	 */
	SPMesh *getMesh();

	/**
	 * @return Number of boundary points of shaving.
	 */
	unsigned int getShavingPointCount();

	/**
	 * Set line width
	 *
	 * @param aWidth Line width
	 */
	void setLineWidth(const float aWidth);
	/**
	 * Set line width scale
	 *
	 * @param aWidthScale Line width scale (width is multiplied on this value at every moveTo)
	 */
	void setLineWidthScale(const float aWidthScale);
	/**
	 * Set GL scale mode
	 *
	 * @param aGlScaleMode Do use GL scale mode (points coordinates are within range of (0...1))
	 */
	void setGlScaleMode(bool aGlScaleMode);
	/**
	 * Set adding mode
	 *
	 * @param addingMode Adding mode (true - add new segment unconditionally, false - add new segment only if threshold is overpassed)
	 */
	void setAddingMode(bool addingMode);
	/**
	 * Set bend smooth mode
	 *
	 * @param doBendSmooth Do smoothing on bend when parameter is true
	 */
	void setBendSmoothMode(bool doBendSmooth);

private:

	/**
	 * Adds new or updates last segment of shaving.
	 *
	 * @param aLeftPoint
	 * @param aRightPoint
	 * @param aAddAsNewSegment
	 * @param aToSpin
	 */
	void addSegment(const glm::vec2 aLeftPoint, const glm::vec2 aRightPoint, const bool aAddAsNewSegment);

	void startSegments(const glm::vec2 aLeftPoint, const glm::vec2 aRightPoint);

	/**
	 * Creates final segments of shaving in moment of breaking shaving off.
	 */
	void finalizeSegment(const glm::vec2 aLeftPoint, const glm::vec2 aRightPoint);

	/**
	 * Indicates whether the last segment of shaving is too long.
	 *
	 * @return "true" if the last segment of shaving has or exceeds the maximum length.
	 */
	bool isCurrentSegmentTooLong();

	void addPairPoints(const glm::vec2& aLeftPoint, const glm::vec2& aRightPoint);

	void updatePairPoints(const glm::vec2& aLeftPoint, const glm::vec2& aRightPoint);

	glm::vec2 positionToVertexPosition(const glm::vec2 aPosition);

	std::vector<glm::vec2> mPlanePositions; /**< Vector of 2D-points which defines boundary of shaving. */
	std::vector<glm::vec2> mTexureCoords;

	unsigned int mWidth; /**< Number of columns in physical grid of model. */
	unsigned int mHeight; /**< Number of lines in physical grid of model. */
	float mInvertWidth; /**< Coefficient which is defined as one divided to mWidth. */
	float mInvertHeight; /**< Coefficient which is defined as one divided to mHeight. */
	float mRatio; /**< Value of ratio of X to Y in model. */
	float mOneDivRatio; /**< Value of ratio of Y to X in model.*/
	float mMult; /**< Width multiplier. */
	float mHalfDivMult; /**< Half of the ratio one to width multiplier. */

	unsigned int mSize; /**< Numbers of boundary points of shaving. */

	const unsigned int mMinPointCount; /**< Minimal number of points for visible shaving. */
	float mLeftLength; /**< Length of left edge of shaving boundary. */
	float mRightLength; /**< Length of right edge of shaving boundary. */
	float mMaxSegmentLength; /**< Maximal length of segment of shaving. */

	bool mIsBrokenFromWood; /**<
	 Holds value "false" in process of creation of shaving.
	 When shaving is broken off from wood, this parameter is set to "true",
	 the shaving is able to fall from wood. */

	float mPreviousAngle; /**< Previous value of rotation angle of the tool during carving.*/
	glm::vec2 mPrevPosition;

	float mCurrentLineWidth;
	float mScaleWidth;

	int mPointsCopiedToMesh, mTexUVCopiedToMesh;
	SPMesh mMesh;
	bool mGlScaleMode; // if it is true - then output is in range [-1...+1], otherwise - in original scale
	bool mIsFirstMove;
	bool mIsStarted;
	bool mAddingMode; // true - unconditionally add new segment, false - add segment by threshold condition
	bool mDoBendSmooth; // make smooth shape on line bend
	std::vector<unsigned> mSectionPoints; // how many points added after each section
};

} //namespace SPhysics

#endif /* _SP_LINE_MESH_H_ */
