/**
* @file SPFMM2D.cpp
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPFMM2D.h"
#include "SPTest.h"


namespace SPhysics
{

	template<typename T>
	SPVoid SPFMM2D<T>::checkInterface(SPField2DTemplate<T>& sdf)
	{

		for(SPUInt i=0;i<state.size();++i) state[i] = SPhysics::FMM_STATE_FAR;

		T val;
		for( SPInt j=0; j<resolution.y; ++j )
		{ 
			const SPInt iBase = resolution.x*j; 
			for( SPInt i=0; i<resolution.x; ++i )
			{ 
				SPInt idx = i+iBase;
				val = sdf[idx];

				if( val > (T)0 )
				{

					T nVal, h=0, info = (T)-LARGE;
					SPBool existInfo = SPFALSE;

					if( i > 0 )
					{ 
						nVal = sdf(i-1,j);
						if( nVal <= (T)0 ) { existInfo=SPTRUE; h=cellSize.x; info=maximum<T>(info,nVal); }
					}

					if( i < resolution.x-1 )
					{ 
						nVal = sdf(i+1,j);
						if( nVal <= (T)0 ) { existInfo=SPTRUE; h=cellSize.x; info=maximum<T>(info,nVal); }
					}

					if( j > 0 )
					{ 
						nVal = sdf(i,j-1);
						if( nVal <= (T)0 ) { existInfo=SPTRUE; h=cellSize.y; info=maximum<T>(info,nVal); }
					}

					if( j < resolution.y-1 )
					{ 
						nVal = sdf(i,j+1);
						if( nVal <= (T)0 ) { existInfo=SPTRUE; h=cellSize.y; info=maximum<T>(info,nVal); }
					}

					if( existInfo )
					{
						sdf[idx] = minimum<T>( val, info+h );
						if( sdf[idx] <= (T)0 ) sdf[idx] = (T)EPSILON;
						state[idx] = SPhysics::FMM_STATE_INTERFACE;
					}

				}
				else {

					SPBool switchSign = SPFALSE;

					if( i > 0 )				{ if( sdf(i-1,j  ) > (T)0 ) switchSign = SPTRUE; }
					if( i < resolution.x-1 ){ if( sdf(i+1,j  ) > (T)0 ) switchSign = SPTRUE; }
					if( j > 0 )				{ if( sdf(i  ,j-1) > (T)0 ) switchSign = SPTRUE; }
					if( j < resolution.y-1 ){ if( sdf(i  ,j+1) > (T)0 ) switchSign = SPTRUE; }

					if( switchSign ) { state[idx] = SPhysics::FMM_STATE_INTERFACE; }
					else { sdf(i,j) = (T)-LARGE; }
				}

			}

		}


	}

	
	template<typename T>
	SPVoid SPFMM2D<T>::initHeap( const SPField2DTemplate<T> &sdf )
	{
		SPFMMHeap2DNode<T> fmmNode;

		for( SPInt j=0; j<resolution.y; ++j )
		{
			for( SPInt i=0; i<resolution.x; ++i )
			{
				const SPInt cell = sdf.cell(i,j);
				const T sd = sdf[cell];

				// no interface cell, so don't do anything
				if( state[cell] != SPhysics::FMM_STATE_INTERFACE ) { continue; }

				// initialize x neighors
				if( i > 0 )
				{ 
					SPInt wCell = sdf.wCell(cell);
					if( state[wCell] == SPhysics::FMM_STATE_FAR )
					{ 
						state[wCell] = SPhysics::FMM_STATE_TRIAL;
						if( sd > (T)0 ) { fmmNode.set( i-1,j, sd+cellSize.x ); heapPositive.push( fmmNode ); }
						else			{ fmmNode.set( i-1,j, sd-cellSize.x ); heapNegative.push( fmmNode ); }
					}
				}

				if( i < resolution.x-1 )
				{ 
					SPInt eCell = sdf.eCell(cell);
					if( state[eCell] == SPhysics::FMM_STATE_FAR)
					{ 
						state[eCell] = SPhysics::FMM_STATE_TRIAL;
						if( sd > (T)0 ) { fmmNode.set( i+1,j, sd+cellSize.x ); heapPositive.push( fmmNode ); }
						else			{ fmmNode.set( i+1,j, sd-cellSize.x ); heapNegative.push( fmmNode ); }
					}
				}

				// initialize y neighors
				if( j > 0 )
				{ 
					SPInt sCell = sdf.sCell(cell);
					if( state[sCell] == SPhysics::FMM_STATE_FAR)
					{ 
						state[sCell] = SPhysics::FMM_STATE_TRIAL;
						if( sd > (T)0 ) { fmmNode.set( i,j-1, sd+cellSize.y ); heapPositive.push( fmmNode ); }
						else			{ fmmNode.set( i,j-1, sd-cellSize.y ); heapNegative.push( fmmNode ); }
					}
				}

				if( j < resolution.y-1 )
				{ 
					SPInt nCell = sdf.nCell(cell);
					if( state[nCell] == SPhysics::FMM_STATE_FAR )
					{
						state[nCell] = SPhysics::FMM_STATE_TRIAL;
						if( sd > (T)0 ) { fmmNode.set( i,j+1, sd+cellSize.y ); heapPositive.push( fmmNode ); }
						else			{ fmmNode.set( i,j+1, sd-cellSize.y ); heapNegative.push( fmmNode ); }
					}
				}

			}//for
		}//for

	}

	
	template<typename T>
	SPVoid SPFMM2D<T>::updatePhi( SPField2DTemplate<T> &sdf, const SPInt& i, const SPInt& j, const SPInt& sgn )
	{
		const SPInt cell = sdf.cell(i,j);

		if( state[cell] == SPhysics::FMM_STATE_INTERFACE ) { return; }

		const SPInt wCell = sdf.wCell(cell);
		const SPInt eCell = sdf.eCell(cell);
		const SPInt sCell = sdf.sCell(cell);
		const SPInt nCell = sdf.nCell(cell);


		SPBool hasInfo  = SPFALSE, hasInfoX = SPFALSE, hasInfoY = SPFALSE;
		T infoX = (T)LARGE, infoY = (T)LARGE;

		// in x-direction
		if( i > 0			   && stateHasInfo(state[wCell]) ) { hasInfo = hasInfoX = SPTRUE; infoX = sdf[wCell]; }
		if( i < resolution.x-1 && stateHasInfo(state[eCell]) ) { hasInfo = hasInfoX = SPTRUE; if(abs<T>(sdf[eCell])<abs<T>(infoX)) infoX = sdf[eCell]; }

		// in y-direction
		if( j > 0			   && stateHasInfo(state[sCell]) ) { hasInfo = hasInfoY = SPTRUE; infoY = sdf[sCell]; }
		if( j < resolution.y-1 && stateHasInfo(state[nCell]) ) { hasInfo = hasInfoY = SPTRUE; if(abs<T>(sdf[nCell])<abs<T>(infoY)) infoY = sdf[nCell]; }

		if( hasInfo==SPFALSE ) { return; } // There are no information for updating this cell.

		// make everything positive for now (we will flip the sign later)
		infoX = abs<T>(infoX);
		infoY = abs<T>(infoY);

		// this is going to hold minimum distance out of 6 possibilities
		T phi = (T)LARGE;

		// first handle the obvious cases
		if( hasInfoX ) { phi = minimum<T>( phi, infoX+cellSize.x ); }
		if( hasInfoY ) { phi = minimum<T>( phi, infoY+cellSize.y ); }

		// now solve for quadratic equations for 2 neighbors (xy)
		if( hasInfoX && hasInfoY )
		{
			const T A = cellSizeSquard.x + cellSizeSquard.y;
			const T B = ( cellSizeSquard.y * infoX ) + ( cellSizeSquard.x * infoY );
			const T C = glm::pow( cellSize.y * infoX, 2) + glm::pow( cellSize.x * infoY, 2) - cellSizeSquard.x * cellSizeSquard.y;

			const T deter = B*B - A*C;
			T phiEst = (T)LARGE;
			if( deter >= (T)0 ) {
				phiEst = minimum<T>( phiEst, ( B + sqrt(deter) ) / A ); 
			}
			phi = minimum<T>( phi, phiEst );
		}

		// now flip the sign if needed
		if( abs<T>(phi) < abs<T>(sdf[cell]) ) { sdf[cell] = sgn * phi; }

		// mark the cell as visited and updated
		state[cell] = SPhysics::FMM_STATE_UPDATED;

	}

	
	template<typename T>
	SPVoid SPFMM2D<T>::advance( FMMHeap2D &heap, const SPField2DTemplate<T> &sdf, const SPInt& i, const SPInt& j, const SPInt& sgn )
	{
		const SPInt idx = sdf.cell(i,j);
		const T sval = sdf[idx];

		// do not expand if we traveled for more than 5 cells
		if( abs<T>(sval) > maxCellSize * redistancingLevel ) { return; }

		SPFMMHeap2DNode<T> fmmNode;
		// expand x neighbors
		if( i > 0 ) { 
			SPInt nIdx = sdf.wCell(idx);
			if( state[nIdx] == SPhysics::FMM_STATE_FAR )
			{ 
				state[nIdx] = SPhysics::FMM_STATE_TRIAL;
				fmmNode.set(i-1,j, sval+sgn*cellSize.x);
				heap.push( fmmNode );
			}
		}

		if( i < resolution.x-1 )
		{ 
			SPInt nIdx = sdf.eCell(idx);
			if( state[nIdx] == SPhysics::FMM_STATE_FAR )
			{ 
				state[nIdx] = SPhysics::FMM_STATE_TRIAL;
				fmmNode.set(i+1,j, sval+sgn*cellSize.x);
				heap.push( fmmNode );
			}
		}

		// expand y neighbors
		if( j > 0 ) { 
			SPInt nIdx = sdf.sCell(idx);
			if( state[nIdx] == SPhysics::FMM_STATE_FAR )
			{ 
				state[nIdx] = SPhysics::FMM_STATE_TRIAL;
				fmmNode.set(i,j-1, sval+sgn*cellSize.y);
				heap.push( fmmNode );
			}
		}

		if( j < resolution.y-1 )
		{ 
			SPInt nIdx = sdf.nCell(idx);
			if( state[nIdx] == SPhysics::FMM_STATE_FAR )
			{ 
				state[nIdx] = SPhysics::FMM_STATE_TRIAL;
				fmmNode.set(i,j+1, sval+sgn*cellSize.y);
				heap.push( fmmNode );
			}
		}
	}

	
	template<typename T>
	SPVoid SPFMM2D<T>::recalculateDistance(SPField2DTemplate<T>& sdf)
	{
		checkInterface(sdf);

		// initialize heap from the boundary values
		initHeap(sdf);

		SPVec2i idx;
		// now propagate along positive side
		// 	while( heapPositive.empty()==SPFALSE ) {
		// 
		// 		idx = heapPositive.top().idx;
		// 		heapPositive.pop();
		// 
		// 		updatePhi( sdf, idx.x, idx.y, +1 );
		// 		advance_FMM( heapPositive, sdf, idx.x, idx.y, +1 );
		// 	}

		// now propagate along negative side
		while( heapNegative.empty()==SPFALSE )
		{
			idx = heapNegative.top().idx;
			heapNegative.pop();

			updatePhi( sdf, idx.x, idx.y, -1 );
			advance( heapNegative, sdf, idx.x, idx.y, -1 );
		}
	}

	template class SPFMM2D<SPFloat>;
	template class SPFMM2D<SPDouble>;

}