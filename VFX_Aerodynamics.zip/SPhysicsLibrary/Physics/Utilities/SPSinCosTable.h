/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPSinCosTable.h
 * @brief  File Sin Cos Table
 * @author Author (a.yusupov@samsung.com)
 */

#ifndef _SINCOSTABLE_H_
#define _SINCOSTABLE_H_

#include "SPDefines.h"

namespace SPhysics
{

/**
 * @class  SinCosTable
 * @brief  Sine and cosine table
 */
template<SPUInt Capacity = 8192>
class SinCosTable
{
public:

	/**
	 * @brief Constructor.
	 * Fill predefined SinCos array. Array values range 0.0f ~ 2.0f * pi.
	 */
	inline SinCosTable();

	/**
	 * @brief Get sin and cos of 'aAngle'.
	 * 'aAngle' will be normalized into range 0.0f ~ 2.0f * pi.
	 *
	 * @param aAngle Angle.
	 * @param aSin Sin.
	 * @param aCos Cos.
	 */
	inline SPVoid get(SPFloat& aAngle, SPFloat& aSin, SPFloat& aCos);
	/**
	 * Get sin and cos of 'aAngle' without angle check.
	 *
	 * @param aAngle Angle.
	 * @param aSin Sin.
	 * @param aCos Cos.
	 */
	inline void getWithoutCheck(const float aAngle, float& aSin, float& aCos);

private:

	struct SinCos
	{
		SPFloat mSin;
		SPFloat mCos;
	};

	SinCos mValue[Capacity]; /**<Array of predefined SinCos values.*/
};

} /* namespace SPhysics */

#include "SPSinCosTable.inl"

#endif /* _SINCOSTABLE_H_ */

