/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPModelObject.h
 * @brief  File Model Object
 * @author Author Arthur Yusupov (a.yusupov@samsung.com)
 */

#ifndef _SPMODELOBJECT_H_
#define _SPMODELOBJECT_H_

#include "SPFileLoad.h"
#include "SPObjectData.h"

#include <glm.hpp>

namespace SPhysics
{

/**
 * @class  SPModelObject
 * @brief  Model object
 */
class SPModelObject
{
public:

	SPModelObject();

	/**
	 * Constructor
	 */
	SPModelObject(const std::string& aName);

	/**
	 * Load model from file.
	 *
	 * @param aName name of model to load.
	 */
	void load(const std::string& aName);

	/**
	 * Fill object with models geometry and given texture.
	 *
	 * @param aObject Object to fill.
	 */
	void fillObject(SPObjectData& aObject);

private:

	SPFile mFile;

};

/**
 * @class  ModelLoader
 * @brief  Model loader
 */
class ModelLoader
{
public:

	/**
	 * @brief  Constructor
	 */
	ModelLoader(const std::string& aName);

	~ModelLoader();

	/**
	 * @brief  Get object
	 */
	SPObjectData& getObject();

private:
	SPModelObject mModel;
	SPObjectData mObject;

};

} // namespace SPhysics

#endif // _SPMODELOBJECT_H_
