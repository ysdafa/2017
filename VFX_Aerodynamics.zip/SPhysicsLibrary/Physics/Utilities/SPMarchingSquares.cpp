/**
* @file SPMarchingSquares.cpp
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/


#include "SPMarchingSquares.h"
#include "SPField2DOperations.h"

namespace SPhysics
{

	
	template<typename T>
	SPVec2t SPMarchingSquares<T>::interpolateBetweenPoints( const SPVec2t& a, const SPVec2t& b, 
		const T value1, const T value2, const T& isoContour ) const
	{
		SPVec2t point;

		if( value2 != value1 ) point = a + (b-a) * (isoContour-value1) / (value2-value1);
		else point = a;

		return point;
	}

	
	template<typename T>
	SPVoid SPMarchingSquares<T>::initialize(const SPVec2i& res, const SPVec2d& gridSize)
	{
		hashGrid.set(res,gridSize,atCELL);

		isInsideSurface.set(res.x-1,res.y-1,gridSize.x,gridSize.y,atCELL);

		reset();
	}

	
	template<typename T>
	SPVoid SPMarchingSquares<T>::reset()
	{
		isInsideSurface.setZero();

		triangleMesh.init();
	}

	
	template<typename T>
	SPVoid SPMarchingSquares<T>::generatePoints(const SPField2DTemplate<T>& sdf, const T& isoContour)
	{
		reset();

		const SPVec2i res = sdf.getResolution();

		std::vector<SPVec3u > triface; triface.reserve(res.x*res.y*5);
		std::vector<SPVec3t > position; position.reserve(res.x*res.y*5);

		SPVec3u faceIndices;
		SPVec3t vertex;

		SPUInt index = 0;
		SPInt i0, i1, j0, j1;
		SPVec2t p0, p1, p2, p3;
		SPVec2t p01, p12, p23, p30;
		
		for(SPInt j=0; j<res.y-1; ++j)
		{
		for(SPInt i=0; i<res.x-1; ++i)
		{

			i0 = i, i1 = i+1;
			j0 = j, j1 = j+1;

			p0 = hashGrid.indexToPosition(i0,j0);
			p1 = hashGrid.indexToPosition(i1,j0);
			p2 = hashGrid.indexToPosition(i1,j1);
			p3 = hashGrid.indexToPosition(i0,j1);

			if ( sdf(i0,j0) > isoContour ) { isInsideSurface(i0,j0) |= 1; }
			if ( sdf(i0,j1) > isoContour ) { isInsideSurface(i0,j0) |= 2; }
			if ( sdf(i1,j1) > isoContour ) { isInsideSurface(i0,j0) |= 4; }
			if ( sdf(i1,j0) > isoContour ) { isInsideSurface(i0,j0) |= 8; }

			index = position.size();

			switch( isInsideSurface(i0,j0) )
			{

				case 15 :
					vertex = SPVec3t(p0.x,p0.y,getInterpolatedCenterValue<T>(sdf,p0)); position.push_back(vertex);
					vertex = SPVec3t(p1.x,p1.y,getInterpolatedCenterValue<T>(sdf,p1)); position.push_back(vertex);
					vertex = SPVec3t(p2.x,p2.y,getInterpolatedCenterValue<T>(sdf,p2)); position.push_back(vertex);
					vertex = SPVec3t(p3.x,p3.y,getInterpolatedCenterValue<T>(sdf,p3)); position.push_back(vertex);
					faceIndices = SPVec3u(index,index+1,index+2); triface.push_back(faceIndices);
					faceIndices = SPVec3u(index,index+2,index+3); triface.push_back(faceIndices);						 
					break;

				case 14:
					p01 = interpolateBetweenPoints(p0,p1,sdf(i0,j0),sdf(i1,j0),isoContour);
					p30 = interpolateBetweenPoints(p0,p3,sdf(i0,j0),sdf(i0,j1),isoContour);

					vertex = SPVec3t(p01.x,p01.y,getInterpolatedCenterValue<T>(sdf,p01)); position.push_back(vertex);
					vertex = SPVec3t(p1.x,p1.y,getInterpolatedCenterValue<T>(sdf,p1)); position.push_back(vertex);
					vertex = SPVec3t(p2.x,p2.y,getInterpolatedCenterValue<T>(sdf,p2)); position.push_back(vertex);
					vertex = SPVec3t(p3.x,p3.y,getInterpolatedCenterValue<T>(sdf,p3)); position.push_back(vertex);
					vertex = SPVec3t(p30.x,p30.y,getInterpolatedCenterValue<T>(sdf,p30)); position.push_back(vertex);
					faceIndices = SPVec3u(index,index+1,index+2); triface.push_back(faceIndices);
					faceIndices = SPVec3u(index,index+2,index+3); triface.push_back(faceIndices);
					faceIndices = SPVec3u(index,index+3,index+4); triface.push_back(faceIndices);							 
					break;

				case 13:
					p23 = interpolateBetweenPoints(p3,p2,sdf(i0,j1),sdf(i1,j1),isoContour);
					p30 = interpolateBetweenPoints(p3,p0,sdf(i0,j1),sdf(i0,j0),isoContour);

					vertex = SPVec3t(p0.x,p0.y,getInterpolatedCenterValue<T>(sdf,p0)); position.push_back(vertex);
					vertex = SPVec3t(p1.x,p1.y,getInterpolatedCenterValue<T>(sdf,p1)); position.push_back(vertex);
					vertex = SPVec3t(p2.x,p2.y,getInterpolatedCenterValue<T>(sdf,p2)); position.push_back(vertex);
					vertex = SPVec3t(p23.x,p23.y,getInterpolatedCenterValue<T>(sdf,p23)); position.push_back(vertex);
					vertex = SPVec3t(p30.x,p30.y,getInterpolatedCenterValue<T>(sdf,p30)); position.push_back(vertex);
					faceIndices = SPVec3u(index,index+1,index+2); triface.push_back(faceIndices);
					faceIndices = SPVec3u(index,index+2,index+3); triface.push_back(faceIndices);
					faceIndices = SPVec3u(index,index+3,index+4); triface.push_back(faceIndices);							 
					break;

				case 12:
					p01 = interpolateBetweenPoints(p0,p1,sdf(i0,j0),sdf(i1,j0),isoContour);
					p23 = interpolateBetweenPoints(p3,p2,sdf(i0,j1),sdf(i1,j1),isoContour);

					vertex = SPVec3t(p01.x,p01.y,getInterpolatedCenterValue<T>(sdf,p01)); position.push_back(vertex);
					vertex = SPVec3t(p1.x,p1.y,getInterpolatedCenterValue<T>(sdf,p1)); position.push_back(vertex);
					vertex = SPVec3t(p2.x,p2.y,getInterpolatedCenterValue<T>(sdf,p2)); position.push_back(vertex);
					vertex = SPVec3t(p23.x,p23.y,getInterpolatedCenterValue<T>(sdf,p23)); position.push_back(vertex);
					faceIndices = SPVec3u(index,index+1,index+2); triface.push_back(faceIndices);
					faceIndices = SPVec3u(index,index+2,index+3); triface.push_back(faceIndices);							 
					break;

				case 11:
					p12 = interpolateBetweenPoints(p2,p1,sdf(i1,j1),sdf(i1,j0),isoContour);
					p23 = interpolateBetweenPoints(p2,p3,sdf(i1,j1),sdf(i0,j1),isoContour);

					vertex = SPVec3t(p0.x,p0.y,getInterpolatedCenterValue<T>(sdf,p0)); position.push_back(vertex);
					vertex = SPVec3t(p1.x,p1.y,getInterpolatedCenterValue<T>(sdf,p1)); position.push_back(vertex);
					vertex = SPVec3t(p12.x,p12.y,getInterpolatedCenterValue<T>(sdf,p12)); position.push_back(vertex);
					vertex = SPVec3t(p23.x,p23.y,getInterpolatedCenterValue<T>(sdf,p23)); position.push_back(vertex);
					vertex = SPVec3t(p3.x,p3.y,getInterpolatedCenterValue<T>(sdf,p3)); position.push_back(vertex);
					faceIndices = SPVec3u(index,index+1,index+2); triface.push_back(faceIndices);
					faceIndices = SPVec3u(index,index+2,index+3); triface.push_back(faceIndices);							 
					faceIndices = SPVec3u(index,index+3,index+4); triface.push_back(faceIndices);
					break;

				case 10:
					p01 = interpolateBetweenPoints(p0,p1,sdf(i0,j0),sdf(i1,j0),isoContour);
					p12 = interpolateBetweenPoints(p2,p1,sdf(i1,j1),sdf(i1,j0),isoContour);
					p23 = interpolateBetweenPoints(p2,p3,sdf(i1,j1),sdf(i0,j1),isoContour);
					p30 = interpolateBetweenPoints(p0,p3,sdf(i0,j0),sdf(i0,j1),isoContour);

					vertex = SPVec3t(p01.x,p01.y,getInterpolatedCenterValue<T>(sdf,p01)); position.push_back(vertex);
					vertex = SPVec3t(p1.x,p1.y,getInterpolatedCenterValue<T>(sdf,p1)); position.push_back(vertex);
					vertex = SPVec3t(p12.x,p12.y,getInterpolatedCenterValue<T>(sdf,p12)); position.push_back(vertex);
					vertex = SPVec3t(p23.x,p23.y,getInterpolatedCenterValue<T>(sdf,p23)); position.push_back(vertex);
					vertex = SPVec3t(p3.x,p3.y,getInterpolatedCenterValue<T>(sdf,p3)); position.push_back(vertex);
					vertex = SPVec3t(p30.x,p30.y,getInterpolatedCenterValue<T>(sdf,p30)); position.push_back(vertex);
					faceIndices = SPVec3u(index,index+1,index+2); triface.push_back(faceIndices);
					faceIndices = SPVec3u(index,index+2,index+3); triface.push_back(faceIndices);							 
					faceIndices = SPVec3u(index,index+3,index+4); triface.push_back(faceIndices);
					faceIndices = SPVec3u(index,index+4,index+5); triface.push_back(faceIndices);
					break;

				case 9:
					p12 = interpolateBetweenPoints(p2,p1,sdf(i1,j1),sdf(i1,j0),isoContour);
					p30 = interpolateBetweenPoints(p3,p0,sdf(i0,j1),sdf(i0,j0),isoContour);

					vertex = SPVec3t(p0.x,p0.y,getInterpolatedCenterValue<T>(sdf,p0)); position.push_back(vertex);
					vertex = SPVec3t(p1.x,p1.y,getInterpolatedCenterValue<T>(sdf,p1)); position.push_back(vertex);
					vertex = SPVec3t(p12.x,p12.y,getInterpolatedCenterValue<T>(sdf,p12)); position.push_back(vertex);
					vertex = SPVec3t(p30.x,p30.y,getInterpolatedCenterValue<T>(sdf,p30)); position.push_back(vertex);
					faceIndices = SPVec3u(index,index+1,index+2); triface.push_back(faceIndices);
					faceIndices = SPVec3u(index,index+2,index+3); triface.push_back(faceIndices);							 
					break;

				case 8:
					p01 = interpolateBetweenPoints(p0,p1,sdf(i0,j0),sdf(i1,j0),isoContour);
					p12 = interpolateBetweenPoints(p2,p1,sdf(i1,j1),sdf(i1,j0),isoContour);

					vertex = SPVec3t(p01.x,p01.y,getInterpolatedCenterValue<T>(sdf,p01)); position.push_back(vertex);
					vertex = SPVec3t(p1.x,p1.y,getInterpolatedCenterValue<T>(sdf,p1)); position.push_back(vertex);
					vertex = SPVec3t(p12.x,p12.y,getInterpolatedCenterValue<T>(sdf,p12)); position.push_back(vertex);
					faceIndices = SPVec3u(index,index+1,index+2); triface.push_back(faceIndices);
					break;

				case 7:
					p01 = interpolateBetweenPoints(p1,p0,sdf(i1,j0),sdf(i0,j0),isoContour);
					p12 = interpolateBetweenPoints(p1,p2,sdf(i1,j0),sdf(i1,j1),isoContour);

					vertex = SPVec3t(p0.x,p0.y,getInterpolatedCenterValue<T>(sdf,p0)); position.push_back(vertex);
					vertex = SPVec3t(p01.x,p01.y,getInterpolatedCenterValue<T>(sdf,p01)); position.push_back(vertex);
					vertex = SPVec3t(p12.x,p12.y,getInterpolatedCenterValue<T>(sdf,p12)); position.push_back(vertex);
					vertex = SPVec3t(p2.x,p2.y,getInterpolatedCenterValue<T>(sdf,p2)); position.push_back(vertex);
					vertex = SPVec3t(p3.x,p3.y,getInterpolatedCenterValue<T>(sdf,p3)); position.push_back(vertex);
					vertex = SPVec3t(p0.x,p0.y,getInterpolatedCenterValue<T>(sdf,p0)); position.push_back(vertex);
					faceIndices = SPVec3u(index,index+1,index+2); triface.push_back(faceIndices);
					faceIndices = SPVec3u(index,index+2,index+3); triface.push_back(faceIndices);
					faceIndices = SPVec3u(index,index+3,index+4); triface.push_back(faceIndices);							 
					break;

				case 6:
					p12 = interpolateBetweenPoints(p1,p2,sdf(i1,j0),sdf(i1,j1),isoContour);
					p30 = interpolateBetweenPoints(p0,p3,sdf(i0,j0),sdf(i0,j1),isoContour);

					vertex = SPVec3t(p12.x,p12.y,getInterpolatedCenterValue<T>(sdf,p12)); position.push_back(vertex);
					vertex = SPVec3t(p2.x,p2.y,getInterpolatedCenterValue<T>(sdf,p2)); position.push_back(vertex);
					vertex = SPVec3t(p3.x,p3.y,getInterpolatedCenterValue<T>(sdf,p3)); position.push_back(vertex);
					vertex = SPVec3t(p30.x,p30.y,getInterpolatedCenterValue<T>(sdf,p30)); position.push_back(vertex);
					faceIndices = SPVec3u(index,index+1,index+2); triface.push_back(faceIndices);
					faceIndices = SPVec3u(index,index+2,index+3); triface.push_back(faceIndices);
					break;

				case 5:
					p01 = interpolateBetweenPoints(p1,p0,sdf(i1,j0),sdf(i0,j0),isoContour);
					p12 = interpolateBetweenPoints(p1,p2,sdf(i1,j0),sdf(i1,j1),isoContour);
					p23 = interpolateBetweenPoints(p3,p2,sdf(i0,j1),sdf(i1,j1),isoContour);
					p30 = interpolateBetweenPoints(p3,p0,sdf(i0,j1),sdf(i0,j0),isoContour);

					vertex = SPVec3t(p0.x,p0.y,getInterpolatedCenterValue<T>(sdf,p0)); position.push_back(vertex);
					vertex = SPVec3t(p01.x,p01.y,getInterpolatedCenterValue<T>(sdf,p01)); position.push_back(vertex);
					vertex = SPVec3t(p12.x,p12.y,getInterpolatedCenterValue<T>(sdf,p12)); position.push_back(vertex);
					vertex = SPVec3t(p2.x,p2.y,getInterpolatedCenterValue<T>(sdf,p2)); position.push_back(vertex);
					vertex = SPVec3t(p23.x,p23.y,getInterpolatedCenterValue<T>(sdf,p23)); position.push_back(vertex);
					vertex = SPVec3t(p30.x,p30.y,getInterpolatedCenterValue<T>(sdf,p30)); position.push_back(vertex);
					faceIndices = SPVec3u(index,index+1,index+2); triface.push_back(faceIndices);
					faceIndices = SPVec3u(index,index+2,index+3); triface.push_back(faceIndices);
					faceIndices = SPVec3u(index,index+3,index+4); triface.push_back(faceIndices);
					faceIndices = SPVec3u(index,index+4,index+5); triface.push_back(faceIndices);							 
					break;

				case 4:
					p12 = interpolateBetweenPoints(p1,p2,sdf(i1,j0),sdf(i1,j1),isoContour);
					p23 = interpolateBetweenPoints(p3,p2,sdf(i0,j1),sdf(i1,j1),isoContour);
				
					vertex = SPVec3t(p12.x,p12.y,getInterpolatedCenterValue<T>(sdf,p12)); position.push_back(vertex);
					vertex = SPVec3t(p2.x,p2.y,getInterpolatedCenterValue<T>(sdf,p2)); position.push_back(vertex);
					vertex = SPVec3t(p23.x,p23.y,getInterpolatedCenterValue<T>(sdf,p23)); position.push_back(vertex);
					faceIndices = SPVec3u(index,index+1,index+2); triface.push_back(faceIndices);
					break;

				case 3:
					p01 = interpolateBetweenPoints(p1,p0,sdf(i1,j0),sdf(i0,j0),isoContour);
					p23 = interpolateBetweenPoints(p2,p3,sdf(i1,j1),sdf(i0,j1),isoContour);

					vertex = SPVec3t(p0.x,p0.y,getInterpolatedCenterValue<T>(sdf,p0)); position.push_back(vertex);
					vertex = SPVec3t(p01.x,p01.y,getInterpolatedCenterValue<T>(sdf,p01)); position.push_back(vertex);
					vertex = SPVec3t(p23.x,p23.y,getInterpolatedCenterValue<T>(sdf,p23)); position.push_back(vertex);
					vertex = SPVec3t(p3.x,p3.y,getInterpolatedCenterValue<T>(sdf,p3)); position.push_back(vertex);
					faceIndices = SPVec3u(index,index+1,index+2); triface.push_back(faceIndices);
					faceIndices = SPVec3u(index,index+2,index+3); triface.push_back(faceIndices);
					break;

				case 2:
					p23 = interpolateBetweenPoints(p2,p3,sdf(i1,j1),sdf(i0,j1),isoContour);
					p30 = interpolateBetweenPoints(p0,p3,sdf(i0,j0),sdf(i0,j1),isoContour);

					vertex = SPVec3t(p23.x,p23.y,getInterpolatedCenterValue<T>(sdf,p23)); position.push_back(vertex);
					vertex = SPVec3t(p3.x,p3.y,getInterpolatedCenterValue<T>(sdf,p3)); position.push_back(vertex);
					vertex = SPVec3t(p30.x,p30.y,getInterpolatedCenterValue<T>(sdf,p30)); position.push_back(vertex);
					faceIndices = SPVec3u(index,index+1,index+2); triface.push_back(faceIndices);
					break;

				case 1:
					p30 = interpolateBetweenPoints(p3,p0,sdf(i0,j1),sdf(i0,j0),isoContour);
					p01 = interpolateBetweenPoints(p1,p0,sdf(i1,j0),sdf(i0,j0),isoContour);

					vertex = SPVec3t(p0.x,p0.y,getInterpolatedCenterValue<T>(sdf,p0)); position.push_back(vertex);
					vertex = SPVec3t(p01.x,p01.y,getInterpolatedCenterValue<T>(sdf,p01)); position.push_back(vertex);
					vertex = SPVec3t(p30.x,p30.y,getInterpolatedCenterValue<T>(sdf,p30)); position.push_back(vertex);
					faceIndices = SPVec3u(index,index+1,index+2); triface.push_back(faceIndices);
					break;
			}
		}}

		triangleMesh.init();
		triangleMesh.addChannel( SPE_POSITION );

		triangleMesh.setTriangles(triface);
		triangleMesh.setVertices(position);

		triangleMesh.addChannel( SPE_NORMAL );

	}

	template class SPMarchingSquares<SPFloat>;
	template class SPMarchingSquares<SPDouble>;
}