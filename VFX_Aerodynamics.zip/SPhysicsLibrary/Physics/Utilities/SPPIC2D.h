/**
* @file SPPIC2D.h
* @brief
*
* @date 2014-05-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_PIC_2D_H_
#define _SP_PIC_2D_H_

#include "SPDefines.h"
#include "SPParticle2D.h"
#include "SPCollision2D.h"

#include <list>
#include <glm.hpp>

namespace SPhysics
{
	typedef SPParticle2D<SPFloat>  SPParticle2Df;	//!< Float 2D Particle
	/**
	* @class     SPPIC2D
	* @brief     PIC 2D
	*/
	class SPPIC2D
	{
	public:
		/**
		* @brief     Constructor
		*/
		SPPIC2D();

		/**
		* @brief     Destructor
		*/
		~SPPIC2D();

		/**
		* @brief     Initialize simulation data
		* @param     [IN] @b screenSize X,Y
		* @param     [IN] @b gridSize X,Y
		* @return     SPVoid
		*/
		SPVoid initialize(const SPFloat& screenSizeX, const SPFloat& screenSizeY, const SPFloat& gridSizeX, const SPFloat& gridSizeY);
		/**
		* @brief     Initialize simulation data
		* @param     [IN] @b screenSize
		* @param     [IN] @b gridSize
		* @return     SPVoid
		*/
		SPVoid initialize(const glm::ivec2& screenSize, const glm::ivec2& gridSize);

		/**
		* @brief     Reset all data sets
		* @return     SPVoid
		*/
		SPVoid reset();

		/**
		* @brief
		* @param     [IN] @b i
		* @param     [IN] @b j
		* @return     SPInt
		*/
		inline SPInt idx(const SPInt& i, const SPInt& j);

		/**
		* @brief  Update
		*/
		SPVoid update();
		/**
		* @brief  Add velocity
		*/
		SPVoid addVelocity(const SPUInt& x, const SPUInt& y, const SPBool& bFirstTouch = SPFALSE);
		/**
		* @brief  Get velocity grid
		*/
		std::vector<glm::vec2> getVelocityGrid();

		/**
		* @brief  Get particles ptr
		*/
		std::vector<SPParticle2Df>* getParticlesPtr();
		/**
		* @brief  Add particle
		*/
		SPVoid addParticle(const SPFloat& xPos, const SPFloat& yPos);
	private:
		SPVoid updateVelocity();
		SPVoid updateParticles();
		SPVoid linearSolverVector(std::vector<glm::vec2>& x, const SPInt& alpha, const SPInt& beta, const SPInt& bType, const SPInt& iTimes);
		SPVoid setBoundaryVector(std::vector<glm::vec2>& x);
		SPVoid setBoundary(std::vector<glm::vec2>& x, const SPInt& bType);
		SPVoid projectVector(std::vector<glm::vec2>& x, std::vector<glm::vec2>& x0);
		SPVoid advectVector(std::vector<glm::vec2>& u, std::vector<glm::vec2>& u0);
		//SPVoid updateIndexing();

	private:

		// Container
		std::vector<SPParticle2Df>              m_vParticles;
		std::vector<std::list<SPParticle2Df*> > m_vIndexingGrid;
		std::vector<SPInt>                      m_vParticlesCount;
		std::vector<glm::vec2>                  m_u;
		std::vector<glm::vec2>                  m_u0;

		// Collision
		SPCollision2D<SPFloat>                  m_cCollision;

		// Resolution
		glm::ivec2                              m_vSimRes;
		glm::ivec2                              m_vScreenSize;
		glm::ivec2                              m_vGridSize;

		// Velocity Var.
		glm::ivec2                              m_vPreviousMousePos;
		glm::ivec2                              m_vCurrentMousePos;
		SPBool                                  m_bVelocity;
	};

	inline SPInt SPPIC2D::idx(const SPInt& i, const SPInt& j)
	{
		return i + (m_vGridSize.x + 2) * j;
	}
}//namespace SPhysics

#endif //_SP_PIC_2D_H_