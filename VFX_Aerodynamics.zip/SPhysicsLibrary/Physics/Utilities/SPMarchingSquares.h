/**
* @file SPMarchingSquares.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_MARCHING_SQUARES_H_
#define _SP_MARCHING_SQUARES_H_

#include "SPDefines.h"
#include "SPField2DTemplate.h"
#include "SPTriangleMesh.h"

#include <vector>
#include <glm.hpp>

namespace SPhysics
{

	/**
	* @class     SPMarchingSquares
	* @brief     Marching squares
	*/
	template<typename T>
	class SPMarchingSquares : public SPObject
	{
	public:
		/**		
		* @brief     Constructor
		*/		
		SPMarchingSquares(){}

		/**		
		* @brief     Destructor
		*/
		virtual ~SPMarchingSquares(){}

		/**		
		* @brief     Constructor
		* @param     [IN] @b other
		*/
		SPMarchingSquares( const SPMarchingSquares<T>& other ) : SPObject(), isInsideSurface( other.isInsideSurface ), hashGrid( other.hashGrid )
		{}

		/**		
		* @brief     Assign data from other instance
		* @param     [IN] @b other
		*/
		SPMarchingSquares<T>& operator=(const SPMarchingSquares<T>& other)
		{
			isInsideSurface = other.isInsideSurface;
			hashGrid = other.hashGrid;

			return *this;
		}

		/**
		* @brief     Interpolate between points
		* @param     [IN] @b p1
		* @param     [IN] @b p2
		* @param     [IN] @b v1
		* @param     [IN] @b v2
		* @param     [IN] @b isoContour
		* @return     SPVec2t
		*/	
		SPVec2t interpolateBetweenPoints( const SPVec2t& p1, const SPVec2t& p2, 
			const T v1, const T v2, const T& isoContour ) const;

		/**
		* @brief     Reset data sets
		* @return     SPVoid
		*/		
		SPVoid reset();
		
		/**
		* @brief     Initialize data sets
		* @param     [IN] @b res
		* @param     [IN] @b gridSize
		* @return     SPVoid
		*/		
		SPVoid initialize(const SPVec2i& res, const SPVec2d& gridSize);
		
		/**
		* @brief     Generate point and mesh
		* @param     [IN] @b sdf
		* @param     [IN] @b isoContour
		* @return     SPVoid
		*/
		SPVoid generatePoints(const SPField2DTemplate<T>& sdf, const T& isoContour);

	private:
		SPField2DTemplate<SPInt> isInsideSurface;

		SPField2DBase hashGrid;

		SPTriangleMesh<T> triangleMesh;
	};

}
#endif //_SP_MARCHING_SQUARES_H_