/**
* @file SPFMMHeap.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/



#ifndef _SP_FMM_HEAP_H_
#define _SP_FMM_HEAP_H_

#include "SPDefines.h"

#include "SPTest.h"
#include "SPConstant.h"
#include "SPGlobal.h"

namespace SPhysics
{

	/**
	* @class     SPFMMHeap2DNode
	* @brief     FMM heap 2D node
	*/
	template<typename T>
	class SPFMMHeap2DNode
	{
	public:
		SPVec2i idx;	//!< Index
		T val;					//!< Value

	public:
		/**
		* @brief     Constructor
		*/
		SPFMMHeap2DNode() { idx = SPVec2i(); val=(T)LARGE; }
		
		/**
		* @brief     Constructor
		* @param     [IN] @b idx_
		* @param     [IN] @b val_
		*/
		SPFMMHeap2DNode( const SPVec2i& idx_, const T& val_ ) : idx( idx_ ), val( val_ ) {}
		
		/**
		* @brief     Set heap data
		* @param     [IN] @b index
		* @param     [IN] @b input
		* @return     SPVoid
		*/
		SPVoid set(const SPVec2i& index, const T& input) { idx = index; val = input; }
		/**
		* @brief     Set heap data
		* @param     [IN] @b i
		* @param     [IN] @b j
		* @param     [IN] @b input
		* @return     SPVoid
		*/
		SPVoid set(const SPInt i, const SPInt j, const T& input) { idx.x = i; idx.y = j; val = input; }

	};

	/**
	 * @class  SPFMMHeapCriterion2D
	 * @brief  FMM heap criterion 2D
	 */
	template<typename T>
	struct SPFMMHeapCriterion2D
	{
		/**
		* @brief  Comparison operator
		*/
		SPBool operator() ( const SPFMMHeap2DNode<T>& n1, const SPFMMHeap2DNode<T>& n2 ) { return ( abs<T>(n1.val) > abs<T>(n2.val) ); }
	};

	/**
	* @brief     Return true if state has information (interface or updated)
	* @param     [IN] @b state
	* @return     SPBool
	*/
	inline SPBool stateHasInfo( const SPChar state )
	{
		return ( state == SPhysics::FMM_STATE_INTERFACE || state == SPhysics::FMM_STATE_UPDATED );
	}
}

#endif
