/*
 * Copyright (c) 2000~2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * TODO
 * @file   SPFastAtan.h
 * @brief  Fast arctangent calculation
 * @author Anton Venglovskiy (a.venglovskiy@samsung.com),
 * @author Sergey Demidenko (s.demidenko@samsung.com)
 */

#ifndef FAST_ATAN_H
#define FAST_ATAN_H

namespace SPhysics
{
const float LB1 = 6.62f;		//!< LB1
const float LB2 = 6.52f;		//!< LB2
const float HB1 = 2.2015f;		//!< HB1
const float HB2 = 1.610f;		//!< HB2
const float HB3 = -0.05707f;	//!< HB3
const float C_Pi = 3.1415926535897932384626433832795f;	//!< Pi (3.14...)
const float C_Pi_m2 = 2.0f * C_Pi;		//!< Pi * 2
const float C_Pi_m3d2 = C_Pi * 1.5f;	//!< Pi * 1.5
const float C_Pi_d2 = C_Pi / 2.0f;		//!< Pi / 2
const float C_Pi_d4 = C_Pi / 4.0f;		//!< Pi / 4
const float C_GRAD_EXP = 180.0f / C_Pi;	//!< Degrees from radians (180/pi)
const float C_RAD_EXP = C_Pi / 180.0f;	//!< Radians from degrees (pi/180)

#define __APPROX_ATAN( X, Y ) ((Y <= (0.35 * X)) ? ((LB1 * Y) / ((LB2 * X) + Y)) : (((HB1 * Y) / ((HB2 * X) + Y)) + HB3))	//!< Approximate arctangent

float SPFastAtan(float x, float y);
}

#endif
