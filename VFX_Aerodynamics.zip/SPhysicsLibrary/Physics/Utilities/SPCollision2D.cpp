/**
* @file SPCollision2D.cpp
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPCollision2D.h"

namespace SPhysics
{
	
	template<typename T>
	SPVoid SPCollision2D<T>::checkForWall( SPParticle2D<T>& particle, const T& wallSpringCoefficient,
		const SPVec2t& position, const SPVec2t& minPosition, const SPVec2t& maxPosition )
	{
		// To do
		const T ptcRadius = 0;//particle.getRadius();

		if( particle.getPosition().x - ptcRadius < minPosition.x + position.x )
		{
			const SPVec2t ptcPosition(particle.getPosition());
			const SPVec2t ptcVelocity(particle.getVelocity());

			const T d = minPosition.x-ptcPosition.x;
			particle.setVelocity( -ptcVelocity.x * wallSpringCoefficient, ptcVelocity.y );
			particle.setPosition( minPosition.x + d + ptcRadius, ptcPosition.y );
		}

		if( particle.getPosition().x + ptcRadius > maxPosition.x + position.x )
		{
			const SPVec2t ptcPosition(particle.getPosition());
			const SPVec2t ptcVelocity(particle.getVelocity());

			const T d = ptcPosition.x-maxPosition.x;
			particle.setVelocity( -ptcVelocity.x * wallSpringCoefficient, ptcVelocity.y );
			particle.setPosition( maxPosition.x - d - ptcRadius , ptcPosition.y );
		}

		if( particle.getPosition().y - ptcRadius < minPosition.y + position.y )
		{
			const SPVec2t ptcPosition(particle.getPosition());
			const SPVec2t ptcVelocity(particle.getVelocity());

			const T d = minPosition.y-ptcPosition.y;
			particle.setVelocity( ptcVelocity.x, -ptcVelocity.y * wallSpringCoefficient );
			particle.setPosition( ptcPosition.x, minPosition.y + d + ptcRadius );
		}

		if( particle.getPosition().y + ptcRadius > maxPosition.y + position.y )
		{
			const SPVec2t ptcPosition(particle.getPosition());

			const SPVec2t ptcVelocity(particle.getVelocity());

			const T d = ptcPosition.y-maxPosition.y;
			particle.setVelocity( ptcVelocity.x, -ptcVelocity.y * wallSpringCoefficient );
			particle.setPosition( ptcPosition.x, maxPosition.y - d - ptcRadius );
		}

	}

	
	template<typename T>
	SPVoid SPCollision2D<T>::checkForWall( SPVec2t& ptcPosition, SPVec2t& ptcVelocity, const T& restitutionCoefficient,
		const SPVec2t& boxMinPosition, const SPVec2t& boxMaxPosition )
	{

		if( ptcPosition.x < boxMinPosition.x )
		{
			const T d = boxMinPosition.x - ptcPosition.x;
			ptcVelocity = SPVec2t( -ptcVelocity.x * restitutionCoefficient, ptcVelocity.y );
			ptcPosition = SPVec2t( boxMinPosition.x + d, ptcPosition.y );
			ptcPosition.x += d;
		}

		if( ptcPosition.x > boxMaxPosition.x )
		{
			const T d = ptcPosition.x - boxMaxPosition.x;
			ptcVelocity = SPVec2t( -ptcVelocity.x * restitutionCoefficient, ptcVelocity.y );
			ptcPosition = SPVec2t( boxMaxPosition.x - d , ptcPosition.y );
			ptcPosition.x -= d;
		}

		if( ptcPosition.y < boxMinPosition.y )
		{
			const T d = boxMinPosition.y - ptcPosition.y;
			ptcVelocity = SPVec2t( ptcVelocity.x, -ptcVelocity.y * restitutionCoefficient );
			ptcPosition = SPVec2t( ptcPosition.x, boxMinPosition.y + d );
			ptcPosition.y += d;
		}

		if( ptcPosition.y > boxMaxPosition.y )
		{
			const T d = ptcPosition.y - boxMaxPosition.y;
			ptcVelocity = SPVec2t( ptcVelocity.x, -ptcVelocity.y * restitutionCoefficient );
			ptcPosition = SPVec2t( ptcPosition.x, boxMaxPosition.y - d );
			ptcPosition.y -= d;
		}

	}

	
	template<typename T>
	SPVoid SPCollision2D<T>::checkForWall( SPVec2t& ptcPosition, T radius, SPVec2t& ptcVelocity, const T& wallSpringCoefficient ,
		const SPVec2t& minPosition, const SPVec2t& maxPosition )
	{
		// To do
		const T ptcRadius = radius;

		if( ptcPosition.x - ptcRadius < minPosition.x )
		{
			//const T d = minPosition.x - ptcPosition.x;
			ptcVelocity = SPVec2t( -ptcVelocity.x * wallSpringCoefficient, ptcVelocity.y * wallSpringCoefficient);
			ptcPosition.x =  minPosition.x  + ptcRadius ;
		}

		if( ptcPosition.x + ptcRadius > maxPosition.x )
		{
			//const T d = ptcPosition.x - maxPosition.x;
			ptcVelocity = SPVec2t( -ptcVelocity.x * wallSpringCoefficient, ptcVelocity.y * wallSpringCoefficient);
			ptcPosition.x =  maxPosition.x - ptcRadius ;
		}

		if(ptcPosition.y - ptcRadius < minPosition.y  )
		{
			//const T d = minPosition.y - ptcPosition.y;
			ptcVelocity = SPVec2t( ptcVelocity.x, -ptcVelocity.y * wallSpringCoefficient * wallSpringCoefficient);
			ptcPosition.y  =  minPosition.y + ptcRadius ;
		}

		//	if( ptcPosition.y + ptcRadius > maxPosition.y  ) {

		//		const T d = ptcPosition.y-maxPosition.y;
		//		ptcVelocity = SPVec2t( ptcVelocity.x, -ptcVelocity.y*wallSpringCoefficient );
		//		particle.setPosition( ptcPosition.x, maxPosition.y - d - ptcRadius );
		//	}

	}

	template class SPCollision2D<SPFloat>;
	template class SPCollision2D<SPDouble>;
} // namespace SPhysics