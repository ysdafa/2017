/*
 * Copyright (c) 2000~2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * TODO
 * @file   SPFastAtan.cpp
 * @brief  Fast arctangent calculation
 * @author Anton Venglovskiy (a.venglovskiy@samsung.com),
 * @author Sergey Demidenko (s.demidenko@samsung.com)
 */

#include "SPFastAtan.h"
#include <math.h>

namespace SPhysics
{

/**
 * @brief  Fast arctangent
 */
float SPFastAtan(float x, float y)
{
	if (x == 0)
	{
		if (y < 0)
		{
			return C_Pi_m3d2;
		}
		else
		{
			return C_Pi_d2;
		}
	}

	if (y == 0)
	{
		if (x < 0)
		{
			return C_Pi;
		}
		else
		{
			return 0.0f;
		}
	}

	/*
	char signNumber = ((*(int*)reinterpret_cast<char*>(&x) & 0x80000000) >> 30) + ((*(int*)reinterpret_cast<char*>(&y) & 0x80000000) >> 31);
	*(int*)reinterpret_cast<char*>(&x) &= 0x7FFFFFFF;
	*(int*)reinterpret_cast<char*>(&y) &= 0x7FFFFFFF;
	*/
	char signNumber = (x < 0.0f) ? 2 : 0 + (y < 0.0f) ? 1 : 0;
	x = fabs(x);
	y = fabs(y);
	bool XBig = (x >= y);

	if (signNumber == 0)
	{
		if (XBig)
		{
			return __APPROX_ATAN(x, y);
		}
		else
		{
			return C_Pi_d2 - __APPROX_ATAN(y, x);
		}
	}

	if (signNumber == 1)
	{
		if (XBig)
		{
			return C_Pi_m2 - __APPROX_ATAN(x, y);
		}
		else
		{
			return C_Pi_m3d2 + __APPROX_ATAN(y, x);
		}
	}

	if (signNumber == 2)
	{
		if (XBig)
		{
			return C_Pi - __APPROX_ATAN(x, y);
		}
		else
		{
			return C_Pi_d2 + __APPROX_ATAN(y, x);
		}
	}

	if (signNumber == 3)
	{
		if (XBig)
		{
			return C_Pi + __APPROX_ATAN(x, y);
		}
		else
		{
			return C_Pi_m3d2 - __APPROX_ATAN(y, x);
		}
	}

	return 0.0f;
}

}
