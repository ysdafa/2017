/**
* @file SPBezierCurve.h
* @brief 
*
* @date 2013-04-18
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_BEZIER_CURVE_H_
#define _SP_BEZIER_CURVE_H_

#include "SPDefines.h"
#include "SPObject.h"
#include "SPMesh.h"
#include "SPArithmetic.h"

#include <vector>
#include <glm.hpp>

namespace SPhysics
{	
	/**
	* @class     SPBezierCurve
	* @brief     Bezier Curve
	*/
	template <typename T>
	class SPBezierCurve : public SPObject
	{
	public:
		/**
		* @brief     Constructor
		*/
		SPBezierCurve(){}
		
		/**
		* @brief     Destructor
		*/
		~SPBezierCurve(){}

		/**
		* @brief     Generate Bezier Curve
		* @param     [IN] @b points positions of curve
		* @param     [IN] @b ptsOnCurve number of points on curve 
		* @return     SPMesh
		*/
		SPMesh generateBezierCurve(const std::vector<SPVec3t >& points, SPInt ptsOnCurve)
		{	
			if(ptsOnCurve == 1)
				ptsOnCurve = 2;
			SPMesh mesh;
			SPInt degree = points.size() - 1;
			
			std::vector<SPDouble> xx;
			std::vector<SPDouble> yy;
			SPDouble bb;
			SPDouble divV;
			SPDouble tt;
			SPDouble _tt;
			SPDouble nfac;
			SPDouble kfac;
			SPDouble n_kfac;

			for(SPInt ii=0; ii<ptsOnCurve; ++ii)
			{			
				//SPFloat xx[101]={0};
				//SPFloat yy[101]={0};				

				xx.resize(ptsOnCurve);
				yy.resize(ptsOnCurve);
				
				divV = 1.0 / (ptsOnCurve - 1);

				//TODO - remove computation from inner loop

				tt = (SPDouble)ii * divV;
				_tt = 1 - tt;

				for(SPInt k=0;k<=degree;k++)
				{	
					//SPDouble tt = (SPDouble)ii / (ptsOnCurve - 1);
					
					//if(_tt<=0) _tt=1;
					nfac   = factorial(degree);
					kfac   = factorial(k);
					n_kfac = factorial(degree - k);

					bb = (nfac/(n_kfac*kfac)) * pow(_tt, degree - k) * pow(tt, k); //Bernstein basis algorithm

					xx[ii] += (bb*points[k].x);
					yy[ii] += (bb*points[k].y);
				}
				mesh.m_tVertex.push_back(SPVec3t((T)xx[ii],(T)yy[ii], (T)0.0));
			}			
			return mesh;
		}
	};

}
#endif //_SP_BRESENHAM_LINE_H_