/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * TODO
 * @file   SPPaperSurface.cpp
 * @brief
 * @author
 */

#include "SPPaperSurface.h"
#include "SPMersenneTwister32.h"
#include <time.h>

SPhysics::SPMersenneTwister32 rand32;	//!< Mersenne twister32 instance

namespace SPhysics
{

/**
 * @brief  Gaussian random [0,1]
 */
double GaussianRand(double aMean, double aVariance)
{
	double u = 0.0;
	double r = 2;

	while (r == 0 || r > 1)
	{
		u = ((double)rand32.getValue() / (RAND32_MAX)) * 2 - 1;
		double v = ((double)rand32.getValue() / (RAND32_MAX)) * 2 - 1;
		r = u * u + v * v;
	}

	double result = (u * sqrt(-2 * log(r) / r) * aVariance) + aMean;

	if (result > 1.0f)
	{
		return 1.0f;
	}

	if (result < 0.0f)
	{
		return 0.0f;
	}

	return result;
}

/**
 * @brief  Gaussian random
 */
double SPPGaussianRandA(double aMean, double aVariance)
{
	double u = 0.0;
	double r = 2;

	while (r == 0 || r > 1)
	{
		u = ((double)rand32.getValue() / (RAND32_MAX)) * 2 - 1;
		double v = ((double)rand32.getValue() / (RAND32_MAX)) * 2 - 1;
		r = u * u + v * v;
	}

	double result = (u * sqrt(-2 * log(r) / r) * aVariance) + aMean;
	return result;
}

SurfaceCell::SurfaceCell() :
	height(0.0f),
	coeffsSum(0.0f)
{
}

PointsMediumStructure::PointsMediumStructure() :
	mWidth(0),
	mHeight(0),
	mMaxValue(0.0f),
	mMinValue(1.0f),
	mSurfaceLattice(NULL),
	mNumberOfBellPoints(0),
	mBellPoints(NULL)
{
	rand32.init(static_cast<unsigned int>(time(0)));
}

PointsMediumStructure::~PointsMediumStructure()
{
	if (mSurfaceLattice)
	{
		delete [] mSurfaceLattice;
		mSurfaceLattice = NULL;
	}

	if (mBellPoints)
	{
		delete [] mBellPoints;
		mBellPoints = NULL;
	}
}

void PointsMediumStructure::initSurfaceSize(int width, int height, int numberOfBellPoints)
{
	mWidth = width;
	mHeight = height;

	if (mSurfaceLattice)
	{
		delete [] mSurfaceLattice;
	}

	if (mBellPoints)
	{
		delete [] mBellPoints;
	}

	mSurfaceLattice = new SurfaceCell[mWidth * mHeight];
	mNumberOfBellPoints = numberOfBellPoints;
	mBellPoints = new BellPoint[numberOfBellPoints];
}

SurfaceCell* PointsMediumStructure::getSurfaceLattice()
{
	return mSurfaceLattice;
}

float PointsMediumStructure::minValue() const
{
	return mMinValue;
}

float PointsMediumStructure::maxValue() const
{
	return mMaxValue;
}

void PointsMediumStructure::createSurface(int bellImpactRadius, float curvatureMean, float curvatureDeviation,
		float heightMean, float heightDeviation)
{
	int latticeLength = mWidth * mHeight;

	for (int i = 0; i < latticeLength; ++i)
	{
		mSurfaceLattice[i].height = 0.0f;
		mSurfaceLattice[i].coeffsSum = 0.0f;
	}

	fillRandom(curvatureMean, curvatureDeviation, heightMean, heightDeviation);
	float distanceToBellPointX = 0.0f;
	float distanceToBellPointY = 0.0f;
	float distanceToBell = 0.0f;
	float height = 0.0f;
	float coeff = 0.0f;
	float curvature = 0.0f;
	float asymmetry = 0.0f;
	float maxShift = 0.0f;

	for (int k = 0; k < mNumberOfBellPoints; k++)
	{
		int bellPointX = 0;
		int bellPointY = 0;
		int startX = 0;
		int endX = 0;
		int startY = 0;
		int endY = 0;
		bellPointX = mBellPoints[k].x;
		bellPointY = mBellPoints[k].y;
		startX = bellPointX - bellImpactRadius;
		startX = startX < 0 ? 0 : startX;
		endX = bellPointX + bellImpactRadius;
		endX = endX > mWidth ? mWidth : endX;
		startY = bellPointY - bellImpactRadius;
		startY = startY < 0 ? 0 : startY;
		endY = bellPointY + bellImpactRadius;
		endY = endY > mHeight ? mHeight : endY;

		for (int j = startY; j < endY; j++)
		{
			for (int i = startX; i < endX; i++)
			{
				SurfaceCell& cell = mSurfaceLattice[j * mWidth + i];
				distanceToBellPointX = float(bellPointX - i);
				distanceToBellPointY = float(bellPointY - j);
				distanceToBell = sqrtf(distanceToBellPointX * distanceToBellPointX + distanceToBellPointY *
									   distanceToBellPointY);

				if (distanceToBell >= bellImpactRadius)
				{
					continue;
				}

				if (mBellPoints[k].isDirect)
				{
					height = mBellPoints[k].height * GAUSSIAN_APPROXIMATION(distanceToBell, mBellPoints[k].curvature);
				}
				else
				{
					height = mBellPoints[k].height * GAUSSIAN_APPROXIMATION_INVERSE(distanceToBell, mBellPoints[k].curvature);
				}

				curvature = 3.0f;
				asymmetry = 20.0f;
				maxShift = 2.0f;
				coeff = (curvature + asymmetry * distanceToBell) /
						(2.0f * (distanceToBell - maxShift) * (distanceToBell - maxShift) + (curvature + asymmetry * distanceToBell));
				cell.height += height * coeff;
				cell.coeffsSum += coeff;
			}
		}
	}

	for (int i = 0; i < latticeLength; i++)
	{
		float& h = mSurfaceLattice[i].height;
		float coeffsSum = mSurfaceLattice[i].coeffsSum;

		if (coeffsSum > 0.0001f)
		{
			h /= coeffsSum;
		}

		if (h > mMaxValue)
		{
			mMaxValue = h;
		}

		if (h < mMinValue)
		{
			mMinValue = h;
		}
	}

	float range = mMaxValue - mMinValue;
	float factor = 1.0f / range;

	for (int i = 0; i < latticeLength; i++)
	{
		float value = (mSurfaceLattice[i].height - mMinValue) * factor;
		mSurfaceLattice[i].height = value;
	}
}

void PointsMediumStructure::fillRandom(float curvatureMean, float curvatureDeviation, float heightMean,
									   float heightDeviation)
{
	for (int i = 0; i < mNumberOfBellPoints; i++)
	{
		mBellPoints[i].x = int(float(rand32.getValue()) / (float)0xffffffff * float(mWidth));
		mBellPoints[i].y = int(float(rand32.getValue()) / (float)0xffffffff * float(mHeight));
		float height = 1.0f;

		while (height <= 0.0000001f)
		{
			height = float(GaussianRand(heightMean, heightDeviation));
		}

		mBellPoints[i].height = height;
		float curvature = 0.0f;

		while (curvature <= 0.0000001f)
		{
			curvature = float(SPPGaussianRandA(curvatureMean, curvatureDeviation));
		}

		mBellPoints[i].curvature = curvature;
		mBellPoints[i].isDirect = rand32.getValue() > (0xffffffff >> 1);
	}
}

FibersMediumStructure::FibersMediumStructure() :
	mWidth(0),
	mHeight(0),
	mMaxValue(0.0f),
	mMinValue(1.0f),
	mSurfaceLattice(NULL),
	mNumberOfBellFibers(0),
	mBellFibers(NULL)
{
}

FibersMediumStructure::~FibersMediumStructure()
{
	if (mSurfaceLattice)
	{
		delete [] mSurfaceLattice;
	}

	if (mBellFibers)
	{
		delete [] mBellFibers;
	}
}

void FibersMediumStructure::initSurfaceSize(int width, int height, int numberOfBellFibers)
{
	mWidth = width;
	mHeight = height;

	if (mSurfaceLattice)
	{
		delete [] mSurfaceLattice;
	}

	if (mBellFibers)
	{
		delete [] mBellFibers;
	}

	mSurfaceLattice = new SurfaceCell[mWidth * mHeight];
	mNumberOfBellFibers = numberOfBellFibers;
	mBellFibers = new BellFiber[numberOfBellFibers];
}

SurfaceCell* FibersMediumStructure::getSurfaceLattice()
{
	return mSurfaceLattice;
}

float FibersMediumStructure::minValue() const
{
	return mMinValue;
}

float FibersMediumStructure::maxValue() const
{
	return mMaxValue;
}

void FibersMediumStructure::createSurface(int bellImpactRadius, float curvatureMean, float curvatureDeviation,
		float heightMean, float heightDeviation)
{
	int latticeLength = mWidth * mHeight;

	for (int i = 0; i < latticeLength; ++i)
	{
		mSurfaceLattice[i].height = 0.0f;
		mSurfaceLattice[i].coeffsSum = 0.0f;
	}

	fillRandom(curvatureMean, curvatureDeviation, heightMean, heightDeviation);
	float bellPointAngle = 0.0f;
	float bellVectorX = 0.0f;
	float bellVectorY = 0.0f;
	float distanceToBellPointX = 0.0f;
	float distanceToBellPointY = 0.0f;
	float dotProduct = 0.0f;
	float bellVectorLength = 0.0f;
	float distanceToBell = 0.0f;
	float cosine = 0.0f;
	float angle = 0.0f;
	float actualDistance = 0.0f;
	float height = 0.0f;
	float coeff = 0.0f;
	float curvature = 3.0f;
	float asymmetry = 20.0f;
	float maxShift = 2.0f;

	for (int k = 0; k < mNumberOfBellFibers; k++)
	{
		int bellPointX = 0;
		int bellPointY = 0;
		int startX = 0;
		int endX = 0;
		int startY = 0;
		int endY = 0;
		bellPointX = mBellFibers[k].x;
		bellPointY = mBellFibers[k].y;
		startX = bellPointX - bellImpactRadius;
		startX = startX < 0 ? 0 : startX;
		endX = bellPointX + bellImpactRadius;
		endX = endX > mWidth ? mWidth : endX;
		startY = bellPointY - bellImpactRadius;
		startY = startY < 0 ? 0 : startY;
		endY = bellPointY + bellImpactRadius;
		endY = endY > mHeight ? mHeight : endY;

		for (int j = startY; j < endY; j++)
		{
			for (int i = startX; i < endX; i++)
			{
				SurfaceCell& cell = mSurfaceLattice[j * mWidth + i];
				bellPointAngle = mBellFibers[k].angle;
				bellVectorX = cosf(bellPointAngle);
				bellVectorY = sinf(bellPointAngle);
				distanceToBellPointX = float(bellPointX - i);
				distanceToBellPointY = float(bellPointY - j);
				dotProduct = bellVectorX * distanceToBellPointX + bellVectorY * distanceToBellPointY;
				bellVectorLength = sqrtf(bellVectorX * bellVectorX + bellVectorY * bellVectorY);
				distanceToBell = sqrtf(distanceToBellPointX * distanceToBellPointX + distanceToBellPointY *
									   distanceToBellPointY);

				if (distanceToBell >= bellImpactRadius)
				{
					continue;
				}

				cosine = 1.0f;

				if (distanceToBell > 0.0001f)
				{
					cosine = dotProduct / (bellVectorLength * distanceToBell);
				}

				cosine = cosine > 1.0f ? 1.0f : cosine < -1.0f ? -1.0f : cosine;
				angle = acosf(cosine);

				if (angle > halfPi)
				{
					angle = pi - angle;
				}

				actualDistance = distanceToBell * sinf(angle);

				if (mBellFibers[k].isDirect)
				{
					height = mBellFibers[k].height * GAUSSIAN_APPROXIMATION(actualDistance, mBellFibers[k].curvature);
				}
				else
				{
					height = mBellFibers[k].height + (1.0f - mBellFibers[k].height) * GAUSSIAN_APPROXIMATION_INVERSE(
								 actualDistance, mBellFibers[k].curvature);
				}

				curvature = 3.0f;
				asymmetry = 20.0f;
				maxShift = 2.0f;
				coeff = (curvature + asymmetry * actualDistance) /
						(2.0f * (actualDistance - maxShift) * (actualDistance - maxShift) + (curvature + asymmetry * actualDistance));
				cell.height += height * coeff;
				cell.coeffsSum += coeff;
			}
		}
	}

	for (int i = 0; i < latticeLength; i++)
	{
		float& h = mSurfaceLattice[i].height;
		float coeffsSum = mSurfaceLattice[i].coeffsSum;

		if (coeffsSum > 0.0001f)
		{
			h /= coeffsSum;
		}

		if (h > mMaxValue)
		{
			mMaxValue = h;
		}

		if (h < mMinValue)
		{
			mMinValue = h;
		}
	}

	float range = mMaxValue - mMinValue;
	float factor = 1.0f / range;

	for (int i = 0; i < latticeLength; i++)
	{
		float value = (mSurfaceLattice[i].height - mMinValue) * factor;
		mSurfaceLattice[i].height = value;
	}
}

void FibersMediumStructure::fillRandom(float curvatureMean, float curvatureDeviation, float heightMean,
									   float heightDeviation)
{
	for (int i = 0; i < mNumberOfBellFibers; i++)
	{
		mBellFibers[i].x = int(float(rand32.getValue()) / (float)0xffffffff * float(mWidth));
		mBellFibers[i].y = int(float(rand32.getValue()) / (float)0xffffffff * float(mHeight));
		mBellFibers[i].angle = float(SPPGaussianRandA(0.0f, pi));
		float height = 0.0f;

		while (height <= 0.0001f)
		{
			height = float(GaussianRand(heightMean, heightDeviation));
		}

		mBellFibers[i].height = height;
		float curvature = 0.0f;

		while (curvature <= 1.0f)
		{
			curvature = float(SPPGaussianRandA(curvatureMean, curvatureDeviation));
		}

		mBellFibers[i].curvature = curvature;
		mBellFibers[i].isDirect = rand32.getValue() > (0xffffffff >> 1);
	}
}

//TODO - check usage - currently not used
void CalculateRandomCoefficients(int* aCoefficients, int aN)
{
	aCoefficients[0] = 1;

	for (int i = 0; i < aN; i++)
	{
		unsigned short r = (unsigned short)rand32.getValue();
		aCoefficients[i] = r;
	}
}

void CalculateBinomialCoefficients(int* aCoefficients, int aN)
{
	aCoefficients[0] = 1;

	for (int i = 1; i < aN; i++)
	{
		aCoefficients[i] = 0;
	}

	for (int i = 1; i < aN; i++)
	{
		for (int j = aN - 1; j > 0; j--)
		{
			aCoefficients[j] += aCoefficients[j - 1];
		}
	}
}

}
