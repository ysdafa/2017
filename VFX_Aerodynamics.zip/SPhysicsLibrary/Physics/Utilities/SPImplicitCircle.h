/**
* @file SPImplicitCircle.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_IMPLICIT_CIRCLE_H_
#define _SP_IMPLICIT_CIRCLE_H_

#include "SPDefines.h"

#include "SPImplicitPrimitive2D.h"

namespace SPhysics
{
	/**
	* @class     SPImplicitCircle
	* @brief     Implicit circle
	*/
	template<typename T>
	class SPImplicitCircle : public SPImplicitPrimitive2D<T>
	{
	private:
		SPVec2t center;
		T radius;
		SPBool outward;

	public:
		/**	
		* @brief     Constructor
		*/
		SPImplicitCircle();
		
		/**	
		* @brief     Constructor
		* @param     [IN] @b x
		* @param     [IN] @b y
		* @param     [IN] @b r
		* @param     [IN] @b outward_
		*/
		SPImplicitCircle(const T& x, const T& y, const T& r, const SPBool outward_ );
		
		/**	
		* @brief     Constructor
		* @param     [IN] @b pos
		* @param     [IN] @b r
		* @param     [IN] @b outward_

		*/
		SPImplicitCircle(const SPVec2t& pos, const T& r, const SPBool outward_ );
		virtual ~SPImplicitCircle(){}
		/**		
		* @brief	Get Signed distance     
		* @param     [IN] @b position
		* @return     T
		*/
		virtual T getSignedDist( const SPVec2t& position ) const;
		/**
		* @brief     Set center data of Circle 
		* @param     [IN] @b pos_x
		* @param     [IN] @b pos_y
		* @return     SPVoid
		*/
		SPVoid setCenter( const T& pos_x, const T& pos_y ) { center.set(pos_x,pos_y); }
		/**
		* @brief     Set center data of Circle
		* @param     [IN] @b position
		* @return     SPVoid
		*/
		SPVoid setCenter( const SPVec2t& position ) { center = position; }
		/**
		* @brief     Set center data of Circle
		* @param     [IN] @b radius_
		* @return     SPVoid
		*/
		SPVoid setRadius( const T& radius_ ) { radius = radius_; }
	};

	template<typename T>
	SPImplicitCircle<T>::SPImplicitCircle()
	{
		center.setZero();
		radius = 0;
		outward = SPTRUE;
	}

	template<typename T>
	SPImplicitCircle<T>::SPImplicitCircle( const T& x, const T& y, const T& r, const SPBool outward_ )
	{
		center = SPVec2t(x,y);
		radius = r;
		outward = outward_;
	};

	template<typename T>
	SPImplicitCircle<T>::SPImplicitCircle( const SPVec2t& pos, const T& r, const SPBool outward_ )
	{
		center = pos;
		radius = r;
		outward = outward_;
	};

	template<typename T>
	T SPImplicitCircle<T>::getSignedDist( const SPVec2t& position ) const 
	{
		T dist = ( (outward)?(1):(-1) ) * ( distance(center,position) - radius );
		if( isAlmostZero(dist) ) dist = -(T)EPSILON;
		return dist;
	}
}
#endif //_SP_IMPLICIT_CIRCLE_H_