/**
* @file SPFMM2D.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_FMM_2D_H_
#define _SP_FMM_2D_H_

#include "SPDefines.h"
#include "SPObject.h"
#include "SPFMMHeap.h"
#include "SPField2DTemplate.h"

#include <vector>
#include <queue>
#include <glm.hpp>

namespace SPhysics
{

	/**
	* @class     SPFMM2D
	* @brief     FMM 2D
	*/
	template<typename T>
	class SPFMM2D : SPObject
	{
	public:
		/**
		* @brief     FMM Heap 2D
		*/
		typedef typename std::priority_queue< SPFMMHeap2DNode<T>, std::vector<SPFMMHeap2DNode<T> >, SPFMMHeapCriterion2D<T> > FMMHeap2D;

	public:
		/**
		* @brief     Constructor
		*/
		SPFMM2D(){}
		
		/**
		* @brief     Destructor
		*/
		~SPFMM2D(){}

		/**
		* @brief     Reset all data sets of FMM
		* @return     SPVoid
		*/
		SPVoid reset() 
		{
			state.clear();
			heapNegative = FMMHeap2D();
			heapPositive = FMMHeap2D();

			resolution = SPVec2i();
			cellSize = SPVec2t();
			cellSizeSquard = SPVec2t();
			maxCellSize = (T)0;
			redistancingLevel = (T)0;
		}

		/**
		* @brief     Initialize FMM data sets
		* @param     [IN] @b sdf
		* @return     SPVoid
		*/
		SPVoid init(const SPField2DTemplate<T>& sdf)
		{
			resolution = sdf.getResolution();
			cellSize = sdf.getCellSize();
			cellSizeSquard = SPVec2t( cellSize.x*cellSize.x, cellSize.y*cellSize.y );
			maxCellSize = maximum<T>(cellSize.x,cellSize.y);
			redistancingLevel = maximum<T>((T)resolution.x,(T)resolution.y);

			state.clear();
			state.resize( sdf.getNumCells() );
		}


		/**
		* @brief     Check the Interface of FMM
		* @param     [IN] @b sdf
		* @return     SPVoid
		*/
		SPVoid checkInterface(SPField2DTemplate<T>& sdf);

		/**
		* @brief     Initialize the heap data
		* @param     [IN] @b S
		* @return     SPVoid
		*/
		SPVoid initHeap(const SPField2DTemplate<T> &S);

		/**
		* @brief     Update the phi
		* @param     [IN] @b sdf
		* @param     [IN] @b i
		* @param     [IN] @b j
		* @param     [IN] @b sgn
		* @return     SPVoid
		*/
		SPVoid updatePhi(SPField2DTemplate<T> &sdf, const SPInt& i, const SPInt& j, const SPInt& sgn);

		/**
		* @brief     Calculate the advance
		* @param     [IN] @b heap
		* @param     [IN] @b sdf
		* @param     [IN] @b i
		* @param     [IN] @b j
		* @param     [IN] @b sgn
		* @return     SPVoid
		*/
		SPVoid advance(FMMHeap2D &heap, const SPField2DTemplate<T> &sdf, const SPInt& i, const SPInt& j, const SPInt& sgn);

		/**
		* @brief     Recalculate the distance
		* @param     [IN] @b sdf
		* @return     SPVoid
		*/
		SPVoid recalculateDistance(SPField2DTemplate<T>& sdf);

	private:
		std::vector<SPChar> state;
		FMMHeap2D heapNegative;
		FMMHeap2D heapPositive;

		SPVec2i resolution;
		SPVec2t cellSize;
		SPVec2t cellSizeSquard;
		T maxCellSize;
		T redistancingLevel;

	};
}

#endif //_SP_FMM_2D_H_