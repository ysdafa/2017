/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPFloatChecker.h
 * @brief  File Float
 * @author Author Arthur Yusupov (a.yusupov@samsung.com)
 */

#ifndef _SP_FLOAT_CHECKER_H_
#define _SP_FLOAT_CHECKER_H_

namespace SPhysics
{

/**
 * Determine is passed value is 'NAN'.
 *
 * @param aValue Value to check
 * @return true if 'aValue' is nan, otherwise false.
 */
inline bool isNan(float aValue);
/**
 * Determine is passed value is not 'INF' and not 'NAN'.
 *
 * @param aValue Value to check
 * @return true if 'aValue' is finity otherwise false.
 */
inline bool isFinity(float aValue);
/**
 * Determine is passed value is 'INF'.
 *
 * @param aValue Value to check
 * @return true if 'aValue' is infinity otherwise false.
 */
inline bool isInf(float aValue);

/**
 * Returns infinity for float.
 *
 * @return infinity for float value.
 */
inline float getInf();

} /* namespace SPhysics */

#include "SPFloatChecker.inl"

#endif /* _SP_FLOAT_CHECKER_H_ */

