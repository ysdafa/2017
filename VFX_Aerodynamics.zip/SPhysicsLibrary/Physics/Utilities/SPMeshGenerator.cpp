/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPMeshGenerator.cpp
 * @brief  Generator of mesh for geometry primitives.
 * @author Andrii Burevych (a.burevych@samsung.com)
 */

#include "SPMeshGenerator.h"
#include "SPObjectData.h"
#include "SPMesh.h"

#include "SPDefines.h"

#include <glm.hpp>
#include <gtc/constants.hpp>


namespace SPhysics
{

#define HALF_POINT_COUNT 6				//!< Half point count
#define HALF_POINT_COUNT_ELLIPSOID 5	//!< Half point count ellipsoid
#define HALF_POINT_COUNT_FOR_CAPSULE 6	//!< Half point count for capsule

void SPMeshGenerator::generateSphere(SPObjectData& aObject, const float aRadius)
{
	SPhysics::SPMesh mesh;
	unsigned int pointCount = 2 * HALF_POINT_COUNT;
	unsigned int vertexCount = pointCount * (pointCount + 1);
	float sect = glm::half_pi<float>() / float(HALF_POINT_COUNT);
	float float_sect = glm::pi<float>() / float(HALF_POINT_COUNT);

	for (unsigned int z = 0; z <= pointCount; z++)
	{
		float angl_z = sect * float(z);
		float sin_z = sin(angl_z);
		float cos_z = cos(angl_z);

		for (unsigned int i = 0; i < pointCount; i++)
		{
			float angl_i = float_sect * float(i);
			mesh.pushbackVertex(SPVec3f(sin(angl_i) * sin_z * aRadius, cos(angl_i) * sin_z * aRadius, cos_z * aRadius));
		}
	}

	mesh.m_tTextureUV.resize(vertexCount, SPVec3f());

	for (unsigned int z = 0; z < pointCount; z++)
	{
		unsigned short pointCountDotZ = (unsigned short)(pointCount * z);
		unsigned short pointCountDotZ1 = (unsigned short)(pointCountDotZ + pointCount);

		for (unsigned short q = 0; q < pointCount; q++)
		{
			mesh.pushbackVertexIndex((unsigned short)(pointCountDotZ1 + q));
			mesh.pushbackVertexIndex((unsigned short)(pointCountDotZ + q));
		}

		mesh.pushbackVertexIndex((unsigned short)(pointCountDotZ1));
		mesh.pushbackVertexIndex((unsigned short)(pointCountDotZ));
	}

	for (unsigned int i = 0; i < vertexCount; i++)
	{
		SPVec3f v = (*mesh.getVertex())[i];
		glm::vec3 n = glm::normalize(glm::vec3(v.x,v.y,v.z));
		mesh.pushbackNormal(SPVec3f(n.x,n.y,n.z));
	}

	aObject = mesh;
	//aObject.mRenderMode = TriangleStrip; // remove material from RefObject
}

void SPMeshGenerator::generateBox(SPObjectData& aObject, const glm::vec3& aHalfExt)
{
	SPhysics::SPMesh mesh;
	const glm::vec3 vertexArr[] =
	{ glm::vec3(-1.f, 1.f, 1.f), glm::vec3(1.f, 1.f, 1.f), glm::vec3(1.f, 1.f, -1.f), glm::vec3(-1.f, 1.f, -1.f), glm::vec3(-1.f, -1.f, 1.f), glm::vec3(1.f, -1.f, 1.f), glm::vec3(1.f, -1.f, -1.f), glm::vec3(-1.f, -1.f, -1.f) };
	unsigned short indexArr[] =
	{ 0, 1, 2, 0, 2, 3, 4, 7, 5, 5, 7, 6, 4, 5, 0, 0, 5, 1, 3, 6, 7, 3, 2, 6, 3, 7, 4, 3, 4, 0, 1, 5, 6, 1, 6, 2 };
	mesh.m_tVertexIndex.resize(COUNT_OF(indexArr));
	memcpy(&mesh.m_tVertexIndex[0], indexArr, sizeof(indexArr));
	mesh.m_tTextureUV.resize(COUNT_OF(indexArr), SPVec3f());

	for (unsigned int i = 0; i < COUNT_OF(vertexArr); i++)
	{
		glm::vec3 ve = vertexArr[i] * aHalfExt;
		glm::vec3 n = glm::normalize(vertexArr[i]);
		mesh.pushbackVertex(SPVec3f(ve.x,ve.y,ve.z));
		mesh.pushbackNormal(SPVec3f(n.x,n.y,n.z));
	}

	aObject = mesh;
	//aObject.mRenderMode = Triangles; // remove material from RefObject
}

void SPMeshGenerator::generateCapsule(SPObjectData& aObject, const float aRadius, const float aHalfLenght)
{
	SPhysics::SPMesh mesh;
	unsigned int pointCount = 2 * HALF_POINT_COUNT_FOR_CAPSULE + 1;
	unsigned int vertexCount = pointCount * (pointCount + 1);
	float sect = glm::half_pi<float>() / (float(HALF_POINT_COUNT_FOR_CAPSULE) + 0.5f);
	float float_sect = glm::pi<float>() / (float(HALF_POINT_COUNT_FOR_CAPSULE) + 0.5f);

	for (unsigned int z = 0; z <= pointCount; z++)
	{
		float angl_z = sect * float(z);
		float sin_z = sin(angl_z);
		float cos_z = cos(angl_z);

		for (unsigned int i = 0; i < pointCount; i++)
		{
			float angl_i = float_sect * float(i);
			mesh.pushbackVertex(SPVec3f(sin(angl_i) * sin_z, cos(angl_i) * sin_z, cos_z) * aRadius);
		}
	}

	mesh.m_tTextureUV.resize(vertexCount, SPVec3f());

	for (unsigned int z = 0; z < pointCount; z++)
	{
		unsigned short pointCountDotZ = (unsigned short)(pointCount * z);
		unsigned short pointCountDotZ1 = (unsigned short)(pointCountDotZ + pointCount);

		for (unsigned int q = 0; q < pointCount; q++)
		{
			mesh.pushbackVertexIndex((unsigned short)(pointCountDotZ1 + q));
			mesh.pushbackVertexIndex((unsigned short)(pointCountDotZ + q));
		}

		mesh.pushbackVertexIndex(pointCountDotZ1);
		mesh.pushbackVertexIndex(pointCountDotZ);
	}

	for (unsigned int i = 0; i < vertexCount; i++)
	{
		if (i < vertexCount / 2)
		{
			(*mesh.getVertex())[i] += SPVec3f(0.f, 0.f, aHalfLenght);
		}
		else
		{
			(*mesh.getVertex())[i] -= SPVec3f(0.f, 0.f, aHalfLenght);
		}

		SPVec3f v = (*mesh.getVertex())[i];
		glm::vec3 n = glm::normalize(glm::vec3(v.x,v.y,v.z));

		mesh.pushbackNormal(SPVec3f(n.x,n.y,n.z));
	}

	aObject = mesh;
	//aObject.mRenderMode = TriangleStrip; // remove material from RefObject
}

void SPMeshGenerator::generateEllipsoid(SPObjectData& aObject, const glm::vec3& aEllipsoidCoef)
{
	SPhysics::SPMesh mesh;
	unsigned int pointCount = 2 * HALF_POINT_COUNT_ELLIPSOID;
	unsigned int vertexCount = pointCount * (pointCount + 1);
	float uStep = glm::half_pi<float>() / float(HALF_POINT_COUNT_ELLIPSOID);
	float vStep = glm::pi<float>() / float(HALF_POINT_COUNT_ELLIPSOID);

	for (int i = -HALF_POINT_COUNT_ELLIPSOID; i <= HALF_POINT_COUNT_ELLIPSOID; i++)
	{
		float u = uStep * float(i);
		float z = aEllipsoidCoef.z * sin(u);
		float cos_u = cos(u);

		for (int j = -HALF_POINT_COUNT_ELLIPSOID; j < HALF_POINT_COUNT_ELLIPSOID; j++)
		{
			float v = vStep * float(j);
			mesh.pushbackVertex(SPVec3f(aEllipsoidCoef.x * cos_u * cos(v),
									 aEllipsoidCoef.y * cos_u * sin(v),
									 z));
		}
	}

	mesh.m_tTextureUV.resize(vertexCount, SPVec3f());

	for (unsigned int z = 0; z < pointCount; z++)
	{
		unsigned short pointCountDotZ = (unsigned short)(pointCount * z);
		unsigned short pointCountDotZ1 = (unsigned short)(pointCountDotZ + pointCount);

		for (unsigned short q = 0; q < pointCount; q++)
		{
			mesh.pushbackVertexIndex((unsigned short)(pointCountDotZ1 + q));
			mesh.pushbackVertexIndex((unsigned short)(pointCountDotZ + q));
		}

		mesh.pushbackVertexIndex((unsigned short)(pointCountDotZ1));
		mesh.pushbackVertexIndex((unsigned short)(pointCountDotZ));
	}

	for (unsigned int i = 0; i < vertexCount; i++)
	{
		SPVec3f v = (*mesh.getVertex())[i];
		glm::vec3 n = glm::normalize(glm::vec3(v.x,v.y,v.z));

		mesh.pushbackNormal(SPVec3f(n.x,n.y,n.z));
	}

	aObject = mesh;
	//aObject.mRenderMode = LineStrip; // remove material from RefObject
}


void SPMeshGenerator::generateGrid(SPObjectData& aObject, const unsigned int aWidth, const unsigned int aHeight)
{
	SPhysics::SPMesh mesh;
	unsigned int tVertexCount = aWidth * aHeight;
	unsigned short tID = 0;
	SPVec3f tVec(0.0f, 0.0f, 0.0f);
	std::vector<std::vector<unsigned short> > tIndexTable(aHeight);
	float tDelX = 1.0f / static_cast<float>(aWidth - 1);
	float tDelY = 1.0f / static_cast<float>(aHeight - 1);
	SPVec3f tTexCoor(0.0f, 1.0f, 0.0f);

	for (unsigned int y = 0; y < aHeight; ++ y)
	{
		tIndexTable[y].resize(aWidth);

		for (unsigned int x = 0; x < aWidth; ++ x)
		{
			mesh.pushbackVertex(tVec);
			tIndexTable[y][x] = tID;
			tID ++;
			tVec.x += 1.0f;
			mesh.pushbackTextureUV(tTexCoor);
			tTexCoor.x += tDelX;
		}

		tVec.x = 0.0f;
		tVec.y += 1.0f;
		tTexCoor.x = 0.0f;
		tTexCoor.y -= tDelY;
	}

	for (unsigned int y = 0; y < (aHeight - 1); ++ y)
	{
		for (unsigned int x = 0; x < (aWidth - 1); ++ x)
		{
			mesh.pushbackVertexIndex(tIndexTable[y][x]);
			mesh.pushbackVertexIndex(tIndexTable[y + 1][x]);
			mesh.pushbackVertexIndex(tIndexTable[y + 1][x + 1]);
			mesh.pushbackVertexIndex(tIndexTable[y][x]);
			mesh.pushbackVertexIndex(tIndexTable[y + 1][x + 1]);
			mesh.pushbackVertexIndex(tIndexTable[y][x + 1]);
		}
	}

	//mesh.m_tTextureUV.resize(tVertexCount, glm::vec3());
	tVec = SPVec3f(0.0f, 0.0f, 1.0f);

	for (unsigned int i = 0; i < tVertexCount; ++ i)
	{
		mesh.pushbackNormal(tVec);
	}

	
	aObject = mesh;//std::move(mesh);
	//aObject.mRenderMode = Triangles; // remove material from RefObject
}

} //namespace SPhysics

