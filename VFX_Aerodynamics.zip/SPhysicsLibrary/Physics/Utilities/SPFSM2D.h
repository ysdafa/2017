/**
* @file SPFSM2D.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_FSM_2D_H_
#define _SP_FSM_2D_H_

#include "SPDefines.h"
#include "SPObject.h"
#include "SPField2DTemplate.h"

#include <vector>
#include <glm.hpp>

namespace SPhysics
{

	/**
	* @class     SPFSM2D
	* @brief     FSM 2D
	*/
	template<typename T>
	class SPFSM2D : SPObject
	{
	public:
		/**
		* @brief	Constructor     
		*/
		SPFSM2D(){}
		/**
		* @brief     Destructor
		*/
		~SPFSM2D(){}

		/**
		* @brief      Reset data of FSM
		* @return     SPVoid
		*/
		SPVoid reset() {
			state.clear();

			resolution = SPVec2i();
			cellSize = SPVec2t();
			cellSizeSquard = SPVec2t();
		}

		/**
		* @brief     Initialize data of FSM
		* @param     [IN] @b sdf
		* @param     [IN] @b a
		* @param     [IN] @b b
		* @return     SPVoid
		*/
		SPVoid init(const SPField2DTemplate<T>& sdf, const T& a, const T& b) {
			state.clear();
			state.resize( sdf.getNumCells() );

			resolution = sdf.getResolution();
			cellSize = sdf.getCellSize();
			cellSizeSquard = SPVec2t( cellSize.x*cellSize.x, cellSize.y*cellSize.y );

			alpha = a;
			beta = b;
		}

		/**
		* @brief     Check the interface
		* @param     [IN] @b state
		* @param     [IN] @b sdf
		* @return     SPVoid
		*/
		SPVoid checkInterface(std::vector<SPChar>& state, SPField2DTemplate<T>& sdf);

		/**
		* @brief     Update the phi
		* @param     [IN] @b phi
		* @param     [IN] @b infoX
		* @param     [IN] @b infoY
		* @param     [IN] @b D
		* @param     [IN] @b maxDist
		* @param     [IN] @b state
		* @return     SPVoid
		*/
		SPVoid updatePhi(T& phi, T infoX, T infoY, const SPVec2t& D, const T& maxDist, const SPChar state);


		/**
		* @brief     Recalculate the distance
		* @param     [IN] @b sdf
		* @return     SPVoid
		*/	
		SPVoid recalculateDistance(SPField2DTemplate<T>& sdf);

	private:
		std::vector<SPChar> state;

		SPVec2i resolution;
		SPVec2t cellSize;
		SPVec2t cellSizeSquard;

		T alpha, beta;

	};

}

#endif //_SP_FSM_2D_H_