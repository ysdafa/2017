/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPFileLoad.cpp
 * @brief  File File
 * @author Author Arthur Yusupov (a.yusupov@samsung.com)
 */

#include "SPFileLoad.h"
#include "SPException.h"

#ifndef ANDROID
#include <stdio.h>
#endif
#include <string.h>

namespace SPhysics
{

SPFile::SPFile()
{
}

SPFile::SPFile(const std::string& aName)
{
	load(aName);
}

#ifdef ANDROID

void SPFile::load(const std::string& aName)
{
	AAssetManager *assetManager = SPAssetManager::GetInstancePtr()->GetAAssetManager();
	RUNTIME_VALUE_CHECK(assetManager == NULL);
	AAsset* asset = AAssetManager_open(assetManager, aName.c_str(), AASSET_MODE_UNKNOWN);
	if (asset == NULL)
	{
		//THROW("Invalid file name: " + aName, invalid_argument);
	}
	RUNTIME_VALUE_CHECK(asset == NULL);
	mBuffer.resize(AAsset_getLength(asset));
	AAsset_read(asset, &mBuffer[0], mBuffer.size());
	AAsset_close(asset);
}

#else

void SPFile::load(const std::string& aName)
{
	FILE* file = fopen(aName.c_str(), "rb");

	if (file == NULL)
	{
		THROW("Invalid file name: " + aName, invalid_argument);
	}

	RUNTIME_VALUE_CHECK(file == NULL);
	fseek(file, 0, SEEK_END);
	int fileLength = ftell(file);
	RUNTIME_VALUE_CHECK(fileLength < 0);
	int seekSuccess = fseek(file, 0, SEEK_SET);
	RUNTIME_VALUE_CHECK(seekSuccess != 0);
	mBuffer.resize(fileLength);
	int fileReadLen = fread(&mBuffer[0], 1, mBuffer.size(), file);
	RUNTIME_VALUE_CHECK(fileReadLen != fileLength);
	fclose(file);
}

#endif

void* SPFile::getBuffer()
{
	return &mBuffer[0];
}
void SPFile::write(const void* aBuffer, const unsigned int aSize)
{
	unsigned int offset = mBuffer.size();
	mBuffer.resize(offset + aSize);
	memcpy(&mBuffer[0] + offset, aBuffer, aSize);
}

void SPFile::flush(const std::string& aName)
{
#ifdef ANDROID
	FILE* file = fopen(("/sdcard/" + aName).c_str(), "wb");
#else
	FILE* file = fopen(("sdcard/" + aName).c_str(), "wb");
#endif
	if (file == NULL)
	{
		SP_LOGE("Can not file.");
		return;
	}
	unsigned int fileWriteLen = fwrite(&mBuffer[0], 1, mBuffer.size(), file);
	RUNTIME_VALUE_CHECK(fileWriteLen != mBuffer.size());
	fclose(file);
	mBuffer.clear();
}

unsigned int SPFile::getLength() const
{
	return mBuffer.size();
}

#ifdef ANDROID // TODO : remove

AAssetManager*& SPFile::getAssetManager()
{
	static AAssetManager* assetManager = NULL;
	return assetManager;
}

#endif

} /* namespace SPhysics */
