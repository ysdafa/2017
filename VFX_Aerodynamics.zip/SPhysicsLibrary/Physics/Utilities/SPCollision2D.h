/**
* @file SPCollision2D.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_COLLISION_2D_H_
#define _SP_COLLISION_2D_H_

#include "SPDefines.h"
#include "SPObject.h"
#include "SPParticle2D.h"

#include <glm.hpp>

namespace SPhysics
{
	/**
	* @class     SPCollision2D
	* @brief     Collision 2D
	*/
	template<typename T>
	class SPCollision2D : SPObject
	{
	public:

		/**
		* @brief     Check a collision for wall
		* @param     [IN] @b particle
		* @param     [IN] @b wallSpringCoefficient
		* @param     [IN] @b position
		* @param     [IN] @b minPosition minimum position
		* @param     [IN] @b maxPosition maximum position
		* @return     SPVoid
		*/
		SPVoid checkForWall( SPParticle2D<T>& particle, const T& wallSpringCoefficient,
			const SPVec2t& position, const SPVec2t& minPosition, const SPVec2t& maxPosition );

		/**
		* @brief     Check a collision for wall
		* @param     [IN] @b ptcPosition particle position
		* @param     [IN] @b ptcVelocity particle velocity
		* @param     [IN] @b restitutionCoefficient
		* @param     [IN] @b boxMinPosition box minimum position
		* @param     [IN] @b boxMaxPosition box maximum position
		* @return     SPVoid
		*/
		SPVoid checkForWall( SPVec2t& ptcPosition, SPVec2t& ptcVelocity, const T& restitutionCoefficient,
			const SPVec2t& boxMinPosition, const SPVec2t& boxMaxPosition );

		// For Soap Bubble
		/**
		* @brief     Check a collision for wall ( Soap Bubble )
		* @param     [IN] @b ptcPosition particle position
		* @param     [IN] @b radius	particle radius
		* @param     [IN] @b ptcVelocity particle velocity
		* @param     [IN] @b restitution coefficient
		* @param     [IN] @b boxMinPosition box minimum position
		* @param     [IN] @b boxMaxPosition box maximum position
		* @return     SPVoid
		*/
		SPVoid checkForWall( SPVec2t& ptcPosition, T radius, SPVec2t& ptcVelocity, const T& restitutionCoefficient,
			const SPVec2t& boxMinPosition, const SPVec2t& boxMaxPosition );

		/**
		* @brief     particle-particle collision
		* @param     [IN] @b p1 particle1
		* @param     [IN] @b p2 particle2 
		* @return     SPBool
		*/
		SPBool isCollision( const SPParticle2D<T>& p1, const SPParticle2D<T>& p2 )
		{
			const T r1r2 = p1.getRadius() + p2.getRadius();
			const SPVec2t v = p1.getPosition()-p2.getPosition();

			return ( pow2(r1r2) > ( pow2(v.x) + pow2(v.y) ) );
		}
	};

}

#endif //_SP_COLLISION_2D_H_