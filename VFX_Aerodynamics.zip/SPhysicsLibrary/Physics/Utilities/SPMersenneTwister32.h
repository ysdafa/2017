/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

#ifndef _MERSENNETWISTER32_H_
#define _MERSENNETWISTER32_H_

#include <stdint.h>

// Mersenne Twister parameters
#define _MT32_N 624
#define _MT32_M 397
#define _MT32_MATRIX_A 0x9908b0dfUL
#define _MT32_UPPER_MASK 0x80000000UL
#define _MT32_LOWER_MASK 0x7fffffffUL
#define RAND32_MAX  0xffffffffUL

#define GAUSSIAN_APPROXIMATION( argumentSquared, curvature ) (curvature / (2.0f * argumentSquared + curvature))
#define GAUSSIAN_APPROXIMATION_INVERSE( argumentSquared, curvature ) ((argumentSquared) / ((argumentSquared) + 0.5f * (curvature)))

namespace SPhysics
{

/**
 * @class  SPMersenneTwister32
 * @brief  Mersenne twister 32
 */
class SPMersenneTwister32
{

public:

	SPMersenneTwister32();

	/**
	* @brief  Init
	*/
	void init(uint32_t s);

	/**
	* @brief  Get value
	*/
	uint32_t getValue();

private:

	uint32_t mt[_MT32_N];
	uintptr_t mti;
};

}    // namespace SPhysics

extern SPhysics::SPMersenneTwister32 rand32;

#endif // _MERSENNETWISTER32_H_
