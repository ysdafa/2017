/**
* @file SPMaterialProperty.cpp
* @brief 
*
* @date 2014-02-04
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/
#include "SPMaterialProperty.h"

namespace SPhysics
{
	SPMaterialProperty::SPMaterialProperty() :
		m_MaterialExponent(0.0f),
		m_Shininess(1.0f),
		m_Reflectivity(1.0f),
		m_Transparency(1.0f),
		m_IndexOfRefraction(1.0f),
		m_CastShadow(false),
		m_ShaderType(SP_ST_BLINN)
	{
	}

	SPMaterialProperty::~SPMaterialProperty()
	{
	}
}

