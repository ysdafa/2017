/**
* @file SPScene.h
* @brief Scene related data structures
*
* @date 2014-01-29
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_SCENE_H_
#define _SP_SCENE_H_

#include "SPMesh.h"
#include "SPMaterialProperty.h"
#include "SPLight.h"
#include "SPCamera.h"

#include <vector>
#include <glm.hpp>

namespace SPhysics
{

	/**
	* @struct    SPModel
	* @brief     Model is entity which has (or consists of) mesh, material and transform data.
	*/
	struct SPModel
	{
		SPMesh mMesh;					//!< Mesh
		SPMat4x4f mTransform;			//!< Transform
		SPMaterialProperty mMaterial;	//!< Material
	};

	/**
	* @struct    SPScene
	* @brief     Structure which contains all scene related data: arrays of objects(models), light sources and cameras
	*/
	struct SPScene
	{
		std::vector<SPLight> mLightArr;		//!< Array of light sources
		std::vector<SPModel> mModelArr;		//!< Array of models(objects)
		std::vector<SPCamera> mCameraArr;	//!< Array of cameras
	};

} //namespace SPhysics

#endif // _SP_SCENE_H_