/**
* @file SPLightProperty.h
* @brief This file includes module that manages light's properties.
*
* @date 2013-05-04
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/


#ifndef _SP_LIGHT_PROPERTY_H_
#define _SP_LIGHT_PROPERTY_H_

#include "SPDefines.h"

#include <vector>
#include <glm.hpp>

namespace SPhysics
{

	/**
	* @class     SPLightProperty
	* @brief     This class manages and specifies light properties. 
	*/
	class SPLightProperty
	{
	public:
		
		/**
		* @enum    LIGHT_TYPE
		* @brief    enumerate Light Type
		*/
		enum LIGHT_TYPE
		{
			DIRECTIONAL_LIGHT=0,
			POINT_LIGHT=1,
			SPOT_LIGHT,
			MAX_SELECTED_E_EXAMPLE
		};

		/**
		* @brief     Constructor
		*/
		SPLightProperty();
		
		/**
		* @brief     Destructor
		*/
		~SPLightProperty();

		/**
		* @struct      _LIGHT_PROPERTY
		* @brief     light's properties ( position, ambient color, diffuse color, direction , etc)
		*/
		typedef struct _LIGHT_PROPERTY {
			SPVec3f position;		//!< Position
			SPVec4f ambientColor;	//!< Ambient color
			SPVec4f diffuseColor;	//!< Diffuse color
			SPVec4f specularColor;	//!< Specular color
			SPVec4f lightdirection;	//!< Light direction
			SPFloat cutoffangle;	//!< Cut-off angle
			SPFloat spotexponent;	//!< Spot exponent
		} LIGHT_PROPERTY;	//!< Light properties

		/**
		* @struct      _ATTENUATION_PROPERTY
		* @brief     light's attenuation properties
		*/
		typedef struct _ATTENUATION_PROPERTY {
			SPFloat constantAttenuation;	//!< Constant attenuation
			SPFloat linearAttenuation;		//!< Linear attenuation
			SPFloat quadraticAttenuation;	//!< Quadratic attenuation
		} ATTENUATION_PROPERTY;	//!< Attenuation properties (a=1/(c+l*d+q*d*d))

		/**
		* @brief     Set light's position
		* @param     [IN] @b x X-Position
		* @param     [IN] @b y Y-Position
		* @param     [IN] @b z Z-Position
		* @return     SPVoid
		*/
		SPVoid setLightPosition(const SPFloat x, const SPFloat y, const SPFloat z);

		/**
		* @brief     Set ambient color
		* @param     [IN] @b r Red color value of light (0~1.f)
		* @param     [IN] @b g Green color value of light (0~1.f)
		* @param     [IN] @b b Blue color value of light (0~1.f)
		* @param     [IN] @b a Alpha channel value of light (0~1.f)
		* @return     SPVoid
		*/
		SPVoid setLightAmbientColor(const SPFloat r, const SPFloat g, const SPFloat b, const SPFloat a);
		
		/**
		* @brief     Set Diffuse color
		* @param     [IN] @b r Red color value of light (0~1.f)
		* @param     [IN] @b g Green color value of light (0~1.f)
		* @param     [IN] @b b Blue color value of light (0~1.f)
		* @param     [IN] @b a Alpha channel value of light (0~1.f)
		* @return     SPVoid
		*/
		SPVoid setLightDiffuseColor(const SPFloat r, const SPFloat g, const SPFloat b, const SPFloat a);
		
		/**
		* @brief     Set Specular color
		* @param     [IN] @b r Red color value of light (0~1.f)
		* @param     [IN] @b g Green color value of light (0~1.f)
		* @param     [IN] @b b Blue color value of light (0~1.f)
		* @param     [IN] @b a Alpha channel value of light (0~1.f)
		* @return     SPVoid
		*/
		SPVoid setLightSpecularColor(const SPFloat r, const SPFloat g, const SPFloat b, const SPFloat a);
		
		/**
		* @brief     Set light's direction
		* @param     [IN] @b x X-direction value
		* @param     [IN] @b y Y-direction value
		* @param     [IN] @b z Z-direction value
		* @return     SPVoid
		*/
		SPVoid setLightDirection(const SPFloat x, const SPFloat y, const SPFloat z);
		
		/**
		* @brief     Set light's Cut-off-angle
		* @param     [IN] @b angle The angle of Cut-Off
		* @return     SPVoid
		*/
		SPVoid setLightCutoffAngle(const SPFloat angle);
		
		/**
		* @brief     Set light's Spot exponent 
		* @param     [IN] @b exp Specifies the exponent of Spot 
		* @return     SPVoid
		*/
		SPVoid setLightSpotExp(const SPFloat exp);
		
		/**
		* @brief     Set Attenuation properties
		* @param     [IN] @b constant Specifies constant attenuation
		* @param     [IN] @b linear Specifies linear attenuation
		* @param     [IN] @b quadratic Specifies quadratic attenuation
		* @return     SPVoid
		*/
		SPVoid setAttenuationProperty(const SPFloat constant, const SPFloat linear, const SPFloat quadratic);

		/**
		* @brief     Get light's position
		* @return     SPFloat* return light's position
		*/
		SPFloat* getLightPosition(){ return (SPFloat*)&m_stLightValue.position;}
		

		/**
		* @brief     Get light's ambient color
		* @return     SPFloat* return light's ambient-color
		*/
		SPFloat* getLightAmbientColor(){ return (SPFloat*)&m_stLightValue.ambientColor;}
		
		/**
		* @brief     Get light's diffuse color
		* @return     SPFloat* return light's diffuse-color
		*/
		SPFloat* getLightDiffuseColor(){ return (SPFloat*)&m_stLightValue.diffuseColor;}
		
		/**
		* @brief     Get light's specular color
		* @return     SPFloat* return light's specular-color
		*/
		SPFloat* getLightSpecularColor(){ return (SPFloat*)&m_stLightValue.specularColor;}
		/**
		* @brief     Get light's direction
		* @return     SPFloat* return light's direction
		*/
		SPFloat* getLightDirection(){ return (SPFloat*)&m_stLightValue.lightdirection;}
	    
		/**
		* @brief     Get Light's cut off angle value
		* @return     SPFloat return light's cut-off-angle
		*/
		SPFloat getLightCutoffAngle(){ return m_stLightValue.cutoffangle;}
		
		/**
		* @brief     Get Light spot exponent value
		* @return     SPFloat return light's spot exponent
		*/
		SPFloat getLightSpotExp(){ return m_stLightValue.spotexponent;}

		/**
		* @brief     Get constant attenuation value
		* @return     SPFloat return constant-attenuation value
		*/
		SPFloat getConstAttenuation(){ return m_stAttenuationValue.constantAttenuation;}
		
		/**
		* @brief     Get linear attenuation value
		* @return     SPFloat return linear-attenuation value
		*/
		SPFloat getLinearAttenuation(){ return m_stAttenuationValue.linearAttenuation;}
		
		/**
		* @brief     Get quadratic attenuation value
		* @return     SPFloat return quadratic-attenuation value
		*/
		SPFloat getQuadraticAttenuation(){ return m_stAttenuationValue.quadraticAttenuation;}


	private:
		LIGHT_TYPE	   m_eLightType;
		LIGHT_PROPERTY m_stLightValue;
		ATTENUATION_PROPERTY m_stAttenuationValue;
	};
} //namespace SPhysics

#endif // _SP_LIGHT_PROPERTY_H_