/**
* @file SPShaderManager.cpp
* @brief 
*
* @date 
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/


#include <stdio.h> 
#include <stdlib.h>

#include "SPLog.h"
#include "SPShaderManager.h"


namespace SPhysics
{
	SPShaderManager::SPShaderManager() :m_nProgramObject(0)
	{
		m_vAttributeLoc.clear();
		m_vUniformLoc.clear();
	}

	SPShaderManager::~SPShaderManager()
	{
		reset();
	}


	SPVoid SPShaderManager::reset()
	{
		if(m_nProgramObject != 0)
			glDeleteProgram (m_nProgramObject);

		if(m_vAttributeLoc.size() != 0)
			m_vAttributeLoc.clear();

		if(m_vUniformLoc.size() != 0)
			m_vUniformLoc.clear();
	}


	SPVoid SPShaderManager::createProgram( const SPChar* vertexShaderCode, const SPChar* fragmentShaderCode )
	{
		SPUInt vertexShaderHandler;
		SPUInt fragmentShaderHandler;

		// create a shader object for vertex shader
		vertexShaderHandler = glCreateShader ( GL_VERTEX_SHADER );

		if ( vertexShaderHandler == 0 )
		{
			SP_LOGE ( "Error :: create a shader object for vertex shader\n");
			return;
		}

		// create a shader object for fragment shader
		fragmentShaderHandler = glCreateShader ( GL_FRAGMENT_SHADER );

		if ( fragmentShaderHandler == 0 )
		{
			SP_LOGE ( "Error :: create a shader object for fragment shader\n");
			glDeleteShader( vertexShaderHandler );
			return;
		}

		// compile the vertex shader
		if(!compileShader(vertexShaderHandler, vertexShaderCode))
		{
			SP_LOGE ( "Error :: compile a shader object for vertex shader\n");
			return;
		}
		
		// compile the fragment shader
		if(!compileShader(fragmentShaderHandler, fragmentShaderCode))
		{
			SP_LOGE ( "Error :: compile a shader object for fragment shader\n");
			return;
		}

		// Create a program object
		m_nProgramObject = glCreateProgram( );

		if(m_nProgramObject != 0)
		{
			glAttachShader ( m_nProgramObject, vertexShaderHandler );
			glAttachShader ( m_nProgramObject, fragmentShaderHandler );
		}
		else
		{
			SP_LOGE ( "Error :: create a program object\n");
			return;
		}
		
		// Link the program
		glLinkProgram ( m_nProgramObject );

		// delete a shader object for vertex & fragment shader
		glDeleteShader ( vertexShaderHandler );
		glDeleteShader ( fragmentShaderHandler );
		
		// Check the link status
		SPInt isLinkError = 0;
		glGetProgramiv ( m_nProgramObject, GL_LINK_STATUS, &isLinkError );

		// if error status about the link
		if ( !isLinkError ) 
		{
			printGLErrorLog(m_nProgramObject, 1);
			glDeleteProgram ( m_nProgramObject );

			return;
		}

	}

	SPVoid SPShaderManager::addAttribute( SPInt index, const SPChar* attributeName )
	{
		if(m_nProgramObject == 0)
			return;

		SPVec2u attributeLoc;

		attributeLoc.y = glGetAttribLocation(m_nProgramObject, attributeName);
		attributeLoc.x = index;

		m_vAttributeLoc.push_back(attributeLoc);
	}

	SPVoid SPShaderManager::addUniform( SPInt index, const SPChar* uniformName )
	{
		if(m_nProgramObject == 0)
			return;

		SPVec2i uniformLoc;

		uniformLoc.y = glGetUniformLocation ( m_nProgramObject, uniformName );
		uniformLoc.x = index;

		m_vUniformLoc.push_back(uniformLoc);
		
	}

	SPUInt SPShaderManager::getProgram()
	{
		return m_nProgramObject;
	}

	SPUInt SPShaderManager::getAttribute( SPInt index )
	{
		SPUInt attributeLoc = 0;

		for(SPInt i=0; i< (SPInt)m_vAttributeLoc.size(); i++)
		{
			if(index == (SPInt)m_vAttributeLoc[i].x)
			{
				attributeLoc = m_vAttributeLoc[i].y;

				break;
			}
		}

		return attributeLoc;
	}

	SPInt SPShaderManager::getUniform( SPInt index )
	{
		SPInt uniformLoc = 0;

		for(SPInt i=0; i< (SPInt)m_vUniformLoc.size(); i++)
		{
			if(index == m_vUniformLoc[i].x)
			{
				uniformLoc = m_vUniformLoc[i].y;
				break;
			}
		}

		return uniformLoc;
	}

	SPUInt SPShaderManager::getAttributeLoc( const SPChar* name )
	{
		if(m_nProgramObject == SPNULL)
			return SPNULL;

		return glGetAttribLocation(m_nProgramObject, name);
	}

	SPInt SPShaderManager::getUniformLoc( const SPChar* name )
	{
		if(m_nProgramObject == SPNULL)
			return SPNULL;

		return glGetUniformLocation(m_nProgramObject, name);;
	}

	SPBool SPShaderManager::compileShader( SPUInt shaderID, const SPChar* shaderCode )
	{
		// replaces the source code in a shader object
		glShaderSource ( shaderID, 1, &shaderCode, SPNULL );

		// compiles a shader object
		glCompileShader ( shaderID );

		SPInt isCompileError = 0;

		// get the compile status from a shader object
		glGetShaderiv ( shaderID, GL_COMPILE_STATUS, &isCompileError );
		printf("shaderID %d  isCompileError %d\n",shaderID,  isCompileError );

		// fail to compile a shader object
		if ( !isCompileError ) 
		{
			printGLErrorLog(shaderID, 0);

			// delete the shader ID because compile error
			glDeleteShader ( shaderID );

			return SPFALSE;
		}

		return SPTRUE;
	}

	SPVoid SPShaderManager::printGLErrorLog( SPUInt objectID, SPUInt objectType)
	{
		SPChar* ErrorLogMsg = SPNULL;
		SPInt logLength = 0;

		if(objectType == 0)
		{
			glGetShaderiv ( objectID, GL_INFO_LOG_LENGTH, &logLength );

			if(logLength > 1)
			{
				ErrorLogMsg = new SPChar[logLength];

				glGetShaderInfoLog ( objectID, logLength, SPNULL, ErrorLogMsg );
				SP_LOGE ( "Compile Error for a shader Object:\n%s\n", ErrorLogMsg );
			}
		}
		else if(objectType == 1)
		{
			glGetProgramiv ( objectID, GL_INFO_LOG_LENGTH, &logLength );

			if(logLength > 1)
			{
				ErrorLogMsg = new SPChar[logLength];

				glGetProgramInfoLog ( objectID, logLength, SPNULL, ErrorLogMsg );
				SP_LOGE ( "Link Error for a Program Object:\n%s\n", ErrorLogMsg );
			}
		}

		if(ErrorLogMsg != SPNULL)
		{
			delete []  ErrorLogMsg;
			ErrorLogMsg = SPNULL;
		}
	}

}//namespace SPhysics