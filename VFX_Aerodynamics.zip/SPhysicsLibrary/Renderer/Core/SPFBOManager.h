/**
* @file SPFBOManager.h
* @brief This file includes module that manages gl-buffer(vbo).
*
* @date 2013-12-31
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_FBO_MANAGER_H_
#define _SP_FBO_MANAGER_H_

#include "SPDefines.h"
#include "SPTextureManager.h"
#include "SPLog.h"

namespace SPhysics
{
	/**
		For FBO Handling

		SPUInt FboHandle : Frame Buffer Object Handle
		SPUInt TextureHandle : Texture Handle
		SPUInt RenderHandle : Render Buffer Handle
	*/
	typedef struct FBOSurface_ {
		FBOSurface_()
		{
			FboHandle = SPUInt();
			TextureHandle = SPUInt();
			RenderHandle = SPUInt();
		}
		FBOSurface_(const SPUInt& _FboHandle, const SPUInt& _TextureHandle, const SPUInt& _RenderHandle)
		{
			FboHandle = _FboHandle;
			TextureHandle = _TextureHandle;
			RenderHandle = _RenderHandle;
		}
		SPUInt FboHandle;		//!< FBO handle
		SPUInt TextureHandle;	//!< Texture handle
		SPUInt RenderHandle;	//!< Render handle
	} FBOSurface;	//!< FBO surface

	typedef struct FBOSurface_3 : public FBOSurface_{
		FBOSurface_3()
		{
			FboHandle = SPUInt();
			TextureHandle = SPUInt();
			TextureHandle2 = SPUInt();
			RenderHandle = SPUInt();
		}

		FBOSurface_3(const SPUInt& _FboHandle, const SPUInt& _TextureHandle, const SPUInt& _TextureHandle2, const SPUInt& _TextureHandle3, const SPUInt& _RenderHandle)
		{
			FboHandle = _FboHandle;
			TextureHandle = _TextureHandle;
			TextureHandle2 = _TextureHandle2;			
			TextureHandle3 = _TextureHandle3;			
			RenderHandle = _RenderHandle;
		}

		SPUInt TextureHandle2;	//!< Texture handle		
		SPUInt TextureHandle3;	//!< Texture handle		
	} FBOSurface3;	//!< FBO surface

	/**
		For Ping Pong Technique ( GPU synchronize)

		WaterBrushSurface Ping : Use Texture Handle
		WaterBrushSurface Pong : Use FBO Handle
	*/
	typedef struct FBOData_{
		FBOSurface Ping;	//!< Ping
		FBOSurface Pong;	//!< Pong
	} FBOData;	//!< FBO Data

	/**
	 * Clear surface
	 */
	inline SPVoid clearSurface(const FBOSurface& s, SPFloat r, SPFloat g, SPFloat b, SPFloat a) {
		glBindFramebuffer(GL_FRAMEBUFFER, s.FboHandle);
		glClearColor(r, g, b, a);
		glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glBindFramebuffer(GL_FRAMEBUFFER, 0);
	}
	
	/**
	 * Create surface
	 */
	inline FBOSurface createSurface(const SPUInt& width, const SPUInt& height, const SPBool& depth = SPFALSE, const SPUInt glOption = GL_UNSIGNED_BYTE, const SPUInt format = GL_RGBA, const SPUInt glInternerFormat = GL_RGBA, const SPUInt texture_interpolation = GL_LINEAR) {
		GLuint fboHandle;

		glGenFramebuffers(1, &fboHandle);
		glBindFramebuffer(GL_FRAMEBUFFER, fboHandle);

		GLuint colorbuffer;
		// Create the onscreen color render buffer. 
		glGenRenderbuffers(1, &colorbuffer);
		glBindRenderbuffer(GL_RENDERBUFFER, colorbuffer);
		glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_RENDERBUFFER, colorbuffer);

		if (depth == SPTRUE)
		{
			GLuint depthbuffer;
			// Create the onscreen depth render buffer.
			glGenRenderbuffers(1, &depthbuffer);
			glBindRenderbuffer(GL_RENDERBUFFER, depthbuffer);
			glRenderbufferStorage(GL_RENDERBUFFER, GL_STENCIL_INDEX8, width, height);
			glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_STENCIL_ATTACHMENT, GL_RENDERBUFFER, depthbuffer);
		}

		GLuint textureHandle;
		glGenTextures(1, &textureHandle);
		glBindTexture(GL_TEXTURE_2D, textureHandle);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, texture_interpolation);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, texture_interpolation);

		glTexImage2D(GL_TEXTURE_2D, 0, glInternerFormat, width, height, 0, format, glOption, 0);
		//glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA16F, width, height, 0, GL_RGBA, GL_FLOAT, 0);

		glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D,
			textureHandle, 0);

		glBindRenderbuffer(GL_RENDERBUFFER, colorbuffer);

		FBOSurface surface = FBOSurface(fboHandle, textureHandle, colorbuffer);	

		clearSurface(surface, 0.0f, 0.0f, 0.0f, 0.0f);

		return surface;
	}

#ifdef GL_ES_VERSION_3_0
	/**
	* Create surface
	*/
	inline FBOSurface3 createSurface_3channel(const SPUInt& width, const SPUInt& height, const SPBool& depth = SPFALSE, const SPUInt glOption = GL_UNSIGNED_BYTE, const SPUInt format = GL_RGBA, const SPUInt glInternerFormat = GL_RGBA, const SPUInt texture_interpolation = GL_LINEAR) {
		GLuint fboHandle;

		glGenFramebuffers(1, &fboHandle);
		glBindFramebuffer(GL_FRAMEBUFFER, fboHandle);

		GLuint colorbuffer;
		// Create the onscreen color render buffer. 
		glGenRenderbuffers(1, &colorbuffer);
		glBindRenderbuffer(GL_RENDERBUFFER, colorbuffer);
		glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT1, GL_RENDERBUFFER, colorbuffer);

// 		glGenRenderbuffers(1, &colorbuffer);
// 		glBindRenderbuffer(GL_RENDERBUFFER, colorbuffer);
// 		glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT1, GL_RENDERBUFFER, colorbuffer);

		if (depth == SPTRUE)
		{
			GLuint depthbuffer;
			// Create the onscreen depth render buffer.
			glGenRenderbuffers(1, &depthbuffer);
			glBindRenderbuffer(GL_RENDERBUFFER, depthbuffer);
			glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH24_STENCIL8, width, height);
			glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_STENCIL_ATTACHMENT, GL_RENDERBUFFER, depthbuffer);
		}

		GLuint textureHandle[3];
		for (int i = 0; i < 3; ++i)
		{
			glGenTextures(1, &textureHandle[i]);
			glBindTexture(GL_TEXTURE_2D, textureHandle[i]);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, texture_interpolation);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, texture_interpolation);
			glTexImage2D(GL_TEXTURE_2D, 0, glInternerFormat, width, height, 0, format, glOption, 0);
		}
		

		
		//glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA16F, width, height, 0, GL_RGBA, GL_FLOAT, 0);

		glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D,
			textureHandle[0], 0);
		glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT1, GL_TEXTURE_2D, 
			textureHandle[1], 0);
		glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT2, GL_TEXTURE_2D,
			textureHandle[2], 0);
		glBindRenderbuffer(GL_RENDERBUFFER, colorbuffer);

		GLenum drawbuffers[] = { GL_COLOR_ATTACHMENT0, GL_COLOR_ATTACHMENT1, GL_COLOR_ATTACHMENT2 };
		glDrawBuffers(3, drawbuffers);

		FBOSurface3 surface = FBOSurface3(fboHandle, textureHandle[0], textureHandle[1], textureHandle[2], colorbuffer);


		// Check if the fbo is setup correctly
		GLenum framebufferstatus = glCheckFramebufferStatus(GL_FRAMEBUFFER);
		if (framebufferstatus != GL_FRAMEBUFFER_COMPLETE)
		{
			switch (framebufferstatus)
			{
			case GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT:
				SP_LOGE("ERROR: gbuffer not set up correctly: GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT\n");
				break;
			case GL_FRAMEBUFFER_INCOMPLETE_DIMENSIONS:
				SP_LOGE("ERROR: gbuffer not set up correctly: GL_FRAMEBUFFER_INCOMPLETE_DIMENSIONS\n");
				break;
			case GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT:
				SP_LOGE("ERROR: gbuffer not set up correctly: GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT\n");
				break;
			case GL_FRAMEBUFFER_UNSUPPORTED:
				SP_LOGE("ERROR: gbuffer not set up correctly: GL_FRAMEBUFFER_UNSUPPORTED\n");
				break;
			}			
		}

		clearSurface(surface, 0.0f, 0.0f, 0.0f, 0.0f);

		return surface;
	}
#endif
	/**
	 * Create empty texture
	 */
	inline GLuint createEmptyTexture(const SPUInt& width, const SPUInt& height, const SPUInt glOption = GL_UNSIGNED_BYTE, const SPUInt format = GL_RGBA, const SPUInt glInternerFormat = GL_RGBA, const SPUInt texture_interpolation = GL_LINEAR) {

		GLuint textureHandle;
		glGenTextures(1, &textureHandle);
		glBindTexture(GL_TEXTURE_2D, textureHandle);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, texture_interpolation);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, texture_interpolation);

		glTexImage2D(GL_TEXTURE_2D, 0, glInternerFormat, width, height, 0, format, glOption, 0);		

		return textureHandle;
	}
	
	/**
	 * Resize surface
	 */
	inline SPVoid resizeSurface(FBOSurface& fbosurface, const SPUInt& width, const SPUInt& height, const SPUInt glOption = GL_UNSIGNED_BYTE) 
	{

		glBindTexture(GL_TEXTURE_2D, fbosurface.TextureHandle);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA,
			glOption, 0);				

		clearSurface(fbosurface, 0.0f, 0.0f, 0.0f, 0.0f);
	}

	/**
	* Resize FBOData
	*/
	inline SPVoid resizeFBOData(FBOData& fbo, const SPUInt& width, const SPUInt& height, const SPUInt glOption = GL_UNSIGNED_BYTE)
	{
		resizeSurface(fbo.Ping, width, height, glOption);
		resizeSurface(fbo.Pong, width, height, glOption);
	}

	/**
	 * Delete surface
	 */
	inline SPVoid deleteSurface(FBOSurface& s)
	{
		if(glIsFramebuffer(s.FboHandle))
			glDeleteFramebuffers(1, &s.FboHandle);
		if (glIsTexture(s.TextureHandle))
			glDeleteTextures(1, &s.TextureHandle);
		if (glIsRenderbuffer(s.RenderHandle))
			glDeleteRenderbuffers(1, &s.RenderHandle);

		s.FboHandle = 0;
		s.TextureHandle = 0;
		s.RenderHandle = 0;
	}

	inline SPVoid deleteSurface(FBOSurface3& s)
	{
		if (glIsFramebuffer(s.FboHandle))
			glDeleteFramebuffers(1, &s.FboHandle);
		if (glIsTexture(s.TextureHandle))
			glDeleteTextures(1, &s.TextureHandle);
		if (glIsTexture(s.TextureHandle2))
			glDeleteTextures(1, &s.TextureHandle2);
		if (glIsTexture(s.TextureHandle3))
			glDeleteTextures(1, &s.TextureHandle3);
		if (glIsRenderbuffer(s.RenderHandle))
			glDeleteRenderbuffers(1, &s.RenderHandle);

		s.FboHandle = 0;
		s.TextureHandle = 0;
		s.TextureHandle2 = 0;
		s.TextureHandle3 = 0;
		s.RenderHandle = 0;
	}

	/**
	 * Swap surfaces
	 */
	inline SPVoid swapSurfaces(FBOData& data) {
		FBOSurface temp = data.Ping;
		data.Ping = data.Pong;
		data.Pong = temp;
	}

	/**
	 * Create FBO data
	 */
	inline FBOData createFBOData(const SPUInt& width, const SPUInt& height) {
		FBOData data;
		data.Ping = createSurface(width, height);
		data.Pong = createSurface(width, height);
		return data;
	}

	/**
	 * Delete FBO data
	 */
	inline SPVoid deleteFBOData( FBOData& s )
	{
		deleteSurface(s.Ping);
		deleteSurface(s.Pong);
	}

	

// 	/**
// 	* @class     SPFBOManager
// 	* @brief    This class manages VBO buffer
// 	*/
// 	class SPFBOManager
// 	{
// 	private:
// 		/**
// 		* @brief     Constructor
// 		*/
// 		SPFBOManager();
//
// 		/**
// 		* @brief     Destructor
// 		*/
// 		~SPFBOManager();
//
// 	public:
//
// 		/**
// 		* @brief     Singleton instance
// 		* @return     SPVBOManager * Return Singleton instance
// 		*/
// 		static SPFBOManager *getInstancePtr();
//
// 		/**
// 		* @brief     Release singleton instance explicitly.
// 		* @return     SPVoid
// 		*/
// 		static SPVoid ReleaseInstance();
//
// 	private:
// 		static SPFBOManager *m_pInstance;
//	};
}//namespace SPhysics

#endif //_SP_FBO_MANAGER_H_