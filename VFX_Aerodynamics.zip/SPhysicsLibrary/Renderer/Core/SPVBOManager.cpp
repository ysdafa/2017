/**
* @file SPVBOManager.cpp
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPLog.h"
#include "SPVBOManager.h"

#include <string.h>
namespace SPhysics
{

	SPVBOManager::SPVBOManager()
	{
	}

	SPVBOManager::~SPVBOManager()
	{
		std::vector <VERTEX_BUFFER_OBJ>::iterator vIter;
		for(vIter = m_vVertexBufferItems.begin(); vIter != m_vVertexBufferItems.end(); ++vIter)
		{
			if(vIter->vBufferID != 0)
			{
				glDeleteBuffers(1, &vIter->vBufferID);
			}
		}
		m_vVertexBufferItems.clear();


		std::vector <INDEX_BUFFER_OBJ>::iterator iIter;
		for(iIter = m_vIndexBufferItems.begin(); iIter != m_vIndexBufferItems.end(); ++iIter)
		{
			if(iIter->iBufferID != 0)
			{
				glDeleteBuffers(1, &iIter->iBufferID);
			}
		}
		m_vIndexBufferItems.clear();
	}

	SPUInt SPVBOManager::getVertexBufferObject( const SPChar* name )
	{
		SPUInt vBufferID = 0;

		std::vector <VERTEX_BUFFER_OBJ>::iterator iter;
		for(iter = m_vVertexBufferItems.begin(); iter != m_vVertexBufferItems.end(); ++iter)
		{
			if(!strcmp(iter->vBufferName,name))
			{
				vBufferID = iter->vBufferID;
				break;
			}
		}

		if(vBufferID == 0)
		{
			glGenBuffers(1, &vBufferID);

			VERTEX_BUFFER_OBJ sBufferOBJ;
			sBufferOBJ.vBufferID = vBufferID;

			strncpy(sBufferOBJ.vBufferName, name, 49);
			sBufferOBJ.vBufferName[49] = '\0';

			m_vVertexBufferItems.push_back(sBufferOBJ);
		}

		return vBufferID;
	}

	SPUInt SPVBOManager::getIndexBufferObject( const SPChar* name )
	{
		SPUInt iBufferID = 0;

		std::vector <INDEX_BUFFER_OBJ>::iterator iter;
		for(iter = m_vIndexBufferItems.begin(); iter != m_vIndexBufferItems.end(); ++iter)
		{
			if(!strcmp(iter->iBufferName,name))
			{
				iBufferID = iter->iBufferID;
				break;
			}
		}

		if(iBufferID == 0)
		{
			glGenBuffers(1, &iBufferID);

			INDEX_BUFFER_OBJ sBufferOBJ;
			sBufferOBJ.iBufferID = iBufferID;

			strncpy(sBufferOBJ.iBufferName, name, 49);
			sBufferOBJ.iBufferName[49] = '\0';

			m_vIndexBufferItems.push_back(sBufferOBJ);
		}

		return iBufferID;
	}

}//namespace SPhysics