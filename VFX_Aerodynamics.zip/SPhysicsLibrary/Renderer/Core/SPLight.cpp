/**
* @file SPLight.h
* @brief 
*
* @date 2014-01-29
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPLight.h"

namespace SPhysics
{


SPLight::SPLight():
	m_LightType(SP_LIGHT_DIRECTIONAL),
	m_Color(0.f,0.f,0.f),
	m_Vector(0.f,0.f,0.f),
	m_Multipler(0.f),
	m_ParamsAttenuation(0.f,0.f,0.f),
	m_HasShadows(false)
{

}
//==================================================================================================
// getters
//==================================================================================================
SPLight::SP_LIGHT_TYPE SPLight::getLightType()
{
	return m_LightType;
}
//--------------------------------------------------------------------------------------------------
const SPVec3f& SPLight::getColor()
{
	return m_Color;
}
//--------------------------------------------------------------------------------------------------
const SPVec3f& SPLight::getDirection()
{
	return m_Vector;
}
//--------------------------------------------------------------------------------------------------
const SPVec3f& SPLight::getPosition()
{
	return m_Vector;
}
//--------------------------------------------------------------------------------------------------
SPFloat SPLight::getMultipler()
{
	return m_Multipler;
}
//--------------------------------------------------------------------------------------------------
const SPVec3f& SPLight::getParamsAttenuation()
{
	return m_ParamsAttenuation;
}
//--------------------------------------------------------------------------------------------------
SPBool SPLight::getHasShadows()
{
	return m_HasShadows;
}
//==================================================================================================
// setters
//==================================================================================================
SPVoid SPLight::setLightType(SP_LIGHT_TYPE lightType)
{
	m_LightType = lightType;
}
//--------------------------------------------------------------------------------------------------
SPVoid SPLight::setColor(const SPVec3f& color)
{
	m_Color = color;
}
//--------------------------------------------------------------------------------------------------
SPVoid SPLight::setDirection(const SPVec3f& direction)
{
	m_Vector = direction;
}
//--------------------------------------------------------------------------------------------------
SPVoid SPLight::setPosition(const SPVec3f& position)
{
	m_Vector = position;
}
//--------------------------------------------------------------------------------------------------
SPVoid SPLight::setMultipler(SPFloat multipler)
{
	m_Multipler = multipler;
}
//--------------------------------------------------------------------------------------------------
SPVoid SPLight::setParamsAttenuation(const SPVec3f& paramsAttenuation)
{
	m_ParamsAttenuation = paramsAttenuation;
}
//--------------------------------------------------------------------------------------------------
SPVoid SPLight::setHasShadows(SPBool hasShadows)
{
	m_HasShadows = hasShadows;
}
//--------------------------------------------------------------------------------------------------

} //namespace SPhysics
