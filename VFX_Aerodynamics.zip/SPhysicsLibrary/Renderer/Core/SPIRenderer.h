/**
* @file SPIRenderer.h
* @brief This file includes module which is used for abstract rendering class
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_I_RENDERER_H_
#define _SP_I_RENDERER_H_

#include "SPDefines.h"
#include "SPShaderManager.h"
#include "SPMVPManager.h"
#include "SPVBOManager.h"
#include "SPMesh.h"

#include <vector>
#include <glm.hpp>

namespace SPhysics
{
	//! @brief Mode for Drawing line
	typedef enum _DRAW_OPTION
	{
		DRAW_POINT,             /*!< drawing point */
		DRAW_LINES,				/*!< drawing line */
		DRAW_LINE_LOOP,			/*!< drawing line-loop */
		DRAW_LINE_STRIP,		/*!< drawing line-stripe */
		DRAW_TRIANGLES,			/*!< drawing trangles */
		DRAW_TRIANGLES_STRIP,	/*!< drawing trangles-strip */
		DRAW_TRIANGLES_FAN,		/*!< drawing trangles-fan */
	}DRAW_OPTION;

	/**
	* @class     SPIRenderer
	* @brief     Renderer Abstract Class
	* @par Features:
	*	  - Some methods are called by child class.
	*/
	class SPIRenderer
	{

	public:
		/**
		* @brief     Constructor
		*/
		SPIRenderer();

		/**
		* @brief     Destructor
		*/
		virtual ~SPIRenderer();

	public:

		/**
		* @brief     Initialize and Prepare rendering\n
						(set camera setting, initialize shader)
		* @param     [IN] @b width Clipping Plane's width size
		* @param     [IN] @b height Clipping Plane's height size
		* @return     SPVoid
		*/
		virtual SPVoid initRender(SPFloat width, SPFloat height){};

		/**
		* @brief     Draws the scene. Set the values which is essential in rendering \n
						(i.e, the matrix, color, mesh data. etc.)
		* @return     SPVoid
		*/
		virtual SPVoid drawRender(){};

		/**
		* @brief     Prepare for rendering & invokes derived class's initRenderer() method.
		* @param     [IN] @b width  Clipping Plane's width size
		* @param     [IN] @b height  Clipping Plane's height size
		* @return     SPVoid
		*/
		SPVoid initialize(SPFloat width, SPFloat height);

		/**
		* @brief     Set the values which is essential in rendering & Draws. \n
						(i.e, the matrix, color, mesh data. etc.)
		* @return     SPVoid
		*/
		SPVoid draw();

		/**
		* @brief     Set Screen size
		* @param     [IN] @b width Width size
		* @param     [IN] @b height Height size
		* @return     SPVoid
		*/
		SPVoid setScreenSize(SPFloat width, SPFloat height);

		/**
		* @brief     Set object's mesh data 
		* @param     [IN] @b mesh Mesh data instance
		* @return     SPVoid
		*/
		SPVoid setMesh(SPMesh* mesh);

		/**
		* @brief     return the object's mesh data 
		* @return     SPMesh*
		*/
		SPMesh* getMesh();

		/**
		* @brief     Set Camera setting when using orthogonal view
		* @param     [IN] @b left	Coordinates for the left vertical clipping planes
		* @param     [IN] @b right right Coordinates for the right vertical clipping planes
		* @param     [IN] @b bottom Coordinates for the bottom horizontal clipping planes
		* @param     [IN] @b top Coordinates for the top horizontal clipping planes
		* @param     [IN] @b nearZ Distances to the near depth clipping planes. distances must be positive.
		* @param     [IN] @b farZ Distances to the far depth clipping planes.  distances must be positive.
		* @return     SPVoid
		*/
		SPVoid setOrthogonalCameraView(SPFloat left, SPFloat right, SPFloat bottom, SPFloat top, SPFloat nearZ, SPFloat farZ);

		/**
		* @brief      Set Camera setting when using perspective view
		* @param     [IN] @b fovy Field of view y angle in degrees.
		* @param     [IN] @b aspect The ratio of the width of a shape to its height
		* @param     [IN] @b nearZ Near plane distance
		* @param     [IN] @b farZ Far plane distance
		* @return     SPVoid
		*/
		SPVoid setPerspectiveCameraView(SPFloat fovy, SPFloat aspect, SPFloat nearZ, SPFloat farZ);

		/**
		* @brief     Set frustum of Camera
		* @param     [IN] @b left Coordinates for the left vertical clipping planes
		* @param     [IN] @b right Coordinates for the right vertical clipping planes
		* @param     [IN] @b bottom Coordinates for the bottom horizontal clipping planes
		* @param     [IN] @b top Coordinates for the top horizontal clipping planes
		* @param     [IN] @b nearZ Distances to the near depth clipping planes.  distances must be positive.
		* @param     [IN] @b farZ Distances to the far depth clipping planes.  distances must be positive.
		* @return     SPVoid
		*/
		SPVoid setFrustumCameraView(SPFloat left, SPFloat right, SPFloat bottom, SPFloat top, SPFloat nearZ, SPFloat farZ);

		/**
		* @brief     Define a Viewing (Transform) matrix
		* @param     [IN] @b eyex The X location of the viewpoint
		* @param     [IN] @b eyey The Y location of the viewpoint
		* @param     [IN] @b eyez The Z location of the viewpoint
		* @param     [IN] @b centerx The position of the reference point X
		* @param     [IN] @b centery The position of the reference point Y
		* @param     [IN] @b centerz The position of the reference point Z
		* @param     [IN] @b upx The X-direction of the up vector
		* @param     [IN] @b upy The Y-direction of the up vector
		* @param     [IN] @b upz The Z-direction of the up vector
		* @return     SPVoid
		*/
		SPVoid setLookAt(SPFloat eyex, SPFloat eyey, SPFloat eyez, SPFloat centerx, SPFloat centery, SPFloat centerz, SPFloat upx, SPFloat upy, SPFloat upz);

		/**
		* @brief     Set view matrix
		* @param     [IN] @b viewMatrix Pointer to float array representing matrix
		* @return     SPVoid
		*/
		SPVoid setViewMatrix(const SPFloat *viewMatrix);
		
		/**
		* @brief     Create Shader Programs
		* @param     [IN] @b vertexShader Vertex shader code
		* @param     [IN] @b fragmentShader Fragment shader code
		* @return     SPVoid
		*/
		SPVoid createShaderProgram(const SPChar* vertexShader, const SPChar* fragmentShader);
		
		/**
		* @brief     Bind vertex position data using specified Vertex shader attribute name
		* @param     [IN] @b name Specify vertex attribute's name
		* @return     SPVoid
		*/
		SPVoid setShaderArrayMeshVertex(const SPChar* name);

		/**
		* @brief     Bind vertex position data using specified Vertex shader attribute name
		* @param     [IN] @b name Specify vertex attribute's name
		* @return     SPVoid
		*/
		SPVoid setShaderArrayMeshVertex2D(const SPChar* name);
		
		/**
		* @brief     Bind vertex normal data using specified Vertex shader attribute name
		* @param     [IN] @b name Specify vertex attribute's name
		* @return     SPVoid
		*/
		SPVoid setShaderArrayMeshNormal(const SPChar* name);
		
		/**
		* @brief     Bind vertex height data using specified Vertex shader attribute name
		* @param     [IN] @b name Specify vertex attribute's name
		* @return     SPVoid
		*/
		SPVoid setShaderArrayMeshHeight(const SPChar* name);

		/**
		* @brief     Bind custom data using specified Vertex shader attribute name
		* @param     [IN] @b name Specify vertex attribute's name
		* @return     SPVoid
		*/
		SPVoid setShaderArrayMeshCustom(const SPChar* name);
		
		/**
		* @brief     Load vertex tangent data using specified Vertex shader attribute name
		* @param     [IN] @b name Specify vertex attribute's name
		* @return     SPVoid
		*/
		SPVoid setShaderArrayMeshTangent(const SPChar* name);
		
		/**
		* @brief     Bind texture uv data using specified Vertex shader attribute name
		* @param     [IN] @b name
		* @return     SPVoid
		*/
		SPVoid setShaderArrayMeshUV(const SPChar* name);
		
		/**
		* @brief     Bind vertex tangent data using specified Vertex shader attribute name
		* @param     [IN] @b name Specify vertex attribute's name
		* @return     SPVoid
		*/
		SPVoid setShaderArrayMeshColor(const SPChar* name);

		/**
		* @brief     Bind a special vector value using specified Vertex shader attribute name
		* @param     [IN] @b name Specify vertex attribute's name
		* @param     [IN] @b value Pointer to array
		* @param     [IN] @b dimension Dimension of vector
		* @return     SPVoid
		*/
		SPVoid setShaderArrayVector( const SPChar* name, SPFloat* value, SPUInt dimension);

		/**
		* @brief     Bind a special vector value using specified Vertex shader attribute name
		* @param     [IN] @b name Specify vertex attribute's name
		* @param     [IN] @b value Pointer to array
		* @param     [IN] @b dimension Dimension of vector
		* @param     [IN] @b stride Stride of vector
		* @return     SPVoid
		*/
		SPVoid setShaderArrayVector( const SPChar* name, SPFloat* value, SPUInt dimension, SPUInt stride);

		/**
		* @brief     Bind a special vector value using specified Vertex shader attribute name
		* @param     [IN] @b name Specify vertex attribute's name
		* @param     [IN] @b value Pointer to array
		* @param     [IN] @b dimension Dimension of vector
		* @param     [IN] @b count count of value
		* @return     SPVoid
		*/
		SPVoid bindVertexBufferArray( const SPChar* name, SPFloat* value, SPUInt dimension, SPUInt count);

		/**
		* @brief     unbind vertex buffer array
		* @return     SPVoid
		*/
		SPVoid unBindVertexBufferArray();

		/**
		* @brief     Bind a index array using specified Vertex shader attribute name
		* @param     [IN] @b name Specify index array's name
		* @param     [IN] @b value Pointer to array
		* @param     [IN] @b count count of value
		* @return     SPVoid
		*/
		SPVoid bindIndexBufferArray( const SPChar* name, SPUShort* value, SPUInt count);

		/**
		* @brief     unbind vertex buffer array
		* @return     SPVoid
		*/
		SPVoid unBindIndexBufferArray();

    	/**
		* @brief     Bind model-view-project matrix using specified shader uniform name
		* @param     [IN] @b name Specify uniform variable's name
		* @return     SPVoid
		*/
		SPVoid setShaderUniformMVPMatrix(const SPChar* name);
		
		/**
		* @brief     Bind model-view matrix using specified shader uniform name
		* @param     [IN] @b name Specify uniform variable's name
		* @return     SPVoid
		*/
		SPVoid setShaderUniformMVMatrix(const SPChar* name);

		/**
		* @brief     Bind model matrix using specified shader uniform name
		* @param     [IN] @b name Specify uniform variable's name
		* @return     SPVoid
		*/
		SPVoid setShaderUniformMMatrix(const SPChar* name);

		/**
		* @brief     Bind inverse transform model matrix using specified shader uniform name
		* @param     [IN] @b name Specify uniform variable's name
		* @return     SPVoid
		*/
		SPVoid setShaderUniformITMMatrix( const SPChar* name );

		/**
		* @brief     Set texture id using shader uniform variable's name
		* @param     [IN] @b name Specify uniform variable's name
		* @param     [IN] @b TextureID Specify textureID 
		* @return     SPVoid
		*/
		SPVoid setShaderUnifromTexture(const SPChar* name, SPUInt TextureID);


		/**
		* @brief     Set cube map texture id using shader uniform variable's name
		* @param     [IN] @b name Specify uniform variable's name
		* @param     [IN] @b TextureID Specify cube map textureID 
		* @return     SPVoid
		*/
		SPVoid setShaderUniformCubeMapTexture( const SPChar* name, SPUInt TextureID );

		/**
		* @brief     Set a special float value using shader uniform variable's name
		* @param     [IN] @b name Specify uniform variable's name
		* @param     [IN] @b special float value 
		* @return     SPVoid
		*/
		SPVoid setShaderUniformValue( const SPChar* name, SPFloat value);

		/**
		* @brief     Set a special vector using shader uniform variable's name
		* @param     [IN] @b name Specify uniform variable's name
		* @param     [IN] @b special vector 
		* @param     [IN] @b dimension of the vector
		* @return     SPVoid
		*/
		SPVoid setShaderUniformVector( const SPChar* name, SPFloat* value, SPUInt dimension, SPUInt count = 1);

		/**
		* @brief     Set a special matrix using shader uniform variable's name
		* @param     [IN] @b name Specify uniform variable's name
		* @param     [IN] @b special matrix
		* @param     [IN] @b dimension of the matrix
		* @return     SPVoid
		*/
		SPVoid setShaderUniformMatrix( const SPChar* name, const SPFloat* value, SPUInt dimension = 4, SPUInt count = 1);

		/**
		* @brief     Set color using shader uniform variable's name
		* @param     [IN] @b name Specify uniform variable's name
		* @return     SPVoid
		*/
		SPVoid setShaderUnformColor(const SPChar* name);
		
		/**
		* @brief     Set the glDrawElements drawing option with DRAW_OPTION using spmesh data structure
		* @param     [IN] @b option DRAW_OPTION(DRAW_POINT/DRAW_LINE_LOOP/DRAW_LINE_STRIP/DRAW_TRIANGLES/DRAW_TRIANGLES_STRIP/DRAW_TRIANGLES_FAN)
		* @return     SPVoid
		*/
		SPVoid setDrawElementsWithOption(SPUInt option);

		/**
		* @brief     Set the glDrawArrays drawing option with DRAW_OPTION using spmesh data structure
		* @param     [IN] @b option DRAW_OPTION(DRAW_POINT/DRAW_LINE_LOOP/DRAW_LINE_STRIP/DRAW_TRIANGLES/DRAW_TRIANGLES_STRIP/DRAW_TRIANGLES_FAN)
		* @return     SPVoid
		*/
		SPVoid setDrawArraysWithOption(SPUInt option);

		/**
		* @brief     draw object using the spmesh data structure
		* @return     SPVoid
		*/
		SPVoid runMeshDraw();

		/**
		* @brief     Set the glDrawElements drawing option with DRAW_OPTION using custom data structure not use spmesh
		* @param     [IN] @b pIndices(Triangles indices), count(number of indices), option DRAW_OPTION(DRAW_POINT/DRAW_LINE_LOOP/DRAW_LINE_STRIP/DRAW_TRIANGLES/DRAW_TRIANGLES_STRIP/DRAW_TRIANGLES_FAN)
		* @return     SPVoid
		*/
		SPVoid setCustomDrawElement(SPUShort* pIndices, SPUInt count, SPUInt option);

		/**
		* @brief     Set the glDrawArrays drawing option with DRAW_OPTION using custom data structure not use spmesh
		* @param     [IN] @b count(number of vertex), option DRAW_OPTION(DRAW_POINT/DRAW_LINE_LOOP/DRAW_LINE_STRIP/DRAW_TRIANGLES/DRAW_TRIANGLES_STRIP/DRAW_TRIANGLES_FAN)
		* @return     SPVoid
		*/
		SPVoid setCustomDrawArrays(SPUInt count, SPUInt option);

		/**
		* @brief     draw object using the custom data structure not use spmesh
		* @return     SPVoid
		*/
		SPVoid runCustomDraw();
		
		/**
		* @brief     Set Color
		* @param     [IN] @b red Red color value of object (0~1.f)
		* @param     [IN] @b green Green color value of object (0~1.f)
		* @param     [IN] @b blue Blue color value of object (0~1.f)
		* @param     [IN] @b alpha Alpha value of object (0~1.f)
		* @return     SPVoid
		*/
		SPVoid setColor(SPFloat red, SPFloat green, SPFloat blue, SPFloat alpha);

		/**
		* @brief     return current Color vector
		* @return     SPVec4f
		*/
		SPVec4f getColor();
		
		/**
		* @brief     Set translated position
		* @param     [IN] @b x X position 
		* @param     [IN] @b y Y position
		* @param     [IN] @b z Z position
		* @return     SPVoid
		*/
		SPVoid setTranslate(SPFloat x, SPFloat y, SPFloat z);

		/**
		* @brief     return current translated position
		* @return     SPVec3f
		*/
		SPVec3f getPosition();
		
		/**
		* @brief     Set the rotation angle and axis 
		* @param     [IN] @b angle The angle of rotation
		* @param     [IN] @b x Rotation Axis - X value
		* @param     [IN] @b y Rotation Axis - Y value
		* @param     [IN] @b z Rotation Axis - Z value
		* @return     SPVoid
		*/
		SPVoid setRotate(SPFloat angle, SPFloat x, SPFloat y, SPFloat z);

		/**
		* @brief     return current rotate vector
		* @return     SPVec4f
		*/
		SPVec4f getRotate();
		
		/**
		* @brief     Set scale proportions. \n
						(Ref. 1.0 - current value)
		* @param     [IN] @b xScale X ratio
		* @param     [IN] @b yScale Y ratio
		* @param     [IN] @b zScale Z ratio
		* @return     SPVoid
		*/
		SPVoid setScale(SPFloat xScale, SPFloat yScale, SPFloat zScale);

		/**
		* @brief     return current scale vector
		* @return     SPVec3f
		*/
		SPVec3f getScale();

		/**
		* @brief     Convert the model matrix with translate/rotate/scale property
		* @param     [IN] @b matrix Floating-point values list
		* @return     SPVoid
		*/
		SPVoid convertModelMatrix( SPFloat* matrix );

		/**
		* @brief     return the view matrix 
		* @return     SPFloat
		*/
		SPFloat* getViewMatrix();

		/**
		* @brief     return the projection matrix
		* @return     SPFloat
		*/
		SPFloat* getProjMatrix();

		//SPVoid setTexture(SPChar *fileName);

		/**
		* @brief     return the VP matrix (view*projection)
		* @return     SPFloat*
		*/
		SPFloat* getVPMatrix();

		/**
		* @brief     return the MVP matrix 
		* @return     SPFloat
		*/
		SPFloat* getMVPMatrix();

		/**
		* @brief     Set the visibility property 
		* @return     SPVoid
		*/
		SPVoid setVisible(SPBool visible);

		/**
		* @brief     return current visibility property 
		* @return     SPBool
		*/
		SPBool getVisible();

		/**
		* @brief     Set the DepthTest property 
		* @return     SPVoid
		*/
		SPVoid setDepthTest(SPBool bEnable);

		/**
		* @brief     Set the DepthTest property option
		* @return     SPVoid
		*/
		SPVoid setDepthTestOption(SPUInt aDepthFunc);

		/**
		* @brief     Set the Blending property 
		* @return     SPVoid
		*/
		SPVoid setBlend(SPBool bEnable);

		/**
		* @brief     Set the ColorMask property 
		* @return     SPVoid
		*/
		SPVoid setColorMask(SPBool bEnable);

		/**
		* @brief     Set the ColorMask property 
		* @return     SPVoid
		*/
		SPVoid setColorMask(SPBool aR, SPBool aG, SPBool aB, SPBool aA);

		/**
		* @brief     Set the DepthMask property 
		* @return     SPVoid
		*/
		SPVoid setDepthMask(SPBool bEnable);

		/**
		* @brief     Set the CullFace property 
		* @return     SPVoid
		*/
		SPVoid setCullFace(SPBool bEnable);

		/**
		* @brief     Set the CullFace property option
		* @return     SPVoid
		*/
		SPVoid setCullFaceOption(SPUInt aCullFace, SPUInt aFrontFace);

		/**
		* @brief     return current visibility property 
		* @return     SPBool
		*/
		SPBool getDepthTest();


		//INTERFACE
		SPVoid MoveCameraX(float _fDist);	//!< Move camera by x-axis
		SPVoid MoveCameraY(float _fDist);	//!< Move camera by y-axis
		SPVoid MoveCameraZ(float _fDist);	//!< Move camera by z-axis

		/**
		* @brief     Set blend option
		* @param     [IN] @b sfactor Source blend option
		* @param     [IN] @b dfactor Destination blend option
		* @return     SPVoid
		*/
		SPVoid setBlendOption(const SPUInt& sfactor, const SPUInt& dfactor);

		/**
		* @brief     Set blend option
		* @param     [IN] @b srcRGB Source RGB blend option
		* @param     [IN] @b dstRGB Destination RGB blend option
		* @param     [IN] @b srcAlpha Source alpha blend option
		* @param     [IN] @b dstAlpha Destination alpha blend option
		* @return     SPVoid
		*/
		SPVoid setBlendOption(const SPUInt& srcRGB, const SPUInt& dstRGB, const SPUInt& srcAlpha, const SPUInt& dstAlpha);

	public:
		/**
		* @brief     update internal Model matrix
		* @return     SPVoid
		*/
		SPVoid updateMVPMtrix();

		/**
		* @brief     after or before draw, reset some variable such as attribute item, number of texture...
		* @return     SPVoid
		*/
		SPVoid resetShaderParameters();
		

	protected:
		SPMesh* m_pRenderMesh;				//!< Mesh which is being rendered
		SPMVPManager* m_pRenderMVP;			//!< MVP manager pointer
		SPShaderManager* m_pRenderShader;	//!< Shader manager pointer
		SPVBOManager*    m_pVBOManager;		//!< vertex buffer object manager pointer

		SPVec4f m_ObjectColor;		//!< Object color
		SPVec4f m_ObjectRotate;	//!< Object rotate
		SPVec3f m_ObjectTranslate;	//!< Object translate
		SPVec3f m_ObjectScale;		//!< Objects scale

		SPFloat m_ScreenWidth;	//!< Screen width
		SPFloat m_ScreenHeight;	//!< Screen height

		SPFloat m_SimulationWidth;	//!< Simulation width
		SPFloat m_SimulationHeight;	//!< Simulation height

		SPUInt  m_NumTexture;		//!< Texture number

		SPBool  m_ConvertModelView;	//!< Convert model view (view matrix is set directly, not through scale/rotate/translate)

		SPBool  m_IsDrawArray;		//!< Draw arrays rendering (false - draw elements)

		SPUInt  m_DrawingOption;	//!< Drawing option (triangle, strip triangle, etc.)

		SPBool  m_bVisisble;		//!< Is visible

		SPBool	m_bBlend;		//!< Blend flag
		SPVec4u m_BlendOption;	//!< Blend option
		SPBool	m_bDepthTest;	//!< Depth test flag
		SPUInt	m_DepthFunc;	//!< Depth function
		SPBool	m_ColorMask[4];	//!< Color mask
		SPBool	m_DepthMask;	//!< Depth mask
		SPBool	m_bCullFace;	//!< Cull face flag
		SPUInt	m_CullFace;		//!< Cull face
		SPUInt	m_FrontFace;	//!< Front face

		std::vector <SPUInt > m_vAttributeItems;	//!< Attribute items
		std::vector <SPUInt > m_vVBOAttributeItems;	//!< Attribute items

		SPUShort* m_pCustomTriangleIndices;	//!< Custom triangle indices
		SPUInt    m_nCustomNumIndices;		//!< Custom indices number
		SPUInt    m_nCustomNumVertex;		//!< Custom verices number
		SPBool    m_bIsCustomDraw;			//!< Is custom draw
	};

}//namespace SPhysics

#endif //_SP_I_RENDERER_H_
