/**
* @file SPDrawBackground.h
* @brief This file includes module that draws background image
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_DRAW_BACKGROUND_H_
#define _SP_DRAW_BACKGROUND_H_

#include "SPDefines.h"
#include "SPIRenderer.h"
#include "SPMesh.h"

#include <glm.hpp>

namespace SPhysics
{
	/**
	* @class     SPDrawBackground
	* @brief     This class is mainly for Drawing Background and supports Mesh setting, color setting, etc,.
	*/
	class SPDrawBackground : public SPIRenderer
	{
	public:
		/**
		* @brief     Constructor
		*/
		SPDrawBackground();
		/**
		* @brief     Destructor
		*/
		~SPDrawBackground();

	public:

		/**
		* @brief     Initialize and Prepare rendering\n
		(set camera setting, initialize shader , create rectangle mesh)
		* @param     [IN] SPFloat width Clipping Plane's width size
		* @param     [IN] SPFloat height Clipping Plane's height size
		* @return     SPVoid
		*/
		SPVoid initRender(SPFloat width, SPFloat height); // virtual

		/**
		* @brief     Resize surface
		*/
		SPVoid resizeSurface(SPFloat width, SPFloat height);

		/**
		* @brief     Mesh setting & binding shader variables for drawing.
		* @return     SPVoid
		 */
		SPVoid drawRender(); // virtual

		/**
		* @brief     Set the texture to rectangle
		* @param     [IN] @b fileName File name of texture
		* @return     SPVoid
		*/
		SPVoid setTexture(const SPChar *fileName);

		/**
		* @brief     Set the texture to rectangle
		* @param     [IN] @b texID texture ID
		* @return     SPVoid
		*/
		SPVoid setTextureID(const SPUInt& texID);

		/**
		* @brief     scale the texture uv vector with scale value
		* @param     [IN] @b value scale value (0.0f : 0%, 1.0f : 100f, 1.2f : 120%)
		* @return     SPVoid
		*/
		SPVoid scaleTextureUV(SPFloat value);

		/**
		* @brief     crop the texture v 
		* @param     [IN] @b value crop value 
		* @return     SPVoid
		*/
		SPVoid cropTextureV(SPFloat value);

		/**
		* @brief     enable the fbo draw flag for the texture coordinate uv
		* @return     SPVoid
		*/
		SPVoid setFBOUV();

		/**
		* @brief     return the current texture ID
		* @return     SPUInt
		*/
		SPUInt getTextureID();

		/**
		* @brief     Set zero centered flag
		*/
		SPVoid setZeroCentered(SPBool zeroCentered);

	private:
		/**
		* @brief     Create mesh data
		* @param     [IN] @b width Rectangle width size
		* @param     [IN] @b height Rectangle height size
		* @return     SPVoid
		*/
		SPVoid createRectVertex(SPFloat width, SPFloat height);
		/**
		* @brief     Create Texture's UV Coordinates to rendering image
		* @return     SPVoid
		*/
		SPVoid createTextureUV();
		/**
		* @brief     Create rectangle-texturing shader program
		* @return     SPVoid
		*/
		SPVoid createRectTextureShader();

		SPBool mIsZeroCentered;

	public:
		SPMesh m_cMesh;			//!< Mesh
		SPUInt m_TextureId;		//!< Texture Id

		SPBool m_bFBOUVDraw;	//!< Flag if required to change Texture UV due to FBO usage

		SPFloat m_fCropHeightV;
	};
}//namespace SPhysics

#endif //_SP_DRAW_BACKGROUND_H_