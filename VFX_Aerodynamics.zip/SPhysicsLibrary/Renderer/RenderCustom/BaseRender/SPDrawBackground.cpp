/**
* @file SPDrawBackground.cpp
* @brief
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPTextureManager.h"
#include "SPDrawBackground.h"

namespace SPhysics
{
	SPDrawBackground::SPDrawBackground()
	{
		m_TextureId = 0;
		m_bFBOUVDraw = SPFALSE;
		mIsZeroCentered = SPFALSE;
		m_fCropHeightV = 0.0f;
	}

	SPDrawBackground::~SPDrawBackground()
	{
	}

	SPVoid SPDrawBackground::initRender( SPFloat width, SPFloat height )
	{
		// Shader Program for DrawRect
		SPChar VertexShader[] =
			"uniform mediump mat4 uMVPMatrix;				\n"
			"attribute vec4 aPosition;						\n"
			"attribute vec2 aTexUV;						    \n"
			"varying vec2 vTexUV;							\n"
			"void main()									\n"
			"{												\n"
			"   vTexUV = aTexUV;							\n"
			"   gl_Position = uMVPMatrix * aPosition;		\n"
			"}												\n";

		SPChar FragmentShader[] =
			"precision mediump float;                           \n"
			"uniform vec4 uColor;								\n"
			"uniform sampler2D uTexMap;                        \n"
			"varying vec2 vTexUV;								\n"
			"void main()                                        \n"
			"{                                                  \n"
			"  vec4 TexColor = texture2D( uTexMap, vTexUV );  \n"
			"  gl_FragColor = TexColor * uColor;				\n"
			"}                                                  \n";

		setOrthogonalCameraView(0.0f, width, 0.0f, height, -5000, 5000.0f);
		//setOrthogonalCameraView( -width * 0.5f, width * 0.5f, -height * 0.5f, height * 0.5f, -5000.0f, 5000.0f);

		m_cMesh.reset();
		createRectVertex(width, height);
		createTextureUV();

		createShaderProgram(VertexShader, FragmentShader);
	}

	SPVoid SPDrawBackground::resizeSurface( SPFloat width, SPFloat height )
	{
		setOrthogonalCameraView(0.0f, width, 0.0f, height, -5000, 5000.0f);
		createRectVertex(width, height);
	}

	SPVoid SPDrawBackground::drawRender()
	{
		setMesh(&m_cMesh);

		setShaderArrayMeshVertex("aPosition");
		setShaderArrayMeshUV("aTexUV");

		setShaderUniformMVPMatrix("uMVPMatrix");

		setShaderUnformColor("uColor");
		setShaderUnifromTexture("uTexMap", m_TextureId);

		setDrawElementsWithOption(SPhysics::DRAW_TRIANGLES_STRIP);
	}

	SPVoid SPDrawBackground::setTexture(const SPChar *fileName )
	{
#if (!ANDROID_PORTING_MODE)
		m_TextureId = SPTextureManager::getInstancePtr()->loadTexture(fileName);
#else
		m_TextureId = SPTextureManager::getInstancePtr()->getTextureID(fileName);
#endif
	}

	SPVoid SPDrawBackground::setTextureID(const SPUInt& texID)
	{
		m_TextureId = texID;
	}

	SPVoid SPDrawBackground::scaleTextureUV( SPFloat value )
	{

		SPFloat scaleValue = (value - 1.0f) * 0.5f;
		SPFloat maxUV = 1.0f - scaleValue;
		SPFloat minUV = 0.0f + scaleValue;

		m_cMesh.m_tTextureUV.clear();
		m_cMesh.m_tTextureUV.resize(4);

		m_cMesh.m_tTextureUV[0] = SPVec3f(minUV, maxUV - m_fCropHeightV, 0.0f);
		m_cMesh.m_tTextureUV[1] = SPVec3f(maxUV, maxUV - m_fCropHeightV, 0.0f);
		m_cMesh.m_tTextureUV[2] = SPVec3f(minUV, minUV + m_fCropHeightV, 0.0f);
		m_cMesh.m_tTextureUV[3] = SPVec3f(maxUV, minUV + m_fCropHeightV, 0.0f);


		if(m_bFBOUVDraw == SPTRUE)
		{
			SPVec3f tmpVec;
			tmpVec= m_cMesh.m_tTextureUV[0];
			m_cMesh.m_tTextureUV[0] = m_cMesh.m_tTextureUV[2];
			m_cMesh.m_tTextureUV[2] = tmpVec;

			tmpVec= m_cMesh.m_tTextureUV[1];
			m_cMesh.m_tTextureUV[1] = m_cMesh.m_tTextureUV[3];
			m_cMesh.m_tTextureUV[3] = tmpVec;
		}
	}

	SPVoid SPDrawBackground::cropTextureV( SPFloat value )
	{
		// Rect Vertex
		//     P3(0,0)            P4(1,0)
		//     * ----------------- *
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1(0,1)            P2(1.1)

		m_fCropHeightV = value;

		m_cMesh.m_tTextureUV.clear();
		m_cMesh.m_tTextureUV.resize(4);

		m_cMesh.m_tTextureUV[0] = SPVec3f(0.0f, 1.0f - m_fCropHeightV, 0.0f);		// point 1
		m_cMesh.m_tTextureUV[1] = SPVec3f(1.0f, 1.0f - m_fCropHeightV, 0.0f);		// point 2
		m_cMesh.m_tTextureUV[2] = SPVec3f(0.0f, m_fCropHeightV, 0.0f);		// point 3
		m_cMesh.m_tTextureUV[3] = SPVec3f(1.0f, m_fCropHeightV, 0.0f);		// point 4
	}

	SPVoid SPDrawBackground::setFBOUV()
	{
		m_bFBOUVDraw = SPTRUE;

		if(m_cMesh.m_tTextureUV.size() != 0)
		{
			SPVec3f tmpVec;
			tmpVec= m_cMesh.m_tTextureUV[0];
			m_cMesh.m_tTextureUV[0] = m_cMesh.m_tTextureUV[2];
			m_cMesh.m_tTextureUV[2] = tmpVec;

			tmpVec= m_cMesh.m_tTextureUV[1];
			m_cMesh.m_tTextureUV[1] = m_cMesh.m_tTextureUV[3];
			m_cMesh.m_tTextureUV[3] = tmpVec;
		}
	}

	SPUInt SPDrawBackground::getTextureID()
	{
		return m_TextureId;
	}

	SPVoid SPDrawBackground::setZeroCentered(SPBool zeroCentered)
	{
		mIsZeroCentered = zeroCentered;
	}

	// private Method
	SPVoid SPDrawBackground::createRectVertex(SPFloat width, SPFloat height)
	{
		// Rect Vertex
		//     P3                  P4
		//     * ----------------- *
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1                  P2

		m_cMesh.m_tVertex.clear();
		m_cMesh.m_tVertex.resize(4);

		// create rect vertex position
		// LeftTop Align Rect Vertex
		
		if (!mIsZeroCentered)
		{
			m_cMesh.m_tVertex[0] = SPVec3f(0.0f, 0.0f, 0.0f);			// point 1
			m_cMesh.m_tVertex[1] = SPVec3f(width, 0.0f, 0.0f);		// point 2
			m_cMesh.m_tVertex[2] = SPVec3f(0.0f, height, 0.0f);		// point 3
			m_cMesh.m_tVertex[3] = SPVec3f(width, height, 0.0f);		// point 4
		}
		else
		{
			SPFloat x(width/2), y(height/2);
			m_cMesh.m_tVertex[0] = SPVec3f(-x, -y, 0.0f);		// point 1
			m_cMesh.m_tVertex[1] = SPVec3f(x, -y, 0.0f);		// point 2
			m_cMesh.m_tVertex[2] = SPVec3f(-x, y, 0.0f);		// point 3
			m_cMesh.m_tVertex[3] = SPVec3f(x, y, 0.0f);		// point 4
		}

		//create rect vertex index
		m_cMesh.m_tVertexIndex.clear();

		m_cMesh.m_tVertexIndex.push_back(0);
		m_cMesh.m_tVertexIndex.push_back(1);
		m_cMesh.m_tVertexIndex.push_back(2);
		m_cMesh.m_tVertexIndex.push_back(3);
	}

	SPVoid SPDrawBackground::createTextureUV()
	{
		// Rect Vertex
		//     P3(0,0)            P4(1,0)
		//     * ----------------- *
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1(0,1)            P2(1.1)

		m_cMesh.m_tTextureUV.clear();
		m_cMesh.m_tTextureUV.resize(4);

		m_cMesh.m_tTextureUV[0] = SPVec3f(0.0f, 1.0f, 0.0f);		// point 1
		m_cMesh.m_tTextureUV[1] = SPVec3f(1.0f, 1.0f, 0.0f);		// point 2
		m_cMesh.m_tTextureUV[2] = SPVec3f(0.0f, 0.0f, 0.0f);		// point 3
		m_cMesh.m_tTextureUV[3] = SPVec3f(1.0f, 0.0f, 0.0f);		// point 4


		if(m_bFBOUVDraw == SPTRUE)
		{
			SPVec3f tmpVec;
			tmpVec= m_cMesh.m_tTextureUV[0];
			m_cMesh.m_tTextureUV[0] = m_cMesh.m_tTextureUV[2];
			m_cMesh.m_tTextureUV[2] = tmpVec;

			tmpVec= m_cMesh.m_tTextureUV[1];
			m_cMesh.m_tTextureUV[1] = m_cMesh.m_tTextureUV[3];
			m_cMesh.m_tTextureUV[3] = tmpVec;
		}
	}
}//namespace SPhysics