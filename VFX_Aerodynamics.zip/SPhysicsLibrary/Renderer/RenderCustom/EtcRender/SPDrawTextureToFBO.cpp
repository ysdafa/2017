/**
* @file SPDrawTextureToFBO.cpp
* @brief 
*
* @date 2014-06-19
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPTextureManager.h"
#include "SPDrawTextureToFBO.h"

namespace
{
	static glm::vec2 gPostEffectPosition[] =
	{
		glm::vec2(-1.0f, -1.0f),
		glm::vec2(-1.0f, 1.0f),
		glm::vec2(1.0f, 1.0f),
		glm::vec2(1.0f, 1.0f),
		glm::vec2(1.0f, -1.0f),
		glm::vec2(-1.0f, -1.0f),
	};

	static glm::vec2 gPostEffectUV[] =
	{
		glm::vec2(0.0f, 0.0f),
		glm::vec2(0.0f, 1.0f),
		glm::vec2(1.0f, 1.0f),
		glm::vec2(1.0f, 1.0f),
		glm::vec2(1.0f, 0.0f),
		glm::vec2(0.0f, 0.0f),
	};
}

namespace SPhysics
{
	SPDrawTextureToFBO::SPDrawTextureToFBO(const SPUInt aTextureId)
							 : mTextureId(aTextureId)
	{
	}

	SPDrawTextureToFBO::~SPDrawTextureToFBO()
	{
	}

	SPVoid SPDrawTextureToFBO::initRender(SPFloat width, SPFloat height)
	{
		SPChar VertexShader[] =  
				"precision mediump float;\n"
				"attribute vec4 aPosition;\n"
				"attribute vec2 aUV;\n"

				"varying vec2 vInterpUV;\n"

				"void main()\n"
				"{\n"
				"    // perspective\n"
				"    gl_Position = aPosition;\n"
				"    vInterpUV = aUV;\n"
				"}\n";

		SPChar FragmentShader[] =  
				"precision mediump float;\n"
				"uniform sampler2D uTexture;\n"

				"varying vec2 vInterpUV;\n"

				"void main()\n"
				"{\n"
				"    gl_FragColor = texture2D( uTexture, vInterpUV );\n"
				"}\n";
		
		createShaderProgram(VertexShader, FragmentShader);
	}

	SPVoid SPDrawTextureToFBO::drawRender()
	{
		glDisable(GL_DEPTH_TEST);
		glDisable(GL_BLEND);

		setShaderArrayVector("aPosition", (SPFloat*)&gPostEffectPosition[0].x, 2);
		setShaderArrayVector("aUV", (SPFloat*)&gPostEffectUV[0].x, 2);
		setShaderUnifromTexture("uTexture", mTextureId);

		setCustomDrawArrays(6, DRAW_TRIANGLES);
	}

	SPVoid SPDrawTextureToFBO::setTexture(const SPUInt aTextureId)
	{
		mTextureId = aTextureId;
	}

}//namespace SPhysics
