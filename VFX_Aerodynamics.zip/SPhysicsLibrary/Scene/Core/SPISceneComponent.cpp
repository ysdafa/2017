/**
* @file SPISceneComponent.cpp
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/


#include <stdio.h> 
#include "SPISceneComponent.h"

namespace SPhysics
{

	SPISceneComponent::SPISceneComponent() : m_nScreenWidth(0), m_nScreenHeight(0), m_nVisibility(1), mIsTransition(SPFALSE)
	{

	}

	SPISceneComponent::~SPISceneComponent()
	{
		if(m_vLayerItems.size() != 0)
		{
			m_vLayerItems.clear();
		}
	}

	SPVoid SPISceneComponent::createSceneLayer()
	{
		makeSceneLayer();
	}

	SPVoid SPISceneComponent::onInitScene( SPInt width, SPInt height )
	{
		m_nScreenWidth = width;
		m_nScreenHeight = height;

		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT);
		glViewport(0,0, m_nScreenWidth, m_nScreenHeight);

		initApp(width, height);

		for(SPInt i=0;i<(SPInt)m_vLayerItems.size();i++)
		{
			if(m_vLayerItems[i].first == MASK_LAYER_SCENE)
			{
				SCENE_LAYER(m_vLayerItems[i])->onInitScene(width, height);
			}
			//m_vLayerItems[i]->onInitScene(width, height);
		}
	}

	SPVoid SPISceneComponent::onSurfaceChanged( SPInt width, SPInt height )
	{
		m_nScreenWidth = width;
		m_nScreenHeight = height;

		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT);
		glViewport(0,0, m_nScreenWidth, m_nScreenHeight);

		onEventSurfaceChanged(width, height);

		for(SPInt i=0;i<(SPInt)m_vLayerItems.size();i++)
		{
			if(m_vLayerItems[i].first == MASK_LAYER_SCENE)
			{
				SCENE_LAYER(m_vLayerItems[i])->onSurfaceChanged(width, height);
			}
			//m_vLayerItems[i]->onInitScene(width, height);
		}
	}

	SPVoid SPISceneComponent::onUpdateScene()
	{
		updateApp();

		for(SPInt i=0;i<(SPInt)m_vLayerItems.size();i++)
		{
			if(m_vLayerItems[i].first == MASK_LAYER_SCENE)
			{
				if( SCENE_LAYER(m_vLayerItems[i])->getVisibility() == SCENE_VISIBLE)
				{
					if(SCENE_LAYER(m_vLayerItems[i])->mIsTransition)
					{
						continue;
					}

					SCENE_LAYER(m_vLayerItems[i])->onUpdateScene();
				}
			}

		}
	}

	// this API is just called once in root scene layer
	// android : JNI Interface, Win32 : S-Physics.cpp
	SPVoid SPISceneComponent::clearGLBuffer()
	{
		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
	}

	SPVoid SPISceneComponent::onDrawScene()
	{
		drawApp();

		for(SPInt i=0;i<(SPInt)m_vLayerItems.size();i++)
		{
			if(m_vLayerItems[i].first == MASK_LAYER_SCENE)
			{
				if(SCENE_LAYER(m_vLayerItems[i])->getVisibility() == SCENE_VISIBLE)
				{
					SCENE_LAYER(m_vLayerItems[i])->onDrawScene();
				}
			}else if(m_vLayerItems[i].first == MASK_LAYER_RENDER)
			{

			}
			
		}
	}

	SPVoid SPISceneComponent::onResetScene()
	{
		resetApp();

		for(SPInt i=0;i<(SPInt)m_vLayerItems.size();i++)
		{
			if(m_vLayerItems[i].first == MASK_LAYER_SCENE)
			{
				if(SCENE_LAYER(m_vLayerItems[i])->getVisibility() == SCENE_VISIBLE)
				{
					SCENE_LAYER(m_vLayerItems[i])->onResetScene();
				}
			}
		}
	}

	SPVoid SPISceneComponent::setForceScene()
	{
		//setForceApp();

		for(SPInt i=0;i<(SPInt)m_vLayerItems.size();i++)
		{
			if(m_vLayerItems[i].first == MASK_LAYER_SCENE)
			{
				if(SCENE_LAYER(m_vLayerItems[i])->getVisibility() == SCENE_VISIBLE)
				{
					SCENE_LAYER(m_vLayerItems[i])->setForceScene();
				}
			}
		}
	}

	SPVoid SPISceneComponent::onKeyEvent( SPInt keyID )
	{
		SP_LOGE(" SPISceneComponent::onKeyEvent  --> %d \n", keyID);
//		keyID = keyID;
		onEventKey((KEY_TYPE)keyID);

		for(SPInt i=0;i<(SPInt)m_vLayerItems.size();i++)
		{
			if(m_vLayerItems[i].first == MASK_LAYER_SCENE)
			{
				if(SCENE_LAYER(m_vLayerItems[i])->getVisibility() == SCENE_VISIBLE)
				{
					SCENE_LAYER(m_vLayerItems[i])->onKeyEvent(keyID);
				}
			}
		}
	}

	SPVoid SPISceneComponent::onCustomEvent( SPInt eventID, SPFloat value )
	{
		onEventCustom(eventID, value);

		for(SPInt i=0;i<(SPInt)m_vLayerItems.size();i++)
		{
			if(m_vLayerItems[i].first == MASK_LAYER_SCENE)
			{
				if(SCENE_LAYER(m_vLayerItems[i])->getVisibility() == SCENE_VISIBLE)
				{
					SCENE_LAYER(m_vLayerItems[i])->onCustomEvent(eventID, value);
				}
			}
		}
	}

	SPVoid SPISceneComponent::onCustomEvent( SPInt eventID, SPFloat xValue, SPFloat yValue, SPFloat zValue )
	{
		onEventCustom(eventID, xValue, yValue, zValue);

		for(SPInt i=0;i<(SPInt)m_vLayerItems.size();i++)
		{
			if(m_vLayerItems[i].first == MASK_LAYER_SCENE)
			{
				if(SCENE_LAYER(m_vLayerItems[i])->getVisibility() == SCENE_VISIBLE)
				{
					SCENE_LAYER(m_vLayerItems[i])->onCustomEvent(eventID, xValue, yValue, zValue);
				}
			}
		}
	}

	SPVoid SPISceneComponent::onTouchEvent( SPInt touchID, SPInt touchNum, SPInt eventType, SPInt xPos[], SPInt yPos[] )
	{
		// Case:: Single Touch Event (Single means First touch )
		if(touchID == 0)
		{
			onEventTouch((TOUCH_TYPE)eventType, xPos[0],  yPos[0]);
		}

		onEventMultiTouch((TOUCH_TYPE)eventType, touchID, touchNum, xPos, yPos);


		for(SPInt i=0;i<(SPInt)m_vLayerItems.size();i++)
		{
			if(m_vLayerItems[i].first == MASK_LAYER_SCENE)
			{
				if(SCENE_LAYER(m_vLayerItems[i])->getVisibility() == SCENE_VISIBLE)
				{
					if(SCENE_LAYER(m_vLayerItems[i])->mIsTransition)
					{
						continue;
					}

					SCENE_LAYER(m_vLayerItems[i])->onTouchEvent(touchID, touchNum, eventType, xPos, yPos);
				}
			}
		}
	}

	SPVoid SPISceneComponent::onHoverEvent(SPInt eventType, SPInt xPos, SPInt yPos)
	{
		onEventHover((HOVER_TYPE)eventType, xPos, yPos);

		for(SPInt i=0;i<(SPInt)m_vLayerItems.size();i++)
		{
			if(m_vLayerItems[i].first == MASK_LAYER_SCENE)
			{
				if(SCENE_LAYER(m_vLayerItems[i])->getVisibility() == SCENE_VISIBLE)
				{
					SCENE_LAYER(m_vLayerItems[i])->onHoverEvent(eventType, xPos, yPos);
				}
			}
		}
	}

	SPVoid SPISceneComponent::onSensorEvent( SPInt sType, SPFloat xValue, SPFloat yValue, SPFloat zValue )
	{

		//SP_LOGE("CSceneComponent %s", __func__);
// 
// 		sensorType = sType;
// 
// 		xValue = xValue;
// 		yValue = yValue;
// 		zValue = zValue;

		onEventSensor((SENSOR_TYPE)sType, xValue, yValue, zValue);

		for(SPInt i=0;i<(SPInt)m_vLayerItems.size();i++)
		{
			if(m_vLayerItems[i].first == MASK_LAYER_SCENE)
			{
				if(SCENE_LAYER(m_vLayerItems[i])->getVisibility() == SCENE_VISIBLE)
				{
					SCENE_LAYER(m_vLayerItems[i])->onSensorEvent(sType, xValue, yValue, zValue);
				}
			}
		}
	}

	SPVoid SPISceneComponent::onSetTextureEvent( const SPChar* name )
	{
		onEventSetTexture(name);

		for(SPInt i=0;i<(SPInt)m_vLayerItems.size();i++)
		{
			if(m_vLayerItems[i].first == MASK_LAYER_SCENE)
			{
				SCENE_LAYER(m_vLayerItems[i])->onSetTextureEvent(name);
			}
		}
	}

	SPVoid SPISceneComponent::onSetTextureColorEvent( const SPChar* name )
	{
		onEventSetTextureColor(name);

		for(SPInt i=0;i<(SPInt)m_vLayerItems.size();i++)
		{
			if(m_vLayerItems[i].first == MASK_LAYER_SCENE)
			{
				if(SCENE_LAYER(m_vLayerItems[i])->getVisibility() == SCENE_VISIBLE)
				{
					SCENE_LAYER(m_vLayerItems[i])->onSetTextureColorEvent(name);
				}
			}
		}
	}

	SPBool SPISceneComponent::isEmpty()
	{
		SPBool result;
		
		result = isEmptyDraw();

		for(SPInt i=0;i<(SPInt)m_vLayerItems.size();i++)
		{
			if(m_vLayerItems[i].first == MASK_LAYER_SCENE)
			{
				if(SCENE_LAYER(m_vLayerItems[i])->getVisibility() == SCENE_VISIBLE)
				{
					result = result || SCENE_LAYER(m_vLayerItems[i])->isEmpty();
				}
			}
		}

		return result;
	}

	SPVoid SPISceneComponent::addSceneLayer( SPISceneComponent *pScene )
	{
		PAIR_ITEM item;
		item.first = MASK_LAYER_SCENE;
		item.second = pScene;
		m_vLayerItems.push_back(item);
	}

	SPVoid SPISceneComponent::removeMaskLayer(SPVoid *pItem)
	{
		for(SPInt i = 0; i < (SPInt)m_vLayerItems.size(); i++)
		{
			if(pItem == m_vLayerItems[i].second)
			{
				m_vLayerItems.erase(m_vLayerItems.begin()+i);						
				break;
			}
		}
	}

	SPVoid SPISceneComponent::setVisibility( SPInt flag )
	{
		m_nVisibility = flag;
	}


	SPInt SPISceneComponent::getVisibility()
	{
		return m_nVisibility;
	}		

}  //namespace SPhysics




