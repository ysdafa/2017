/**
* @file SPAerodynamicsApp.cpp
* @brief
*
* @date 2014-06-16
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPAerodynamicsApp.h"
#include "SPTextureManager.h"

static float gQuality(30.f);
static std::string gDiffuseTextureName("Res/aerodynamics/flake_diffuse.png");
static std::string gNormalTextureName("Res/aerodynamics/flake_normal.png");
static std::string gBackgroundTextureName("Res/aerodynamics/bg_alpha.png");

namespace SPhysics
{

SPAerodynamicsApp::SPAerodynamicsApp()
	: mController()
	, mTouchHandler(0)
	, mBrushWidth(0.05f)
	, mPrePointSpriteRenderer(0)
	, mPointSpriteRenderer(0)
	, mBackgroundRenderer(0)
	, mVBRenderer(0)
	, mHBRenderer(0)
	, mApplyDOFRenderer(0)
	, mDiffuseTextureId(0)
	, mNormalTextureId(0)
	, mBackgroundTextureId(0)
	, mDrawingSurfaceSize()
	, mScreenSize()
	, mIScreenSize()
	, mFocalDistance(1.f)
	, mFocalRange(1000.f)
	, mVecToLight(glm::normalize(glm::vec3(0.0f, 1.f, 1.f)))
	, mSpecularPower(200.f)
	, mSpecularIntensity(40.f)
	, mLightColor(1.f)
	, mLightIntensity(3.f)
	, mLightAmbient(0.8f)
	, mFocalAngle(90.f)
	, mFarZ(1000.f)
	, mNearZ(1.f)
{
}

SPAerodynamicsApp::~SPAerodynamicsApp()
{
	delete mPrePointSpriteRenderer;
	delete mPointSpriteRenderer;
	delete mBackgroundRenderer;
	delete mVBRenderer;
	delete mHBRenderer;
	delete mApplyDOFRenderer;
	mMainFBO.destroyFBOSurface();
	mFBO1.destroyFBOSurface();
	mFBO2.destroyFBOSurface();
}

SPVoid SPAerodynamicsApp::initApp(SPInt width, SPInt height)
{
	mDiffuseTextureId = SPTextureManager::getInstancePtr()->loadTexture(gDiffuseTextureName.c_str());
	mNormalTextureId = SPTextureManager::getInstancePtr()->loadTexture(gNormalTextureName.c_str());
	mBackgroundTextureId = SPTextureManager::getInstancePtr()->loadTexture(gBackgroundTextureName.c_str());

	TEXTURE_COLOR_BUFFER * textureInfo(SPTextureManager::getInstancePtr()->loadTextureColor(gDiffuseTextureName.c_str()));

	glm::vec2 animationTextureSize(static_cast<float>(textureInfo->ImgWidth),
								   static_cast<float>(textureInfo->ImgHeight));
	glm::vec2 frameSize(animationTextureSize.x);

	mScreenSize = glm::vec2(static_cast<float>(width), static_cast<float>(height));
	mIScreenSize = glm::ivec2(width, height);

	glm::vec3 eye(gQuality, 0.f, 0.f);
	eye.y = eye.x * tan(mFocalAngle * 0.5f * glm::pi<float>() / 180.f) * 2.f;
	eye.x = eye.y * mScreenSize.x / mScreenSize.y;

	mController.init(int(eye.x), int(eye.y), int(gQuality), 
					 animationTextureSize, frameSize,
					 gSPADl_bellPointsNumber, gSPADl_transferringCoefficient, gSPADl_minCurvature,
					 gSPADl_velocityToAssign, gSPADl_forceCoefficient, gSPADl_heightForceCoefficient, gSPADl_collisionRangeNumber,
					 gSPADl_streamingRangeNumber);

	eye *= 0.5f;
	glm::vec3 centre(eye.x, eye.y, 1.f);
	glm::vec3 up(0.f, -1.f, 0.f);

	mFocalDistance = static_cast<float>(mController.getDepth()) * 0.5f;
	mFocalRange = static_cast<float>(mController.getDepth()) * 2.f;

	glm::vec2 frameSizeInTextureCoord1 = (frameSize / animationTextureSize);
	mPrePointSpriteRenderer = new SPDrawPrePointSprite(&((*mController.getParticles())[0]),
		&((*mController.getParticleTexOffset())[0]),
		mDiffuseTextureId,
		0.2f,
		frameSizeInTextureCoord1,
		0.01f,
		(unsigned int)(mController.getParticles()->size()));

	mPrePointSpriteRenderer->initialize(mScreenSize.x, mScreenSize.y);
	mPrePointSpriteRenderer->setLookAt(eye.x, eye.y, eye.z, 
		centre.x, centre.y, centre.z,
		up.x, up.y, up.z);
	mPrePointSpriteRenderer->setPerspectiveCameraView(mFocalAngle, mScreenSize.x / mScreenSize.y, mNearZ, mFarZ);

	glm::vec2 frameSizeInTextureCoord2 = frameSize / animationTextureSize;

	mPointSpriteRenderer = new SPDrawPointSprite(&(*mController.getParticles())[0],
		&(*mController.getParticleTexOffset())[0],
		mDiffuseTextureId,
		mNormalTextureId,
		mBackgroundTextureId,
		0.2f,
		frameSizeInTextureCoord2,
		mFocalDistance,
		mFocalRange,
		mVecToLight,
		mSpecularPower,
		mSpecularIntensity,
		mLightColor,
		mLightIntensity,
		mLightAmbient,
		mController.getParticles()->size());

	mPointSpriteRenderer->initialize(mScreenSize.x, mScreenSize.y);
	mPointSpriteRenderer->setLookAt(eye.x, eye.y, eye.z, 
		centre.x, centre.y, centre.z,
		up.x, up.y, up.z);
	mPointSpriteRenderer->setPerspectiveCameraView(mFocalAngle, mScreenSize.x / mScreenSize.y, mNearZ, mFarZ);

	mBackgroundRenderer = new SPDrawTextureToFBO(mBackgroundTextureId);
	mBackgroundRenderer->initialize(width, height);

	mMainFBO.createFBOSurface(width, height);
	mMainFBO.enableFBODepthBuffer();
	mFBO1.createFBOSurface(width >> 3, height >> 3);
	mFBO2.createFBOSurface(width >> 3, height >> 3);

	mVBRenderer = new SPDrawVerticalBlur(mFBO1.getFBOTexture());
	mVBRenderer->initialize(width >> 3, height >> 3);

	mHBRenderer = new SPDrawHorizontalBlur(mFBO2.getFBOTexture());
	mHBRenderer->initialize(width >> 3, height >> 3);

	mApplyDOFRenderer = new SPDrawApplyDOF(mMainFBO.getFBOTexture(), mFBO1.getFBOTexture());
	mApplyDOFRenderer->initialize(width, height);

	mTouchHandler = mController.getTouchHandler();
	mTouchHandler->setScaleWidth(mBrushWidth);
	mTouchHandler->setScaleLength(0.15f);

	mDrawingSurfaceSize = glm::vec2(static_cast<float>(mController.getWidth()), 
		static_cast<float>(mController.getHeight()));
}

SPVoid SPAerodynamicsApp::updateApp()
{
	mController.process();
}

SPVoid SPAerodynamicsApp::drawApp()
{
	mMainFBO.bindFBOSurface();
	glClear(GL_DEPTH_BUFFER_BIT);
	mBackgroundRenderer->setTexture(mBackgroundTextureId);
	mBackgroundRenderer->draw();
	mPrePointSpriteRenderer->draw();
	mPointSpriteRenderer->draw();
	glDepthMask(GL_TRUE);
	mMainFBO.unbindFBOSurface(mIScreenSize.x, mIScreenSize.y);
	mBackgroundRenderer->setTexture(mMainFBO.getFBOTexture());
	mFBO1.bindFBOSurface();
	mBackgroundRenderer->draw();
	mFBO1.unbindFBOSurface(mIScreenSize.x, mIScreenSize.y);
	mFBO2.bindFBOSurface();
	mVBRenderer->draw();
	mFBO2.unbindFBOSurface(mIScreenSize.x, mIScreenSize.y);
	mFBO1.bindFBOSurface();
	mHBRenderer->draw();
	mFBO1.unbindFBOSurface(mIScreenSize.x, mIScreenSize.y);
	mApplyDOFRenderer->draw();
}

SPVoid SPAerodynamicsApp::onEventTouch(TOUCH_TYPE eventType, SPInt xPos, SPInt yPos)
{
	mTouchHandler->onTouchMove(static_cast<float>(xPos) / static_cast<float>(mScreenSize.x) * mDrawingSurfaceSize.x,
							   (1.f - static_cast<float>(yPos) / static_cast<float>(mScreenSize.y)) * mDrawingSurfaceSize.y, 0.f);
}

SPVoid SPAerodynamicsApp::onEventSensor()
{
}

SPVoid SPAerodynamicsApp::onEventKey()
{

}

SPVoid SPAerodynamicsApp::resetApp()
{
}

SPVoid SPAerodynamicsApp::setForceApp()
{
}

SPVoid SPAerodynamicsApp::reset()
{
}

}    //namespace SPhysics
