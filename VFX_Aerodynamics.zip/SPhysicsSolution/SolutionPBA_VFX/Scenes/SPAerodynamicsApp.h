/**
* @file SPAerodynamicsApp.h
* @brief
*
* @date 2014-06-16
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_AERODYNAMICS_APP_H_
#define _SP_AERODYNAMICS_APP_H_

#include "SPADController.h"
#include "SPISceneComponent.h"

#include "SPDrawPrePointSprite.h"
#include "SPDrawPointSprite.h"
#include "SPDrawTextureToFBO.h"
#include "SPDrawVerticalBlur.h"
#include "SPDrawHorizontalBlur.h"
#include "SPDrawApplyDOF.h"
#include "SPNonCopyable.h"

#include "SPFBO.h"


namespace SPhysics
{
	class SPAerodynamicsApp: NonCopyable,  public SPISceneComponent
	{
	public:
		SPAerodynamicsApp();
		~SPAerodynamicsApp();

	public:
		SPVoid initApp(SPInt width, SPInt height);
		SPVoid updateApp();
		SPVoid drawApp();
		SPVoid onEventKey();
		SPVoid onEventTouch(TOUCH_TYPE eventType, SPInt xPos, SPInt yPos);
		SPVoid onEventSensor();
		SPVoid resetApp();
		SPVoid setForceApp();

		SPVoid reset();

	private:
		// simulation
		SPADController mController;
		ForceTool* mTouchHandler;
		float mBrushWidth;
		SPDrawPrePointSprite * mPrePointSpriteRenderer;
		SPDrawPointSprite * mPointSpriteRenderer;
		SPDrawTextureToFBO * mBackgroundRenderer;
		SPDrawVerticalBlur * mVBRenderer;
		SPDrawHorizontalBlur * mHBRenderer;
		SPDrawApplyDOF * mApplyDOFRenderer;
		unsigned int mDiffuseTextureId;
		unsigned int mNormalTextureId;
		unsigned int mBackgroundTextureId;
		glm::vec2 mDrawingSurfaceSize;
		glm::vec2 mScreenSize;
		glm::ivec2 mIScreenSize;

		float				mFocalDistance;
		float				mFocalRange;
		glm::vec3			mVecToLight;
		float				mSpecularPower;
		float				mSpecularIntensity;
		glm::vec3			mLightColor;
		float				mLightIntensity;
		float				mLightAmbient;
		glm::vec2			mInvScreenSize;
		float				mFocalAngle;
		float				mFarZ;
		float				mNearZ;

		SPFBO				mMainFBO;
		SPFBO				mFBO1;
		SPFBO				mFBO2;
	};

}    //namespace SPhysics

#endif //_SP_FIREWORKS_APP_H_
