/**
* @file SPSceneManagerPBAVFX.cpp
* @brief
*
* @date
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include <stdio.h>
#include "SPLog.h"
#include "SPSceneManagerPBAVFX.h"
#include "SPFPS.h"
#include "SPRecodeVideoApp.h"


#include "SPAerodynamicsApp.h"


namespace SPhysics
{

	SPSceneManagerPBAVFX::SPSceneManagerPBAVFX() : m_pApp(SPNULL), m_pFPS(SPNULL), m_pRecordVideo(SPNULL)
	{

	}

	SPSceneManagerPBAVFX::~SPSceneManagerPBAVFX()
	{
		SP_SAFE_DELETE(m_pApp);
		SP_SAFE_DELETE(m_pFPS);
		SP_SAFE_DELETE(m_pRecordVideo);

		releaseSingletonInstance();
	}

	void SPSceneManagerPBAVFX::makeSceneLayer()
	{
#ifndef _WIN32
		SP_LOGI("SPSceneManagerPBAVFX %s", __func__);
#endif

		m_pApp = new SPAerodynamicsApp();
	


		addSceneLayer(m_pApp);


		//enableFPSViewer();
		//enableRecordVideo();

	}

	SPVoid SPSceneManagerPBAVFX::setCurrentScene(int currentScene)
	{
	}

	SPVoid SPSceneManagerPBAVFX::enableFPSViewer()
	{
		if(m_pFPS == SPNULL)
			m_pFPS = new SPFPS();

		addSceneLayer(m_pFPS);
	}

	SPVoid SPSceneManagerPBAVFX::enableRecordVideo()
	{
		if(m_pRecordVideo == SPNULL)
			m_pRecordVideo = new SPRecodeVideoApp();

		addSceneLayer(m_pRecordVideo);
	}

} // namespace SPhysics
