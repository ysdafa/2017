/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * TODO
 * @file   SPADController.h
 * @brief
 * @author
 */

#ifndef AERODYNAMICSCONTROLLER_H_94F781F4481F4C20A62009688C79A441
#define AERODYNAMICSCONTROLLER_H_94F781F4481F4C20A62009688C79A441

#include "SPADCollisionDemon.h"
#include "SPADFastCollisionDemon.h"
#include "SPADStreamingDemon.h"
#include "SPADInitialBoundariesDemon.h"
#include "SPADInitialVelocitiesDemon.h"
#include "SPADParticleSimulation.h"
#include "SPNonCopyable.h"

#include <vector>

namespace SPhysics
{
class SPTask;
class SPTaskPool;


#ifdef DIRECT_NEIGHBOR_ACCESS
#define CHECK_NEIGHBOR(I, X, Y) (cellObject.mNeighbors[I] != NULL)
#else
#define CHECK_NEIGHBOR(I, X, Y) m_lattice->checkNeighbor(I, X, Y)
#endif

class PointsMediumStructure;

class CellObject;
template<typename TCellObject>
class Lattice;
class EventDispatcher;
class Brush;
class ForceTool;

struct PresetParams
{
	float brushSize;
	float viscosity;
	float curvature;
	float diffusion;

	PresetParams() :
		brushSize(0),
		viscosity(0),
		curvature(0),
		diffusion(0)
	{
	}
};

/**
 * @class SPADController
 * @brief wrapper class for aerodynamics simulation algorithms
 */
class SPADController: NonCopyable
{
public:
	/**
	 * @brief default constructor
	 */
	SPADController();
	/**
	 * @brief destructor
	 */
	~SPADController();
	/**
	 * @brief get the lattice
	 * @return      reference to the lattice
	 */
	Lattice<CellObject>& getLattice();
	/**
	 * @brief get streaming demon
	 * @return      reference to the streaming demon
	 */
	StreamingDemon& getStreamingDemon();

	/**
	 * @brief initialization of parameters
	 * @param width                                 lattice width
	 * @param height                                lattice height
	 * @param transferringCoefficient
	 * @param preservingDirectionCoefficient
	 * @param minCurvature
	 * @param velocityToAssign
	 * @param forceCoefficient
	 * @param heightForceCoefficient
	 * @param collisionRangesNumber
	 * @param streamingRangesNumber
	 */
	void init(int width, int height, int depth, const glm::vec2& aAnimationTextureSize,
			  const glm::vec2& aFrameSize,
			  int bellPointsNumber, float transferringCoefficient,
			  float minCurvature, float velocityToAssign, float forceCoefficient, float heightForceCoefficient,
			  int collisionRangesNumber, int streamingRangesNumber);

	int getXoZLatticeXOffset();
	int getZoYLatticeXOffset();
	int getXoZLatticeYOffset();
	int getZoYLatticeYOffset();

	int getLatticeWidth() const;
	int getLatticeHeight() const;

	inline glm::mat4 getScale() const;

#ifdef AERODYNAMICS_MULTI_THREAD
	/**
	 * TODO
	 * @param aViscosity
	 */
	void createTaskPool(int aTasksCount);
	/**
	 * TODO
	 * @param aViscosity
	 */
	void setEventDispatcher(EventDispatcher* aEventDispatcher);
	/**
	 * TODO
	 * @param aViscosity
	 */
	void bindEvents(SPEvent* aEvents);
#endif
	/**
	 * TODO
	 * @param aViscosity
	 */
	void assignAirViscosity(float aViscosity);
	/**
	 * TODO
	 */
	bool process();
	/**
	 * TODO
	 */
	void setClearFlag();

	void setFreezeFlag();
	/**
	 * TODO
	 */
	void clear();
	void freeze();
	inline float getCurvature() const;
	inline void setCurvature(float curvature);
	inline float getForceCoefficient() const;
	inline void setForceCoefficient(float coefficient);
	void setPresetToChange(int presetID);
	void loadPreset();

//#ifdef AERODYNAMICS_MULTI_THREAD
	/**
	 * TODO
	 * @param aParams
	 */
	void walkLatticeRange(SPADWalkLatticeRangeParams aParams);
	/**
	 * TODO
	 * @param aParams
	 */
	void walkLatticeSync(SPADWalkLatticeSyncParams aParams);
//#endif
	/**
	 * TODO
	 * @param aKphi1
	 * @param aKphi2
	 * @param aKphiBehavior
	 * @param aKbendBehavior
	 * @param aKbend
	 * @param aKellipseDeformation
	 */
	void setBrushParam(float aKphi1, float aKphi2, float aKphiBehavior, float aKbendBehavior, float aKbend,
					   float aKellipseDeformation);
	/**
	 * TODO
	 * @param aKphi1
	 * @param aKphi2
	 * @param aKphiBehavior
	 * @param aKbendBehavior
	 * @param aKbend
	 * @param aKellipseDeformation
	 */
	void getBrushParam(float& aKphi1, float& aKphi2, float& aKphiBehavior, float& aKbendBehavior, float& aKbend,
					   float& aKellipseDeformation);
	/**
	 * create or change force map
	 * @param aWidth width of force map
	 * @param aHeight height of force map
	 * @param aStep step between neighbor cell of force map
	 */
	void doCreateForceMap(int aWidth, int aHeight);

	void addForceMapToLattice();
	/**
	 * TODO
	 */
	float getPhi() const;
	/**
	 * get TouchHandler
	 * @param aTool tool type
	 * @return TouchHandler with chosen tool type
	 */
	ForceTool* getTouchHandler();
	void setPauseCalculationsIfIdle(bool pauseCalculations);

	bool getPauseCalculationsIfIdle();

	void resetVelocities();

	void setWhetherToProcess(bool process);

	bool getWhetherToProcess();

	inline int getWidth() const;
	inline int getHeight() const;
	inline int getDepth() const;
	inline std::vector<glm::vec3>* getParticles();
	inline std::vector<glm::vec2>* getParticleTexOffset();
	inline ParticleConfiguration& getParticleConfigutation();

private:
	/**
	 * TODO - give short up description for each class member
	 */
	Lattice<CellObject> mLattice;
	PointsMediumStructure* mPaperSurface;
	InitialVelocitiesDemon mInitDemon;
	StreamingDemon mStreamingDemon;
	CollisionDemon mCollisionDemon;
	FastCollisionDemon mFastCollisionDemon;
	InitialBoundariesDemon mInitialBoundariesDemon;
	BouncebackDemon mBoundaryDemon;

	int mWidth;
	int mHeight;
	int mDepth;

	int mXoZLatticeXOffset;
	int mXoZLatticeYOffset;
	int mZoYLatticeXOffset;
	int mZoYLatticeYOffset;

	int mCollisionRangesNumber;
	int mStreamingRangesNumber;

	float mVelocityToAssign;

	SPADWalkLatticeRangeParams* mCollisionParams;
	SPADWalkLatticeSyncParams* mStreamingParams;

#ifdef AERODYNAMICS_MULTI_THREAD
	SPTask** mCollisionTasks;
	SPTask** mStreamingTasks;
	SPTaskPool* mTaskPool;
	SPEvent mEvent;
	SPEvent* mEvents;
	SPCollisionEvent mCollisionEvent;
	SPEventDispatcher* mEventDispatcher;
#endif

	bool mClearFlag;
	bool mFreezeFlag;
	bool mIntentToStop;

	Brush* mBrush;

	ForceMap mForceMap;

	bool mProcess;
	bool mPauseCalculationsIfIdle;

	PresetParams mPresetParams;
	int mPresetID;
	bool mChangePreset;

	ParticleSimulation mParticleSimulation;

	float mPrevTime;
};

}    // namespace SPhysics

#include "SPADController.inl"

#endif // _AERODYNAMICSCONTROLLER_H_
