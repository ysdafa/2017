/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   ForceTool.h
 * @brief  Abstract Paint tool class.
 * @author Author (o.snyezhko@samsung.com)
 */

#ifndef PAINT_TOOL_H_0F11E0E81C454E709B53D2325C62B878
#define PAINT_TOOL_H_0F11E0E81C454E709B53D2325C62B878

#include "SPNonCopyable.h"

#include <iostream>
#include <glm.hpp>
namespace SPhysics
{

class SPADController;
/**
 * struct Force cell with parametres
 */
struct Force
{
	/**
	 * Constructor.
	 */
	Force();
	glm::vec2 mVelocity; /**<Vector of velocity*/
	bool mIsSolid;/**<is cell solid*/
	bool mToAddVelocity;
};
/**
 * struct ForceMap with array of Force
 */
struct ForceMap : NonCopyable
{
	/**
	 * Constructor.
	 */
	ForceMap();
	/**
	 * Destructor.
	 */
	~ForceMap();
	/**
	 * init force map
	 * @param aWidth force map width
	 * @param aHeight force map height
	 */
	void init(int aWidth, int aHeight);
	/**
	 *	check there is cell
	 * @param aNumber number of neighbor cell
	 * @param aX coordinate x
	 * @param aY coordinate y
	 * @return true when there is otherwise not
	 */
	inline bool doCheckNeighbor(int aNumber, int aX, int aY);
	/**
	 *	check is neighbor cell solid
	 * @param aNumber number of neighbor cell
	 * @param aX coordinate x
	 * @param aY coordinate y
	 * @return true when this cell is solid otherwise not
	 */
	inline bool isNeighborSolid(int aNumber, int aX, int aY);
	/**
	 * get pointer to Force by coordinate (x,y)
	 * @param aX coordinate x
	 * @param aY coordinate y
	 * @return pointer to Force
	 */
	Force* operator()(int aX, int aY) const;
	/**
	 *	clear forceMap
	 */
	void clear();
	/**
	 * get force map width
	 * @return width
	 */
	int getWidth() const;
	/**
	 *	get force map height
	 * @return height
	 */
	int getHeight() const;

	int getDepth() const;
	Force* mMap; /**< Force map */
private:

	int mWidth; /**< Width */
	int mHeight; /**< Height */
};
class ForceTool
{
public:

	/**
	 * Constructor.
	 */
	ForceTool();
	/**
	 * Destructor.
	 */
	virtual ~ForceTool();

	/**
	 *	TouchDown method
	 * @param aX x position
	 * @param aY y position
	 * @param aZ z position/pressure(0..1)
	 */
	virtual void onTouchDown(float aX, float aY, float aZ) = 0;
	/**
	 *	TouchUp method
	 * @param aX x position
	 * @param aY y position
	 * @param aZ z position/pressure(0..1)
	 */
	virtual void onTouchUp(float aX, float aY, float aZ) = 0;
	/**
	 *	TouchMove method
	 * @param aX x position
	 * @param aY y position
	 * @param aZ z position/pressure(0..1)
	 */
	virtual void onTouchMove(float aX, float aY, float aZ) = 0;
	/**
	 *	set scale of radius/width
	 * @param aScale scale of radiuses
	 */
	virtual void setScaleWidth(float aScale) = 0;
	/**
	 *	set scale of length
	 * @param aScale scale length
	 */
	virtual void setScaleLength(float aScale) = 0;
	/**
	 *  set size scale
	 * @param aScale size scale
	 */
	virtual void setScaleSize(float aScale) = 0;
	/**
	 * get scale width
	 * @return getScale width
	 */
	virtual float getScaleWidth() const;
	/**
	 * get scale length
	 * @return scale length
	 */
	virtual float getScaleLength() const;
	/**
	 * get scale size
	 * @return scale size
	 */
	virtual float getScaleSize() const;
	/**
	 * get force map for adding velocity vector and ink to each cell
	 * @return point to force map
	 */
	ForceMap* getForceMap() const;
	/**
	 * set force map for adding velocity vector and ink to each cell
	 * @param point to force map
	 */
	void setForceMap(ForceMap* aForceMap);
	/**
	 *	set tool position
	 * @param aPos tool position
	 */
	void setPos(glm::vec3 aPos);
	/**
	 *	get tool position
	 * @return tool position
	 */
	glm::vec3 getPos() const;
	/**
	 * set ForceMapInterface pointer for callback
	 * @param aInterface ForceMapInterface pointer for callback
	 */
	void setForceMapInterface(SPADController* aInterface);
	/**
	 *	get ink percent of ink amount
	 * @return ink percent of ink amount
	 */

	void drawForceRemain();
	static int mXoZLatticeXOffset;
	static int mXoZLatticeYOffset;
	static int mZoYLatticeXOffset;
	static int mZoYLatticeYOffset;

	static float mScaleXtoY;
	static int mWidth;
	static int mHeight;

	static bool mOnlyPositive;

	static bool mVelocitiesFromCorner;

protected:
	glm::vec3 mPos; /**< current position */
	glm::vec3 mOldPos; /**< old position */
	ForceMap* mForceMap; /**< force map to add velocities and ink */
	float mVelocityMul; /**< multiple velocities on forceMap */
	float mScaleWidth;/**< Width scale*/
	float mScaleLength;/**< Length scale*/
	float mScaleSize; /**< Size scale */
	SPADController* mForceInterface; /**< Pointer to ForceMapInterface */
};

}	//namespace SPhysics
#include "AerodynamicsForceTool.inl"
#endif /*_PAINT_TOOL_H_*/
