#include "SPADEventDispatcher.h"

namespace SPhysics
{

EventDispatcher::EventDispatcher() :
	m_numberOfSyncObjects(0),
	m_height(0),
	m_syncObjects(NULL),
	m_rangeStarts(NULL),
	m_rangeEnds(NULL),
	m_collisionFinishedRows(NULL),
	m_streamingFinishedRows(NULL),
	m_streamingReadyRows(NULL),
	m_clearRowFlags(NULL)
{
}

EventDispatcher::EventDispatcher(int syncObjectsNumber) :
	m_numberOfSyncObjects(syncObjectsNumber),
	m_height(0),
	m_syncObjects(new CollisionEvent[m_numberOfSyncObjects]),
	m_rangeStarts(new int[m_numberOfSyncObjects]),
	m_rangeEnds(new int[m_numberOfSyncObjects]),
	m_collisionFinishedRows(NULL),
	m_streamingFinishedRows(NULL),
	m_streamingReadyRows(NULL),
	m_clearRowFlags(NULL)
{
}

EventDispatcher::~EventDispatcher()
{
	delete[] m_syncObjects;
	delete[] m_rangeStarts;
	delete[] m_rangeEnds;
	delete[] m_collisionFinishedRows;
}

void EventDispatcher::init(int height, bool* readyRows, bool* finishedRows, bool* clearRowFlags)
{
	m_streamingReadyRows = readyRows;
	m_streamingFinishedRows = finishedRows;
	m_clearRowFlags = clearRowFlags;
	m_height = height;
	m_collisionFinishedRows = new bool[m_height];

	for (int i = 0; i < m_height; i++)
	{
		m_collisionFinishedRows[i] = m_clearRowFlags[i];
	}
}

void EventDispatcher::bindEvents(SPEvent* events)
{
	for (int i = 0; i < m_numberOfSyncObjects; i++)
	{
		m_syncObjects[i].setEvent(events + i);
	}
}

void EventDispatcher::bindRanges(SPADWalkLatticeSyncParams*& params)
{
	for (int i = 0; i < m_numberOfSyncObjects; i++)
	{
		m_rangeStarts[i] = params[i].startRange;
		m_rangeEnds[i] = params[i].endRange;
		(*(params + i)).syncEvent = (m_syncObjects + i);
	}
}

void EventDispatcher::clearReadyRows()
{
	for (int i = 0; i < m_height; i++)
	{
		m_collisionFinishedRows[i] = m_clearRowFlags[i];
	}
}

bool EventDispatcher::checkCollisionFinishedRow(int rowNumber)
{
	return m_collisionFinishedRows[rowNumber];
}

}    // namespace SPhysics
