/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * TODO
 * @file   BouncebackDemon.cpp
 * @brief
 * @author Author()
 */

#include "SPADBouncebackDemon.h"

namespace SPhysics
{

void BouncebackDemon::assignAirViscosity(float aViscosity)
{
	mTransferringCoefficient = aViscosity;
}

}    // namespace SPhysics