/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   Brush.h
 * @brief  Brush class.
 * @author Author (o.snyezhko@samsung.com)
 */

#ifndef BRUSH_H_FAA7988FA0AA492A913433B79A1E5C7B
#define BRUSH_H_FAA7988FA0AA492A913433B79A1E5C7B

#include "AerodynamicsForceTool.h"
#include "SPLog.h"
#include <gtx/transform.hpp>
#include "SPADSpineNode.h"
#include "SPSinCosTable.h"
#include "SPNonCopyable.h"

#include <iostream>

namespace SPhysics
{

/**
 * additional math constants
 */
class SpineNode;

/**
 * struct Point with some members
 */
struct Point
{
	glm::vec3 mPoint;/**<coordinate x,y,z*/
	glm::vec2 mV;/**<vector from old point*/
};

/**
 * struct Range with min and max values
 */
struct Range
{
	float mMin;    /// min value
	float mMax;    /// max value
	inline void reset();
	inline void addValue(float value);
};

struct RangeMap : NonCopyable
{
	RangeMap();
	~RangeMap();
	void init(int aWidth, int aHeight);
	void reset();
	inline void setRange(glm::vec3 aP1, glm::vec3 aP2);
	Range* mColumns;
	Range* mRows;
	int mWidth;
	int mHeight;
};
/**
 * Class Brush
 */
const float m_pi = glm::pi<float>();
const float m_pi_2 = m_pi * 0.5f;
const float m_1_pi = 1 / m_pi;
const float mRadToDegree = 180 / m_pi;
class Brush: public ForceTool, NonCopyable
{
public:
	/**
	 * Constructor.
	 *
	 * @param aSteps total nodes number - 4 for brush simulation
	 */
	Brush(int aSteps);
	/**
	 * Destructor.
	 */
	virtual ~Brush();

	//===================set brush parametres========================
	/**
	 * set phi to inverse
	 * @param aKPhi1 phi to inverse
	 */
	void setPhiCoefficient1(float aPhiCoefficient1);
	/**
	 * set limit phi
	 * @param aKPhi1 limit phi
	 */
	void setPhiCoefficient2(float aPhiCoefficient2);
	/**
	 * set coefficient of phi bend behavior
	 * @param aKPhi1 coefficient of phi bend behavior
	 */
	void setPhiBehavior(float aPhiBehavior);
	/**
	 * set coefficient of bend behavior
	 * @param aKPhi1 coefficient of bend behavior
	 */
	void setBendBehavior(float aBendBehavior);    // bend behavior
	/**
	 * set bend coefficient
	 * @param aKPhi1 bend coefficient
	 */
	void setBendCoefficient(float aBendCoefficient);
	/**
	 * set ellipse deformation coefficient
	 * @param aKEllipseDef ellipse deformation coefficient
	 */
	void setEllipseDeformationCoefficient(float aEllipseDeformationCoefficient);
	/**
	 *	set angle Phi
	 * @param aPhi angle Phi
	 */
	void setPhi(float aPhi);
	/**
	 *	set angle Teta
	 * @param aTeta angle Teta
	 */
	void setTeta(float aTeta);

	//===================get brush parametres========================
	/**
	 * get phi to inverse
	 * @return phi to inverse
	 */
	float getPhiCoefficient1() const;
	/**
	 * get limit phi
	 * @return limit phi
	 */
	float getPhiCoefficient2() const;
	/**
	 * get coefficient of phi bend behavior
	 * @return coefficient of phi bend behavior
	 */
	float getPhiBehavior() const;
	/**
	 * get coefficient of bend behavior
	 * @return coefficient of bend behavior
	 */
	float getBendBehavior() const;
	/**
	 * get bend coefficient
	 * @return bend coefficient
	 */
	float getBendCoefficient() const;
	/**
	 * get ellipse deformation coefficient
	 * @return ellipse deformation coefficient
	 */
	float getEllipseDeformationCoefficient() const;
	/**
	 *	get angle Phi
	 * @return angle Phi
	 */
	float getPhi() const;
	/**
	 *	get angle Teta
	 * @return angle Teta
	 */
	float getTeta() const;
	/**
	 *	set scale of radiuses
	 * @param aScale scale of radiuses
	 */
	virtual void setScaleWidth(float aScale);
	/**
	 *	set scale of length
	 * @param aScale scale of length
	 */
	virtual void setScaleLength(float aScale);
	/**
	 *	set Brush size
	 * @param aScale scale of size
	 */
	virtual void setScaleSize(float aScale);

	/**
	 *	draw nodes
	 */
	void doDraw();
	/**
	 * draw force map for adding velocities and ink to each cell
	 */
	void drawForce();
	/**
	 * draw force map for adding velocities and ink to each cell during touch down
	 */
	void drawForceOnTouchDown();
	/**
	 *	Equillibrium brush
	 */
	void equillibrium();
	/**
	 *	TouchDown method
	 * @param aX x position
	 * @param aY y position
	 * @param aZ z position/pressure(0..1)
	 */
	virtual void onTouchDown(float aX, float aY, float aZ);
	/**
	 *	TouchUp method
	 * @param aX x position
	 * @param aY y position
	 * @param aZ z position/pressure(0..1)
	 */
	virtual void onTouchUp(float aX, float aY, float aZ);
	/**
	 *	TouchMove method
	 * @param aX x position
	 * @param aY y position
	 * @param aZ z position/pressure(0..1)
	 */
	virtual void onTouchMove(float aX, float aY, float aZ);

	void setForceMap(ForceMap* aForceMap);

private:
	/**
	 * build nodes by Hermite spline
	 */
	inline void preparePointsByHermitSpline();

	/**
	 * create translated matrix by position, angles Phi and Teta
	 */
	inline glm::mat4x4 translatePoint(glm::vec3 aPos, float aPhi, float aTeta);

	/**
	 * magic function
	 * 		2 * (aTeta^2 + aC)
	 *    --------------------   -  1
	 *  	2 *  aTeta^2 + aC
	 * @param aTeta parameter of function
	 * @param aC parameter of function
	 * @return result of function
	 */
	inline float function(float aTeta, float aC);
	inline void fillSpot(Point* points, int startId);

	SpineNode* mRoot;/**< pointer to a root Node of brush */
	SpineNode* mTop; /**< pointer to a top Node of brush */
	glm::vec3 mCurrTop;/**< current brush top position */
	glm::vec3 mOldTop;/**< old brush top position */
	glm::vec3 mMiddle;/**< current brush middle position */
	float mTotalLength; /**< total length */
	float mFirstPartLength;/**< first part length */
	int mSign;/**< sign to inverse Teta */
	bool mInverse;/**< flag to inverse bending behavior */
	float mPhi; /**< Phi angle in radian */
	float mTeta;/**< Teta angle in radian */
	Point* mOldPoints; /**< old array of points to build spot of ink */
	Point* mNewPoints;/**< new array of points to build spot of ink */
	int mPonintsCount;/**< total points array's size */

	int mStartID; /**< start id of tatal point array to build spot of ink */
	int mOldStartID;/**< old start id of tatal point array to build spot of ink */

	float mPhiCoefficient1; /**<phi bending to inverse*/
	float mPhiCoefficient2; /**<max phi bending*/
	float mPhiBehavior; /**<phi behavior*/
	float mBendBehavior; /**< bend behavior >0.1*/
	float mBendCoefficient; /**<bend coefficient >0.1*/
	float mEllipseDeformationCoefficient; /**< bending during ellipse's deformation (less than 0.1 but not zero)*/
	float mFrictionCoefficient;    // friction
	float mDeformationCoefficient;    //  coefficient of deformation

	glm::vec2 mCentre; /**< position of the center of circuit*/

	float* mH00;/**< parametres for Hermire spline*/
	float* mH10;/**< parametres for Hermire spline*/
	float* mH01;/**< parametres for Hermire spline*/
	float* mH11;/**< parametres for Hermire spline*/
	float mCurrentHeight;    // Current height (0 .. 1)
	float mMinHeigth;    // Minimum height (0 .. 1)

	static SPhysics::SinCosTable<8192> tableSin; /**< table of sin/cos to get sin/cos*/
	RangeMap mRangeMap;
};

}    // namespace SPhysics

#include "SPADBrush.inl"

#endif /* _BRUSH_H_ */

