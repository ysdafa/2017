/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * TODO
 * @file   InitialBoundariesDemon.h
 * @brief
 * @author Author()
 */

#ifndef INITIALBOUNDARIESDEMON_H_65634175149146FCA4107ECB648F6FE7
#define INITIALBOUNDARIESDEMON_H_65634175149146FCA4107ECB648F6FE7

#include "SPADCellDemon.h"
#include "SPADCellObject.h"

namespace SPhysics
{

/**
 * @class InitialBoundariesDemon
 * @brief class handling initial boundaries setting in the lattice
 */
class InitialBoundariesDemon: public CellDemon<CellObject>
{
public:
	/**
	 * @brief make a cell solid
	 * @param aCellObject           the cell to be set solid
	 * @param aX                    the x coordinate of the cell in the lattice
	 * @param aY                    the y coordinate of the cell in the lattice
	 */
	inline void handle(CellObject* aCellObject, int aX, int aY, int* aIndexPtr);

	void init(int width, int height, int depth);

	int mWidth;
	int mHeight;
	int mDepth;
};

}    // namespace SPhysics

#include "SPADInitialBoundariesDemon.inl"

#endif /* _INITIALBOUNDARIESDEMON_H_ */
