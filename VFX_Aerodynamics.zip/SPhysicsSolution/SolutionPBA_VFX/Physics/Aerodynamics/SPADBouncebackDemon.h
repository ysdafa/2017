/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * TODO
 * @file   BouncebackDemon.h
 * @brief
 * @author Author()
 */

#ifndef BOUNCEBACKDEMON_H_7360513C077B43DC95C332B4664232F5
#define BOUNCEBACKDEMON_H_7360513C077B43DC95C332B4664232F5

#include "SPADCellDemon.h"
#include "SPADCellObject.h"

#include <cmath>

namespace SPhysics
{

/**
 * @class BouncebackDemon
 * @brief class handling redistribution of flow toward border
 */
class BouncebackDemon: public CellDemon<CellObject>
{
public:

	/**
	 * Constructor.
	 */
	inline BouncebackDemon();

	/**
	 * @brief redistribution of flow toward border
	 * @param aCellObject       reference to a near-border cell
	 * @param ax                x coordinate of the cell in the lattice
	 * @param aY                y coordinate of the cell in the lattice
	 * @param aDirection        direction toward the border
	 */
	inline void handle(CellObject* aCellObject, int ax, int aY, int aDirection, int* aIndexPtr);
	/**
	 * @brief assigning new viscosity parameter
	 * @param aViscosity
	 */
	void assignAirViscosity(float aViscosity);
private:
	/// portion of flow to be redistributed to other directions
	float mTransferringCoefficient;
};

}    // namespace SPhysics

#include "SPADBouncebackDemon.inl"
#endif // _BOUNCEBACKDEMON_H_
