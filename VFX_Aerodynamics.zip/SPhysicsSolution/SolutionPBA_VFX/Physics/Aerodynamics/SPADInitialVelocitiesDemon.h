/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * TODO
 * @file   InitialVelocitiesDemon.h
 * @brief
 * @author Author()
 */

#ifndef INITIALVELOCITIESDEMON_H_1899185E566E4FE5A9438D5729766F96
#define INITIALVELOCITIESDEMON_H_1899185E566E4FE5A9438D5729766F96

#include "SPADCellDemon.h"
#include "SPADCellObject.h"

namespace SPhysics
{

/**
 * @class InitialVelocitiesDemon
 * @brief class, performing initialization of the lattice cells
 */
class InitialVelocitiesDemon: public CellDemon<CellObject>
{
public:
	/**
	 * @brief default constructor
	 */
	InitialVelocitiesDemon();
	/**
	 * @brief initialize a cell
	 * @param aCellObject       the cell to initialize
	 * @param aX                x coordinate of the cell in the lattice
	 * @param aY                y coordinate of the cell in the lattice
	 */
	inline void handle(CellObject* aCellObject, int aX, int aY, int* aIndexPtr);
	/**
	 * @brief initialize parameters
	 * @param aVelocityToAssign     velocity to initially assign to every cell in every direction
	 * @param aForceCoefficient     coefficient for friction force calculation
	 */
	void init(float aVelocityToAssign, float aForceCoefficient);

private:
	/// velocity to initially assign to every cell in every direction
	float mVelocityToAssign;
	/// coefficient for friction force calculation
	float mForceCoefficient;
};

}    // namespace SPhysics

#include "SPADInitialVelocitiesDemon.inl"
#endif /* _INITIALVELOCITIESDEMON_H_ */
