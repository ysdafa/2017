/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * TODO
 * @file   CollisionDemon.h
 * @brief
 * @author Author()
 */

#ifndef COLLISIONDEMON_H_303E1582A1234D0DA25691EB4D1ADB27
#define COLLISIONDEMON_H_303E1582A1234D0DA25691EB4D1ADB27

#include "SPADCellDemon.h"
#include "SPADCellObject.h"

namespace SPhysics
{

/**
 * @class CollisionDemon
 * @brief class handling collision step and pigment mixing after streaming step
 */
class CollisionDemon: public CellDemon<CellObject>
{
public:

	/**
	 * Constructor.
	 */
	inline CollisionDemon();

	/**
	 * @brief handle collision and pigment mixing in a cell
	 * @param aCellObject       the given cell
	 * @param aX                cell x coordinate in the lattice
	 * @param aY                cell y coordinate in the lattice
	 */
	inline void handle(CellObject* aCellObject, int aX, int aY, int* aIndexPtr);
	/**
	 * @brief initialization of the class instance
	 * @param aDispersionCurvature                  curvature of the gaussian used for flow dispersion
	 * @param aForceCoefficient                     coefficient defining how strongly the friction force influences the flow
	 * @param aMaxVelocityInverse                   normalization coefficient for flow dispersion
	 */
	void init(float aDispersionCurvature, float aForceCoefficient, float aMaxVelocityInverse);
	/**
	 * @brief getting dispersion curvature
	 */
	float getCurvature() const;
	/**
	 * @brief setting new dispersion curvature
	 * @param curvature         new curvature value
	 */
	void setCurvature(float curvature);

	/**
	 * @brief getting force coefficient
	 */
	float getForceCoefficient() const;

	/**
	 * @brief setting new force coefficient
	 * @param coefficient         new force coefficient
	 */
	void setForceCoefficient(float coefficient);

	bool mStopIdle;
private:
	/// curvature of the gaussian used for flow dispersion
	float mDispersionCurvature;
	/// coefficient defining how strongly the friction forces influence the flow
	float mForceCoefficient;
	/// normalization coefficient for flow dispersion
	float mMaxVelocityInverse;
};

}    // namespace SPhysics

#include "SPADCollisionDemon.inl"

#endif /* _COLLISIONDEMON_H_ */
