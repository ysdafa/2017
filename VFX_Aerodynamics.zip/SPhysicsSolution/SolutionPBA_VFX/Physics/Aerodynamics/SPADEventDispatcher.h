#ifndef EVENTDISPATCHER_H_A8D87A906627465F9378AE019D22894C
#define EVENTDISPATCHER_H_A8D87A906627465F9378AE019D22894C

#include "SPEvent.h"

namespace SPhysics
{

/**
 * @class CollisionEvent
 * @brief wrapper class for an event
 */
class CollisionEvent
{
public:
	/**
	 * @brief default constructor
	 */
	CollisionEvent() :
		m_event(NULL)
	{
	}
	/**
	 * @brief destructor
	 */
	~CollisionEvent()
	{
	}
	/**
	 * @brief binding an event to wrap
	 * @param a_event       the event to bind to this instance
	 */
	void setEvent(SPEvent* a_event)
	{
		m_event = a_event;
	}
	/**
	 * @brief delegating wait() message to the wrapped event
	 */
	void wait()
	{
		m_event->wait();
	}
	/**
	 * @brief delegating signal() message to the wrapped event
	 */
	void signal()
	{
		m_event->signal();
	}
	/**
	 * @brief delegating reset() message to the wrapped event
	 */
	void reset()
	{
		m_event->reset();
	}
private:
	/// pointer to the wrapped event
	SPEvent* m_event;
};

struct SPADWalkLatticeSyncParams;

class EventDispatcher: NonCopyable
{
public:
	EventDispatcher();
	EventDispatcher(int nubmerOfSyncObjects);
	~EventDispatcher();
	void init(int height, bool* readyRows, bool* finishedRows, bool* clearRowFlags);
	void bindEvents(SPEvent* events);
	void bindRanges(SPADWalkLatticeSyncParams*& params);
	inline void signal(int rowNumber);
	void clearReadyRows();
	bool checkCollisionFinishedRow(int rowNumber);
private:
	int m_numberOfSyncObjects;
	int m_height;
	CollisionEvent* m_syncObjects;
	int* m_rangeStarts;
	int* m_rangeEnds;
	bool* m_collisionFinishedRows;
	bool* m_streamingFinishedRows;
	bool* m_streamingReadyRows;
	bool* m_clearRowFlags;
};

struct SPADWalkLatticeSyncParams
{
	int rangeNumber;
	int startRange;
	int endRange;
	CollisionEvent* syncEvent;
};

struct SPADWalkLatticeRangeParams
{
	int startRange;
	int endRange;
	EventDispatcher* eventDispatcher;
};

}    // namespace SPhysics

#include "SPADEventDispatcher.inl"

#endif /* _EVENTDISPATCHER_H_ */
