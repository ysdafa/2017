/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * TODO
 * @file   CellObject.cpp
 * @brief  Brush simulation
 * @author Author ()
 */

#include "SPADLattice.h"
#include "SPADCellObject.h"
#include "AerodynamicsForceTool.h"

namespace SPhysics
{

const float gSPADex[gSPADneighbor_count] =
{ -glm::one_over_root_two<float>(), 0.0f, glm::one_over_root_two<float>(), 1.0f, -1.0f, -glm::one_over_root_two<float>(), 0.0f, glm::one_over_root_two<float>() };

const float gSPADey[gSPADneighbor_count] =
{ -glm::one_over_root_two<float>(), -1.0f, -glm::one_over_root_two<float>(), 0.0f, 0.0f, glm::one_over_root_two<float>(), 1.0f, glm::one_over_root_two<float>() };

CellObject::CellObject() :
	mxVelocity(0.0f),
	myVelocity(0.0f),
	mHeight(0.0f),
	mMass(0.0f),
	mxForce(0.0f),
	myForce(0.0f),
	mForce(NULL),
	mIsSolid(false)
{
	for (int i = 0; i < gSPADneighbor_count; i++)
	{
		mVelocities[i] = 0.0f;
		mTempVelocities[i] = 0.0f;
	}
}

CellObject::~CellObject()
{
}

void CellObject::SetSolid(bool aIsSolid)
{
	mIsSolid = aIsSolid;
}

void CellObject::assignNewVelocity(float aNewVelocityX, float aNewVelocityY)
{
	float coefficients[gSPADneighbor_count] =
	{ 0 };
	float coeffsSum = 0.0f;
	float velocitySum = 0.0f;

	for (int i = 0; i < gSPADneighbor_count; i++)
	{
		float thisVectorX = gSPADex[i];
		float thisVectorY = gSPADey[i];
		float vectorSumX = thisVectorX - aNewVelocityX;
		float vectorSumY = thisVectorY - aNewVelocityY;
		float vectorSumSquared = vectorSumX * vectorSumX + vectorSumY * vectorSumY;
		coefficients[i] = GAUSSIAN_APPROXIMATION(vectorSumSquared, gSPADcurvature);
		coeffsSum += coefficients[i];
		velocitySum += mVelocities[i];
	}

	float coeffsSumInv = 1.0f / coeffsSum;

	for (int i = 0; i < gSPADneighbor_count; i++)
	{
		coefficients[i] *= coeffsSumInv;
		mVelocities[i] = velocitySum * coefficients[i];
	}
}

void CellObject::addVelocity(float aVelocityX, float aVelocityY)
{
	float coefficients[gSPADneighbor_count];
	float velocitySum = 0.0f;
	float newVelocityX = aVelocityX + mxVelocity;
	float newVelocityY = aVelocityY + myVelocity;
	float coeffsSumInv = 1.0f;
#ifdef SKIP_SOLVE

	if (fabs(newVelocityX) > l_draftCoeff || fabs(newVelocityY) > l_draftCoeff)
	{
#endif
		float coeffsSum = 0.0f;

		for (int i = 0; i < gSPADneighbor_count; i++)
		{
			float vectorSumX = gSPADex[i] - newVelocityX;
			float vectorSumY = gSPADey[i] - newVelocityY;
			float vectorSumSquared = vectorSumX * vectorSumX + vectorSumY * vectorSumY;
			coefficients[i] = GAUSSIAN_APPROXIMATION(vectorSumSquared, gSPADcurvature);
			coeffsSum += coefficients[i];
			velocitySum += mVelocities[i];
		}

		if (coeffsSum > 0.0001f)
		{
			coeffsSumInv = 1.0f / coeffsSum;
		}

#ifdef SKIP_SOLVE
	}
	else
	{
		for (int i = 0; i < gSPADneighbor_count; i++)
		{
			coefficients[i] = gSPADneighbor_count_inverse;
			velocitySum += mVelocities[i];
		}
	}

#endif
	mMass = 0.0f;
	mxVelocity = 0.0f;
	myVelocity = 0.0f;

	for (int i = 0; i < gSPADneighbor_count; i++)
	{
		mVelocities[i] = velocitySum * coefficients[i] * coeffsSumInv;
		mMass += mVelocities[i];
		mxVelocity += mVelocities[i] * gSPADex[i];
		myVelocity += mVelocities[i] * gSPADey[i];
	}
}

void CellObject::addVelocityForced(float aVelocityX, float aVelocityY)
{
	float coefficients[gSPADneighbor_count] =
	{ 0 };
	float coeffsSum = 0.0f;
	float velocitySum = 0.0f;
	float newVelocityX = aVelocityX + mxVelocity;
	float newVelocityY = aVelocityY + myVelocity;

	for (int i = 0; i < gSPADneighbor_count; i++)
	{
		float thisVectorX = gSPADex[i];
		float thisVectorY = gSPADey[i];
		float vectorSumX = thisVectorX - newVelocityX;
		float vectorSumY = thisVectorY - newVelocityY;
		float vectorSumSquared = vectorSumX * vectorSumX + vectorSumY * vectorSumY;
		coefficients[i] = GAUSSIAN_APPROXIMATION(vectorSumSquared, gSPADcurvature);
		coeffsSum += coefficients[i];
		velocitySum += mVelocities[i];
	}

	float coeffsSumInv = 1.0f / coeffsSum;

	for (int i = 0; i < gSPADneighbor_count; i++)
	{
		coefficients[i] *= coeffsSumInv;
		mVelocities[i] = velocitySum * coefficients[i];
		mxVelocity += mVelocities[i] * gSPADex[i];
		myVelocity += mVelocities[i] * gSPADey[i];
	}

	float newVelocity = sqrtf(newVelocityX * newVelocityX + newVelocityY * newVelocityY);
	float currentVelocity = sqrtf(mxVelocity * mxVelocity + myVelocity * myVelocity);
	float ratio = 1.0f;

	if (currentVelocity > 0.0001f)
	{
		ratio = newVelocity / currentVelocity;
	}

	if (ratio > 1.0f)
	{
		for (int i = 0; i < gSPADneighbor_count; i++)
		{
			mVelocities[i] *= ratio;
		}
	}
}

void CellObject::resetCell()
{
}

}    // namespace SPhysics
