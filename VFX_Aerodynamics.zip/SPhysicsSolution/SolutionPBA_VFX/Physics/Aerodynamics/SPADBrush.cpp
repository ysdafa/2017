/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   Brush.cpp
 * @brief  Brush class.
 * @author Author (o.snyezhko@samsung.com)
 */

#include "SPADBrush.h"
#include "SPADController.h"

#include <math.h>
#include <time.h>

namespace SPhysics
{

const float m_2pi = 2 * m_pi;
SPhysics::SinCosTable<8192> Brush::tableSin;

Brush::Brush(int aStep) :
	ForceTool(),
	mRoot(NULL),
	mTop(NULL),
	mTotalLength(0.0f),
	mFirstPartLength(0.0f),
	mSign(1),
	mInverse(false),
	mPhi(0),
	mTeta(/*m_pi*0.25*/0),
	mOldPoints(NULL),
	mNewPoints(NULL),
	mPonintsCount(0),
	mStartID(0),
	mOldStartID(0),
	mFrictionCoefficient(gSPADk_friction),
	mDeformationCoefficient(0.0f),
	mCurrentHeight(0.0f),
	mMinHeigth(l_min_height)
{
	mVelocityMul = l_velocityMul;
	mPonintsCount = (gSPADl_steps << 1) * 3;
	float shift = 2.0f;
	int step2 = (aStep + 1) * (aStep + 1);
	step2 -= aStep * aStep;
	mTotalLength = 0;
	float rootRadius = float(aStep) - shift;
	float invRadius = 1 / rootRadius;
	mRoot = new SpineNode(float(step2), rootRadius, 1.0f);
	SpineNode* node = mRoot;

	for (float i = float(aStep); i >= shift; i--)
	{
		float Radius = (i - shift) + 0.1f;
		float length = ((i * i) - (i - 1) * (i - 1));
		node->setDownNode(new SpineNode(length, Radius, (Radius * (invRadius))));
		node->getDownNode()->setUpNode(node);
		node = node->getDownNode();
		mTotalLength += length;
	}

	mTop = node;
	mH00 = new float[gSPADl_steps];
	mH10 = new float[gSPADl_steps];
	mH01 = new float[gSPADl_steps];
	mH11 = new float[gSPADl_steps];

	for (int i = 0; i < gSPADl_steps; i++)
	{
		float j = float(i) * gSPADl_dt;
		float j2 = j * j;
		float j3 = j2 * j;
		mH00[i] = 2 * j3 - 3 * j2 + 1;
		mH10[i] = j3 - 2 * j2 + j;
		mH01[i] = -2 * j3 + 3 * j2;
		mH11[i] = j3 - j2;
	}

	mNewPoints = new Point[mPonintsCount];
	mOldPoints = new Point[mPonintsCount];
	/// ===== default parametr=======
	mPhiCoefficient1 = 0.8f;
	mPhiCoefficient2 = 0.6f;
	mPhiBehavior = 0.2f;
	mBendBehavior = 0.3f;
	mBendCoefficient = 4.0f;
	mEllipseDeformationCoefficient = 0.05f;
	mStartID = -1;
}

Brush::~Brush()
{
	delete mRoot;
	delete[] mOldPoints;
	delete[] mNewPoints;
	delete[] mH00;
	delete[] mH10;
	delete[] mH01;
	delete[] mH11;
}

//===================set brush parametres========================
void Brush::setPhiCoefficient1(float aPhiCoefficient1)    // phi to inverse
{
	mPhiCoefficient1 = aPhiCoefficient1;
}
void Brush::setPhiCoefficient2(float aPhiCoefficient2)    // limit phi
{
	mPhiCoefficient2 = aPhiCoefficient2;
}
void Brush::setPhiBehavior(float aPhiBehavior)    // phi bend behavior
{
	mPhiBehavior = aPhiBehavior;
}
void Brush::setBendBehavior(float aBendBehavior)    // bend behavior
{
	mBendBehavior = aBendBehavior;
}
void Brush::setBendCoefficient(float aBendCoefficient)    // bend coefficient
{
	mBendCoefficient = aBendCoefficient;
}
void Brush::setEllipseDeformationCoefficient(float aEllipseDeformationCoefficient)    // ellipse deformation
{
	mEllipseDeformationCoefficient = aEllipseDeformationCoefficient;
}
void Brush::setPhi(float aPhi)    // Phi
{
	mPhi = aPhi;
}
void Brush::setTeta(float aTeta)    //Teta
{
	mTeta = aTeta;
}

//===================get brush parametres========================
float Brush::getPhiCoefficient1() const
{
	return mPhiCoefficient1;
}
float Brush::getPhiCoefficient2() const
{
	return mPhiCoefficient2;
}
float Brush::getPhiBehavior() const
{
	return mPhiBehavior;
}
float Brush::getBendBehavior() const
{
	return mBendBehavior;
}
float Brush::getBendCoefficient() const
{
	return mBendCoefficient;
}
float Brush::getEllipseDeformationCoefficient() const
{
	return mEllipseDeformationCoefficient;
}
float Brush::getPhi() const
{
	return mPhi;
}
float Brush::getTeta() const
{
	return mTeta;
}

void Brush::setScaleWidth(float aScale)
{
	float tempScale = aScale / mScaleWidth;
	mScaleWidth = aScale;
	SpineNode* node = mRoot;

	while (node)
	{
		node->multiplyRadius(tempScale);
		node = node->getDownNode();
	}
}
void Brush::setScaleLength(float aScale)
{
	mTotalLength = 0;
	float tempScale = aScale / mScaleLength;
	mScaleLength = aScale;
	SpineNode* node = mRoot;

	while (node)
	{
		node->multiplyLength(tempScale);
		mTotalLength += node->getLength();
		node = node->getDownNode();
	}
}
void Brush::setScaleSize(float aScale)
{
	mTotalLength = 0;
	float tempScale = aScale / mScaleSize;
	mScaleSize = aScale;
	SpineNode* node = mRoot;

	while (node)
	{
		node->multiplyLength(tempScale);
		node->multiplyRadius(tempScale);
		mTotalLength += node->getLength();
		node = node->getDownNode();
	}
}
void Brush::doDraw()
{
	if (mRoot == NULL)
	{
		return;
	}

	mRangeMap.reset();
	preparePointsByHermitSpline();
	glm::vec3 shift = glm::vec3(mCentre - glm::vec2(mPos), 0);
	mCentre = glm::vec2(mPos);
	Point* nPoint = mNewPoints;
	Point* oPoint = mOldPoints;

	if (oPoint)
	{
		for (int i = 0; i < mPonintsCount; i++, nPoint++, oPoint++)
		{
			nPoint->mPoint -= shift;
			nPoint->mV = glm::vec2(nPoint->mPoint - oPoint->mPoint) * mVelocityMul;

			if (i >= mStartID)
			{
				mRangeMap.setRange(nPoint->mPoint, oPoint->mPoint);
			}
		}

		fillSpot(mNewPoints, mStartID);
		fillSpot(mOldPoints, mOldStartID);
	}
	else
	{
		for (int i = 0; i < mPonintsCount; i++, nPoint++)
		{
			nPoint->mPoint -= shift;
		}

		fillSpot(mNewPoints, mStartID);
	}

	Point* temporaryPoint = mNewPoints;
	mNewPoints = mOldPoints;
	mOldPoints = temporaryPoint;
}

void Brush::drawForceOnTouchDown()
{
	float zFromTop = mTotalLength - mPos.z;
	SpineNode* node = mTop;
	float len = 1;
	float a = 0;
	float b = 0;

	while (node)
	{
		a = node->getRadius();
		node = node->getUpNode();
		b = node->getRadius();
		len = node->getLength();

		if (zFromTop < len)
		{
			break;
		}

		zFromTop -= len;
	}

	float Radius = (zFromTop / len) * (b - a) + a + 1;
	float RadiusForVelocity = Radius + 1;
	glm::vec2 topLeft(floor(mPos.x - RadiusForVelocity), floor(mPos.y - RadiusForVelocity)),
		bottomRight(ceil(mPos.x + RadiusForVelocity), ceil(mPos.y + RadiusForVelocity));
	topLeft.x = topLeft.x < 0 ? 0 : topLeft.x;
	topLeft.y = topLeft.y < 0 ? 0 : topLeft.y;
	int width = mForceMap->getWidth();
	int height = mForceMap->getHeight();
	float squareRadius = RadiusForVelocity * RadiusForVelocity;
	bottomRight.x = bottomRight.x > float(width) ? float(width) : bottomRight.x + 1.0f;
	bottomRight.y = bottomRight.y > float(height) ? float(height) : bottomRight.y + 1.0f;

	for (int y = int(topLeft.y); y < bottomRight.y; y++)
	{
		Force* f = (*mForceMap)(int(topLeft.x), y);
		float dy = mPos.y - float(y);
		float dySquared = dy * dy;

		for (int x = int(topLeft.x); x < bottomRight.x; x++, f++)
		{
			float dx = mPos.x - float(x);
			float dxSquared = dx * dx;
			float square = squareRadius - dxSquared - dySquared;

			if (square < 0)
			{
				continue;
			}

			float l = sqrtf(dx + dy);
			l = l > 0.001f ? 1 / l : 1;
			f->mVelocity = glm::vec2(dx + float(rand() & 31) - 16.0f,
									 dy + float(rand() & 31) - 16.0f) * l * 3.0f * mVelocityMul;
		}
	}
}
void Brush::drawForce()
{
	if (mStartID < 0 || mStartID >= (mPonintsCount - 3))
	{
		return;
	}

	if (!mForceMap)
	{
		return;
	}

	int height = ForceTool::mHeight;
	int width = ForceTool::mWidth;

	for (int i = 0; i < height; i++)
	{
		if (!mForceMap->doCheckNeighbor(LEFT_NEIGHBOR_INDEX, 0, i)
			|| !mForceMap->doCheckNeighbor(RIGHT_NEIGHBOR_INDEX, 0, i))
		{
			continue;
		}

		Range& xRange = mRangeMap.mRows[i];
		float yy = float(i);
		int startX = int(xRange.mMin);
		startX = startX < 0 ? 0 : startX;
		float endX = xRange.mMax > (width - 1) ? float(width - 1) : xRange.mMax;
		Range* yRange = mRangeMap.mColumns + startX;

		for (int j = startX; j <= endX; j++, yRange++)
		{
			if (i < (int)(yRange->mMin) || i > (yRange->mMax))
			{
				continue;
			}

			float xx = float(j);
		
			Force* f1 = (*mForceMap)(j, i);
			Force* f2 = (*mForceMap)(int(i * ForceTool::mScaleXtoY), j + ForceTool::mXoZLatticeYOffset);
			Force* f3 = (*mForceMap)(width - j, i + ForceTool::mZoYLatticeYOffset);

			if (f1->mIsSolid)
			{
				continue;
			}

			glm::vec2 addVelocity;
			glm::vec2 addVelocityForxOy;
			glm::vec2 addVelocityForxOz;
			glm::vec2 addVelocityForzOy;
			float totalC(0);

			for (int m = mStartID; m < (mPonintsCount); ++m)
			{
				glm::vec2 dd;
				dd.x = mOldPoints[m].mPoint.x - xx;
				dd.y = mOldPoints[m].mPoint.y - yy;
				float length = sqrtf(dd.x * dd.x + dd.y * dd.y);
				length = length > 0.001f ? 1.f / length : 1000.f;
				totalC += length;
				addVelocity += mOldPoints[m].mV * length;
				dd.x = mNewPoints[m].mPoint.x - xx;
				dd.y = mNewPoints[m].mPoint.y - yy;
				length = sqrtf(dd.x * dd.x + dd.y * dd.y);
				length = length > 0.001f ? 1.f / length : 1000.f;
				totalC += length;
				addVelocity += mNewPoints[m].mV * length;
			}

			totalC = (totalC > 0.001f ? 1.f / totalC : 1000.f);
			addVelocityForxOy = addVelocity;
			addVelocityForxOz.x = addVelocity.y;
			addVelocityForxOz.y = addVelocity.x;
			addVelocityForzOy.x = -addVelocity.x;
			addVelocityForzOy.y = addVelocity.y;

			if (mOnlyPositive)
			{
				addVelocityForxOz.y = addVelocityForxOz.y < 0 ? 0 : addVelocityForxOz.y;
			}
			
			f1->mVelocity = addVelocityForxOy * totalC;
			f2->mVelocity = addVelocityForxOz * totalC * ForceTool::mScaleXtoY;
			f3->mVelocity = addVelocityForzOy * totalC;
		}
	}
}
void Brush::equillibrium()
{
	float cosA;
	float sinA;
	tableSin.get(mTeta, sinA, cosA);
	float z = (mTotalLength * cosA);
	float deformationCoeff = mPos.z / z;

	if (z > 0.1f && 0.9f > deformationCoeff)
	{
		float deformationCoeffSq = deformationCoeff * deformationCoeff;
		float mainTeta = acosf(mPos.z / mTotalLength);
		float deltaTeta = mInverse ? mainTeta + mTeta : mainTeta - mTeta;
		float afterMainTeta = mInverse ? mTeta - deltaTeta : deltaTeta + mTeta;
		mOldTop = mCurrTop;
		mFirstPartLength = mTotalLength * 0.5f;
		tableSin.get(afterMainTeta, sinA, cosA);
		mFirstPartLength /= cosA;
		float secondLength = mTotalLength - mFirstPartLength;
		tableSin.get(mPhi, cosA, sinA);
		float topx = mTotalLength * cosA;
		float topy = mTotalLength * sinA;
		float vectorToTopx = mCurrTop.x - mPos.x;
		float vectorToTopy = mCurrTop.y - mPos.y;
		float deltaPhiMain = 0;
		float deltaPhiSecond = 0;
		float invForCosine = sqrtf((vectorToTopx * vectorToTopx + vectorToTopy * vectorToTopy) *
								   (topx * topx + topy * topy));

		if (invForCosine > 0.01)
		{
			if (mInverse)
			{
				afterMainTeta = mTeta - deltaTeta * function(deltaTeta, mBendBehavior / (deformationCoeffSq));
				mFirstPartLength = mPos.z * (function(deformationCoeff, mBendCoefficient));
			}
			else
			{
				afterMainTeta = mTeta + deltaTeta * function(deltaTeta, mBendBehavior / (deformationCoeffSq));
				mFirstPartLength = mPos.z * (function(deformationCoeff, mBendCoefficient));
			}

			tableSin.get(afterMainTeta, sinA, cosA);
			mFirstPartLength /= cosA;
			secondLength = mTotalLength - mFirstPartLength;
			float cosineOfTop = (topx * vectorToTopx + topy * vectorToTopy) / invForCosine;
			deltaPhiMain = cosineOfTop <= 1 && cosineOfTop >= -1 ? acosf(cosineOfTop) : 0;
			float firstLimitOfPhi = m_pi * function(mTeta, mPhiCoefficient1 / (deformationCoeffSq));
			mInverse = deltaPhiMain >= firstLimitOfPhi ? true : false;
			float secondLimitOfPhi = m_pi * function(mTeta, mPhiCoefficient2 / (deformationCoeffSq));
			deltaPhiMain = mInverse ?/*dphi_main<(180-limitPhi2)?(180-limitPhi2):*/
						   deltaPhiMain :
						   deltaPhiMain > secondLimitOfPhi ? secondLimitOfPhi : deltaPhiMain;
			deltaPhiMain = (vectorToTopx * topy - vectorToTopy * topx) > 0 ? -deltaPhiMain : deltaPhiMain;
			float main_phi1 = deltaPhiMain;    //>0?180-dphi_main:-180-dphi_main:dphi_main;
			deltaPhiSecond = main_phi1 * (1.0f - function(mTeta + 0.01f, mPhiBehavior / (deformationCoeffSq)));
			deltaPhiSecond = deltaPhiMain - deltaPhiSecond;

			if (afterMainTeta < 0)
			{
				deltaPhiSecond = deltaPhiSecond < 0 ? -m_pi - deltaPhiSecond : m_pi - deltaPhiSecond;
			}
		}

		deltaPhiSecond += mPhi;
		deltaPhiMain += mPhi;
		tableSin.get(afterMainTeta, sinA, cosA);
		mMiddle.z = mPos.z - mFirstPartLength * cosA;
		float projectionLength = mFirstPartLength * sinA;
		tableSin.get(deltaPhiSecond, sinA, cosA);
		mMiddle.x = mPos.x + projectionLength * cosA;
		mMiddle.y = mPos.y + projectionLength * sinA;
		deltaPhiSecond = deltaPhiMain - deltaPhiSecond;
		float projectionLength2 = sqrtf(secondLength * secondLength - mMiddle.z * mMiddle.z);
		float phiFract(deltaPhiSecond / 3.1415926535f);
		float phiInt;
		deltaPhiSecond = 3.1415926535f * modff(phiFract, & phiInt);
		tableSin.get(deltaPhiSecond, sinA, cosA);
		float cosineOfProjection = projectionLength * sinA / projectionLength2;
		cosineOfProjection = cosineOfProjection > 1 ? 1 : cosineOfProjection < -1 ? -1 : cosineOfProjection;
		deltaPhiMain = asinf(cosineOfProjection) + deltaPhiMain;
		tableSin.get(deltaPhiMain, sinA, cosA);
		mCurrTop.x = projectionLength2 * cosA + mMiddle.x;
		mCurrTop.y = projectionLength2 * sinA + mMiddle.y;
		mCurrTop = mOldTop + (mCurrTop - mOldTop) * mFrictionCoefficient;
		mCurrTop.z = 0;
	}
	else
	{
		mInverse = false;
		float sinP;
		float cosP;
		float sinT;
		float cosT;
		tableSin.get(mPhi, sinP, cosP);
		tableSin.get(mTeta, sinT, cosT);
		mFirstPartLength = mTotalLength * 0.5f;
		glm::vec3 delta(mFirstPartLength * sinT * cosP, mFirstPartLength * sinT * sinP, -mFirstPartLength * cosT);
		mMiddle = mPos + delta;
		mOldTop = mCurrTop;
		mCurrTop = mMiddle + delta;
	}
}

void Brush::onTouchDown(float aX, float aY, float aZ)
{
	mCurrentHeight = 0.95f;
	setPos(glm::vec3(aX, aY, mTotalLength + 10));
	equillibrium();
	doDraw();
	setPos(glm::vec3(aX, aY, mTotalLength * 0.95f));
	equillibrium();
	doDraw();
	drawForceOnTouchDown();
	mForceInterface->addForceMapToLattice();
}

void Brush::onTouchUp(float aX, float aY, float aZ)
{
}

void Brush::onTouchMove(float aX, float aY, float aZ)
{
	if (mCurrentHeight > 0.94f)
	{
		float dx = aX - mPos.x;
		float dy = aY - mPos.y;

		if (fabs(dx) < 1.5f && fabs(dy) < 1.5f)
		{
			return;
		}

		if (dx < 0.0001f && dx > -0.0001f)
		{
			mPhi = dy < 0 ? m_pi_2 : -m_pi_2;
		}
		else
		{
			mPhi = atanf(dy / dx);
			mPhi = dx < 0 ? mPhi : mPhi + m_pi;
		}
	}

	glm::vec3 pos = mPos;
	float targetHeight = ((1 - aZ) * (1 - mMinHeigth) + mMinHeigth);
	glm::vec3 vec = glm::vec3(aX, aY, targetHeight * mTotalLength) - pos;
	float distToPrev = sqrtf(vec.x * vec.x + vec.y * vec.y);

	if (distToPrev < 1.0f)
	{
		return;
	}

	static float inv_step = 1 / 10.0f;
	static float inv_stepH = 1 / 0.2f;
	int stepsLength = int(ceil(distToPrev * inv_step));
	float deltaH = mCurrentHeight - targetHeight;
	mCurrentHeight = targetHeight;
	int stepsHeight = int(ceil(deltaH * inv_stepH));
	int steps = stepsLength > stepsHeight ? stepsLength : stepsHeight;
//	id = 0;
	vec /= (float)steps;

	for (int i = 0; i < steps; i++)
	{
		pos += vec;
		setPos(pos);
		equillibrium();
		doDraw();
		drawForce();
		drawForceRemain();
	}

	mForceInterface->addForceMapToLattice();
}

void Brush::setForceMap(ForceMap* aForceMap)
{
	mForceMap = aForceMap;
	mRangeMap.init(ForceTool::mWidth, ForceTool::mHeight);
}

RangeMap::RangeMap() :
	mColumns(NULL),
	mRows(NULL),
	mWidth(0),
	mHeight(0)
{
}
RangeMap::~RangeMap()
{
	delete[] mColumns;
	delete[] mRows;
}

void RangeMap::init(int aWidth, int aHeight)
{
	if (mWidth != aWidth)
	{
		delete[] mColumns;
		mColumns = new Range[aWidth];
		mWidth = aWidth;
	}

	if (mHeight != aHeight)
	{
		delete[] mRows;
		mRows = new Range[aHeight];
		mHeight = aHeight;
	}
}
void RangeMap::reset()
{
	for (Range* pRange = mColumns, *pEndRange = mColumns + mWidth; pRange < pEndRange; pRange++->reset())
		;

	for (Range* pRange = mRows, *pEndRange = mRows + mHeight; pRange < pEndRange; pRange++->reset())
		;
}

}    // namespace SPhysics
