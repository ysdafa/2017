/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * TODO
 * @file   InitialVelocitiesDemon.cpp
 * @brief
 * @author Author()
 */

#include "SPADInitialVelocitiesDemon.h"

namespace SPhysics
{

InitialVelocitiesDemon::InitialVelocitiesDemon() :
	mVelocityToAssign(0.0f),
	mForceCoefficient(0.0f)
{
}

void InitialVelocitiesDemon::init(float aVelocityToAssign, float aForceCoefficient)
{
	mVelocityToAssign = aVelocityToAssign;
	mForceCoefficient = aForceCoefficient;
}

}    // namespace SPhysics