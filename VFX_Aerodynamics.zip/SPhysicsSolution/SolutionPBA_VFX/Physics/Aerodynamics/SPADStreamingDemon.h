/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * TODO
 * @file   StreamingDemon.h
 * @brief
 * @author Author()
 */

#ifndef STREAMINGDEMON_H_1CE63A2A869B419EA9B4ADBF824581A8
#define STREAMINGDEMON_H_1CE63A2A869B419EA9B4ADBF824581A8

#include "SPADCellDemon.h"
#include "SPADCellObject.h"
#include "SPADBouncebackDemon.h"

namespace SPhysics
{

/**
 * @class StreamingDemon
 * @brief class, responsible for streaming simulation
 */
class StreamingDemon: public CellDemon<CellObject>
{
public:
	/**
	 * @brief default constructor
	 */
	StreamingDemon();
	/**
	 * @brief handle streaming simulation in a lattice cell
	 * @param aCellObject           the lattice cell
	 * @param aX                    the x coordinate of the cell in the lattice
	 * @param aY                    the y coordinate of the cell in the lattice
	 */
	inline void handle(CellObject* aCellObject, int aX, int aY, int* aIndexPtr);
	/**
	 * @brief parameter initialization
	 * @param aTransferringCoefficient          portion of the flow to be transferred to the neighboring cells
	 * @param aBoundaryDemon                    pointer to a demon handling streaming near borders
	 */
	void init(float aTransferringCoefficient, BouncebackDemon* aBoundaryDemon);

	void assignAirViscosity(float viscosity);

private:
	/// portion of the flow to be transferred to the neighboring cells (water viscosity)
	float mTransferringCoefficient;

	/// pointer to a demon, handling streaming near borders
	BouncebackDemon* mBoundaryDemon;
};

}    // namespace SPhysics

#include "SPADStreamingDemon.inl"

#endif /* _STREAMINGDEMON_H_ */
