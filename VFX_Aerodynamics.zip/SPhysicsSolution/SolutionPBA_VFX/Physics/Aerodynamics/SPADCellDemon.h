/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * TODO
 * @file   CellDemon.h
 * @brief
 * @author Author ()
 */

#ifndef CELLDEMON_H_FD557D3A7B7B4E418530168F97D2AB70
#define CELLDEMON_H_FD557D3A7B7B4E418530168F97D2AB70

#include "SPADEventDispatcher.h"
#include "SPADLattice.h"
#include "SPADCellObject.h"
#include <glm.hpp>
#include <gtc/constants.hpp>
#include <string.h>

namespace SPhysics
{

/**
 * TODO
 */
template<typename TCellObject>
class CellDemon
{
public:
	/**
	 * TODO
	 */
	CellDemon();
	/**
	 * TODO
	 */
	~CellDemon();
	/**
	 * TODO
	 * @param aCapillarityCell
	 * @param aX
	 * @param aY
	 */
	void handle(TCellObject& aCapillarityCell, int aX, int aY);
	/**
	 * TODO
	 */
	void beforeWalk();
	/**
	 * TODO
	 */
	void afterWalk();
	/**
	 * TODO
	 * @param aLattice
	 */
	void bindLattice(Lattice<TCellObject>& aLattice);
	/**
	 * TODO
	 * @param aDt
	 */
	void setDt(float aDt);
	/**
	 * TODO
	 * @return
	 */
	float dt() const;

protected:
	Lattice<TCellObject>* mLattice;
	float mDt;
};

}    // namespace SPhysics

#include "SPADCellDemon.inl"

#endif // _CELLDEMON_H_
