#include "SPADParticleSimulation.h"
#include "SPADCellObject.h"
#include <iostream>
#include <algorithm>
#include "SPLog.h"

namespace SPhysics
{

Cell::Cell() :
	mRootParticle(NULL),
	mTailParticle(NULL),
	mX(0),
	mY(0),
	mZ(0)
{
}
Cell::Cell(int x, int y, int z) :
	mRootParticle(NULL),
	mTailParticle(NULL),
	mX(x),
	mY(y),
	mZ(z)
{
}

Particle::Particle(float aRadius, int aID) :
	mPosition(NULL),
	mNext(NULL),
	mPrevious(NULL),
	mRadius(aRadius),
	mCell(NULL),
	mID(aID)
{
}
void ParticleSimulation::createParticles(int aCount)
{
	mParticles.resize(aCount, Particle(c_particleRadius, -1));
	mParticleVertex.resize(aCount);
	mParticleTexOffset.resize(aCount);
	std::vector<Particle>::iterator particle = mParticles.begin();
	int i = 0;
	int frameCount(static_cast<int>((mAnimationTextureSize.y / mFrameSize.y) + 0.5f));

	for (std::vector<glm::vec3>::iterator vertIterator = mParticleVertex.begin(),
		 endVertex = mParticleVertex.end(); vertIterator != endVertex; ++vertIterator, ++particle, i++)
	{
		glm::vec3 pos = glm::vec3(float((rand() % (mWidth * 100)) * 0.01f),
								  float(float((rand() % (mLength * 100)) * 0.01f)), float(float((rand() % (mHeight * 100)) * 0.01f)));
		*vertIterator = pos;
		particle->mID = i;
		particle->mAcceleration = glm::vec3(0.0f, mConfigutation.mGravity, 0.0f);
		mSimulation[int(pos.z) * mWidth * mLength + int(pos.y) * mWidth + int(pos.x)].add(&(*particle));
		mParticleTexOffset[i] = glm::vec2(0.f, mFrameSizeInTexCoord.y * static_cast<float>(rand() % frameCount));
	}

	mFirstID = aCount;
}
void ParticleSimulation::init(int width,
							  int height,
							  int depth,
							  Lattice<CellObject>* aLattice,
							  const glm::vec2& aAnimationTextureSize,
							  const glm::vec2& aFrameSize,
							  float aMaxRadius,
							  float aVelocitySense,
							  float aVelocityCurvature,
							  float aFriction,
							  float aGravity,
							  float aBounce,
							  float aBounceEdge,
							  float quality)
{
	mAnimationTextureSize = aAnimationTextureSize;
	mFrameSize = aFrameSize;
	mFrameSizeInTexCoord = mFrameSize / mAnimationTextureSize;
	mAnimationPath = 0.f;
	mAnimationSpeed = 10.0f;//0.8f;
	mConfigutation.mVelocitySense = aVelocitySense;
	mConfigutation.mVelocityCurvature = aVelocityCurvature;
	mConfigutation.mFriction = aFriction;
	mConfigutation.mGravity = aGravity;
	mConfigutation.mBounce = aBounce;
	mConfigutation.mBounceEdge = aBounceEdge;
	mQuality = 1 / quality;
	mConfigutation.mMaxRadius = aMaxRadius;
	mWidth = int(width * quality) - 2;
	mLength = int(height * quality) - 2;
	mHeight = int(depth * quality) - 2;
	inv_width = 2 / float(mWidth);
	inv_length = 2 / float(mLength);
	inv_height = c_depthOutput / float(mHeight);
	mWidthBounce = mWidth - 0.0001f;
	mLengthBounce = mLength - 0.0001f;
	mHeightBounce = mHeight - 0.0001f;
	mLength -= (mMode == FallDown ? 1 : 0);
	mSize = mWidth * mHeight * mLength;
	mDeltaZ = mWidth * mLength;
	mDeltaY = mWidth;
	mParticleVertex.resize(mMaxSize);
	mParticles.resize(mMaxSize, Particle(c_particleRadius, -1));
	mLattice = aLattice;

	for (int i = 0; i < mMaxSize; ++i)
	{
		mParticles[i].mPosition = &mParticleVertex[i];
		mParticleVertex[i] = outPos;
	}

	mFirstID = 0;
	mSimulation = new Cell[mWidth * mHeight * mLength];
	Cell* cell = mSimulation;
	mFloor.mY = mLength;

	for (int i = 0; i < mHeight; ++i)
	{
		for (int j = 0; j < mLength; ++j)
		{
			for (int k = 0; k < mWidth; ++k, cell++)
			{
				cell->mX = k;
				cell->mY = j;
				cell->mZ = i;
			}
		}
	}

#ifdef PARTICLE_MULTITHREAD
	mTaskPool = new SPTaskPool(threadsMove);
	mMoveTasks = new SPTask*[threadsMove];
	mMoveParams = new SPParticleParams[threadsMove];
	int size = int(mParticles.size());
	int id = 0;

	for (int i = threadsMove; i > 0;)
	{
		int step = size / i;
		i--;
		mMoveTasks[i] = mTaskPool->select();
		mMoveParams[i].dt = 0.1f;
		mMoveParams[i].mStart = id;
		mMoveParams[i].mEnd = id + step;
		id = mMoveParams[i].mEnd;
		size -= step;
	}

	mCollisionTasks = new SPTask*[2];
#endif
	mNextFPS = (rand() & 7) + 1;
	mNextParticles = (rand() & 15) + 1;
	mNextParticlesRandom = (rand() & 31) + 20;

	mFloatLength = static_cast<float>(mLength);
}

ParticleSimulation::ParticleSimulation() :
	mSimulation(NULL),
	mWidth(0),
	mHeight(0),
	mLength(0),
	mFloatLength(0.f),
	mWidthBounce(0),
	mHeightBounce(0),
	mLengthBounce(0),
	mSize(0),
	inv_width(0),
	inv_height(0),
	inv_length(0),
	mFirstID(0),
	mDeltaZ(0),
	mDeltaY(0),
	mQuality(1.f),
	mMaxSize(c_particleMaxCount),
	mNextParticles(0),
	mNextParticlesRandom(0),
	mNextFPS(0),
	mLattice(NULL),
	mMode(FallDownWallNFloorNRandom),
	mAnimationPath(0.f),
	mAnimationSpeed(0.f)
#ifdef PARTICLE_MULTITHREAD
	, mMoveTasks(0)
	, mCollisionTasks(0)
	, mTaskPool(0)
	, mMoveParams(0)
#endif
{
	mConfigutation.mBounce = c_particleBounce;
}

ParticleSimulation::~ParticleSimulation()
{
	if (mSimulation)
	{
		delete[] mSimulation;
	}
}
void ParticleSimulation::moveRange(ParticleParams aParam)
{
	float friction(1.f - mConfigutation.mFriction);
	int i(aParam.mStart);
	int end(aParam.mEnd);

	float framesPassed(mAnimationPath / mFrameSizeInTexCoord.y);
	float intPart;
	framesPassed = modff(framesPassed, & intPart);
	mAnimationPath = framesPassed * mFrameSizeInTexCoord.y;
	intPart *= mFrameSizeInTexCoord.y;
	float squareDt(aParam.dt * aParam.dt);
	float precalcDt(mConfigutation.mVelocitySense * aParam.dt);
	for (Particle* particle = &mParticles[aParam.mStart];
		 i < end; particle++, ++i)
	{
		float shift(intPart + mParticleTexOffset[i].y);
		mParticleTexOffset[i].y = ( shift > 1.f ) ? shift - 1.f : shift;

		move(particle, precalcDt, squareDt, friction);
	}
}

void ParticleSimulation::collisionRange(ParticleParams aParam)
{
}
void ParticleSimulation::updateConfiguration()
{
#ifdef WITH_GRAVITY
	int size = int(mParticles.size());

	if (size == 0)
	{
		return;
	}

	float gravity = mConfigutation.mGravity;
	std::vector<Particle>::iterator particle = mParticles.begin();

	for (int i = 0; i < size; ++i, particle++)
	{
		particle->mAcceleration.y = gravity;
	}

#endif
}
void ParticleSimulation::simulate(float dt)
{
	mAnimationPath += dt * mAnimationSpeed;
	ForceTool::mOnlyPositive = false;
	ForceTool::mVelocitiesFromCorner = false;

#ifndef PARTICLE_MULTITHREAD
	float friction = 1.f - mConfigutation.mFriction;
#endif

	if (mMode >= FallDown && mNextFPS <= 0)
	{
		for (int i = 0; i < mNextParticles; ++i)
		{
			int id = rand() % 10;
			Particle* particle = mFloor.mRootParticle;

			for (int j = 0; j < id && particle; ++j, particle = particle->mNext);

			if (particle == NULL)
			{
				if (mFloor.mTailParticle)
				{
					particle = mFloor.mTailParticle;
				}
				else
				{
					break;
				}
			}

			glm::vec3 nextPos;
			nextPos.y = 0.01f;
			nextPos.x = rand() % ((mWidth - 2) * 10) * 0.1f + 1;
			nextPos.z = rand() % ((mHeight - 2) * 10) * 0.1f + 1;
			*particle->mPosition = nextPos;
			//*(particle->mPosition) = nextPos;
			mFloor.remove(particle);
			int shift = int(nextPos.x) + int(nextPos.z) * mDeltaZ;
			(mSimulation + shift)->add(particle);
			particle->mID = 1;
		}

			for (int i = 0; i < mNextParticlesRandom; i++)
			{
				int id = rand() & 15;
				Particle* particle = mFloor.mRootParticle;

				for (int j = 0; j < id && particle; ++j, particle = particle->mNext)
					;

				if (particle == NULL)
				{
					if (mFloor.mTailParticle)
					{
						particle = mFloor.mTailParticle;
					}
					else
					{
						break;
					}
				}

				glm::vec3 nextPos;
				nextPos.y = rand() % ((mLength - 2) * 10) * 0.1f + 1;
				nextPos.x = rand() % ((mWidth - 2) * 10) * 0.1f + 1;
				nextPos.z = rand() % ((mHeight - 2) * 10) * 0.1f + 1;
				*(particle->mPosition) = nextPos;
				mFloor.remove(particle);
				int shift = int(nextPos.x) + int(nextPos.y) * mDeltaY + int(nextPos.z) * mDeltaZ;
				(mSimulation + shift)->add(particle);
				particle->mID = 1;
			}

			mNextParticlesRandom = (rand() & 31) + 20;

		mNextFPS = (rand() & 3) + 2;
		mNextParticles = (rand() & 15) + 15;
	}

	mNextFPS--;
#ifndef PARTICLE_MULTITHREAD
	int i = 0;

	float framesPassed(mAnimationPath / mFrameSizeInTexCoord.y);
	float intPart;
	framesPassed = modff(framesPassed, & intPart);
	mAnimationPath = framesPassed * mFrameSizeInTexCoord.y;
	intPart *= mFrameSizeInTexCoord.y;
	float squareDt(dt * dt);
	float precalcDt(mConfigutation.mVelocitySense * dt);
	for (int i = 0; i<mParticles.size(); ++i)
	{
		Particle* particle = &mParticles[i];
		float shift(intPart + mParticleTexOffset[i].y);
		mParticleTexOffset[i].y = ( shift > 1.f ) ? shift - 1.f : shift;
		move(&(*particle), precalcDt, squareDt, friction);
	}
	/*for (std::vector<Particle>::iterator particle = mParticles.begin(), endParticle = mParticles.end();
		 particle != endParticle; ++i)
	{
		float shift(intPart + mParticleTexOffset[i].y);
		mParticleTexOffset[i].y = ( shift > 1.f ) ? shift - 1.f : shift;
		move(&(*particle++), precalcDt, squareDt, friction);
	}*/

#else

	for (int i = 0; i < threadsMove; i++)
	{
		mMoveTasks[i]->start<ParticleSimulation, ParticleParams>(*this, &ParticleSimulation::moveRange,
				mMoveParams[i]);
	}

	for (int i = 0; i < threadsMove; i++)
	{
		mMoveTasks[i]->wait();
	}

#endif
}

}	//namespace SPhysics