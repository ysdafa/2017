/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   ForceTool.cpp
 * @brief  Abstract Paint tool class.
 * @author Author (o.snyezhko@samsung.com)
 */
#include "AerodynamicsForceTool.h"
#include "SPADConfiguration.h"
namespace SPhysics
{

int ForceTool::mXoZLatticeXOffset = 0;
int ForceTool::mXoZLatticeYOffset = 0;
int ForceTool::mZoYLatticeXOffset = 0;
int ForceTool::mZoYLatticeYOffset = 0;
float ForceTool::mScaleXtoY = 1.0f;
int ForceTool::mWidth = 0;
int ForceTool::mHeight = 0;
bool ForceTool::mOnlyPositive = false;
bool ForceTool::mVelocitiesFromCorner = false;
ForceMap::ForceMap() :
	mMap(NULL),
	mWidth(0),
	mHeight(0)
{
}
ForceMap::~ForceMap()
{
	if (mMap)
	{
		delete[] mMap;
	}
}
void ForceMap::init(int aWidth, int aHeight)
{
	if (mWidth != aWidth || mWidth != aHeight)
	{
		if (mMap)
		{
			delete[] mMap;
		}

		mWidth = aWidth;
		mHeight = aHeight;
		mMap = new Force[aWidth * aHeight];
	}
}

Force* ForceMap::operator()(int aX, int aY) const
{
	return &mMap[aX + aY * mWidth];
}
int ForceMap::getWidth() const
{
	return mWidth;
}
int ForceMap::getHeight() const
{
	return mHeight;
}
void ForceMap::clear()
{
	int len = mWidth * mHeight;
	Force* f = mMap;

	for (int i = 0; i < len; ++i)
	{
		*(f++) = Force();
	}
}

Force::Force() :
	mVelocity(glm::vec2(0)),
	mIsSolid(false),
	mToAddVelocity(true)
{
}

ForceTool::ForceTool() :
	mForceMap(NULL),
	mVelocityMul(0.0f),
	mScaleWidth(1.0f),
	mScaleLength(1.0f),
	mScaleSize(1.0f),
	mForceInterface(NULL)
{
}

ForceTool::~ForceTool()
{
}

ForceMap* ForceTool::getForceMap() const
{
	return mForceMap;
}

void ForceTool::setForceMap(ForceMap* aForceMap)
{
	mForceMap = aForceMap;
}

void ForceTool::setPos(glm::vec3 aPos)
{
	mOldPos = mPos;
	mPos = aPos;
}

glm::vec3 ForceTool::getPos() const
{
	return mPos;
}

float ForceTool::getScaleWidth() const
{
	return mScaleWidth;
}

float ForceTool::getScaleLength() const
{
	return mScaleLength;
}

float ForceTool::getScaleSize() const
{
	return mScaleSize;
}

void ForceTool::setForceMapInterface(SPADController* aInterface)
{
	mForceInterface = aInterface;
}
void ForceTool::drawForceRemain()
{
	if (mVelocitiesFromCorner)
	{
		static const int x[4] =
		{ 0, 1, 1, 0 };
		static const int y[4] =
		{ 0, 0, 1, 1 };
		int width = mForceMap->getWidth();
		Force* startForce = (*mForceMap)(1, 1);
		float step = c_radiusForceFromCorner / (float)c_stepsFromCorner;

		for (int i = 0; i < 4; ++i)
		{
			Force* force = startForce + (x[i] * (width - 2) + y[i] * (width - 2) * width + mXoZLatticeYOffset);
			int sx = int(1.0f - 2.0f * x[i]);
			int sy = int(1.0f - 2.0f * y[i]);
			float vx = c_radiusForceFromCorner;
			float vy = c_radiusForceFromCorner;
			force->mVelocity += glm::vec2(sx * vx, sy * vy);

			for (int j = 1; j < c_stepsFromCorner; ++j)
			{
				(force + j * sx)->mVelocity += glm::vec2(sx * vx, sy * (vy - step));
				(force + j * width * sy)->mVelocity += glm::vec2(sx * (vx - step), sy * vy);
			}
		}
	}
}

}	//namespace SPhysics
