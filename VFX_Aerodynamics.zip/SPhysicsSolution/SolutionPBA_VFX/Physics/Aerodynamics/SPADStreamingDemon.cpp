/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * TODO
 * @file   StreamingDemon.cpp
 * @brief
 * @author Author()
 */

#include "SPADStreamingDemon.h"
namespace SPhysics
{

StreamingDemon::StreamingDemon() :
	CellDemon(),
	mTransferringCoefficient(0.0f),
	mBoundaryDemon(NULL)
{
}

void StreamingDemon::init(float aTransferringCoefficient, BouncebackDemon* aBoundaryDemon)
{
	mTransferringCoefficient = aTransferringCoefficient;
	mBoundaryDemon = aBoundaryDemon;
}

void StreamingDemon::assignAirViscosity(float viscosity)
{
	mTransferringCoefficient = viscosity;
}

}    // namespace SPhysics
