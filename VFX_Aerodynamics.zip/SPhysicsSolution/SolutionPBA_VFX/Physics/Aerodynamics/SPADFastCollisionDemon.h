/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * TODO
 * @file   FastCollisionDemon.h
 * @brief
 * @author Author()
 */

#ifndef FASTCOLLISIONDEMON_H_C2993C56FDF94AE38B174F22E6F3A65F
#define FASTCOLLISIONDEMON_H_C2993C56FDF94AE38B174F22E6F3A65F

#include "SPADCellDemon.h"
#include "SPADCellObject.h"
#include "AerodynamicsForceTool.h"

namespace SPhysics
{

/**
 * @class FastCollisionDemon
 * @brief class handling fast collision step and pigment mixing after streaming step
 */
class FastCollisionDemon: public CellDemon<CellObject>
{
public:

	/**
	 * Constructor
	 */
	inline FastCollisionDemon();

	/**
	 * @brief handle collision and pigment mixing in a cell
	 * @param aCellObject               cell to process
	 * @param aX                        x coordinate of the cell in the lattice
	 * @param aY                        y coordinate of the cell in the lattice
	 */
	inline void handle(CellObject* aCellObject, int aX, int aY, int* aIndexPtr);
	/**
	 * @brief initialization of the class instance
	 * @param aDispersionCurvature                  curvature of the gaussian used for flow dispersion
	 * @param aPreservingDirectionCoefficient       part of velocity that should preserve its direction
	 * @param aForceCoefficient                     coefficient defining how strongly the friction force influences the flow
	 * @param aMaxVelocityInverse                   normalization coefficient for flow dispersion
	 */
	void init(float aDispersionCurvature, float aForceCoefficient, float aMaxVelocityInverse);

	/**
	 * @brief getting dispersion curvature
	 */
	inline float getCurvature() const;
	/**
	 * @brief setting new dispersion curvature
	 * @param curvature         new curvature value
	 */
	inline void setCurvature(float curvature);
	/**
	 * @brief getting force coefficient
	 */
	inline float getForceCoefficient() const;
	/**
	 * @brief setting new force coefficient
	 * @param coefficient         new force coefficient
	 */
	inline void setForceCoefficient(float coefficient);
private:
	/// curvature of the gaussian used for flow dispersion
	float mDispersionCurvature;
	/// coefficient defining how strongly the friction forces influence the flow
	float mForceCoefficient;
	/// normalization coefficient for flow dispersion
	float mMaxVelocityInverse;
};

}    // namespace SPhysics

#include "SPADFastCollisionDemon.inl"
#endif /* _FASTCOLLISIONDEMON_H_ */
