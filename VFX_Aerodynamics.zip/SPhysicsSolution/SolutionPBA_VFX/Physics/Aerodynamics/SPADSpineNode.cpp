/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SpineNode.h
 * @brief  class of nodes for brush
 * @author Author (o.snyezhko@samsung.com)
 */

#include "SPADSpineNode.h"
#include <stddef.h>

namespace SPhysics
{

SpineNode::SpineNode() :
	mLength(0),
	mRadius(0),
	mUpNode(NULL),
	mDownNode(NULL),
	mLeakCoef(0.0f),
	mMass(0.0f),
	mMaxMass(0.0f)
{
}

SpineNode::SpineNode(float aLength, float aRadius, float aMaxMass) :
	mLength(aLength),
	mRadius(aRadius),
	mUpNode(NULL),
	mDownNode(NULL),
	mLeakCoef(0.0f),
	mMass(0.0f),
	mMaxMass(aMaxMass)
{
}

SpineNode::~SpineNode()
{
	delete mDownNode;
}

void SpineNode::setDownNode(SpineNode* aDownNode)
{
	mDownNode = aDownNode;
}

void SpineNode::setUpNode(SpineNode* aUpNode)
{
	mUpNode = aUpNode;
}

void SpineNode::setPosition(glm::vec3 aPos)
{
	mPos = aPos;
}

void SpineNode::setRadius(float aRadius)
{
	mRadius = aRadius;
}

void SpineNode::multiplyRadius(float aCoeficient)
{
	mRadius *= aCoeficient;
}

void SpineNode::multiplyLength(float aCoeficient)
{
	mLength *= aCoeficient;
}

SpineNode* SpineNode::getDownNode() const
{
	return mDownNode;
}

SpineNode* SpineNode::getUpNode() const
{
	return mUpNode;
}

float SpineNode::getLength() const
{
//	return 0.0f;
	return mLength;
}

float SpineNode::getRadius() const
{
	return mRadius;
}

float SpineNode::doLeak(float aMass)
{
	float succedMass = 0;
	float totalMass = mMass + aMass;

	if (mDownNode)
	{
		succedMass = mDownNode->doLeak(totalMass * mLeakCoef);
	}

	mMass -= succedMass;
	float dm = totalMass - mMaxMass;

	if (dm > 0)
	{
		dm = mMaxMass - mMass;
		mMass = mMaxMass;
	}
	else
	{
		mMass = totalMass;
		dm = aMass;
	}

	return dm;
}

}    // namespace SPhysics