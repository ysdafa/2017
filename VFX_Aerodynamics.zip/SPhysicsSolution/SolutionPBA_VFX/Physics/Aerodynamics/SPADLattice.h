/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * TODO
 * @file   CommonLbm.h
 * @brief
 * @author Author ()
 */

#ifndef LATTICE_H_43DDE3BC5DF64306A0E23E94561E5FC6
#define LATTICE_H_43DDE3BC5DF64306A0E23E94561E5FC6

#include "SPADEventDispatcher.h"
#include "SPADCellObject.h"
#include "SPMersenneTwister32.h"
#include <glm.hpp>
#include <string.h>

namespace SPhysics
{

#define TEMPLATE_LATTICE template< typename TCellObject>
#define PARAMS_LATTICE TCellObject

//#define GAUSSIAN_APPROXIMATION( argumentSquared, curvature ) (curvature / (2.0f * argumentSquared + curvature))
//#define GAUSSIAN_APPROXIMATION_INVERSE( argumentSquared, curvature ) (argumentSquared / (argumentSquared + 0.5f * curvature))
#define GAUSSIAN_APPROXIMATION_INVERSE_HALF( argumentSquared, halfCurvature ) (argumentSquared / (argumentSquared + halfCurvature))
#define SYGMOID(argument, parameter) ((1.0f + parameter) * argument / (abs(argument) + parameter))

/**
 * TODO
 * @param aArgumentSquared
 * @param aCurvature
 * @return
 */
inline float GaussianApproximation(float aArgumentSquared, float aCurvature);

/**
 * TODO
 * @param aArgumentSquared
 * @param aCurvature
 * @return
 */
inline float GaussianApproximationInverse(float aArgumentSquared, float aCurvature);

/**
 * TODO
 * @param aMean
 * @param aVariance
 * @return
 */
inline double SPADGaussianRand(double aMean, double aVariance);


/**
 * TODO
 */
template<typename TCellObject>
class Lattice
{
public:
	/**
	 * TODO
	 */
	enum
	{
		CellObjectSize = sizeof(TCellObject)    //!< CellObjectSize
	};
	/**
	 * TODO
	 */
	enum TraversalMethod
	{
		wtLattice,
		wtLatticeBound,
		wtLatticeWithoutBound
	};
	/**
	 * TODO
	 */
	enum
	{
		nright,
		ntopright,
		ntop,
		ntopleft,
		nbottomright,
		nbottom,
		nbottomleft,
		nleft,
		ncentre
	};
public:
	/**
	 * Constructor
	 */
	Lattice();
	/**
	 * Destructor
	 */
	virtual ~Lattice();
	/**
	 * ToDO
	 * @param aWidth
	 * @param aHeight
	 * @param aCollisionRowRangesNumber
	 * @param astreamingRowRangesNumber
	 * @param aDensity
	 */
	virtual void init(int aWidth, int aHeight, int aDepth, int aCollisionRowRangesNumber,
					  int astreamingRowRangesNumber, float aDensity = 1.0f);

	void setAdditionalLatticeOffsets(int XoZ_xOffset, int XoZ_yOffset, int ZoY_xOffset, int ZoY_yOffset);

	inline int XoZ_xOffset() const;
	inline int XoZ_yOffset() const;
	inline int ZoY_xOffset() const;
	inline int ZoY_yOffset() const;

	inline int XoY_left() const;
	inline int XoY_right() const;
	inline int XoY_top() const;
	inline int XoY_bottom() const;

	inline int XoZ_left() const;
	inline int XoZ_right() const;
	inline int XoZ_top() const;
	inline int XoZ_bottom() const;

	inline int ZoY_left() const;
	inline int ZoY_right() const;
	inline int ZoY_top() const;
	inline int ZoY_bottom() const;

	/**
	 * TODO
	 */
	void dropReadyRows();
	/**
	 * TODO
	 * @return
	 */
	int width() const;
	/**
	 * TODO
	 * @return
	 */
	int height() const;
	/**
	 * TODO
	 * @param aCellDemon
	 * @param aTraversalMethod
	 */
	template<typename TCellDemon>
	void walkLattice(TCellDemon& aCellDemon, TraversalMethod aTraversalMethod);

	/**
	 * TODO
	 * @param aCellDemon
	 * @param aTraversalMethod
	 * @param aRangeStart
	 * @param aRangeEnd
	 * @param aEventDispatcher
	 */
	template<typename TCellDemon>
	void walkLatticeRange(TCellDemon& aCellDemon, TraversalMethod aTraversalMethod, int aRangeStart,
						  int aRangeEnd, EventDispatcher* aEventDispatcher);

	/**
	 * TODO
	 * @param aCellDemon
	 * @param aTraversalMethod
	 * @param aRangeStart
	 * @param aRangeEnd
	 * @param aSyncObject
	 */
	template<typename TCellDemon>
	void walkLatticeSync(TCellDemon& aCellDemon, TraversalMethod aTraversalMethod, int aRangeNumber,
						 int aRangeStart, int aRangeEnd, CollisionEvent* aSyncObject);

	/**
	 * TODO
	 * @param aCellDemon
	 */
	template<typename TCellDemon>
	void walkLatticeFinal(TCellDemon& aCellDemon);

	/**
	 * TODO
	 * @return
	 */
	TCellObject& next();
	/**
	 * TODO
	 * @return
	 */
	TCellObject& prev();
	/**
	 * TODO
	 * @return
	 */
	TCellObject& current();
	/**
	 * TODO
	 * @return
	 */
	TCellObject& first();
	/**
	 * TODO
	 * @return
	 */
	TCellObject& last();
	/**
	 * TODO
	 * @param aPosition
	 * @return
	 */
	TCellObject& setCursor(int aPosition);
	/**
	 * TODO
	 * @param aNumber
	 * @return
	 */
	TCellObject& neighbor(int aNumber);
	/**
	 * TODO
	 * @param aNumber
	 * @param aX
	 * @param aY
	 * @return
	 */
	inline TCellObject& neighbor(int aNumber, int aX, int aY);
	/**
	 * TODO
	 * @param aNumber
	 * @param aX
	 * @param aY
	 * @return
	 */
	bool checkNeighbor(int aNumber, int aX, int aY);

	/**
	 * TODO
	 * @param aCellDemon
	 * @param aTraversalMethod
	 */
	template<typename TCellDemon>
	void operator()(TCellDemon& aCellDemon, TraversalMethod aTraversalMethod);

	/**
	 * TODO
	 * @param aPosition
	 * @return
	 */
	TCellObject& operator[](int aPosition);

	/**
	 * TODO
	 * @param ax
	 * @param aY
	 * @return
	 */
	TCellObject& operator()(int ax, int aY);
	/**
	 * TODO
	 * @return
	 */
	bool isEmpty();

	/**
	 * TODO
	 * @param aNumber
	 * @param aStart
	 * @param aEnd
	 */
	void getCollisionRange(int aNumber, int& aStart, int& aEnd);

	/**
	 * TODO
	 * @param aNumber
	 * @param aStart
	 * @param aEnd
	 */
	void getStreamingRange(int aNumber, int& aStart, int& aEnd);
	/**
	 * TODO
	 * @return
	 */
	bool* getReadyRows();
	/**
	 * TODO
	 * @return
	 */
	bool* getFinishedRows();

	bool* getClearRowFlags();

	void copy(Lattice<TCellObject>& lattice);
private:
	/**
	 * TODO -give a short up description to member of class
	 */
	TCellObject* mLattice;
	int mCursor;
	int mWidth;
	int mHeight;
	int mHigh;
	int mLength;

	int mXoZLatticeXOffset;
	int mXoZLatticeYOffset;
	int mZoYLatticeXOffset;
	int mZoYLatticeYOffset;

	int mXoY_left;
	int mXoY_right;
	int mXoY_top;
	int mXoY_bottom;

	int mXoZ_left;
	int mXoZ_right;
	int mXoZ_top;
	int mXoZ_bottom;

	int mZoY_left;
	int mZoY_right;
	int mZoY_top;
	int mZoY_bottom;

	bool* mRowsReady;
	bool* mRowsFinished;
	bool* mClearRowFlags;
	int mNumberOfCollisionRowRanges;
	int mNumberOfStreamingRowRanges;
	int* mCollisionRangeStarts;
	int* mCollisionRangeEnds;
	int* mStreamingRangeStarts;
	int* mStreamingRangeEnds;
	CollisionEvent* mSyncObject;
	int** mWalkSyncCounters;

	bool* mCollisionEndFlags;
	int mNeighbours[gSPADneighbor_count];
};

}    // namespace SPhysics

#include "SPADLattice.inl"

#endif // _LATTICE_H_
