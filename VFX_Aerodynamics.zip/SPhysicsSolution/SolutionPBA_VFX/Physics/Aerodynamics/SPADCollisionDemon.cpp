/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * TODO
 * @file   CollisionDemon.cpp
 * @brief
 * @author Author()
 */

#include "SPADCollisionDemon.h"

namespace SPhysics
{

void CollisionDemon::init(float aDispersionCurvature, float aForceCoefficient, float aMaxVelocityInverse)
{
	mDispersionCurvature = aDispersionCurvature;
	mForceCoefficient = aForceCoefficient;
	mMaxVelocityInverse = aMaxVelocityInverse;
}

}    // namespace SPhysics
