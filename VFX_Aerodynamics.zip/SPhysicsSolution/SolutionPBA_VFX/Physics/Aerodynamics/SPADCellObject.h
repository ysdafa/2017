/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * TODO
 * @file   CellObject.h
 * @brief  Brush simulation
 * @author Author ()
 */

#ifndef CELLOBJECT_H_2023DB9122EE488886D09A292AD43FAD
#define CELLOBJECT_H_2023DB9122EE488886D09A292AD43FAD

#include "SPLog.h"
#include "SPADConfiguration.h"

namespace SPhysics
{

struct Force;

/**
 * @class CellObject
 * @brief class representing a cell of a lattice
 */
class CellObject
{
public:

	/**
	 * @brief default constructor
	 */
	CellObject();

	/**
	 * @brief destructor
	 */
	~CellObject();

	/**
	 * @brief set this cell as (non-)solid
	 * @param aIsSolid      whether the cell should be set solid (true) or non-solid (false)
	 */
	void SetSolid(bool aIsSolid);

	/**
	 * @brief set this cell as (non-)solid, but wettable
	 * @param aIsInterSolid     whether the cell should be set solid (true) or non-solid (false)
	 */
	void SetInterSolid(bool aIsInterSolid);

	/**
	 * @return      true if the cell is solid, false otherwise
	 */
	inline bool IsSolid();

	/**
	 * @brief redistribute velocities in the cell to obtain the given average velocity
	 * @param aNewVelocityX     new average velocity x component
	 * @param aNewVelocityY     new average velocity y component
	 */
	void assignNewVelocity(float aNewVelocityX, float aNewVelocityY);

	/**
	 * @brief alter the stream in the cell by adding velocity
	 * @param aVelocityX        x component of the velocity to add
	 * @param aVelocityY        y component of the velocity to add
	 */
	void addVelocity(float aVelocityX, float aVelocityY);

	/**
	 * @brief forcibly alter the stream in the cell to obtain given average velocity flow direction
	 * @param aVelocityX        x component of the average velocity
	 * @param aVelocityY        y component of the average velocity
	 */
	void addVelocityForced(float aVelocityX, float aVelocityY);

	/**
	 * @brief reset cell to default state
	 */
	void resetCell();

	/// velocity vectors in the cell
	float mVelocities[gSPADneighbor_count];
	/// array to temporarily store new velocities after streaming step
	float mTempVelocities[gSPADneighbor_count];
	/// x component of the average velocity in the cell
	float mxVelocity;
	/// y component of the average velocity in the cell
	float myVelocity;
	/// paper height in the cell
	float mHeight;
	/// mass of air in the cell
	float mMass;
	/// friction force in the cell x component
	float mxForce;
	/// friction force in the cell y component
	float myForce;
	/// brush force in cell
	Force* mForce;

private:
	/// whether the cell is non-wettable solid
	bool mIsSolid;
};

}    // namespace SPhysics

#include "SPADCellObject.inl"

#endif // _CELLOBJECT_H_
