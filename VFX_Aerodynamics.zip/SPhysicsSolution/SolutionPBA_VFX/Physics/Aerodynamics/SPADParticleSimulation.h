/**
 * TODO
 * @file   CellObject.h
 * @brief  Brush simulation
 * @author Author ()
 */

#ifndef PARTICLE_SIMULATION_H_57DFC1C5F64044C2889172A332841792
#define PARTICLE_SIMULATION_H_57DFC1C5F64044C2889172A332841792

#include "SPLog.h"
#include "SPADConfiguration.h"
#include "AerodynamicsForceTool.h"
#include "SPTask.h"
#include "SPTaskPool.h"
#include "SPADLattice.h"

#include <vector>
#include <list>
#include <iostream>
#include <glm.hpp>
#include <gtx/transform.hpp>

#define WITH_GRAVITY

#define _3D_PARTICLES

// #define PARTICLE_MULTITHREAD

namespace SPhysics
{

static const int neigh_x[c_particleNeighborCount] =
{ 1, 1, 0, -1, 0, 1, 1, 0, -1, -1, -1, 0, 1 };
static const int neigh_y[c_particleNeighborCount] =
{ 0, 1, 1, 1, 0, 0, 1, 1, 1, 0, -1, -1, -1 };
static const int neigh_z[c_particleNeighborCount] =
{ 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1 };
static const int maxCountNears = 8;
static const glm::vec3 outPos(-FLT_MAX, -FLT_MAX, -FLT_MAX);

struct Cell;
struct Particle;

static const int threadsMove = 4;

struct ParticleConfiguration
{
	float mVelocitySense;
	float mVelocityCurvature;
	float mFriction;
	float mGravity;
	float mBounce;
	float mBounceEdge;
	float mScale;
	float mMaxRadius;
	ParticleConfiguration()
	{
		mVelocitySense = 0.f;
		mVelocityCurvature = 0.f;
		mFriction = 0.f;
		mGravity = 0.f;
		mBounce = 0.f;
		mBounceEdge = 0.f;
		mScale = 0.f;
		mMaxRadius = 0.f;
	};
};

struct Cell
{
	Cell();
	Cell(int x, int y, int z);
	inline void add(Particle* aParticle);
	inline void remove(Particle* aParticle);
	inline void move(Particle* aParticle, Cell* aCell);
	Particle* mRootParticle;
	Particle* mTailParticle;
	//Cell* neighbor[c_particleNeighborCount];
	glm::vec3 mAddVelocity;
	int mX;
	int mY;
	int mZ;
};
struct Particle
{
	Particle(float aRadius, int aID);
	glm::vec3* mPosition;
	glm::vec3 mDeltaPosition;
	glm::vec3 mAcceleration;
	Particle* mNext;
	Particle* mPrevious;
	float mRadius;
	Cell* mCell;
	int mID;
	inline void move(glm::vec3& aPosition, float dtSq, float aFriction);
	inline void push(glm::vec3& aPosition, glm::vec3 delta);
};

struct ParticleParams
{
	int mStart;
	int mEnd;
	float dt;
};

class ParticleSimulation : NonCopyable
{
public:
	enum ProjectionPlane
	{
		XoY,
		XoZ,
		ZoY
	};
	ParticleSimulation();

	~ParticleSimulation();

	enum Mode
	{
		FreeBouncing,
		FallDown,
		FallDownWallNFloor,
		FallDownWallNFloorNRandom,
		FallWallFloorRandomPositiveCorner
	};

	glm::mat4 getScaleMatrix() const
	{
		//glm::mat4 mat = glm::translate(-(float)mWidth * 0.5f, -(float)(mLength + 1) * 0.5f, 0.0f) * glm::mat4(1.0f);
		glm::mat4 mat = glm::translate(glm::mat4(1.0f), glm::vec3(-(float)mWidth * 0.5f, -(float)(mLength + 1) * 0.5f, 0.0f));
		mat = glm::scale(glm::mat4(1.0f), glm::vec3(inv_width, -inv_length, inv_height)) * mat; //// NEED TO CHECK JOON
		mat = glm::transpose(mat);
		return mat;
	}

	void simulate(float dt = 0.1f);
	inline void addParticle(glm::vec3 aPos);
	inline void removeParticle(Particle* particle);
	void createParticles(int aCount);
	void updateConfiguration();

	void init(int aWidth,
			  int aHeight,
			  int aDepth,
			  Lattice<CellObject>* aLattice,
			  const glm::vec2& aAnimationTextureSize,
			  const glm::vec2& aFrameSize,
			  float aMaxRadius = c_particleRadius,
			  float aVelocitySense = c_particleVelocitySense,
			  float aVelocityCurvature = c_particleVelocityCurvature,
			  float aFriction = c_particleFricition,
			  float aGravity = c_particleGravity,
			  float aBounce = c_particleBounce,
			  float aBounceEdge = c_particleBounceToEdge,
			  float aQuality = c_particleSimulationQuality);
	inline Cell* getNeighbor(int x, int y, int z, int i);

	inline void collision(Cell* aCell1, Cell* aCell2);
	inline void collisionOne(Cell* aCell);

	ParticleConfiguration& getConfiguration()
	{
		return mConfigutation;
	}
	inline void collisionParticle(Particle* aParticle, Cell* aCell2);
	inline void move(Particle* aParticle, float precalcDt, float squareDt, float aFriction);
	inline void push(Particle* aParticle, glm::vec3 aPenetration);
	inline void moveToCell(Particle* aParticle, Cell* aNextCell);
	inline void bouncing(float& aValue, float& aDelta, float aMin, float aMax);

	void moveRange(ParticleParams aParam);

	void collisionRange(ParticleParams aParam);
	ParticleConfiguration mConfigutation;

	Cell* mSimulation;

	Cell mFloor;
	int mWidth;
	int mHeight;
	int mLength;
	float mFloatLength;
	float mWidthBounce;
	float mHeightBounce;
	float mLengthBounce;
	int mSize;
	float inv_width;
	float inv_height;
	float inv_length;
	int mFirstID;
	int mDeltaZ;
	int mDeltaY;
	float mQuality;

	int mMaxSize;

	int mNextParticles;

	int mNextParticlesRandom;

	int mNextFPS;
	std::vector<glm::vec3> mParticleVertex;
	std::vector<glm::vec2> mParticleTexOffset;
	std::vector<Particle> mParticles;
	Lattice<CellObject>* mLattice;

	Mode mMode;
	inline glm::vec3 getVelocity(int x, int y, int z);
	inline void setVelocity(int x, int y, int z, glm::vec3 aVelocity);
	inline glm::vec3 getForce(int x, int y, int z);
	inline CellObject& getCellFromProjectionXoY(int firstCoord, int secondCoord);
	inline CellObject& getCellFromProjectionXoZ(int firstCoord, int secondCoord);
	inline CellObject& getCellFromProjectionZoY(int firstCoord, int secondCoord);

	glm::vec2 mAnimationTextureSize;
	glm::vec2 mFrameSize;
	glm::vec2 mFrameSizeInTexCoord;
	float mAnimationPath;
	float mAnimationSpeed;

#ifdef PARTICLE_MULTITHREAD
	SPTask** mMoveTasks;
	SPTask** mCollisionTasks;
	SPTaskPool* mTaskPool;

	ParticleParams* mMoveParams;
#endif
};

}	//namespace SPhysics
#include "SPADParticleSimulation.inl"
#endif
