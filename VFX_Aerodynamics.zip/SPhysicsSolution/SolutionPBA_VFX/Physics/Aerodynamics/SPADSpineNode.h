/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   	SpineNode.h
 * @brief	class of nodes for brush
 * @author 	Author (o.snyezhko@samsung.com)
 */

#ifndef SPINENODE_H_FB658E85710E441293BA2A7A61E6BD30
#define SPINENODE_H_FB658E85710E441293BA2A7A61E6BD30

#include "SPNonCopyable.h"
#include <glm.hpp>

namespace SPhysics
{

class SpineNode : NonCopyable
{
public:
	/**
	 * Coinstructor
	 */
	SpineNode();
	/**
	 * Constructor
	 * @param aLength lenght from previos SpinNode
	 * @param aRadius Radius of SpinNode for Brush
	 * @param aMaxMass
	 */
	SpineNode(float aLength, float aRadius, float aMaxMass);

	/**
	 * Destructor
	 */
	virtual ~SpineNode();

	/**
	 * Set neighbor SpinNode to below
	 * @param aDownNode SpineNode to below
	 */
	void setDownNode(SpineNode* aDownNode);

	/**
	 * Set neighbor SpinNode to above
	 * @param aUpNode SpineNode to above
	 */
	void setUpNode(SpineNode* aUpNode);

	/**
	 * set Position of SpinNode
	 * @param aPos position vec3(x,y,z)
	 */
	void setPosition(glm::vec3 aPos);

	/**
	 * set Radius of SpinNode
	 * @param aRadius Radius
	 */
	void setRadius(float aRadius);

	/**
	 * multiply Radius to a coefficient
	 * @param aCoeficient coefficient
	 */
	void multiplyRadius(float aCoeficient);

	/**
	 * multiply Length to a coefficient
	 * @param aCoeficient coefficient
	 */
	void multiplyLength(float aCoeficient);

	/**
	 * get neighbor SpinNode from below
	 * @return neighbor SpineNode from below
	 */
	SpineNode* getDownNode() const;

	/**
	 * get neighbor SpinNode from above
	 * @return neighbor SpinNode from above
	 */
	SpineNode* getUpNode() const;

	/**
	 *get length
	 * @return length
	 */
	float getLength() const;

	/**
	 * get radius
	 * @return radius
	 */
	float getRadius() const;

	/**
	 * Leaking ink to next SpineNode
	 * @param aMass ink mass to transfer to next SpineNode
	 * @return succed mass to transfer
	 */
	float doLeak(float aMass);

private:
	float mLength;/**< length from neighbor above */
	glm::vec3 mPos;/**< position */
	float mRadius;/**< Radius */
	SpineNode* mUpNode; /**< neighbor node above */
	SpineNode* mDownNode; /**< neighbor node below */
	float mLeakCoef; /**< Coefficient to leak Ink */
	float mMass; /**< Current ink mass */
	float mMaxMass;/**< Max ink mass to leak*/
};

}    // namespace SPhysics

#endif /* _SPINENODE_H_ */
