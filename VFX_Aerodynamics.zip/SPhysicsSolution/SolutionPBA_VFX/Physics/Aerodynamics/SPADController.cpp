/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * TODO
 * @file   SPADController.cpp
 * @brief
 * @author
 */

#include "SPADController.h"
#include "SPTaskPool.h"
#include "SPTask.h"
#include "SPEvent.h"
#include "SPADBrush.h"
#include "AerodynamicsForceTool.h"
#include "SPPaperSurface.h"
#include "SPADLattice.h"
#include "SPADCellObject.h"
#include "AerodynamicsForceTool.h"
#include "SPException.h"

#include <time.h>
#include <sstream>

namespace SPhysics
{

SPADController::SPADController() :
	mPaperSurface(NULL),
	mInitialBoundariesDemon(),
	mWidth(0),
	mHeight(0),
	mDepth(0),
	mXoZLatticeXOffset(0),
	mXoZLatticeYOffset(0),
	mZoYLatticeXOffset(0),
	mZoYLatticeYOffset(0),
	mCollisionRangesNumber(0),
	mStreamingRangesNumber(0),
	mVelocityToAssign(0.0f),
	mCollisionParams(NULL),
	mStreamingParams(NULL),
#ifdef AERODYNAMICS_MULTI_THREAD
	mCollisionTasks(NULL),
	mStreamingTasks(NULL),
	mTaskPool(NULL),
	mEvents(NULL),
	mEventDispatcher(NULL),
#endif
	mClearFlag(false),
	mFreezeFlag(false),
	mIntentToStop(false),
	mBrush(NULL),
	mProcess(true),
	mPauseCalculationsIfIdle(false),
	mPresetID(0),
	mChangePreset(false),
	mPrevTime(static_cast<float>(clock()) / CLOCKS_PER_SEC)
{
	rand32.init(static_cast<unsigned int>(clock()));
}

SPADController::~SPADController()
{
	delete mPaperSurface;
	delete[] mCollisionParams;
	delete[] mStreamingParams;
#ifdef AERODYNAMICS_MULTI_THREAD
	delete mTaskPool;
	delete[] mCollisionTasks;
	delete[] mStreamingTasks;
	delete mEventDispatcher;
#endif
	delete mBrush;
}

Lattice<CellObject>& SPADController::getLattice()
{
	return mLattice;
}
StreamingDemon& SPADController::getStreamingDemon()
{
	return mStreamingDemon;
}

#ifdef AERODYNAMICS_MULTI_THREAD

void SPADController::setEventDispatcher(EventDispatcher* aEventDispatcher)
{
	mEventDispatcher = aEventDispatcher;
	int realHeight = mDepth + (mHeight << 1);
	mEventDispatcher->init(realHeight, mLattice.getReadyRows(), mLattice.getFinishedRows(),
						   mLattice.getClearRowFlags());
	mEventDispatcher->bindRanges(mStreamingParams);

	for (int i = 0; i < mCollisionRangesNumber; i++)
	{
		mCollisionParams[i].eventDispatcher = mEventDispatcher;
	}
}
void SPADController::bindEvents(SPhysics::SPEvent* aEvents)
{
	mEventDispatcher->bindEvents(aEvents);
}

#endif

void SPADController::init(int aWidth, int aHeight, int aDepth,
								  const glm::vec2& aAnimationTextureSize, const glm::vec2& aFrameSize, int aBellPointsNumber,
								  float aTransferringCoefficient, float aMinCurvature, float aVelocityToAssign, float aForceCoefficient,
								  float aHeightForceCoefficient, int aCollisionRangesNumber, int aStreamingRangesNumber)
{
#ifdef TESTING
	ARGUMENT_VALUE_CHECK(aWidth <= 0)
	ARGUMENT_VALUE_CHECK(aHeight <= 0)
	ARGUMENT_VALUE_CHECK(aVelocityToAssign <= 0.f)
	ARGUMENT_VALUE_CHECK(aMinCurvature <= 0.f)
	ARGUMENT_VALUE_CHECK(aForceCoefficient <= 0.f)
	ARGUMENT_VALUE_CHECK(aTransferringCoefficient <= 0.f)
	ARGUMENT_VALUE_CHECK(aHeightForceCoefficient <= 0.f)
	ARGUMENT_VALUE_CHECK(aCollisionRangesNumber < 1)
	ARGUMENT_VALUE_CHECK(aStreamingRangesNumber < 1)
	ARGUMENT_VALUE_CHECK(aBellPointsNumber < 1)
#endif
	mWidth = aWidth;
	mHeight = aHeight;
	mDepth = aDepth;
	mVelocityToAssign = aVelocityToAssign;
#ifndef AERODYNAMICS_MULTI_THREAD
	mCollisionRangesNumber = 1;
	mStreamingRangesNumber = 1;
#else
	mCollisionRangesNumber = aCollisionRangesNumber;
	mStreamingRangesNumber = aStreamingRangesNumber;
	createTaskPool(mCollisionRangesNumber + mStreamingRangesNumber);
	EventDispatcher* eventDispatcher = new EventDispatcher(mStreamingRangesNumber);
	mCollisionEvent.setEvent(&mEvent);
#endif
	int realWidth = mWidth;
	int realHeight = mDepth + (mHeight << 1);
	mXoZLatticeXOffset = 0;
	mXoZLatticeYOffset = mHeight;
	mZoYLatticeXOffset = 0;
	mZoYLatticeYOffset = mHeight + mDepth;
	ForceTool::mXoZLatticeXOffset = mXoZLatticeXOffset;
	ForceTool::mXoZLatticeYOffset = mXoZLatticeYOffset;
	ForceTool::mZoYLatticeXOffset = mZoYLatticeXOffset;
	ForceTool::mZoYLatticeYOffset = mZoYLatticeYOffset;
	ForceTool::mWidth = mWidth;
	ForceTool::mHeight = mHeight;
	ForceTool::mScaleXtoY = mWidth / (float)mHeight;
	mLattice.init(mWidth, mHeight, mDepth, mCollisionRangesNumber, mStreamingRangesNumber);
	mLattice.setAdditionalLatticeOffsets(mXoZLatticeXOffset, mXoZLatticeYOffset, mZoYLatticeXOffset,
										 mZoYLatticeYOffset);
	mPaperSurface = new SPhysics::PointsMediumStructure;
	mPaperSurface->initSurfaceSize(mWidth, mHeight, aBellPointsNumber);
	mPaperSurface->createSurface();

	for (int j = 0; j < mHeight; j++)
	{
		for (int i = 0; i < mWidth; i++)
		{
			mLattice(i, j).mHeight = mPaperSurface->getSurfaceLattice()[j * mWidth + i].height;
		}
	}

	delete mPaperSurface;
	mPaperSurface = new SPhysics::PointsMediumStructure;
	mPaperSurface->initSurfaceSize(mWidth, mDepth, aBellPointsNumber);
	mPaperSurface->createSurface();

	for (int j = 0; j < mDepth; j++)
	{
		for (int i = 0; i < mWidth; i++)
		{
			mLattice(i, j + mXoZLatticeYOffset).mHeight = mPaperSurface->getSurfaceLattice()[j * mWidth + i].height;
		}
	}

	delete mPaperSurface;
	mPaperSurface = new SPhysics::PointsMediumStructure;
	mPaperSurface->initSurfaceSize(mDepth, mHeight, aBellPointsNumber);
	mPaperSurface->createSurface();

	for (int j = 0; j < mHeight; j++)
	{
		for (int i = 0; i < mDepth; i++)
		{
			mLattice(i, j + mZoYLatticeYOffset).mHeight = mPaperSurface->getSurfaceLattice()[j * mDepth + i].height;
		}
	}

	delete mPaperSurface;
	mPaperSurface = NULL;
	mInitDemon.bindLattice(mLattice);
	mInitDemon.init(mVelocityToAssign, aHeightForceCoefficient);
	mBoundaryDemon.bindLattice(mLattice);
	mBoundaryDemon.assignAirViscosity(aTransferringCoefficient);
	mStreamingDemon.bindLattice(mLattice);
	mStreamingDemon.init(aTransferringCoefficient, &mBoundaryDemon);
#ifdef FAST_COLLISION
	mFastCollisionDemon.bindLattice(mLattice);
	mFastCollisionDemon.init(aMinCurvature, aForceCoefficient,
							 1.0f / (8.0f * aVelocityToAssign));
#else
	mCollisionDemon.bindLattice(mLattice);
	mCollisionDemon.init(aMinCurvature, aForceCoefficient, 1.0f / (gSPADneighbor_count * aVelocityToAssign));
#endif
	mInitialBoundariesDemon.bindLattice(mLattice);
	mInitialBoundariesDemon.init(mWidth, mHeight, mDepth);
	mLattice.walkLattice<InitialBoundariesDemon>(mInitialBoundariesDemon, Lattice<CellObject>::wtLattice);
	mLattice.walkLattice<InitialVelocitiesDemon>(mInitDemon, Lattice<CellObject>::wtLatticeWithoutBound);
#ifdef AERODYNAMICS_MULTI_THREAD
	mLattice.walkLattice<StreamingDemon>(mStreamingDemon, Lattice<CellObject>::wtLatticeWithoutBound);
#endif
	mCollisionParams = new SPADWalkLatticeRangeParams[mCollisionRangesNumber];
	mStreamingParams = new SPADWalkLatticeSyncParams[mStreamingRangesNumber];
#ifdef AERODYNAMICS_MULTI_THREAD
	mCollisionTasks = new SPhysics::SPTask*[mCollisionRangesNumber];
	mStreamingTasks = new SPhysics::SPTask*[mStreamingRangesNumber];
#endif

	for (int i = 0; i < mCollisionRangesNumber; i++)
	{
		mLattice.getCollisionRange(i, mCollisionParams[i].startRange, mCollisionParams[i].endRange);
	}

	for (int i = 0; i < mStreamingRangesNumber; i++)
	{
		mStreamingParams[i].rangeNumber = i;
		mLattice.getStreamingRange(i, mStreamingParams[i].startRange, mStreamingParams[i].endRange);
	}

	doCreateForceMap(realWidth, realHeight);
	Force* f = mForceMap(0, 0);

	for (int j = 0; j < realHeight; j++)
	{
		for (int i = 0; i < realWidth; i++, f++)
		{
			f->mIsSolid = mLattice(i, j).IsSolid();
			mLattice(i, j).mForce = f;
		}
	}

	f = mForceMap(0, 0);

	for (int j = 0; j < realHeight; j++)
	{
		for (int i = 0; i < realWidth; i++, f++)
		{
			bool isSolid = f->mIsSolid;

			for (int k = 0; !isSolid && k < gSPADneighbor_count; k++)
			{
				if (!mForceMap.doCheckNeighbor(k, i, j) || mForceMap.isNeighborSolid(k, i, j))
				{
					isSolid = true;
					break;
				}
			}

			f->mToAddVelocity = !isSolid;
		}
	}

	mBrush = new Brush(11);
	mBrush->setForceMap(&mForceMap);
	mBrush->setForceMapInterface(this);
	mBrush->setScaleLength(1.5f);
	mPresetParams.brushSize = 0.2f;
	mPresetParams.viscosity = 0.07f;
	mPresetParams.curvature = 20.0f;
	mPresetParams.diffusion = 0.05f;
#ifdef AERODYNAMICS_MULTI_THREAD

	for (int i = 0; i < mCollisionRangesNumber; i++)
	{
		mCollisionTasks[i] = mTaskPool->select();
	}

	for (int i = 0; i < mStreamingRangesNumber; i++)
	{
		mStreamingTasks[i] = mTaskPool->select();
	}

#endif
#ifdef AERODYNAMICS_MULTI_THREAD
	mEvents = new SPhysics::SPEvent[mStreamingRangesNumber];
	eventDispatcher->bindEvents(mEvents);
	setEventDispatcher(eventDispatcher);
#endif
	mParticleSimulation.init(mWidth, mHeight, mDepth, &mLattice, aAnimationTextureSize, aFrameSize);
	mParticleSimulation.createParticles(c_particleCount);
	mBrush->setScaleWidth(0.62f);
	loadPreset();
}

int SPADController::getXoZLatticeXOffset()
{
	return mXoZLatticeXOffset;
}

int SPADController::getXoZLatticeYOffset()
{
	return mXoZLatticeYOffset;
}

int SPADController::getZoYLatticeXOffset()
{
	return mZoYLatticeXOffset;
}

int SPADController::getZoYLatticeYOffset()
{
	return mZoYLatticeYOffset;
}

int SPADController::getLatticeWidth() const
{
	return mLattice.width();
}

int SPADController::getLatticeHeight() const
{
	return mLattice.height();
}

#ifdef AERODYNAMICS_MULTI_THREAD
void SPADController::createTaskPool(int aTasksCount)
{
	delete mTaskPool;
	mTaskPool = new SPTaskPool(aTasksCount);
}
#endif

void SPADController::setBrushParam(float aKphi1, float aKphi2, float aKphiBehavior,
		float aKbendBehavior, float aKbend, float aKellipseDeformation)
{
	mBrush->setPhiCoefficient1(aKphi1);
	mBrush->setPhiCoefficient2(aKphi2);
	mBrush->setPhiBehavior(aKphiBehavior);
	mBrush->setBendCoefficient(aKbend);
	mBrush->setBendBehavior(aKbendBehavior);
	mBrush->setEllipseDeformationCoefficient(aKellipseDeformation);
}

void SPADController::doCreateForceMap(int aWidth, int aHeight)
{
	mForceMap.init(aWidth, aHeight);
}

void SPADController::getBrushParam(float& aKphi1, float& aKphi2, float& aKphiBehavior,
		float& aKbendBehavior, float& aKbend, float& aKellipseDeformation)
{
	aKphi1 = mBrush->getPhiCoefficient1();
	aKphi2 = mBrush->getPhiCoefficient2();
	aKphiBehavior = mBrush->getPhiBehavior();
	aKbend = mBrush->getBendCoefficient();
	aKbendBehavior = mBrush->getBendBehavior();
	aKellipseDeformation = mBrush->getEllipseDeformationCoefficient();
}
void SPADController::assignAirViscosity(float aViscosity)
{
	mStreamingDemon.assignAirViscosity(aViscosity);
	mBoundaryDemon.assignAirViscosity(aViscosity);
}

void SPADController::setPauseCalculationsIfIdle(bool pauseCalculations)
{
	mPauseCalculationsIfIdle = pauseCalculations;
	mProcess = true;
	mIntentToStop = false;
}

bool SPADController::getPauseCalculationsIfIdle()
{
	return mPauseCalculationsIfIdle;
}

void SPADController::setWhetherToProcess(bool process)
{
	mProcess = process;
	mIntentToStop = false;
}

bool SPADController::getWhetherToProcess()
{
	return mProcess;
}

void SPADController::setPresetToChange(int presetID)
{
	mPresetID = presetID;
	mChangePreset = true;
}

void SPADController::loadPreset()
{
	mBrush->setScaleWidth(mPresetParams.brushSize);
	setCurvature(mPresetParams.curvature);
	mChangePreset = false;
}

bool SPADController::process()
{
	if (!mPauseCalculationsIfIdle || mProcess)
	{
		mCollisionDemon.mStopIdle = mPauseCalculationsIfIdle;
#ifndef AERODYNAMICS_MULTI_THREAD
		mLattice.walkLattice<StreamingDemon>(mStreamingDemon, Lattice<CellObject>::wtLatticeWithoutBound);
#ifdef FAST_COLLISION
		mLattice.walkLattice<FastCollisionDemon>(mFastCollisionDemon, Lattice<CellObject>::wtLatticeWithoutBound);
#else
		mLattice.walkLattice<CollisionDemon>(mCollisionDemon, Lattice<CellObject>::wtLatticeWithoutBound);
#endif
#else

		for (int i = 0; i < mCollisionRangesNumber; i++)
		{
			mCollisionTasks[i]->start<SPADController, SPADWalkLatticeRangeParams>(*this,
					&SPADController::walkLatticeRange, mCollisionParams[i]);
		}

		for (int i = 0; i < mStreamingRangesNumber; i++)
		{
			mStreamingTasks[i]->start<SPADController, SPADWalkLatticeSyncParams>(*this,
					&SPADController::walkLatticeSync, mStreamingParams[i]);
		}

		for (int i = 0; i < mStreamingRangesNumber; i++)
		{
			mStreamingTasks[i]->wait();
		}

		mLattice.walkLatticeFinal<StreamingDemon>(mStreamingDemon);
		mLattice.dropReadyRows();
		mEventDispatcher->clearReadyRows();
#endif
	}

	float currTime(static_cast<float>(clock()) / static_cast<float>(CLOCKS_PER_SEC));
	float dt(currTime - mPrevTime);
	mPrevTime = currTime;
	mParticleSimulation.simulate(c_simulationSpeed * dt);

	if (mClearFlag)
	{
		clear();
	}

	if (mChangePreset)
	{
		loadPreset();
	}

	return true;
}

void SPADController::setClearFlag()
{
	mClearFlag = true;
}
void SPADController::setFreezeFlag()
{
	mFreezeFlag = true;
}

void SPADController::clear()
{
	mForceMap.clear();

	for (int y = 0; y < mLattice.height(); y++)
	{
		for (int x = 0; x < mLattice.width(); x++)
		{
			CellObject& cellObject = mLattice(x, y);

			for (int i = 0; i < gSPADneighbor_count; i++)
			{
				cellObject.mVelocities[i] = mVelocityToAssign;
				cellObject.mTempVelocities[i] = 0.0f;
			}

			cellObject.mMass = 8.0f * mVelocityToAssign;
			cellObject.mxVelocity = 0.0f;
			cellObject.myVelocity = 0.0f;
		}
	}

#ifdef AERODYNAMICS_MULTI_THREAD
	mLattice.walkLattice<StreamingDemon>(mStreamingDemon, Lattice<CellObject>::wtLatticeWithoutBound);
#endif
	mClearFlag = false;
}

void SPADController::freeze()
{
}

void SPADController::resetVelocities()
{
	for (int y = 1; y < mLattice.height() - 1; y++)
	{
		for (int x = 1; x < mLattice.width() - 1; x++)
		{
			CellObject& cellObject = mLattice(x, y);

			for (int i = 0; i < gSPADneighbor_count; i++)
			{
				cellObject.mVelocities[i] = mVelocityToAssign;
				cellObject.mTempVelocities[i] = 0.0f;
			}

			cellObject.mMass = mVelocityToAssign * 8.0f;
			cellObject.mxVelocity = 0.0f;
			cellObject.myVelocity = 0.0f;
		}
	}

#ifdef AERODYNAMICS_MULTI_THREAD
	mLattice.walkLattice<StreamingDemon>(mStreamingDemon, Lattice<CellObject>::wtLatticeWithoutBound);
#endif
}

//#ifdef AERODYNAMICS_MULTI_THREAD
void SPADController::walkLatticeRange(SPADWalkLatticeRangeParams aParams)
{
#ifdef FAST_COLLISION
	mLattice.walkLatticeRange<FastCollisionDemon>(
		mFastCollisionDemon,
		Lattice<CellObject>::wtLatticeWithoutBound, aParams.startRange,
		aParams.endRange, aParams.eventDispatcher);
#else
	mLattice.walkLatticeRange<CollisionDemon>(mCollisionDemon, Lattice<CellObject>::wtLatticeWithoutBound,
			aParams.startRange, aParams.endRange, aParams.eventDispatcher);
#endif
}

void SPADController::walkLatticeSync(SPADWalkLatticeSyncParams aParams)
{
	mLattice.walkLatticeSync<StreamingDemon>(mStreamingDemon, Lattice<CellObject>::wtLatticeWithoutBound,
			aParams.rangeNumber, aParams.startRange, aParams.endRange, aParams.syncEvent);
}

void SPADController::addForceMapToLattice()
{
	if (mPauseCalculationsIfIdle)
	{
		setWhetherToProcess(true);
	}
}

float SPADController::getPhi() const
{
	return mBrush->getPhi();
}

ForceTool* SPADController::getTouchHandler()
{
	return mBrush;
}

}    // namespace SPhysics
