/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * TODO
 * @file   SPADConfiguration.h
 * @brief
 * @author Author ()
 */

#ifndef AERODYNAMICSCONFIGURATION_H_A2C1B8E2DC6949A1B2D0B55FD73B86BA
#define AERODYNAMICSCONFIGURATION_H_A2C1B8E2DC6949A1B2D0B55FD73B86BA

#include <gtc/constants.hpp>
#include "SPException.h"
#include <math.h>
#include <float.h>

namespace SPhysics
{

#define LEFT_NEIGHBOR_INDEX 1
#define RIGHT_NEIGHBOR_INDEX 6

// #define AERODYNAMICS_MULTI_THREAD
#define SKIP_SOLVE
#define TESTING
// #define FAST_COLLISION
#define DIRECT_NEIGHBOR_ACCESS

//*********************************************************************
//****************************INIT PARAMS******************************
//*********************************************************************
const int gSPADl_bellPointsNumber = 3000;
const float gSPADl_transferringCoefficient = 0.97f;    //0.99f;
const float l_draftCoeff = 0.001f;
#ifdef FAST_COLLISION
const float gSPADl_minCurvature = 3300.0f;    //3750.0f;
const float gSPADl_forceCoefficient = 80.0f;//60.0f;    //0.37f;
#else
const float gSPADl_minCurvature = 30.0f;    //20.0f;    //3750.f;    //20.0f;
const float gSPADl_forceCoefficient = 0.37f;    //0.37f;
#endif
const float gSPADl_velocityToAssign = 20.0f;
const float gSPADl_heightForceCoefficient = 60.1f;    //40.0f;    //capillarity force
const int gSPADl_collisionRangeNumber = 4;
const int gSPADl_streamingRangeNumber = 4;

const int c_particleCount = 4000;

const float c_depthOutput = 2.0f;

const float c_simulationSpeed = 2.5f;

const int c_particleMaxCount = 4000;

const float l_velocityMul = 0.5f;
const float l_min_height = 0.4f;

const float c_particleSimulationQuality = 1.0f;

const float c_particleFricition = 0.2f;    //0.1f;
const float c_particleVelocitySense = 3.f;    //7.0f;//20.0f;
const float c_particleGravity = 8.0f;    //2.0f;
const float c_particleBounce = 0.25f;    //0.5f * 0.5f /* half to reduce calc*/;
const float c_particleBounceToEdge = 1.0f;
const float c_particleVelocityCurvature = 0.01f;    //.01f;
const float c_particleRadius = 0.5f * c_particleSimulationQuality;

const int c_particleNeighborCount = 13;
const float c_radiusOutput = 8.0f;

const float c_radiusForceFromCorner = 40.0f;
const int c_stepsFromCorner = 8;

const double c_cosine_for_spot = 0.08715574274765817355806427083747;

const bool onlyPositiveZ = false;

//*********************************************************************
//****************************INIT PARAMS******************************
//*********************************************************************
//*********************************************************************
//****************************INIT PARAMS FOR BRUSH********************
//*********************************************************************
const float maxZToTouch = 1.0f;
const float gSPADk_friction = 0.6f;
const int gSPADl_steps = 10;
//const float l_min_dx = 0.0001f;
//*********************************************************************
const float gSPADl_dt = 1 / (float)gSPADl_steps;
//const float l_ellipse_width = 7.0f;
//const float gSPADl_ellipse_length = 15.0f;

/**
 * TODO - give short up description to each constant
 */
static const int gSPADneighbor_count = 8;
//static const int c_neighbor_count_with_self = gSPDAneighbor_count + 1;
static const float gSPADneighbor_count_inverse = 1.0f / (float)gSPADneighbor_count;
static const int gSPADopposite_directions_sum = 7;

//NOT USED - a lie
extern const float gSPADex[gSPADneighbor_count];
extern const float gSPADey[gSPADneighbor_count];
static const float gSPADcurvature = 50.0f;

}    // namespace SPhysics

#endif // _INKCONFIGURATION_H_
