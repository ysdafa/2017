/**
* @file SPRectImageDrawer.h
* @brief This file includes module that draws background image
*
* @date 2015-02-10
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_RECT_IMAGE_DRAWAVER_H_
#define _SP_RECT_IMAGE_DRAWAVER_H_

#include "SPIRenderer.h"
#include "SPMesh.h"

#include "glm.hpp"
#include <string>


namespace SPhysics
{
	/**
	* @class     SPIceParticleDrawer
	* @brief     This class is mainly for Drawing Background and supports Mesh setting, color setting, etc,.
	*/
	class SPRectImageDrawer : public SPIRenderer
	{
	public:
		/**
		* @brief     Constructor
		*/
		SPRectImageDrawer();
		/**
		* @brief     Destructor
		*/
		~SPRectImageDrawer();

		/**
		* @brief     Initialize and Prepare rendering\n
		(set camera setting, initialize shader , create rectangle mesh)
		* @param     [IN] float width Clipping Plane's width size
		* @param     [IN] float height Clipping Plane's height size
		* @return     void
		*/
		void initRender(float width, float height); // virtual

		/**
		* @brief     Mesh setting & binding shader variables for drawing.
		* @return     void
		 */
		void drawRender(); // virtual

		/**
		* @brief     Set the texture to rectangle
		* @param     [IN] @b fileName File name of texture
		* @return     void
		*/
		void setTexture(const SPChar *fileName);

		/**
		* @brief     return the current texture ID
		* @return     SPUInt
		*/
		SPUInt getTextureID();

	protected:

		virtual void initShadersCode(std::string& aVertexShader, std::string& aFragmentShader) = 0;

		/**
		* @brief     Create mesh data
		* @param     [IN] @b width Rectangle width size
		* @param     [IN] @b height Rectangle height size
		* @return     void
		*/
		void createMesh();

		SPMesh m_cMesh;			//!< Mesh
		SPUInt m_TextureId;		//!< Texture Id

	};

}//namespace SPhysics

#endif /*_SP_RECT_IMAGE_DRAWAVER_H_ */
