/**
* @file SPIceMaskDrawer.cpp
* @brief
*
* @date 2015-02-10
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPTextureManager.h"
#include "SPRectImageDrawer.h"

#include <gtx/transform.hpp>

#include "SPException.h"

#include <SPLog.h>

namespace SPhysics
{
	SPRectImageDrawer::SPRectImageDrawer():
		m_TextureId(-1)
	{
	}

	SPRectImageDrawer::~SPRectImageDrawer()
	{
	}

	void SPRectImageDrawer::initRender(float width, float height)
	{
		ARGUMENT_VALUE_CHECK(width <= 0);
		ARGUMENT_VALUE_CHECK(height <= 0);

		m_ScreenWidth = width;
		m_ScreenHeight= height;

		float ratio = m_ScreenWidth / m_ScreenHeight;
		setOrthogonalCameraView(-1.0f * ratio, 1.0f * ratio, -1.0f, 1.0f, 1.0f, 100.0f);
		setLookAt(0.0f, 0.0f, 10.0f, 0.0f, 0.0f, 0.0f, 0.f, 1.0f, 0.0f);

		createMesh();

		std::string vertexShader;
		std::string fragmentShader;

		initShadersCode(vertexShader, fragmentShader);

		createShaderProgram(vertexShader.c_str(), fragmentShader.c_str());
	}

	void SPRectImageDrawer::drawRender()
	{
	}

	void SPRectImageDrawer::setTexture(const char *fileName )
	{
		m_TextureId = SPTextureManager::getInstancePtr()->loadTexture(fileName);
	}

	SPUInt SPRectImageDrawer::getTextureID()
	{
		return m_TextureId;
	}

	void SPRectImageDrawer::createMesh()
	{
		m_cMesh.reset();

		// Rect Vertex
		//     P3                  P4
		//     * ----------------- *
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1                  P2

		m_cMesh.m_tVertex.clear();
		m_cMesh.m_tVertex.resize(4);

		// create rect vertex position
		// LeftTop Align Rect Vertex

		m_cMesh.m_tVertex[0] = SPVec3f(-1.0f, -1.0f, 0.0f);		// point 1
		m_cMesh.m_tVertex[1] = SPVec3f( 1.0f, -1.0f, 0.0f);		// point 2
		m_cMesh.m_tVertex[2] = SPVec3f(-1.0f,  1.0f, 0.0f);		// point 3
		m_cMesh.m_tVertex[3] = SPVec3f( 1.0f,  1.0f, 0.0f);		// point 4
		
		//create rect vertex index
		m_cMesh.m_tVertexIndex.clear();

		m_cMesh.m_tVertexIndex.push_back(0);
		m_cMesh.m_tVertexIndex.push_back(1);
		m_cMesh.m_tVertexIndex.push_back(2);
		m_cMesh.m_tVertexIndex.push_back(3);

		// Rect Vertex
		//     P3(0,0)            P4(1,0)
		//     * ----------------- *
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1(0,1)            P2(1.1)

		m_cMesh.m_tTextureUV.clear();
		m_cMesh.m_tTextureUV.resize(4);

		m_cMesh.m_tTextureUV[0] = SPVec3f(0.0f, 1.0f, 0.0f);		// point 1
		m_cMesh.m_tTextureUV[1] = SPVec3f(1.0f, 1.0f, 0.0f);		// point 2
		m_cMesh.m_tTextureUV[2] = SPVec3f(0.0f, 0.0f, 0.0f);		// point 3
		m_cMesh.m_tTextureUV[3] = SPVec3f(1.0f, 0.0f, 0.0f);		// point 4

		setMesh(&m_cMesh);
	}
}//namespace SPhysics
