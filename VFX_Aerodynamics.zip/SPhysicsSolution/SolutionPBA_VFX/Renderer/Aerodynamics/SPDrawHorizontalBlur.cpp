/**
* @file SPDrawTextureToFBO.cpp
* @brief 
*
* @date 2014-06-19
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPTextureManager.h"
#include "SPDrawHorizontalBlur.h"

#include <sstream>

namespace
{
	static glm::vec2 gPostEffectPosition[] =
	{
		glm::vec2(-1.0f, -1.0f),
		glm::vec2(-1.0f, 1.0f),
		glm::vec2(1.0f, 1.0f),
		glm::vec2(1.0f, 1.0f),
		glm::vec2(1.0f, -1.0f),
		glm::vec2(-1.0f, -1.0f),
	};

	static glm::vec2 gPostEffectUV[] =
	{
		glm::vec2(0.0f, 0.0f),
		glm::vec2(0.0f, 1.0f),
		glm::vec2(1.0f, 1.0f),
		glm::vec2(1.0f, 1.0f),
		glm::vec2(1.0f, 0.0f),
		glm::vec2(0.0f, 0.0f),
	};
}

namespace SPhysics
{
	SPDrawHorizontalBlur::SPDrawHorizontalBlur(SPUInt aTextureId)
							 : mTextureId(aTextureId)
	{
	}

	SPDrawHorizontalBlur::~SPDrawHorizontalBlur()
	{
	}

	SPVoid SPDrawHorizontalBlur::initRender(SPFloat width, SPFloat height)
	{
		SPChar VertexShader[] =  
			"precision mediump float;\n"
			"attribute vec4 aPosition;\n"
			"attribute vec2 aUV;\n"

			"uniform vec2 uFilterKernel[7];\n"

			"varying vec2 vInterpTap0;\n"
			"varying vec2 vInterpTap1;\n"
			"varying vec2 vInterpTap2;\n"
			"varying vec2 vInterpTap3;\n"
			"varying vec2 vInterpTap1Neg;\n"
			"varying vec2 vInterpTap2Neg;\n"
			"varying vec2 vInterpTap3Neg;\n"

			"void main()\n"
			"{\n"
			"    gl_Position = aPosition;\n"

			"    vInterpTap0 = aUV;\n"
			"    vInterpTap1 = aUV + uFilterKernel[1];\n"
			"    vInterpTap2 = aUV + uFilterKernel[2];\n"
			"    vInterpTap3 = aUV + uFilterKernel[3];\n"
			"    vInterpTap1Neg = aUV - uFilterKernel[1];\n"
			"    vInterpTap2Neg = aUV - uFilterKernel[2];\n"
			"    vInterpTap3Neg = aUV - uFilterKernel[3];\n"
			"}\n";

		SPChar FragmentShader[] =
			"precision mediump float;\n"
			"const vec4 thresh0 = vec4( 0.1, 0.3, 0.5, -0.01 );\n"
			"const vec4 thresh1 = vec4( 0.6, 0.7, 0.8, 0.9 );\n"

			"uniform sampler2D uTexture;\n"
			"uniform vec2 uFilterKernel[7];\n"

			"varying vec2 vInterpTap0;\n"
			"varying vec2 vInterpTap1;\n"
			"varying vec2 vInterpTap2;\n"
			"varying vec2 vInterpTap3;\n"
			"varying vec2 vInterpTap1Neg;\n"
			"varying vec2 vInterpTap2Neg;\n"
			"varying vec2 vInterpTap3Neg;\n"

			"void main()\n"
			"{\n"
			"    vec4 s0, s1, s2, s3, s4, s5, s6;\n"
			"    vec4 weights4;\n"
			"    vec3 weights3;\n"
			"    vec4 colorSum;\n"
			"    float weightSum;\n"

			"    s0 = texture2D( uTexture, vInterpTap0 );\n"
			"    s1 = texture2D( uTexture, vInterpTap1 );\n"
			"    s2 = texture2D( uTexture, vInterpTap2 );\n"
			"    s3 = texture2D( uTexture, vInterpTap3 );\n"
			"    s4 = texture2D( uTexture, vInterpTap1Neg );\n"
			"    s5 = texture2D( uTexture, vInterpTap2Neg );\n"
			"    s6 = texture2D( uTexture, vInterpTap3Neg );\n"

			"    weights4.x = clamp( s1.a - thresh0.x, 0.0, 1.0 );\n"
			"    weights4.y = clamp( s2.a - thresh0.y, 0.0, 1.0 );\n"
			"    weights4.z = clamp( s3.a - thresh0.z, 0.0, 1.0 );\n"
			"    weights4.w = clamp( s0.a - thresh0.w, 0.0, 1.0 );\n"

			"    colorSum = s0 * weights4.x + s1 * weights4.y + s2 * weights4.z + s3 * weights4.w;\n"
			"    weightSum = dot( weights4, vec4( 1.0 ) );\n"

			"    weights3.x = clamp( s4.a - thresh0.x, 0.0, 1.0 );\n"
			"    weights3.y = clamp( s5.a - thresh0.y, 0.0, 1.0 );\n"
			"    weights3.z = clamp( s6.a - thresh0.z, 0.0, 1.0 );\n"

			"    colorSum += s4 * weights3.x + s5 * weights3.y + s6 * weights3.z;\n"
			"    weightSum += dot( weights3, vec3( 1.0 ) );\n"

			"    // step 2\n"
			"    vec2 tap4 = vInterpTap0 + uFilterKernel[4];\n"
			"    vec2 tap5 = vInterpTap0 + uFilterKernel[5];\n"
			"    vec2 tap6 = vInterpTap0 + uFilterKernel[6];\n"
			"    vec2 tap4Neg = vInterpTap0 - uFilterKernel[4];\n"
			"    vec2 tap5Neg = vInterpTap0 - uFilterKernel[5];\n"
			"    vec2 tap6Neg = vInterpTap0 - uFilterKernel[6];\n"

			"    s0 = texture2D( uTexture, tap4 );\n"
			"    s1 = texture2D( uTexture, tap5 );\n"
			"    s2 = texture2D( uTexture, tap6 );\n"
			"    s3 = texture2D( uTexture, tap4Neg );\n"
			"    s4 = texture2D( uTexture, tap5Neg );\n"
			"    s5 = texture2D( uTexture, tap6Neg );\n"

			"    weights3.x = clamp( s0.a - thresh1.x, 0.0, 1.0 );\n"
			"    weights3.y = clamp( s1.a - thresh1.y, 0.0, 1.0 );\n"
			"    weights3.z = clamp( s2.a - thresh1.z, 0.0, 1.0 );\n"

			"    colorSum += s0 * weights3.x + s1 * weights3.y + s2 * weights3.z;\n"
			"    weightSum += dot( weights3, vec3( 1.0 ) );\n"

			"    weights3.x = clamp( s3.a - thresh1.x, 0.0, 1.0 );\n"
			"    weights3.y = clamp( s4.a - thresh1.y, 0.0, 1.0 );\n"
			"    weights3.z = clamp( s5.a - thresh1.z, 0.0, 1.0 );\n"

			"    colorSum += s3 * weights3.x + s4 * weights3.y + s5 * weights3.z;\n"
			"    weightSum += dot( weights3, vec3( 1.0 ) );\n"

			"    colorSum /= weightSum;\n"

			"    gl_FragColor = vec4( colorSum.rgb, weightSum );\n"
			"}\n";

		float dx(1.f / width);
		mV[0] = glm::vec2(0.0f);
		mV[1] = glm::vec2(1.3366f * dx, 0.f);
		mV[2] = glm::vec2(3.4295f * dx, 0.f);
		mV[3] = glm::vec2(5.4264f * dx, 0.f);
		mV[4] = glm::vec2(7.4359f * dx, 0.f);
		mV[5] = glm::vec2(9.4436f * dx, 0.f);
		mV[6] = glm::vec2(11.4401f * dx, 0.f);
		
		createShaderProgram(VertexShader, FragmentShader);
	}

	SPVoid SPDrawHorizontalBlur::drawRender()
	{
		glDisable(GL_DEPTH_TEST);
		glDisable(GL_BLEND);

		setShaderArrayVector("aPosition", &gPostEffectPosition[0].x, 2);
		setShaderArrayVector("aUV", &gPostEffectUV[0].x, 2);
		setShaderUnifromTexture("uTexture", mTextureId);

		for (int i(0); i < 7; ++i)
		{
			std::stringstream out;
			out << "uFilterKernel[" << i << "]";
			setShaderUniformVector(out.str().c_str(), & mV[i].x, 2);
		}

		setCustomDrawArrays(6, _DRAW_OPTION::DRAW_TRIANGLES);
	}

	SPVoid SPDrawHorizontalBlur::setTexture(const SPUInt aTextureId)
	{
		mTextureId = aTextureId;
	}

}//namespace SPhysics
