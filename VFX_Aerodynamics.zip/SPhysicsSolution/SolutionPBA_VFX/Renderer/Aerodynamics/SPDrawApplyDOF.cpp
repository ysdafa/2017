/**
* @file SPDrawTextureToFBO.cpp
* @brief 
*
* @date 2014-06-19
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPTextureManager.h"
#include "SPDrawApplyDOF.h"

namespace
{
	static glm::vec2 gPostEffectPosition[] =
	{
		glm::vec2(-1.0f, -1.0f),
		glm::vec2(-1.0f, 1.0f),
		glm::vec2(1.0f, 1.0f),
		glm::vec2(1.0f, 1.0f),
		glm::vec2(1.0f, -1.0f),
		glm::vec2(-1.0f, -1.0f),
	};

	static glm::vec2 gPostEffectUV[] =
	{
		glm::vec2(0.0f, 0.0f),
		glm::vec2(0.0f, 1.0f),
		glm::vec2(1.0f, 1.0f),
		glm::vec2(1.0f, 1.0f),
		glm::vec2(1.0f, 0.0f),
		glm::vec2(0.0f, 0.0f),
	};
}

namespace SPhysics
{
	SPDrawApplyDOF::SPDrawApplyDOF(const SPUInt aImageTextureId,
								   const SPUInt aBluredTextureId)
							 : mImageTextureId(aImageTextureId)
							 , mBluredTextureId(aBluredTextureId)
	{
	}

	SPDrawApplyDOF::~SPDrawApplyDOF()
	{
	}

	SPVoid SPDrawApplyDOF::initRender(SPFloat width, SPFloat height)
	{
		SPChar VertexShader[] =
			"precision mediump float;\n"

			"// particle scale system with animation\n"
			"attribute vec4 aPosition;\n"
			"attribute vec2 aUV;\n"

			"varying vec2 vInterpUV;\n"

			"void main()\n"
			"{\n"
			"    gl_Position = aPosition;\n"
			"    vInterpUV = aUV;\n"
			"}\n";

		SPChar FragmentShader[] =
			"precision mediump float;\n"

			"uniform sampler2D uImage;\n"
			"uniform sampler2D uBlur;\n"

			"varying vec2 vInterpUV;\n"

			"void main()\n"
			"{\n"
			"    vec4 imageColor = texture2D( uImage, vInterpUV );\n"
			"    vec4 blurColor = texture2D( uBlur, vInterpUV );\n"
			"    vec3 finalColor = mix( imageColor.rgb, blurColor.rgb, imageColor.a );\n"
			"    gl_FragColor = vec4( finalColor, 1.0 );\n"
			"}\n";
		
		createShaderProgram(VertexShader, FragmentShader);
	}

	SPVoid SPDrawApplyDOF::drawRender()
	{
		glDisable(GL_DEPTH_TEST);
		glDisable(GL_BLEND);

		setShaderArrayVector("aPosition", (SPFloat*)&gPostEffectPosition[0].x, 2);
		setShaderArrayVector("aUV", (SPFloat*)&gPostEffectUV[0].x, 2);
		setShaderUnifromTexture("uImage", mImageTextureId);
		setShaderUnifromTexture("uBlur", mBluredTextureId);

		setCustomDrawArrays(6, _DRAW_OPTION::DRAW_TRIANGLES);
	}

}//namespace SPhysics
