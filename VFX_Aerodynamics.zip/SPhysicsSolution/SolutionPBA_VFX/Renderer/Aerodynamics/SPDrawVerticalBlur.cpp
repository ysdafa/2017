/**
* @file SPDrawTextureToFBO.cpp
* @brief 
*
* @date 2014-06-19
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPTextureManager.h"
#include "SPDrawVerticalBlur.h"
#include <sstream>

namespace
{
	static glm::vec2 gPostEffectPosition[] =
	{
		glm::vec2(-1.0f, -1.0f),
		glm::vec2(-1.0f, 1.0f),
		glm::vec2(1.0f, 1.0f),
		glm::vec2(1.0f, 1.0f),
		glm::vec2(1.0f, -1.0f),
		glm::vec2(-1.0f, -1.0f),
	};

	static glm::vec2 gPostEffectUV[] =
	{
		glm::vec2(0.0f, 0.0f),
		glm::vec2(0.0f, 1.0f),
		glm::vec2(1.0f, 1.0f),
		glm::vec2(1.0f, 1.0f),
		glm::vec2(1.0f, 0.0f),
		glm::vec2(0.0f, 0.0f),
	};
}

namespace SPhysics
{
	SPDrawVerticalBlur::SPDrawVerticalBlur(SPUInt aTextureId)
							 : mTextureId(aTextureId)
	{
	}

	SPDrawVerticalBlur::~SPDrawVerticalBlur()
	{
	}

	SPVoid SPDrawVerticalBlur::initRender(SPFloat width, SPFloat height)
	{
		SPChar VertexShader[] =  
			"precision mediump float;\n"
			"attribute vec4 aPosition;\n"
			"attribute vec2 aUV;\n"

			"uniform vec2 uFilterKernel[7];\n"

			"varying vec2 vInterpTap0;\n"
			"varying vec2 vInterpTap1;\n"
			"varying vec2 vInterpTap2;\n"
			"varying vec2 vInterpTap3;\n"
			"varying vec2 vInterpTap1Neg;\n"
			"varying vec2 vInterpTap2Neg;\n"
			"varying vec2 vInterpTap3Neg;\n"

			"void main()\n"
			"{\n"
			"    gl_Position = aPosition;\n"

			"    vInterpTap0 = aUV;\n"
			"    vInterpTap1 = aUV + uFilterKernel[1];\n"
			"    vInterpTap2 = aUV + uFilterKernel[2];\n"
			"    vInterpTap3 = aUV + uFilterKernel[3];\n"
			"    vInterpTap1Neg = aUV - uFilterKernel[1];\n"
			"    vInterpTap2Neg = aUV - uFilterKernel[2];\n"
			"    vInterpTap3Neg = aUV - uFilterKernel[3];\n"
			"}\n";

		SPChar FragmentShader[] =  
			"precision mediump float;\n"
			"const vec4 weights0 = vec4( 0.080, 0.075, 0.070, 0.100 );\n"
			"const vec4 weights1 = vec4( 0.065, 0.060, 0.055, 0.050 );\n"

			"uniform sampler2D uTexture;\n"
			"uniform vec2 uFilterKernel[7];\n"

			"varying vec2 vInterpTap0;\n"
			"varying vec2 vInterpTap1;\n"
			"varying vec2 vInterpTap2;\n"
			"varying vec2 vInterpTap3;\n"
			"varying vec2 vInterpTap1Neg;\n"
			"varying vec2 vInterpTap2Neg;\n"
			"varying vec2 vInterpTap3Neg;\n"

			"void main()\n"
			"{\n"
			"    vec4 s0, s1, s2, s3, s4, s5, s6;\n"
			"    vec4 colorWeightSum;\n"

			"    s0 = texture2D( uTexture, vInterpTap0 );\n"
			"    s1 = texture2D( uTexture, vInterpTap1 );\n"
			"    s2 = texture2D( uTexture, vInterpTap2 );\n"
			"    s3 = texture2D( uTexture, vInterpTap3 );\n"
			"    s4 = texture2D( uTexture, vInterpTap1Neg );\n"
			"    s5 = texture2D( uTexture, vInterpTap2Neg );\n"
			"    s6 = texture2D( uTexture, vInterpTap3Neg );\n"

			"    s0.rgb = s0.rgb * s0.a;\n"
			"    s1.rgb = s1.rgb * s1.a;\n"
			"    s2.rgb = s2.rgb * s2.a;\n"
			"    s3.rgb = s3.rgb * s3.a;\n"
			"    s4.rgb = s4.rgb * s4.a;\n"
			"    s5.rgb = s5.rgb * s5.a;\n"
			"    s6.rgb = s6.rgb * s6.a;\n"

			"    colorWeightSum = s0 * weights0.w + \n"
			"        ( s1 + s4 ) * weights0.x +\n"
			"        ( s2 + s5 ) * weights0.y +\n"
			"        ( s3 + s6 ) * weights0.z;\n"

			"    // step 2\n"
			"    vec2 tap4 = vInterpTap0 + uFilterKernel[4];\n"
			"    vec2 tap5 = vInterpTap0 + uFilterKernel[5];\n"
			"    vec2 tap6 = vInterpTap0 + uFilterKernel[6];\n"
			"    vec2 tap4Neg = vInterpTap0 - uFilterKernel[4];\n"
			"    vec2 tap5Neg = vInterpTap0 - uFilterKernel[5];\n"
			"    vec2 tap6Neg = vInterpTap0 - uFilterKernel[6];\n"

			"    s0 = texture2D( uTexture, tap4 );\n"
			"    s1 = texture2D( uTexture, tap5 );\n"
			"    s2 = texture2D( uTexture, tap6 );\n"
			"    s3 = texture2D( uTexture, tap4Neg );\n"
			"    s4 = texture2D( uTexture, tap5Neg );\n"
			"    s5 = texture2D( uTexture, tap6Neg );\n"

			"    s0.rgb = s0.rgb * s0.a;\n"
			"    s1.rgb = s1.rgb * s1.a;\n"
			"    s2.rgb = s2.rgb * s2.a;\n"
			"    s3.rgb = s3.rgb * s3.a;\n"
			"    s4.rgb = s4.rgb * s4.a;\n"
			"    s5.rgb = s5.rgb * s5.a;\n"

			"    colorWeightSum += ( s1 + s3 ) * weights1.x + \n"
			"        ( s1 + s4 ) * weights1.y +\n"
			"        ( s3 + s5 ) * weights1.z;\n"

			"    colorWeightSum.rgb /= colorWeightSum.a;\n"

			"    gl_FragColor = colorWeightSum;\n"
			"}\n";

		SPFloat dy(1.f / height);
		mV[0] = glm::vec2(0.0f);
		mV[1] = glm::vec2(0.f, 1.3366f * dy);
		mV[2] = glm::vec2(0.f, 3.4295f * dy);
		mV[3] = glm::vec2(0.f, 5.4264f * dy);
		mV[4] = glm::vec2(0.f, 7.4359f * dy);
		mV[5] = glm::vec2(0.f, 9.4436f * dy);
		mV[6] = glm::vec2(0.f, 11.4401f * dy);
		
		createShaderProgram(VertexShader, FragmentShader);
	}

	SPVoid SPDrawVerticalBlur::drawRender()
	{
		glDisable(GL_DEPTH_TEST);
		glDisable(GL_BLEND);

		setShaderArrayVector("aPosition", &gPostEffectPosition[0].x, 2);
		setShaderArrayVector("aUV", &gPostEffectUV[0].x, 2);
		setShaderUnifromTexture("uTexture", mTextureId);

		for (int i(0); i < 7; ++i)
		{
			std::stringstream out;
			out << "uFilterKernel[" << i << "]";
			setShaderUniformVector(out.str().c_str(), & mV[i].x, 2);
		}

		setCustomDrawArrays(6, DRAW_TRIANGLES);
	}

	SPVoid SPDrawVerticalBlur::setTexture(const SPUInt aTextureId)
	{
		mTextureId = aTextureId;
	}

}//namespace SPhysics
