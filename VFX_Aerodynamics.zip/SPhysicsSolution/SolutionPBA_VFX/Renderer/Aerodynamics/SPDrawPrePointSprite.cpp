/**
* @file SPDrawPrePointSprite.cpp
* @brief 
*
* @date 2014-06-17
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPTextureManager.h"
#include "SPDrawPrePointSprite.h"

namespace SPhysics
{
	SPDrawPrePointSprite::SPDrawPrePointSprite(glm::vec3* aPositions,
							 glm::vec2* aFramePitch,
							 unsigned int aDiffuseTextureId,
							 float aSpriteSize,
							 glm::vec2& aFrameSizeInTextureCoord,
							 float aAlphaDiscardBorder,
							 unsigned int aPointCount)
							 : mPositions(aPositions)
							 , mFramePitch(aFramePitch)
							 , mDiffuseTextureId(aDiffuseTextureId)
							 , mRTSize()
							 , mSpriteSize(aSpriteSize)
							 , mFrameSizeInTextureCoord(aFrameSizeInTextureCoord)
							 , mAlphaDiscardBorder(aAlphaDiscardBorder)
							 , mHeightOfNearPlane()
							 , mPointCount(aPointCount)
	{
	}

	SPDrawPrePointSprite::~SPDrawPrePointSprite()
	{
	}

	SPVoid SPDrawPrePointSprite::initRender(SPFloat width, SPFloat height )
	{
		mRTSize = glm::vec2(width, height);
		setPerspectiveCameraView(90.0f, width / height, 1.0f, 1000.0f);
		setLookAt(0.f, 0.f, 0.f, 0.f, 0.f, -1.f, 0.f, -1.f, 0.f);

		SPChar VertexShader[] =  
			"// glsl pba PWS Vertex Shader\n"
			"// animated point sprites depth\n"
			"// author: Oleksandr Melnychuck\n"

			"//#version 100\n"
			"precision mediump float;\n"
			"// particle scale system with animation\n"
			"attribute vec4 aPosition;\n"
			"attribute vec2 aFramePitch;\n"
			"uniform mat4 uModelViewProjectionMatrix;\n"
			"uniform float uHeightOfNearPlane;\n"
			"uniform float uSpriteSize;\n"
			"varying vec2 vInterpFramePitch;\n"

			"void main()\n"
			"{\n"
			"    // perspective\n"
			"    gl_Position = uModelViewProjectionMatrix * aPosition;\n"
			"    gl_PointSize = ( uHeightOfNearPlane * uSpriteSize ) / gl_Position.w;\n"
			"    vInterpFramePitch = aFramePitch;\n"
			"}\n";

		SPChar FragmentShader[] =  
			"// glsl pba PWS Fragment Shader\n"
			"// animated point sprites depth\n"
			"// author: Oleksandr Melnychuck\n"

			"//#version 100\n"
			"precision mediump float;\n"
			"uniform sampler2D uDiffuseTexture;\n"
			"uniform vec2 uFrameSize;\n"
			"uniform float uAlphaDiscardBorder;\n"
			"varying vec2 vInterpFramePitch;\n"

			"void main()\n"
			"{\n"
			"    vec2 uv = gl_PointCoord.xy * uFrameSize + vInterpFramePitch;\n"
			"    vec4 color = texture2D( uDiffuseTexture, uv );\n"
			"    if( color.a <= uAlphaDiscardBorder )\n"
			"        discard;\n"
			"    gl_FragColor = color;\n"
			"}\n";
		
		createShaderProgram(VertexShader, FragmentShader);
	}

	SPVoid SPDrawPrePointSprite::drawRender()
	{
		glEnable(GL_DEPTH_TEST);
		glDepthFunc(GL_LESS);
		glDisable(GL_BLEND);
		glColorMask(false, false, false, false);
		glDepthMask(GL_TRUE);

		setShaderArrayVector("aPosition", (SPFloat*)&mPositions->x, 3);
		setShaderArrayVector("aFramePitch", (SPFloat*)&mFramePitch->x, 2);

		setShaderUniformMVPMatrix("uModelViewProjectionMatrix");
		setShaderUniformVector("uHeightOfNearPlane", &mHeightOfNearPlane, 1);
		setShaderUniformVector("uSpriteSize", &mSpriteSize, 1);
		setShaderUniformVector("uFrameSize", (SPFloat*)&mFrameSizeInTextureCoord.x, 2);
		setShaderUniformVector("uAlphaDiscardBorder", &mAlphaDiscardBorder, 1);

		setShaderUnifromTexture("uDiffuseTexture", mDiffuseTextureId);

		setCustomDrawArrays(mPointCount, DRAW_POINT);
	}

	SPVoid SPDrawPrePointSprite::setPerspectiveCameraView(SPFloat fovy, SPFloat aspect, SPFloat nearZ, SPFloat farZ)
	{
		if(m_pRenderMVP == SPNULL)
			m_pRenderMVP = new SPMVPManager();

		m_pRenderMVP->setPerspective(fovy, aspect, nearZ, farZ);

		mHeightOfNearPlane = mRTSize.y / (2.f * tan(0.5f * fovy * 3.1415923565f / 180.f));
	}

}//namespace SPhysics
