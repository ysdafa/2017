/**
* @file SPDrawPointSprite.cpp
* @brief 
*
* @date 2014-06-19
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPTextureManager.h"
#include "SPDrawPointSprite.h"

namespace SPhysics
{
	SPDrawPointSprite::SPDrawPointSprite(glm::vec3* aPositions,
							 glm::vec2* aFramePitch,
							 unsigned int aDiffuseTextureId,
							 unsigned int aNormalTextureId,
							 unsigned int aBackgroundTextureId,
							 float aSpriteSize,
							 glm::vec2& aFrameSizeInTextureCoord,
							 float aFocalDistance,
							 float aFocalRange,
							 glm::vec3 & aVecToLight,
							 float aSpecularPower,
							 float aSpecularIntensity,
							 glm::vec3 & aLightColor,
							 float aLightIntensity,
							 float aLightAmbient,
							 unsigned int aPointCount)
							 : mPositions(aPositions)
							 , mFramePitch(aFramePitch)
							 , mDiffuseTextureId(aDiffuseTextureId)
							 , mNormalTextureId(aNormalTextureId)
							 , mBackgroundTextureId(aBackgroundTextureId)
							 , mRTSize()
							 , mSpriteSize(aSpriteSize)
							 , mFrameSizeInTextureCoord(aFrameSizeInTextureCoord)
							 , mHeightOfNearPlane()
							 , mPointCount(aPointCount)
							 , mFocalDistance(aFocalDistance)
							 , mFocalRange(aFocalRange)
							 , mVecToLight(aVecToLight)
							 , mSpecularPower(aSpecularPower)
							 , mSpecularIntensity(aSpecularIntensity)
							 , mLightColor(aLightColor)
							 , mLightIntensity(aLightIntensity)
							 , mLightAmbient(aLightAmbient)
							 , mAmbientFactor(0.f)
	{
	}

	SPDrawPointSprite::~SPDrawPointSprite()
	{
	}

	SPVoid SPDrawPointSprite::initRender(SPFloat width, SPFloat height )
	{
		mRTSize = glm::vec2(width, height);
		setPerspectiveCameraView(90.0f, width / height, 1.0f, 1000.0f);
		setLookAt(0.f, 0.f, 0.f, 0.f, 0.f, -1.f, 0.f, -1.f, 0.f);
		mAmbientFactor = std::max<float>(1.f - mLightAmbient, 0.f);
		mInvScreenSize = 1.f / mRTSize;

		SPChar VertexShader[] =  
			"precision mediump float;\n"
			"// particle scale system with animation\n"
			"attribute vec4 aPosition;\n"
			"attribute vec2 aFramePitch;\n"

			"uniform mat4 uModelViewProjectionMatrix;\n"
			"uniform mat4 uMVMatrix;\n"
			"uniform float uHeightOfNearPlane;\n"
			"uniform float uSpriteSize;\n"

			"uniform float uFocalDistance;\n"
			"uniform float uFocalRange;\n"

			"uniform vec3 uVecToLight;\n"

			"varying vec3 vInterpFramePitch;\n"
			"varying vec3 vInterpHalfVector;\n"

			"void main()\n"
			"{\n"
			"    // perspective\n"
			"    gl_Position = uModelViewProjectionMatrix * aPosition;\n"
			"    gl_PointSize = ( uHeightOfNearPlane * uSpriteSize ) / gl_Position.w;\n"

			"    vec3 viewPosition = ( uMVMatrix * aPosition ).xyz;\n"
			"    vInterpFramePitch.xy = aFramePitch;\n"
			"    vInterpFramePitch.z = abs( viewPosition.z + uFocalDistance ) / uFocalRange;\n"
			"    vec3 vecToViewer = normalize( - viewPosition );\n"
			"    vInterpHalfVector = normalize( vecToViewer + uVecToLight );\n"
			"}\n";

		SPChar FragmentShader[] =  
			"precision mediump float;\n"
			"uniform sampler2D uDiffuseTexture;\n"
			"uniform sampler2D uNormalTexture;\n"
			"uniform sampler2D uBackgroundTexture;\n"

			"uniform vec3 uVecToLight;\n"
			"uniform float uSpecularPower;\n"
			"uniform float uSpecularIntensity;\n"
			"uniform vec3 uLightColor;\n"
			"uniform float uLightIntensity;\n"
			"uniform float uLightAmbient;\n"
			"uniform vec2 uFrameSize;\n"
			"uniform float uAmbientFactor;\n"
			"uniform vec2 uInvScreenSize;\n"

			"varying vec3 vInterpFramePitch;\n"
			"varying vec3 vInterpHalfVector;\n"

			"void main()\n"
			"{\n"
			"    vec2 uv = gl_PointCoord.xy * uFrameSize + vInterpFramePitch.xy;\n"
			"    vec4 color = texture2D( uDiffuseTexture, uv );\n"

			"    vec4 back = texture2D( uBackgroundTexture, gl_FragCoord.xy * uInvScreenSize );\n"
			"    color.rgb = color.rgb * color.a + back.rgb * ( 1.0 - color.a );\n"

			"    vec3 normal = normalize( texture2D( uNormalTexture, uv ).rgb * 2.0 - 1.0 );\n"
			"    float diffuseFactor = max( dot( uVecToLight, normal ), 0.0 );\n"
			"    float specularFactor = pow( max( dot( normal, vInterpHalfVector ), 0.0 ), uSpecularPower );\n"

			"    gl_FragColor = vec4( color.xyz * uLightAmbient + uLightColor * uAmbientFactor * uLightIntensity *\n"
			"        ( color.xyz * diffuseFactor + specularFactor * uSpecularIntensity ), vInterpFramePitch.z );\n"
			// "    gl_FragColor = vec4( color );\n"
			"}\n";
		
		createShaderProgram(VertexShader, FragmentShader);
	}

	SPVoid SPDrawPointSprite::drawRender()
	{
		glEnable(GL_DEPTH_TEST);
		glDepthFunc(GL_EQUAL);
		glDisable(GL_BLEND);
		glColorMask(true, true, true, true);
		glDepthMask(GL_FALSE);

		setShaderArrayVector("aPosition", (SPFloat*)&mPositions->x, 3);
		setShaderArrayVector("aFramePitch", (SPFloat*)&mFramePitch->x, 2);

		setShaderUniformMVPMatrix("uModelViewProjectionMatrix");
		setShaderUniformMVMatrix("uMVMatrix");
		setShaderUniformVector("uHeightOfNearPlane", &mHeightOfNearPlane, 1);
		setShaderUniformVector("uSpriteSize", &mSpriteSize, 1);
		setShaderUniformVector("uFocalDistance", &mFocalDistance, 1);
		setShaderUniformVector("uFocalRange", &mFocalRange, 1);
		setShaderUniformVector("uVecToLight", (SPFloat*)&mVecToLight.x, 3);

		setShaderUniformVector("uSpecularPower", &mSpecularPower, 1);
		setShaderUniformVector("uSpecularIntensity", &mSpecularIntensity, 1);
		setShaderUniformVector("uLightColor", (SPFloat*)&mLightColor.x, 3);
		setShaderUniformVector("uLightIntensity", &mLightIntensity, 1);
		setShaderUniformVector("uLightAmbient", &mLightAmbient, 1);
		setShaderUniformVector("uFrameSize", (SPFloat*)&mFrameSizeInTextureCoord.x, 2);
		setShaderUniformVector("uAmbientFactor", &mAmbientFactor, 1);
		setShaderUniformVector("uInvScreenSize", (SPFloat*)&mInvScreenSize.x, 2);

		setShaderUnifromTexture("uDiffuseTexture", mDiffuseTextureId);
		setShaderUnifromTexture("uNormalTexture", mNormalTextureId);
		setShaderUnifromTexture("uBackgroundTexture", mBackgroundTextureId);

		setCustomDrawArrays(mPointCount, DRAW_POINT);
	}

	SPVoid SPDrawPointSprite::setPerspectiveCameraView(SPFloat fovy, SPFloat aspect, SPFloat nearZ, SPFloat farZ)
	{
		if(m_pRenderMVP == SPNULL)
			m_pRenderMVP = new SPMVPManager();

		m_pRenderMVP->setPerspective(fovy, aspect, nearZ, farZ);

		mHeightOfNearPlane = mRTSize.y / (2.f * tan(0.5f * fovy * 3.1415923565f / 180.f));
	}

}//namespace SPhysics
