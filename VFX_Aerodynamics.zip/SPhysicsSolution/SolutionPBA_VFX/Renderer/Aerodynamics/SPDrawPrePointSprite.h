/**
* @file SPDrawPrePointSprite.h
* @brief This file includes module that draws background image
*
* @date 2014-06-17
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_DRAW_PRE_POINT_SPRITE_H_
#define _SP_DRAW_PRE_POINT_SPRITE_H_

#include "SPDefines.h"
#include "SPIRenderer.h"

#include <glm.hpp>
#include <gtc/constants.hpp>

namespace SPhysics
{

	/**
	* @class     SPDrawFireworksDepth
	* @brief     This class is mainly for Drawing Background and supports Mesh setting, color setting, etc,.
	*/
	class SPDrawPrePointSprite : public SPIRenderer
	{
	public:
		/**
		* @brief     Constructor
		*/
		SPDrawPrePointSprite(glm::vec3* aPositions,
							 glm::vec2* aFramePitch,
							 unsigned int mDiffuseTextureId,
							 float aSpriteSize,
							 glm::vec2 & aFrameSizeInTextureCoord,
							 float aAlphaDiscardBorder,
							 unsigned int aPointCount);
		/**
		* @brief     Destructor
		*/
		~SPDrawPrePointSprite();

	public:

		/**
		* @brief     Initialize and Prepare rendering\n
		(set camera setting, initialize shader , create rectangle mesh)
		* @param     [IN] SPFloat width Clipping Plane's width size
		* @param     [IN] SPFloat height Clipping Plane's height size
		* @return     SPVoid
		*/
		SPVoid initRender(SPFloat width, SPFloat height); // virtual

		/**
		* @brief     Mesh setting & binding shader variables for drawing.
		* @return     SPVoid
		 */
		SPVoid drawRender(); // virtual

		/**
		* @brief      Set Camera setting when using perspective view
		* @param     [IN] @b fovy Field of view y angle in degrees.
		* @param     [IN] @b aspect The ratio of the width of a shape to its height
		* @param     [IN] @b nearZ Near plane distance
		* @param     [IN] @b farZ Far plane distance
		* @return     SPVoid
		*/
		SPVoid setPerspectiveCameraView(SPFloat fovy, SPFloat aspect, SPFloat nearZ, SPFloat farZ); // virtual

	private:
		glm::vec3*	mPositions;
		glm::vec2*	mFramePitch;
		unsigned int 		mDiffuseTextureId;
		glm::vec2			mRTSize;
		float				mSpriteSize;
		glm::vec2			mFrameSizeInTextureCoord;
		float				mAlphaDiscardBorder;
		float				mHeightOfNearPlane;
		unsigned int		mPointCount;
	};

}//namespace SPhysics

#endif //_SP_DRAW_FIREWORKS_DEPTH_H_
