/**
* @file      SPImageLoader.cpp
* @brief     
* @date      2013-06-17 
* @author    ParkIncheol
* @see 
* * Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/
#pragma warning(disable:4996)
#include <stdio.h> 
#include <stdlib.h>
#include <string.h>
#include "SPImageLoader.h"
#include "SPTextureManager.h"
//#include "SPLog.h"
#include "png.h"
namespace SPhysics
{
	SPImageLoader::SPImageLoader() : mSdcardFileLoad(SPFALSE)
	{
	}
	SPImageLoader::~SPImageLoader()
	{
	}		

	IMG_COLOR_BUFFER* SPImageLoader::loadColorBuffer( const SPChar *fileName )
	{
		IMG_COLOR_BUFFER *tmpBuff = SPNULL;

		if(mSdcardFileLoad == SPTRUE)
		{
			char fPath[128] = {0,};

			// Configure 1st file name
			sprintf(fPath, "%s%s", "sdcard/", fileName);

			tmpBuff = loadImgRawdata(fPath);
		}else
		{
			tmpBuff = loadImgRawdata(fileName);
		}

		// add the file path to IMG Buffer
		if(tmpBuff != SPNULL)
		{
			SPInt  fileNameSize = strlen(fileName);
			if( fileNameSize <128 )
				strcpy(tmpBuff->FileName, fileName);
			else {
				strncpy(tmpBuff->FileName, fileName, 127);
				tmpBuff->FileName[127] = '\0';
			}
		}

		return tmpBuff;
	}

	IMG_COLOR_BUFFER* SPImageLoader::loadImgRawdata( const SPChar *fileName )
	{
		// initialize the variables
		SPUInt uiWidth =0, uiHeight=0, uiImageSize = 0;
		SPUInt uiPixelSize = 3; // Number of the color channel, RGBA=4
		SPInt bit_depth;
		SPInt color_type;
		SPUInt RGBformat = GL_RGBA;

		FILE* fp = fopen(fileName, "rb");
		if (fp == SPNULL)
		{
			//DBGOUTPUT("+ Failed to open '%'s", fileName);
			return 0;
		}

		SPUChar buf[8];
		if (fread(buf, 1, 8, fp) != 8)
		{
			fclose(fp);
			return 0;
		}

		if (png_sig_cmp(buf, 0, 8))
		{
			fclose(fp);
			return 0;
		}

		/* Create and initialize the png_struct with the desired error handler
		* functions.  If you want to use the default stderr and longjump method,
		* you can supply SPNULL for the last three parameters.  We also supply the
		* the compiler header file version, so that we know if the application
		* was compiled with a compatible version of the library.  REQUIRED
		*/
		png_structp png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, 0, 0, 0);

		if (png_ptr == SPNULL)
		{
			//DBGOUTPUT("+ Failed to png_create_read_struct");
			fclose(fp);
			return 0;
		}

		/* Allocate/initialize the memory for image information.  REQUIRED. */
		png_infop info_ptr = png_create_info_struct(png_ptr);
		if (!info_ptr)
		{
			png_destroy_read_struct(&png_ptr, SPNULL, SPNULL);
			fclose(fp);
			return 0;
		}

		if (setjmp(png_jmpbuf(png_ptr)))
		{
			/* Free all of the memory associated with the png_ptr and info_ptr */
			png_destroy_read_struct(&png_ptr, &info_ptr, SPNULL);
			fclose(fp);
			/* If we get here, we had a problem reading the file */
			return 0;
		}

		 /* set up the input control if you are using standard C streams */
		png_init_io(png_ptr, fp);

		/* If we have already read some of the signature */
		png_set_sig_bytes(png_ptr, 8);


		/* The call to png_read_info() gives us all of the information from the
		* PNG file before the first IDAT (image data chunk).  REQUIRED
		*/
		png_read_info(png_ptr, info_ptr);

		png_uint_32 ihdr_width, ihdr_height;
		png_get_IHDR(png_ptr, info_ptr, &ihdr_width, &ihdr_height, &bit_depth, &color_type, SPNULL, SPNULL, SPNULL);

		// ------------------------
		uiWidth = ihdr_width;
		uiHeight = ihdr_height;
		color_type = color_type;

		if (color_type == PNG_COLOR_TYPE_RGB_ALPHA)
		{
			uiPixelSize=4;
		}
		else
		{
			uiPixelSize = 3;
			RGBformat = GL_RGB;
		}

		uiImageSize = uiWidth * uiHeight * uiPixelSize; // 32bit RGBA888 : 4 byte  or 24bit RGB888 : 3 byte
		bit_depth = bit_depth;

		/* Turn on interlace handling.  REQUIRED if you are not using
		* png_read_image().  To see how to handle interlacing passes,
		* see the png_read_row() method below:
		*/
		SPInt number_of_passes = png_set_interlace_handling(png_ptr);

		/* Optional call to gamma correct and add the background to the palette
		* and update info structure.  REQUIRED if you are expecting libpng to
		* update the palette for you (ie you selected such a transform above).
		*/
		png_read_update_info(png_ptr, info_ptr);

		// read file
		if (setjmp(png_jmpbuf(png_ptr)))
		{
			png_destroy_read_struct(&png_ptr, &info_ptr, SPNULL);
			fclose(fp);
			return 0;
		}

		/* The easiest way to read the image: */
		png_bytep* row_pointers = (png_bytep*) malloc(sizeof(png_bytep) * uiHeight);
		for (SPUInt y=0; y<uiHeight; y++)
			row_pointers[y] = (png_byte*) malloc(png_get_rowbytes(png_ptr, info_ptr));

		 /* Now it's time to read the image.  One of these methods is REQUIRED */
		png_read_image(png_ptr, row_pointers);


		SPUChar *pixels = SPNULL;

		pixels = (SPUChar *)row_pointers;
		////////////////////////////////////////////////////////////////////////////////

		SPUInt tempWidth = uiWidth;
		SPUInt tempHeight = uiHeight;

		IMG_COLOR_BUFFER* sRGBBuffer = new IMG_COLOR_BUFFER();

		sRGBBuffer->ImgData = new SPUChar[tempWidth * tempHeight * uiPixelSize];
		memset(sRGBBuffer->ImgData, 0x0, sizeof(SPUChar) * tempWidth * tempHeight * uiPixelSize);

		sRGBBuffer->ImgHeight = tempHeight;
		sRGBBuffer->ImgWidth = tempWidth;
		sRGBBuffer->ImgSize = tempWidth * tempHeight * uiPixelSize;
		sRGBBuffer->PixelSize = uiPixelSize;

		SPInt tmpArrayIdx;
		for (SPUInt y = 0; y < tempHeight; y++)
		{
			if(y < uiHeight)
			{
				for (SPUInt x = 0; x < tempWidth; x++)
				{
					if(x < uiWidth)
					{
						// Mirror vertical
						//tmpArrayIdx = (tempHeight -1 - y) *tempWidth*uiPixelSize + x*uiPixelSize; // original
						tmpArrayIdx = (y) *tempWidth*uiPixelSize + x*uiPixelSize;						// changed
						sRGBBuffer->ImgData[tmpArrayIdx] = row_pointers[y][x*uiPixelSize];
						sRGBBuffer->ImgData[tmpArrayIdx + 1] = row_pointers[y][x*uiPixelSize+1];
						sRGBBuffer->ImgData[tmpArrayIdx + 2] = row_pointers[y][x*uiPixelSize+2];
						if(uiPixelSize == 4)
						{
							sRGBBuffer->ImgData[tmpArrayIdx + 3] = row_pointers[y][x * 4 + 3];
						}
					}
					else break;
				}
			}
			else break;
		}

		/* Read rest of file, and get additional chunks in info_ptr - REQUIRED */
		png_read_end(png_ptr, info_ptr);

		/* Clean up after the read, and free any memory allocated - REQUIRED */
		png_destroy_read_struct(&png_ptr, &info_ptr, SPNULL);

		pixels = SPNULL;

		for (SPUInt y=0; y<uiHeight; y++)
			free(row_pointers[y]);
		free(row_pointers);

		fclose(fp);

		return sRGBBuffer;
	}

	SPVoid SPImageLoader::enableSDCardFilePath()
	{
		mSdcardFileLoad = SPTRUE;
	}

	SPVoid SPImageLoader::disableSDCardFilePath()
	{
		mSdcardFileLoad = SPFALSE;
	}

	SPUInt SPImageLoader::setTexture( SPVoid* data, SPInt width, SPInt height )
	{
		//SP_LOGE("[%s] this API avalable just on the Android", __FUNCTION__);
		return 0;
	}

	IMG_COLOR_BUFFER*  SPImageLoader::setTextureColor(const SPChar* name, SPVoid* data, SPInt width, SPInt height )
	{
		//SP_LOGE("[%s] this API avalable just on the Android", __FUNCTION__);
		return 0;
	}

}  //namespace SPhysics