/**
* @file SPImageLoader.h
* @brief This file includes module which is related  with texturing
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_TEXTUREIMAGE_LOADER__H_
#define _SP_TEXTUREIMAGE_LOADER__H_

#include "SPDefines.h"

#include <vector>
#include <string.h>

namespace SPhysics
{
	/**
	* @struct     IMAGE_RGB_BUFFER
	* @brief     Specifies the Buffer's properties after loading Image file
	*/
	struct IMG_COLOR_BUFFER
	{
		SPInt ImgWidth;
		SPInt ImgHeight;
		SPUChar* ImgData;
		SPChar FileName[128];
		SPInt ImgSize;
		SPInt PixelSize;
		IMG_COLOR_BUFFER() : ImgWidth(0), ImgHeight(0), ImgData(SPNULL), ImgSize(0), PixelSize(4)
		{
			memset(FileName,0,sizeof(FileName));
		}
	};

	/**
	* @class     SPImageLoader
	* @brief     This class provides the functions that load images file.
	*/
	class SPImageLoader
	{
	public:
		/**
		* @brief     Constructor
		*/
		SPImageLoader();

		/**
		* @brief     Destructor
		*/
		virtual ~SPImageLoader();
	
		friend class SPTextureManager;

	private:
		//! protect illegal construction 
		SPImageLoader(const SPImageLoader& other);
		SPImageLoader& operator=(const SPImageLoader& other);

		/**
		* @brief     Loads PNG image file and return rgb buffer's contents
		* @param     [IN] @b fileName Specifies image file name
		* @return     IMAGE_RGB_BUFFER * Return Buffer's specific contents.
		*/
		IMG_COLOR_BUFFER*  loadColorBuffer(const SPChar *fileName);

		/**
		* @brief     Loads PNG image file and return rgb buffer's contents
		* @param     [IN] @b fileName Specifies image file name
		* @return     IMAGE_RGB_BUFFER * Return Buffer's specific contents.
		*/
		IMG_COLOR_BUFFER*  loadImgRawdata(const SPChar *fileName);

		/**
		* @brief     with this set, File open changed
		* @return    SPVoid
		*/
		SPVoid enableSDCardFilePath();

		/**
		* @brief     with this set, File open changed
		* @return    SPVoid
		*/
		SPVoid disableSDCardFilePath();

		/**
		* @brief     This method supports Java Invocation when setting images.
		* @param     [IN] @b data Buffer's data
		* @param     [IN] @b width Buffer's width size
		* @param     [IN] @b height Buffer's height size
		* @see	JNI Code
		* @return     SPVoid
		*/
		SPUInt setTexture(SPVoid* data, SPInt width, SPInt height);

		/**
		* @brief     This method supports Java Invocation when setting images.
		* @param     [IN] @b name Specifies Image file's name
		* @param     [IN] @b data Buffer's data
		* @param     [IN] @b width Buffer's width size
		* @param     [IN] @b height Buffer's height size
		* @see	JNI Code
		* @return     SPVoid
		*/
		IMG_COLOR_BUFFER*  setTextureColor( const SPChar* name, SPVoid* data, SPInt width, SPInt height);

	private:
		SPBool mSdcardFileLoad;
	};

}	//namespace SPhysics

#endif // _SP_TEXTUREIMAGE_LOADER__H_
