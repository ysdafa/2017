/*
 * Copyright (c) 2000~2014 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPViewCamera.h
 * @brief  File Object
 * @author Andrii Burevych (a.burevych@samsung.com)
 */

#ifndef _SP_VIEW_CAMERA_H_
#define _SP_VIEW_CAMERA_H_

#include <glm.hpp>

namespace SPhysics
{

/**
 * @class SPViewCamera
 * @brief Camera view
 */
class SPViewCamera
{
public:

	/**
	 * Perspective projection.
	 *
	 * @param aFov View angle.
	 * @param aRatio Aspect ratio.
	 * @param aNearZ Near border.
	 * @param aFarZ Far border.
	 */
	static void makePerspectiveProjection(const float aFov, const float aRatio, const float aNearZ,
										  const float aFarZ);

	/**
	 * Set orthogonal projection.
	 *
	 * @param aLeft Left border.
	 * @param aRight Right border.
	 * @param aBottom Bottom border.
	 * @param aTop Top border.
	 * @param aNearZ Near border.
	 * @param aFarZ Far border.
	 */
	static void makeOrthogonalProjection(const float aLeft, const float aRight, const float aBottom,
										 const float aTop, const float aNearZ, const float aFarZ);

	/**
	 * Set Camera position and direction.
	 *
	 * @param aEye Camera position.
	 * @param aCenter Camera direction.
	 * @param aUp Up side.
	 */
	static void setViewCamera(const glm::vec3& aEye, const glm::vec3& aCenter, const glm::vec3& aUp = glm::vec3(0.f, 1.f, 0.f));

	/**
	 * Set camera position in the world.
	 *
	 * @param aCameraPosition global camera position.
	 */
	static void setCameraPosition(const glm::vec3& aCameraPosition);

	/**
	 * Set camera direction (view point position).
	 *
	 * @param aLookAtPoint Point which camera looks at.
	 */
	static void setCameraLookAt(const glm::vec3& aLookAtPoint);

	/**
	 * Rotate camera around local axis.
	 *
	 * @param aAlpha delta angle around X- axis.
	 * @param aBeta  delta angle around Y- axis.
	 */
	static void setCameraRotate(float aAlpha, float aBeta);

	/**
	 * Get camera position.
	 */
	static const glm::vec3& getCameraPosition();

	/**
	 * Get camera direction vector.
	 */
	static const glm::vec3& getCameraDirectVector();

	/**
	 * Get camera normal vector.
	 */
	static const glm::vec3& getCameraNormalVector();

	/**
	 * Get camera vertical vector.
	 */
	static glm::vec3 getCameraVerticalVector();

	/**
	 * Get view matrix.
	 */
	static const glm::mat4& getViewMatrix();

	/**
	 * Get projection matrix.
	 */
	static const glm::mat4& getProjectionMatrix();

	/**
	 * Updates camera position & direction.
	 *
	 */
	static void updateViewCamera();

private:

	static glm::mat4 mViewMatrix; /**<View matrix*/
	static glm::mat4 mProjectionMatrix; /**<Projection matrix*/
	static glm::vec3 mCameraPos;
	static glm::vec3 mCameraDir;
	static glm::vec3 mCameraNormal;
	static glm::vec3 mCameraVertical;
};

} /* namespace SPhysics */

#endif // _SP_VIEW_CAMERA_H_
