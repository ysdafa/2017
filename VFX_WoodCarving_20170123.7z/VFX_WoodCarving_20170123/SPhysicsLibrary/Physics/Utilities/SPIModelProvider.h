/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPIModelProvider.h
 * @brief  Implementation of model provider with cache.
 */

#ifndef _MODELPROVIDERINTERFACE_H_
#define _MODELPROVIDERINTERFACE_H_

#include "SPObjectData.h"

namespace SPhysics
{

/**
 * @class  SPIModelProvider
 * @brief  Model provider interface
 */
class SPIModelProvider
{
public:

	virtual ~SPIModelProvider() {};

	/**
	 * Load model from external resource
	 * @param aModelName name of model
	 */
	virtual const SPObjectData* loadModel(const std::string& aModelName) = 0;
};

}

#endif
