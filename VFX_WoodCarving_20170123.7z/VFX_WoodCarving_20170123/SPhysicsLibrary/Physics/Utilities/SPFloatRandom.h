/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPFloatRandom.h
 * @brief  File Float Random
 * @author Author (a.yusupov@samsung.com)
 */

#ifndef _FLOATRANDOM_H_
#define _FLOATRANDOM_H_

#include "SPDefines.h"
#include "SPThread.h"

namespace SPhysics
{

/**
 * @class  FloatRandom
 * @brief  Float random
 */
template<SPUInt Capacity = 8192, SPUInt RandomDivider = 8192>
class FloatRandom
{
public:

	/**
	 * @brief Constructor.
	 * Fill predefined random array.
	 */
	inline FloatRandom();

	/**
	 * @brief Get next random value.
	 * Value range 0.0f ~ 1.0f.
	 *
	 * @return Random value. Range 0.0f ~ 1.0f.
	 */
	inline SPFloat get();

private:

	SPFloat mValue[Capacity]; /**<Array of predefined random values.*/
	SPUInt mNumber; /**<Current index in array.*/
};

} /* namespace SPhysics */

#include "SPFloatRandom.inl"

#endif /* _FLOATRANDOM_H_ */

