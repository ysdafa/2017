/**
* @file SPImplicitPrimitive2D.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_IMPLICIT_PRIMITIVE_2D_H_
#define _SP_IMPLICIT_PRIMITIVE_2D_H_

#include "SPDefines.h"
#include "SPObject.h"
#include "SPConstant.h"
#include "SPComparison.h"
#include "SPOperations.h"
#include "SPTest.h"

#include <glm.hpp>

namespace SPhysics
{
	/**
	* @class     SPImplicitPrimitive2D
	* @brief     Implicit primitive 2D
	*/
	template<typename T>
	class SPImplicitPrimitive2D : public SPObject
	{
	public:
		/**
		* @brief     Constructor
		*/
		SPImplicitPrimitive2D() {}
		
		/**
		* @brief     Destructor
		*/
		virtual ~SPImplicitPrimitive2D() {}
		
		/**
		* @brief     Get signed distance
		* @param     [IN] @b position
		* @return     T
		*/
		virtual T getSignedDist( const SPVec2t& position ) const = 0;
	};
}

#endif //_SP_IMPLICIT_PRIMITIVE_2D_H_

