/**
* @file SPImplicitBox2D.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_IMPLICIT_BOX_2D_H_
#define _SP_IMPLICIT_BOX_2D_H_

#include "SPDefines.h"

#include "SPImplicitPrimitive2D.h"

namespace SPhysics
{
	/**
	* @class     SPImplicitBox2D
	* @brief     Implicit box 2D
	*/
	template<typename T>
	class SPImplicitBox2D : public SPImplicitPrimitive2D<T>
	{
	private:

		SPVec2t centerPosition;
		T width, height;

		SPVec2t n[4], t[4];
		SPBool  outward;

	public:

		/**
		* @brief	Constructor     
		*/		
		SPImplicitBox2D(){}
		
		/**
		* @brief     Constructor
		* @param     [IN] @b c
		* @param     [IN] @b w
		* @param     [IN] @b h
		* @param     [IN] @b outward_
		*/
		SPImplicitBox2D( const SPVec2t& c, const T& w, const T& h, const SPBool& outward_ )	{ set(c, w, h, outward_); }
		
		/**
		* @brief     Destructor
		*/
		virtual ~SPImplicitBox2D(){}

		/**
		* @brief     Set data sets
		* @param     [IN] @b c
		* @param     [IN] @b w
		* @param     [IN] @b h
		* @param     [IN] @b outward_
		* @return     SPVoid
		*/
		SPVoid set( const SPVec2t& c, const T& w, const T& h, const SPBool& outward_ ) {

			centerPosition = c;
			width = w;
			height = h;
			outward = outward_;

			if( outward ) {

				t[0] = SPVec2t( c.x + w, 0      );
				t[1] = SPVec2t( c.x - w, 0      );
				t[2] = SPVec2t( 0,    c.y + h   );
				t[3] = SPVec2t( 0,    c.y - h   );

				n[0] = SPVec2t(  1,  0 );
				n[1] = SPVec2t( -1,  0 );
				n[2] = SPVec2t(  0,  1 );
				n[3] = SPVec2t(  0, -1 );

			}
		}

		/**
		* @brief     Get Signed distance
		* @param     [IN] @b pos
		* @return     T
		*/
		virtual T getSignedDist( const SPVec2t& pos ) const {

			T dot0 = glm::dot( pos - t[0], n[0] );
			T dot1 = glm::dot( pos - t[1], n[1] );
			T dot2 = glm::dot( pos - t[2], n[2] );
			T dot3 = glm::dot( pos - t[3], n[3] );

			T dist = -LARGE;
			dist = maximum( dist, dot0 );
			dist = maximum( dist, dot1 );
			dist = maximum( dist, dot2 );
			dist = maximum( dist, dot3 );

			if( isAlmostZero(dist) ) dist = -(T)EPSILON;

			return dist;
		}
	};
}
#endif //_SP_IMPLICIT_BOX_2D_H_