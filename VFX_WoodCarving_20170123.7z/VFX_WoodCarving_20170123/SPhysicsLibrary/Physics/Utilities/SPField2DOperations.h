/**
* @file SPField2DOperations.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_FIELD_2D_OPERATIONS_H_
#define _SP_FIELD_2D_OPERATIONS_H_

#include "SPDefines.h"

#include "SPTest.h"
#include "SPOperations.h"
#include "SPComparison.h"
#include "SPInterpolation.h"
#include "SPField2DTemplate.h"

namespace SPhysics
{

	/**
	* @brief     Return true if defined location on the grid is Node
	* @param     [IN] @b field Field 
	* @return     SPBool
	*/
	inline SPBool definedAtNode( SPField2DBase& field )
	{
		if( field.getLocation() == atNODE ) { return SPTRUE; }
		return SPFALSE;
	}

	/**
	* @brief     Return true if defined location on the grid is 'X' Edge
	* @param     [IN] @b field Field 
	* @return     SPBool
	*/
	inline SPBool definedAtXEdge( SPField2DBase& field )
	{
		if( field.getLocation() == atXEDGE ) { return SPTRUE; }
		return SPFALSE;
	}

	/**
	* @brief     Return true if defined location on the grid is 'Y' Edge
	* @param     [IN] @b field Field
	* @return     SPBool
	*/
	inline SPBool definedAtYEdge( SPField2DBase& field )
	{
		if( field.getLocation() == atYEDGE ) { return SPTRUE; }
		return SPFALSE;
	}

	/**
	* @brief     Return true if defined location on the grid is 'Z' Edge
	* @param     [IN] @b field Field
	* @return     SPBool
	*/
	inline SPBool definedAtZEdge( SPField2DBase& field )
	{
		if( field.getLocation() == atZEDGE ) { return SPTRUE; }
		return SPFALSE;
	}

	/**
	* @brief     Return true if defined location on the grid is 'U' Face
	* @param     [IN] @b field Field
	* @return     SPBool
	*/
	inline SPBool definedAtUFace( SPField2DBase& field )
	{
		if( field.getLocation() == atUFACE ) { return SPTRUE; }
		return SPFALSE;
	}

	/**
	* @brief     Return true if defined location on the grid is 'V' Face
	* @param     [IN] @b field Field
	* @return     SPBool
	*/
	inline SPBool definedAtVFace( SPField2DBase& field )
	{
		if( field.getLocation() == atVFACE ) { return SPTRUE; }
		return SPFALSE;
	}

	/**
	* @brief     Return true if defined location on the grid is 'W' Face
	* @param     [IN] @b field Field
	* @return     SPBool
	*/
	inline SPBool definedAtWFace( SPField2DBase& field )
	{
		if( field.getLocation() == atWFACE ) { return SPTRUE; }
		return SPFALSE;
	}

	/**
	* @brief     Return true if defined location on the grid is Cell
	* @param     [IN] @b field Field
	* @return     SPBool
	*/
	inline SPBool definedAtCell( SPField2DBase& field )
	{
		if( field.getLocation() == atCELL ) { return SPTRUE; }
		return SPFALSE;
	}

	/**
	* @brief     Return true if grid is computable
	* @param     [IN] @b f0 Field
	* @param     [IN] @b f1 Field
	* @return     SPBool
	*/
	inline SPBool computable( SPField2DBase& f0, SPField2DBase& f1 )
	{
		SPInt nx0, ny0;   f0.getResolution( nx0, ny0 );
		SPInt nx1, ny1;   f1.getResolution( nx1, ny1 );

		if( nx0 != nx1 ) { return SPFALSE; }
		if( ny0 != ny1 ) { return SPFALSE; }

		SPDouble lx0, ly0;   f0.getDimension( lx0, ly0 );
		SPDouble lx1, ly1;   f1.getDimension( lx1, ly1 );

		if( lx0 != lx1 ) { return SPFALSE; }
		if( ly0 != ly1 ) { return SPFALSE; }

		return SPTRUE;
	}

	/**
	* @brief     Get interpolated node value
	* @param     [IN] @b S Scalar Field 
	* @param     [IN] @b pos position
	* @return     T
	*/
	template <typename T>
	inline T getNodeValue( SPField2DTemplate<T>& S, const SPVec2t& pos )
	{
		#ifdef DEBUGGING
		 VERIFY(S.getLoation()==atNODE);
		#endif

		// because (x-i,y-j) must be 0~1
		SPVec2t clampedPosition;
		clampedPosition.x = clamp( pos.x, (T)0, S.lx() );
		clampedPosition.y = clamp( pos.y, (T)0, S.ly() );

		const T x = clampedPosition.x / S.dx();
		const T y = clampedPosition.y / S.dy();

		SPVec2i index;
		index.x = (SPInt)x;
		index.y = (SPInt)y;

		// because (i,j) must be a cell index
		SPVec2i clampedIndex;
		clampedIndex.x = clamp( index.x, 0, S.nx()-1 );
		clampedIndex.y = clamp( index.y, 0, S.ny()-1 );

		SPInt n[4];
		S.getNodesOfCell( clampedIndex.x,clampedIndex.y, n );

		return biLinearInterpolation( S[n[0]], S[n[1]], S[n[2]], S[n[3]], x-clampedIndex.x, y-clampedIndex.y );
	}

	/**
	* @brief     Get interpolated node value
	* @param     [IN] @b V Vector Field 
	* @param     [IN] @b pos position 
	* @return     SPVec2t
	*/
	template <typename T>
	inline SPVec2t getNodeValue( SPField2DTemplate<SPVec2t >& V, const SPVec2t& pos )
	{
		#ifdef DEBUGGING
		 VERIFY(V.getLoation()==atNODE);
		#endif

		// because (x-i,y-j) must be 0~1
		 SPVec2t clampedPosition;
		 clampedPosition.x = clamp( pos.x, (T)0, V.lx() );
		 clampedPosition.y = clamp( pos.y, (T)0, V.ly() );

		const T x = clampedPosition.x / V.dx();
		const T y = clampedPosition.y / V.dy();

		SPVec2i index;
		index.x = (SPInt)x;
		index.y = (SPInt)y;

		// because (i,j) must be a cell index
		SPVec2i clampedIndex;
		clampedIndex.x = clamp( index.x, 0, V.nx()-1 );
		clampedIndex.y = clamp( index.y, 0, V.ny()-1 );

		SPInt n[4];
		V.getNodesOfCell( clampedIndex.x,clampedIndex.y, n );

		return biLinearInterpolation( V[n[0]], V[n[1]], V[n[2]], V[n[3]], x-clampedIndex.x, y-clampedIndex.y );
	}

	/**
	* @brief     Get the interpolated Center value
	* @param     [IN] @b scalarField scalar field
	* @param     [IN] @b pos position 
	* @return     T
	*/
	template <typename T>
	inline T getInterpolatedCenterValue( const SPField2DTemplate<T>& scalarField, const SPVec2t& pos )
	{
		return getInterpolatedCenterValue<T>(scalarField, pos.x, pos.y);
	}

	/**
	* @brief     Get the interpolated Center value
	* @param     [IN] @b scalarField scalar field
	* @param     [IN] @b x position x
	* @param     [IN] @b y position y
	* @return     T
	*/
	template <typename T>
	inline T getInterpolatedCenterValue( const SPField2DTemplate<T>& scalarField, const T& x, const T& y )
	{
		// because (x-i,y-j) must be 0~1
		const SPVec2t cellSize = scalarField.getCellSize();
		const T newPositionX = x - cellSize.x*(T)0.5;
		const T newPositionY = y - cellSize.y*(T)0.5;

		SPVec2t float_index;
		float_index.x = newPositionX / cellSize.x;
		float_index.y = newPositionY / cellSize.y;

		// because (i,j) must be a cell index
		SPVec2i int_index;
		int_index.x = clamp<SPInt>( (SPInt)floor(float_index.x), 0, scalarField.nx()-2 );
		int_index.y = clamp<SPInt>( (SPInt)floor(float_index.y), 0, scalarField.ny()-2 );
		//std::cout<<"c i : "<<clampedIndex.x<<", c j : "<<clampedIndex.y<<std::endl;

		return biLinearInterpolation<T,T>( 
			scalarField(int_index.x  ,int_index.y  ), 
			scalarField(int_index.x+1,int_index.y  ), 
			scalarField(int_index.x+1,int_index.y+1), 
			scalarField(int_index.x  ,int_index.y+1),
			float_index.x-(T)int_index.x, float_index.y-(T)int_index.y );
	}

	/**
	* @brief     Get the interpolated Center value
	* @param     [IN] @b vectorField vector field
	* @param     [IN] @b pos position
	* @return     SPVec2t
	*/
	template <typename T>
	inline SPVec2t getInterpolatedCenterValue( const SPField2DTemplate<SPVec2t >& vectorField, const SPVec2t& pos )
	{
		return getInterpolatedCenterValue<T>(vectorField, pos.x, pos.y);
	}

	/**
	* @brief     Get the interpolated Center value
	* @param     [IN] @b vectorField vector field
	* @param     [IN] @b x position x
	* @param     [IN] @b y position y
	* @return     SPVec2t
	*/
	template <typename T>
	inline SPVec2t getInterpolatedCenterValue( const SPField2DTemplate<SPVec2t >& vectorField, const T& x, const T& y )
	{
		// because (x-i,y-j) must be 0~1
		const SPVec2t cellSize = (SPVec2t)vectorField.getCellSize();
		const T newPositionX = x - cellSize.x*(T)0.5;
		const T newPositionY = y - cellSize.y*(T)0.5;

		SPVec2t float_index;
		float_index.x = newPositionX / cellSize.x;
		float_index.y = newPositionY / cellSize.y;

		// because (i,j) must be a cell index
		SPVec2i int_index;
		int_index.x = clamp<SPInt>( (SPInt)floor(float_index.x), 0, vectorField.nx()-2 );
		int_index.y = clamp<SPInt>( (SPInt)floor(float_index.y), 0, vectorField.ny()-2 );
		//std::cout<<"c i : "<<clampedIndex.x<<", c j : "<<clampedIndex.y<<std::endl;

		return biLinearInterpolation( 
			vectorField(int_index.x  ,int_index.y  ), 
			vectorField(int_index.x+1,int_index.y  ), 
			vectorField(int_index.x+1,int_index.y+1), 
			vectorField(int_index.x  ,int_index.y+1),
			float_index.x-(T)int_index.x, float_index.y-(T)int_index.y );
	}

	/**
	* @brief     Get nodes of cell
	* @param     [IN] @b S Scalar Field
	* @param     [IN] @b i index
	* @param     [IN] @b j index
	* @return     T
	*/
	template <typename T>
	inline T cellFromNode( SPField2DTemplate<T>& S, SPInt i, SPInt j )
	{
		#ifdef DEBUGGING
		 VERIFY(S.getLoation()==atNODE);
		 VERIFY(0<=i&&i<=S.nx()-1);
		 VERIFY(0<=j&&j<=S.ny()-1);
		#endif

		SPInt node[4];
		S.getNodesOfCell( i, j, node );

		return (T)( (T).25 * ( S[node[0]] + S[node[1]] + S[node[2]] + S[node[3]] ) );
	}

	/**
	* @brief     Get nodes of cell
	* @param     [IN] @b V Vector Field
	* @param     [IN] @b i index
	* @param     [IN] @b j index
	* @return     SPVec2t
	*/
	template <typename T>
	inline SPVec2t cellFromNode( SPField2DTemplate<SPVec2t >& V, SPInt i, SPInt j )
	{
		#ifdef DEBUGGING
		 VERIFY(V.getLoation()==atNODE);
		 VERIFY(0<=i&&i<=S.nx()-1);
		 VERIFY(0<=j&&i<=S.ny()-1);
		#endif

		SPInt node[4];
		V.getNodesOfCell( i, j, node );

		SPVec2d r( (T)0.25 * ( V[node[0]].x + V[node[1]].x + V[node[2]].x + V[node[3]].x ),
							(T)0.25 * ( V[node[0]].y + V[node[1]].y + V[node[2]].y + V[node[3]].y ) );

		return r;
	}

	/**
	* @brief     Copy a Field data
	* @param     [IN] @b source source for copy
	* @param     [OUT] @b target target for copy
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid copyData( SPField2DTemplate<T>& source, SPField2DTemplate<T>& target )
	{
		if( !computable( source, target ) )
		{
			std::cout<<"Error@copyData(): Not computable."<<std::endl;
			return;
		}

		SPInt size = source.getSize();

		memcpy( &target[0], &source[0], size*sizeof(SPDouble) );
	}

	/**
	* @brief     Copy a Field data
	* @param     [IN] @b source source for copy
	* @param     [OUT] @b target target for copy
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid copyData( SPField2DTemplate<SPVec2t >& source, SPField2DTemplate<SPVec2t >& target )
	{
		if( !computable( source, target ) )
		{
			std::cout<<"Error@copyData(): Not computable."<<std::endl;
			return;
		}

		SPInt size = source.getSize();

		memcpy( &target[0], &source[0], size*sizeof(SPVec2d) );
	}

	/**
	* @brief     Return True if Target is moved
	* @param     [IN] @b position position 
	* @param     [IN] @b phi scalar field
	* @param     [IN] @b nrm normal
	* @param     [IN] @b phiGoal updated scalar value
	* @return     SPBool
	*/
	inline SPBool moveToTarget( SPVec2d& position, SPField2DTemplate<SPDouble>& phi, SPField2DTemplate<SPVec2d >& nrm, SPDouble phiGoal )
	{
		SPDouble phiEst;
		phiEst = getNodeValue( phi, position );
		SPDouble scale = phiGoal - phiEst;

		if( isAlmostZero(scale) ) { return SPTRUE; }

		SPVec2d normal = getNodeValue( nrm, position );
		normalize( normal );

		addMultiply( position, scale, normal );

		return SPFALSE;
	}

	/**
	* @brief     Calculate the gradient
	* @param     [IN] @b S Scalar Field
	* @param     [IN] @b pos position 
	* @return     gradient of input position 
	*/
	template <typename T>
	inline SPVec2t gradient( SPField2DTemplate<T>& S, SPVec2t& pos )
	{
		T eps = S.getEpsilon();
		T eps2 = (T)2*eps;

		T w = getNodeValue( S, SPVec2t( pos.x - eps, pos.y, pos.z ) ); // west  (-x)
		T e = getNodeValue( S, SPVec2t( pos.x + eps, pos.y, pos.z ) ); // east  (+x)
		T s = getNodeValue( S, SPVec2t( pos.x, pos.y - eps, pos.z ) ); // south (-y)
		T n = getNodeValue( S, SPVec2t( pos.x, pos.y + eps, pos.z ) ); // north (+y)

		return SPVec2t( ( e - w ) / eps2,
							( n - s ) / eps2 );
	}

	/**
	* @brief     Calculate the gradient
	* @param     [IN] @b V Vector Field
	* @param     [IN] @b pos position 
	* @return     gradient of input position 
	*/
	template <typename T>
	inline SPMat2x2t gradient( SPField2DTemplate<SPVec2t >& V, SPVec2t& pos )
	{
		T eps = V.getEpsilon();
		T eps2 = (T)2*eps;

		T w = getNodeValue( V, SPVec2t( pos.x - eps, pos.y, pos.z ) ); // west  (-x)
		T e = getNodeValue( V, SPVec2t( pos.x + eps, pos.y, pos.z ) ); // east  (+x)
		T s = getNodeValue( V, SPVec2t( pos.x, pos.y - eps, pos.z ) ); // south (-y)
		T n = getNodeValue( V, SPVec2t( pos.x, pos.y + eps, pos.z ) ); // north (+y)

		return SPMat2x2t( ( e.x - w.x ) / eps2, ( n.x - s.x ) / eps2,
							 ( e.y - w.y ) / eps2, ( n.y - s.y ) / eps2 );
	}

	/**
	* @brief     Calculate the curl
	* @param     [IN] @b S Scalar Field
	* @param     [IN] @b pos position 
	* @return     curl of input position 
	*/
	template <typename T>
	inline SPVec2t curl( SPField2DTemplate<T>& S, SPVec2t& pos )
	{
		T eps = S.getEpsilon();
		T eps2 = (T)2*eps;

		T w = getNodeValue( S, SPVec2t( pos.x - eps, pos.y ) ); // west  (-x)
		T e = getNodeValue( S, SPVec2t( pos.x + eps, pos.y ) ); // east  (+x)
		T s = getNodeValue( S, SPVec2t( pos.x, pos.y - eps ) ); // south (-y)
		T n = getNodeValue( S, SPVec2t( pos.x, pos.y + eps ) ); // north (+y)

		return SPVec2t( ( n - s ) / eps2,
							( w - e ) / eps2 );
	}

	/**
	* @brief     Calculate the curl
	* @param     [IN] @b V Vector Field 
	* @param     [IN] @b pos position 
	* @return    curl of input position 
	*/
	template <typename T>
	inline T curl( SPField2DTemplate<SPVec2t >& V, SPVec2t& pos )
	{
		T eps = V.getEpsilon();
		T eps2 = (T)2 * eps;

		SPVec2t w = getNodeValue( V, SPVec2t( pos.x - eps, pos.y ) ); // west  (-x)
		SPVec2t e = getNodeValue( V, SPVec2t( pos.x + eps, pos.y ) ); // east  (+x)
		SPVec2t s = getNodeValue( V, SPVec2t( pos.x, pos.y - eps ) ); // south (-y)
		SPVec2t n = getNodeValue( V, SPVec2t( pos.x, pos.y + eps ) ); // north (+y)

		return ( ( ( e.y - w.y ) - ( n.x - s.x ) ) / eps2 );
	}

	/**
	 * @brief  Merge level set
	 */
	template<typename T>
	inline SPVoid mergeLevelset( SPField2DTemplate<T>& dst, SPField2DTemplate<T>& S )
	{ 
	}

	/**
	 * @brief  Merge level set
	 */
	template<typename T>
	inline SPVoid mergeLevelset( SPField2DTemplate<T>& C, SPField2DTemplate<T> A, SPField2DTemplate<T> B, const T& alpha, const T& beta, const T& gamma ) // Levelsets in Production: Spider-Man 3
	{
	}
}
#endif

