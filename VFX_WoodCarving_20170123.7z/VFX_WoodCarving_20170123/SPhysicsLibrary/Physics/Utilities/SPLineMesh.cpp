/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPLineMesh.cpp
 * @brief  Class SPLineMesh
 * @author Author Andrii Krenevych (a.krenevych@samsung.com) (base version)
 * @author Author Yevgeniy Volkov (y.volkov@samsung.com) (improvements)
 */

#include "SPLineMesh.h"

#include <gtx/compatibility.hpp>
#include <gtc/epsilon.hpp>
#include <gtx/norm.hpp>
#include <gtc/constants.hpp>
#include <gtx/transform.hpp>

#include <string.h>
#include <stdlib.h>

#include "SPLog.h"

#define PI_DIV_18  (3.14159265358979f/18)	//!< Pi/18 (=3.14159/18) ~ 10 degrees in radians

namespace SPhysics
{

SPLineMesh::SPLineMesh(const unsigned int aCapacity,
			const unsigned int aWidth, const unsigned int aHeight, const float aRatio, const float aMult) :
	mWidth(aWidth),
	mHeight(aHeight),
	mInvertWidth(1.0f / float(mWidth - 1)),
	mInvertHeight(1.0f / float(mHeight - 1)),
	mRatio(aRatio),
	mOneDivRatio(1.0f / mRatio),
	mMult(aMult),
	mHalfDivMult(0.5f / mMult),
	mSize(0),
	mMinPointCount(4),
	mLeftLength(0.f),
	mRightLength(0.f),
	mMaxSegmentLength(0.01f * mMult),
	mIsBrokenFromWood(false),
	mPreviousAngle(0.0f),
	mCurrentLineWidth(1.0f),
	mScaleWidth(1.0005f),
	mPointsCopiedToMesh(0),
	mTexUVCopiedToMesh(0),
	mGlScaleMode(false),
	mIsFirstMove(true),
	mIsStarted(false),
	mAddingMode(true),
	mDoBendSmooth(false)
{
	mPlanePositions.reserve(aCapacity);
	mTexureCoords.reserve(aCapacity);
}

SPLineMesh::~SPLineMesh()
{
}

void SPLineMesh::start(glm::vec2 aPosition)
{
	mPrevPosition = aPosition;
	mIsStarted = true;
}

void SPLineMesh::moveTo(glm::vec2 aPosition)
{
	if (aPosition == mPrevPosition)
	{
		SP_LOGI("SPLineMesh::moveTo : move to same point (%.0f %.0f)", aPosition.x, aPosition.y);
		return;
	}

	glm::vec2 delta(aPosition - mPrevPosition);
	float angle = -glm::atan(delta.x, delta.y);
	
	// make smooth shape on the bend
	if (mDoBendSmooth && !mIsFirstMove)
	{
		float deltaAngle = angle - mPreviousAngle;
		int n = int(glm::abs(deltaAngle) / PI_DIV_18) + 1; // one step ~10 degrees (==180/18)
		for (int i=1; i<n; ++i)
		{
			// rotate active line from previous angle to next angle with several middle points
			float ai = mPreviousAngle + deltaAngle * i / n;
			glm::mat2 rotateMatr = glm::mat2 ( glm::rotate(ai, glm::vec3(0.0f, 0.0f, -1.0f)) );
			glm::vec2 radius(mCurrentLineWidth, 0);
			glm::vec2 rotatedRadious = radius * rotateMatr;
			glm::vec2 smoothLeft = mPrevPosition - rotatedRadious;
			glm::vec2 smoothRight = mPrevPosition + rotatedRadious;
			addSegment(smoothLeft, smoothRight, mAddingMode);
		}
	}

	glm::vec2 adelta(glm::abs(delta));
	unsigned int iterations;
	int iterLen = 1;

	if (adelta.x > adelta.y)
		iterations = (unsigned)glm::round(adelta.x/iterLen);
	else
		iterations = (unsigned)glm::round(adelta.y/iterLen);

	if (iterations == 0)
		iterations++;

	delta /= iterations;

	bool iterNonZero = (iterations!=0);

	glm::vec2 pos(mPrevPosition);
	if(mIsFirstMove)
		iterations++; // if it is first move, than need to add first segment, which is start position of whole line
	else
		pos += delta; // otherwise, first position is same as last position from previous move and has been already added

	glm::mat2 transformationMatrix = glm::mat2(glm::rotate(glm::mat4(), angle, glm::vec3(0, 0, 1)));

	unsigned start = 1;
	for (unsigned i = start; i <= iterations; ++i)
	{
			mCurrentLineWidth *= mScaleWidth;

			glm::vec2 radius(mCurrentLineWidth, 0);
			glm::vec2 rotatedRadius = transformationMatrix * radius;

			glm::vec2 left = pos - rotatedRadius;
			glm::vec2 right = pos + rotatedRadius;

			if (mGlScaleMode)
			{
				left = positionToVertexPosition(left);
				right = positionToVertexPosition(right);
			}

			//addSegment(left, right, false); // original
			addSegment(left, right, mAddingMode); // updated

			pos += delta;
	}

	if (iterNonZero)
	{
		mPrevPosition = aPosition;
		mPreviousAngle = angle;
	}
	mIsFirstMove = false;
	mSectionPoints.push_back(mPlanePositions.size());
}

void SPLineMesh::finalize()
{
	if (mSize <= 2 && mIsStarted)
	{
		for (float a=10; a<=170; a+=20)
		{
			glm::vec2 radius(0, mCurrentLineWidth);

			glm::mat2 transformationLeftMatrix = glm::mat2(glm::rotate(glm::radians(a), glm::vec3(0, 0, 1)));
			glm::mat2 transformationRightMatrix = glm::mat2(glm::rotate(glm::radians(a), glm::vec3(0, 0, -1)));

			glm::vec2 left = transformationLeftMatrix * radius + mPrevPosition;
			glm::vec2 right = transformationRightMatrix * radius + mPrevPosition;

			addPairPoints(left, right);
		}
		mIsStarted = false;
		return;
	}
	finalizeSegment(mPlanePositions[mSize - 2], mPlanePositions[mSize - 1]);
	mIsStarted = false;
	//SP_LOGI("points %d", mPlanePositions.size());
}

void SPLineMesh::clear(unsigned controlPointsLeft/*=0*/)
{
	mMesh.m_tVertex.clear();
	mMesh.m_tTextureUV.clear();
	mMesh.m_tVertexIndex.clear();

	if (controlPointsLeft==0)
	{
		mPlanePositions.clear();
		mTexureCoords.clear();
		mSize = 0;
	}
	else if (mPlanePositions.size() > controlPointsLeft*2)
	{
		mPlanePositions.erase(mPlanePositions.begin(), mPlanePositions.end()- controlPointsLeft*2);
		mTexureCoords.erase(mTexureCoords.begin(), mTexureCoords.end() - controlPointsLeft*2);
		mSize = controlPointsLeft*2;
	}
	mPointsCopiedToMesh = mPlanePositions.size();
	mTexUVCopiedToMesh = mTexureCoords.size();
}

void SPLineMesh::clearSections(unsigned sectionsLeft)
{
	if (sectionsLeft > mSectionPoints.size() - 1)
		return;
	unsigned pointsLeft = mSectionPoints[mSectionPoints.size() - 1] - mSectionPoints[mSectionPoints.size() - 1 - sectionsLeft];
	clear(pointsLeft/2);

	unsigned sub = mSectionPoints[mSectionPoints.size() - 1 - sectionsLeft];
	mSectionPoints.erase(mSectionPoints.begin(), mSectionPoints.end() - sectionsLeft);
	for (unsigned i=0; i<mSectionPoints.size(); ++i)
		mSectionPoints[i] -= sub;
}

void SPLineMesh::createMesh()
{
	if (mSize<4)
		return;

	// copy vertices
	mMesh.m_tVertex.resize(mPlanePositions.size());
	for (unsigned i=0; i<mPlanePositions.size(); ++i)
	{
		mMesh.m_tVertex[i].x = mPlanePositions[i].x;
		mMesh.m_tVertex[i].y = mPlanePositions[i].y;
		mMesh.m_tVertex[i].z = 0;
	}

	// copy texture coordinates
	mMesh.m_tTextureUV.resize(mTexureCoords.size());
	for (unsigned i=0; i<mTexureCoords.size(); ++i)
	{
		mMesh.m_tTextureUV[i].x = mTexureCoords[i].x;
		mMesh.m_tTextureUV[i].y = 1 - mTexureCoords[i].y;
		mMesh.m_tTextureUV[i].z = 0;
	}

	// create indices array from rectangles
	mMesh.m_tVertexIndex.clear();
	for(unsigned i=0, j=2; j<mPlanePositions.size(); i+=2, j+=2)
	{
		// i * - * i+1
		//   | / |
		// j * - * j+1
		mMesh.m_tVertexIndex.push_back(i);
		mMesh.m_tVertexIndex.push_back(i+1);
		mMesh.m_tVertexIndex.push_back(j);

		mMesh.m_tVertexIndex.push_back(j);
		mMesh.m_tVertexIndex.push_back(i+1);
		mMesh.m_tVertexIndex.push_back(j+1);
	}
}

void SPLineMesh::updateMesh()
{
	if (mSize<4)
		return;
	if ((int)mPlanePositions.size() == mPointsCopiedToMesh)
		return;

	// copy new vertices to mesh
	mMesh.m_tVertex.resize(mPlanePositions.size());
	for (unsigned i=mPointsCopiedToMesh; i<mPlanePositions.size(); ++i)
	{
		mMesh.m_tVertex[i].x = mPlanePositions[i].x;
		mMesh.m_tVertex[i].y = mPlanePositions[i].y;
		mMesh.m_tVertex[i].z = 0;
	}

	// copy new texture coordinates
	mMesh.m_tTextureUV.resize(mTexureCoords.size());
	for (unsigned i=mTexUVCopiedToMesh; i<mTexureCoords.size(); ++i)
	{
		mMesh.m_tTextureUV[i].x = mTexureCoords[i].x;
		mMesh.m_tTextureUV[i].y = 1 - mTexureCoords[i].y;
		mMesh.m_tTextureUV[i].z = 0;
	}

	// create indices array from rectangles
	unsigned newIndicesSize = mPlanePositions.size()*3 - 6; // == (VertexCount/2 - 1) * 2 * 3
	unsigned a=mPointsCopiedToMesh, b=mPointsCopiedToMesh+2;
	if (mPointsCopiedToMesh!=0)
	{
		a-=2;
		b-=2;
	}

	mMesh.m_tVertexIndex.reserve(newIndicesSize);
	for(unsigned i=a, j=b; j<mPlanePositions.size(); i+=2, j+=2)
	{
		// i * - * i+1
		//   | / |
		// j * - * j+1
		mMesh.m_tVertexIndex.push_back(i);
		mMesh.m_tVertexIndex.push_back(i+1);
		mMesh.m_tVertexIndex.push_back(j);

		mMesh.m_tVertexIndex.push_back(j);
		mMesh.m_tVertexIndex.push_back(i+1);
		mMesh.m_tVertexIndex.push_back(j+1);
	}

	// check if size was calcualted correctlty - important for performance
	//if (mMesh.m_tVertexIndex.size() != newIndicesSize)
	//	SP_LOGI("INDICES SIZE WAS WRONG !!!");

	mPointsCopiedToMesh = mPlanePositions.size();
	mTexUVCopiedToMesh = mTexureCoords.size();
}

SPMesh *SPLineMesh::getMesh()
{
	return &mMesh;
}

void SPLineMesh::addSegment(const glm::vec2 aLeftPoint, const glm::vec2 aRightPoint, const bool aAddAsNewSegment)
{
	if (mSize == 0)
	{
		startSegments(aLeftPoint, aRightPoint);
	}
	else if (mSize < mMinPointCount || isCurrentSegmentTooLong() || aAddAsNewSegment)
	{
		addPairPoints(aLeftPoint, aRightPoint);
	}
	else
	{
		updatePairPoints(aLeftPoint, aRightPoint);
	}
}

void SPLineMesh::startSegments(const glm::vec2 aLeftPoint, const glm::vec2 aRightPoint)
{
	glm::vec2 center(0.5f * (aLeftPoint + aRightPoint));

	glm::vec2 leftRadius = aLeftPoint - center;
	glm::vec2 rightRadius = aRightPoint - center;

	for (float phy = 80.0f, stepPhy = 20.0f; phy > 0.0f; phy -= stepPhy)
	{
		glm::mat2 transformationLeftMatrix = glm::mat2(glm::rotate(glm::radians(phy), glm::vec3(0, 0, 1)));
		glm::mat2 transformationRightMatrix = glm::mat2(glm::rotate(glm::radians(phy), glm::vec3(0, 0, -1)));

		glm::vec2 left = transformationLeftMatrix * leftRadius + center;
		glm::vec2 right = transformationRightMatrix * rightRadius + center;

		addPairPoints(left, right);
	}

	addPairPoints(aLeftPoint, aRightPoint);
}

void SPLineMesh::finalizeSegment(const glm::vec2 aLeftPoint, const glm::vec2 aRightPoint)
{
	glm::vec2 center(0.5f * (aLeftPoint + aRightPoint));
	glm::vec2 leftRadius = aLeftPoint - center;
	glm::vec2 rightRadius = aRightPoint - center;
	for (float phy = 20.0f, stepPhy = 20.0f; phy < 90.0f; phy += stepPhy)
	{
		glm::mat2 transformationLeftMatrix = glm::mat2(glm::rotate(glm::radians(phy), glm::vec3(0, 0, -1)));
		glm::mat2 transformationRightMatrix = glm::mat2(glm::rotate(glm::radians(phy), glm::vec3(0, 0, 1)));

		glm::vec2 left = transformationLeftMatrix * leftRadius + center;
		glm::vec2 right = transformationRightMatrix * rightRadius + center;

		addPairPoints(left, right);
	}
}

void SPLineMesh::addPairPoints(const glm::vec2& aLeftPoint, const glm::vec2& aRightPoint)
{
 	if (mSize == 0)
	{
		mLeftLength = 0.0f;
		mRightLength = 0.0f;
	}
	else
	{
		mLeftLength += glm::distance(aLeftPoint, mPlanePositions[mSize - 2]);
		mRightLength += glm::distance(aRightPoint, mPlanePositions[mSize - 1]);
	}

	mSize+=2;
	mPlanePositions.push_back(aLeftPoint);
	mPlanePositions.push_back(aRightPoint);

	if (mGlScaleMode)
	{
		mTexureCoords.push_back(glm::vec2(mPlanePositions[mSize - 2].x * mHalfDivMult * mOneDivRatio + 0.5f,
											mPlanePositions[mSize - 2].y * mHalfDivMult + 0.5f));
		mTexureCoords.push_back(glm::vec2(mPlanePositions[mSize - 1].x * mHalfDivMult * mOneDivRatio + 0.5f,
											mPlanePositions[mSize - 1].y * mHalfDivMult + 0.5f));
	}
	else
	{
		mTexureCoords.push_back(glm::vec2(mPlanePositions[mSize-2].x / mWidth, mPlanePositions[mSize-2].y / mHeight));
		mTexureCoords.push_back(glm::vec2(mPlanePositions[mSize-1].x / mWidth, mPlanePositions[mSize-1].y / mHeight));
	}
	
}

void SPLineMesh::updatePairPoints(const glm::vec2& aLeftPoint, const glm::vec2& aRightPoint)
{
	mLeftLength -= glm::distance(mPlanePositions[mSize - 2], mPlanePositions[mSize - 4]);
	mRightLength -= glm::distance(mPlanePositions[mSize - 1], mPlanePositions[mSize - 3]);
	mLeftLength += glm::distance(aLeftPoint, mPlanePositions[mSize - 4]);
	mRightLength += glm::distance(aRightPoint, mPlanePositions[mSize - 3]);

	mPlanePositions[mSize - 2] = aLeftPoint;
	mPlanePositions[mSize - 1] = aRightPoint;
	
	mTexureCoords[mSize - 2].x = mPlanePositions[mSize - 2].x * mHalfDivMult * mOneDivRatio + 0.5f;
	mTexureCoords[mSize - 2].y = mPlanePositions[mSize - 2].y * mHalfDivMult + 0.5f;
	mTexureCoords[mSize - 1].x = mPlanePositions[mSize - 1].x * mHalfDivMult * mOneDivRatio + 0.5f;
	mTexureCoords[mSize - 1].y = mPlanePositions[mSize - 1].y * mHalfDivMult + 0.5f;
}

unsigned int SPLineMesh::getShavingPointCount()
{
	return mSize;
}

void SPLineMesh::setLineWidth(const float aWidth)
{
	mCurrentLineWidth = aWidth;
}

void SPLineMesh::setLineWidthScale(const float aWidthScale)
{
	mScaleWidth = aWidthScale;
}

void SPLineMesh::setGlScaleMode(bool aGlScaleMode)
{
	mGlScaleMode = aGlScaleMode;
}

void SPLineMesh::setAddingMode(bool addingMode)
{
	mAddingMode = addingMode;
}

void SPLineMesh::setBendSmoothMode(bool doBendSmooth)
{
	mDoBendSmooth = doBendSmooth;
}

bool SPLineMesh::isCurrentSegmentTooLong()
{
	if (mSize <= 2)
	{
		return false;
	}

	float distance2Left = glm::distance2(mPlanePositions[mSize - 2], mPlanePositions[mSize - 4]);
	float distance2Right = glm::distance2(mPlanePositions[mSize - 1], mPlanePositions[mSize - 3]);
	float distance2 = glm::max(distance2Left, distance2Right);

	return distance2 > mMaxSegmentLength;
}

inline glm::vec2 SPLineMesh::positionToVertexPosition(const glm::vec2 aPosition)
{
	return glm::vec2((aPosition.x * mInvertWidth - 0.5f) * 2.0f * mMult * mRatio,
					 (aPosition.y * mInvertHeight - 0.5f) * 2.0f * mMult);
}

}//namespace SPhysics
