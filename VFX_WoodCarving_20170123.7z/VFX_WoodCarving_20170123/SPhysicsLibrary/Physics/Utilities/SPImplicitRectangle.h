/**
* @file SPImplicitRectangle.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_IMPLICIT_RECTANGLE_H_
#define _SP_IMPLICIT_RECTANGLE_H_

#include "SPDefines.h"

#include "SPImplicitPrimitive2D.h"

namespace SPhysics
{
	/**
	* @class     SPImplicitRectangle
	* @brief     Implicit rectangle
	*/
	template<typename T>
	class SPImplicitRectangle : public SPImplicitPrimitive2D<T>
	{
	private:
		SPVec2t minPt;
		SPVec2t maxPt;

		SPVec2t n[4], t[4];
		SPBool  outward;

	public:

		/**
		* @brief     Constructor
		*/
		SPImplicitRectangle(){}
		
		/**
		* @brief     Constructor
		* @param     [IN] @b minPt_
		* @param     [IN] @b maxPt_
		* @param     [IN] @b outward_
		*/
		SPImplicitRectangle( const SPVec2t& minPt_, const SPVec2t& maxPt_, const SPBool& outward_ )	{ set(minPt_, maxPt_, outward_); }
		
		/**
		* @brief     Destructor
		*/
		virtual ~SPImplicitRectangle(){}

		/**
		* @brief     Set data sets
		* @param     [IN] @b minPt_
		* @param     [IN] @b maxPt_
		* @param     [IN] @b outward_
		* @return     SPVoid
		*/
		SPVoid set( const SPVec2t& minPt_, const SPVec2t& maxPt_, const SPBool& outward_ )
		{
			minPt = minPt_;
			maxPt = maxPt_;
			outward = outward_;

			if( outward )
			{
				t[0] = SPVec2t( maxPt.x, 0      );
				t[1] = SPVec2t( minPt.x, 0      );
				t[2] = SPVec2t( 0,    maxPt.y   );
				t[3] = SPVec2t( 0,    minPt.y   );

				n[0] = SPVec2t(  1,  0 );
				n[1] = SPVec2t( -1,  0 );
				n[2] = SPVec2t(  0,  1 );
				n[3] = SPVec2t(  0, -1 );

			}
		}

		/**
		* @brief     Get signed distance
		* @param     [IN] @b pos
		* @return     T
		*/
		virtual T getSignedDist( const SPVec2t& pos ) const
		{
			T dot0 = glm::dot( pos - t[0], n[0] );
			T dot1 = glm::dot( pos - t[1], n[1] );
			T dot2 = glm::dot( pos - t[2], n[2] );
			T dot3 = glm::dot( pos - t[3], n[3] );

			T dist = -LARGE;
			dist = maximum( dist, dot0 );
			dist = maximum( dist, dot1 );
			dist = maximum( dist, dot2 );
			dist = maximum( dist, dot3 );

			if( isAlmostZero(dist) ) dist = -(T)EPSILON;

			return dist;
		}
	};
}
#endif //_SP_IMPLICIT_RECTANGLE_H_