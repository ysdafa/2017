/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPCircularBuffer.h
 * @brief  File Circular buffer
 * @author Author (a.vysotskyi@samsung.com)
 */

#ifndef _CIRCULARBUFFER_H_
#define _CIRCULARBUFFER_H_

namespace SPhysics
{
	
/**
 * SPCircularBuffer<T, Capacity> Storage with limited size and FIFO behavior
 * T - class of items stored in buffer
 * aCapacity - maximum number of elements, stored in buffer
 */
template<class T, unsigned int Capacity>
class SPCircularBuffer
{
public:
	/**
	 * Constuctor. Initialize an empty buffer
	 */
	SPCircularBuffer();

	/**
	 * Return count of items currently stored in buffer
	 * @return counter of stored items. Less or equal to value of template parameter "Capacity"
	 */
	unsigned int getSize() const;

	/**
	 * Return maximum count of items can be stored in buffer
	 * @return maximum count of stored items.
	 */
	unsigned int getCapacity() const;

	/**
	 * Add new item to storage and remove 0-th item if size becomes grater than capacity
	 * @param aNewElement new element to add to storage. New element always appears as last item in storage.
	 */
	void push(const T& aNewElement);

	/**
	 * Take item reference by index
	 * @param aIndex index of requested item. Assert appears if no such element in storage.
	 */
	T& operator[](unsigned int aIndex);

	/**
	 * Take first item reference. Equivalent to [0]
	 * @return reference to first item. Assert appears if storage is empty.
	 */
	T& getFirst();

	/**
	 * Take last item reference. Equivalent to [getSize() - 1]
	 * @return reference to last item. Assert appears if storage is empty.
	 */
	T& getLast();

	/**
	 * Take constant reference to item by index
	 * @param aIndex index of requested item. Assert appears if no such element in storage.
	 */
	const T& operator[](unsigned int aIndex) const;

	/**
	 * Take constant reference to first item. Equivalent to constant version of [0]
	 * @return constant reference to first item. Assert appears if storage is empty.
	 */
	const T& getFirst() const;

	/**
	 * Take constant refernce to last item. Equivalent to constant version of [getSize() - 1]
	 * @return constant reference to last item. Assert appears if storage is empty.
	 */
	const T& getLast() const;

private:
	std::vector<T>
	mBuffer; /**< Storage of items. Size of vector always equal to value of template parameter "Capacity" */
	unsigned int mFirstIndex; /**< Index of element in mBuffer that appears as first item in circular buffer */
};

}    //namespace SPhysics;

#include "SPCircularBuffer.inl"

#endif
