/**
* @file SPField2Dadvection.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/


#ifndef _SP_FIELD_2D_ADVECTION_H_
#define _SP_FIELD_2D_ADVECTION_H_

#include "SPDefines.h"

#include "SPScalarField2D.h"
#include "SPVectorField2D.h"
#include "SPGlobal.h"
#include "Operations2D.h"
#include "SPField2DOperations.h"

namespace SPhysics
{
	/**
	* @brief     Calculate advection vectors of Field
	* @param     [IN] @b V Vector Field
	* @param     [IN] @b S Scalar Field
	* @param     [IN] @b dt time step
	* @param     [IN] @b method : LINEAR, SPE_RK2, SPE_RK3, SPE_RK4, BFECC
	* @return     SPVoid
	*/
	SPVoid advect( SPField2DTemplate<SPVec2d >& V, SPField2DTemplate<SPDouble>& S, SPDouble dt, SPInt method )
	{

		switch( method ) {

		case LINEAR: { break; }
		case SPE_RK2:    { break; }
		case SPE_RK3:    { break; }
		case SPE_RK4:    { break; }
		case BFECC:  { break; }
		default:
			std::cout<<"Error@advect(): Invalid method."<<std::endl;
			break;
		}
	}

	/**
	* @brief     Calculate advection vectors of Field
	* @param     [IN] @b V Vector Field
	* @param     [IN] @b dt time step
	* @param     [IN] @b method : LINEAR, SPE_RK2, SPE_RK3, SPE_RK4, BFECC
	* @return     SPVoid
	*/
	SPVoid advect( SPField2DTemplate<SPVec2d >& V, SPDouble dt, SPInt method )
	{
		switch( method )
		{

		case LINEAR: { advectLinear ( V, dt ); break; }
		case SPE_RK2:    { break; }
		case SPE_RK3:    { break; }
		case SPE_RK4:    { break; }
		case BFECC:  { break; }
		default:
			std::cout<<"Error@advect(): Invalid method."<<std::endl;
			break;

		}
		//setBoundaryCondition( V );
	}

	/**
	* @brief     Calculate advection vectors of FaceGrid
	* @param     [IN] @b V Vector Field
	* @param     [IN] @b dt time step
	* @return     SPVoid
	*/
	SPVoid advectLinear( SPFaceGrid2D<SPDouble>& V, const SPDouble dt )
	{

		// 	if( !DefinedAtNode( V ) ) {
		// 		std::cout<<"Error@advect(): Invalid location."<<std::endl;
		// 		return;
		// 	}

		const SPVec2i res = V.getResolution();
		const SPInt m_NxPlus1 = res.x+1;
		const SPInt m_NyPlus1 = res.y+1;

		const SPVec2d cellSize = V.getCellSize();
		const SPVec2d gridSize = V.getDimension();
		const SPVec2d zero_vector(0,0);

		SPFaceGrid2D<SPDouble> V0( V.getResolution(), V.getDimension() );
		SPswap( V0, V );

		for( SPInt j=0; j<res.y; ++j )
		{ 
			for( SPInt i=0; i<m_NxPlus1; ++i )
			{
				SPVec2d pos; 
				pos.x = i*cellSize.x;
				pos.y = (j+0.5)*cellSize.y;

				const SPVec2d u_face_velocity = V0.getInterpolatedValue(pos);

				SPVec2d backPt = pos;
				addMultiply( backPt, -dt, u_face_velocity );
				SPVec2d clampedPosition = CLAMP<SPDouble>(backPt, zero_vector, gridSize);
				V.setUFace(i,j, V0.getInterpolatedValue(clampedPosition).x);
			}
		}

		for( SPInt j=0; j<m_NyPlus1; ++j )
		{ 
			for( SPInt i=0; i<res.x; ++i )
			{ 

				SPVec2d pos; 
				pos.x = (i+0.5)*cellSize.x;
				pos.y = j*cellSize.y;

				const SPVec2d v_face_velocity = V0.getInterpolatedValue(pos);

				SPVec2d backPt = pos;
				addMultiply( backPt, -dt, v_face_velocity );
				SPVec2d clampedPosition = CLAMP<SPDouble>(backPt, zero_vector, gridSize);
				V.setVFace(i,j, V0.getInterpolatedValue(clampedPosition).y);
			}
		}
	}

}

#endif //_SP_FIELD_2D_ADVECTION_H_