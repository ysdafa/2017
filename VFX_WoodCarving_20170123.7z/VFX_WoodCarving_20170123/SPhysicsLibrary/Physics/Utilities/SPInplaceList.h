/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPInplaceList.h
 * @brief  Class which organizes linked list.
 * @author Andrii Vysotskyi (a.vysotskyi@samsung.com)
 */

#ifndef _INPLACELIST_H_
#define _INPLACELIST_H_

namespace SPhysics
{

/**
 * SPInplaceList<T> is a class that implemented head of two-directional list
 * of objects T inherited from SPInplaceList<T>::Item. The operators getLast is
 * not implemented yet but trivial.
 */
template<class T>
class SPInplaceList
{
public:
	/**
	 * SPInplaceList<T>::Item class that implement  item functionality of list item.
	 * Inherit your object from this class to allow link it into two-directional list.
	 * The operators getPrev is not implemented but trivial.
	 */
	class Item
	{
	protected:
		/**
		 * Constructor. Initialize item as not linked to any list.
		 */
		Item();

	public:
		/**
		 * Retraive pointer to next item in list.
		 * @return pointer to next list item if exists. NULL otherwise.
		 */
		T* getNext();

	private:
		friend class SPInplaceList<T> ;
		T* mNext; /**< Pointer to next list item. NULL if this item is last or not linked to list */
		T* mPrev; /**< Pointer to previous item in list. NULL if this item is first item in list or not linked */
	};

public:
	/**
	 * Constructor. Initialize list as empty.
	 */
	SPInplaceList();
	/**
	 * Destructor. Unlink all items from list (if any).
	 */
	~SPInplaceList();

public:
	/**
	 * Unlink all items from list (if any). After call to this fuction list appears empty.
	 */
	void clearList();

	/**
	 * Get first item of list.
	 * @return pointer to first list element. NULL if list is empty.
	 */
	T* getFirst();

	/**
	 * Link item to list as new first item.
	 * @param aItem pointer to new list element. Assert will be triggered if aItem already linked to this or other list
	 */
	void linkItem(T* aItem);

	/**
	 * Unlink item from list.
	 * @param aItem pointer to element that will be unlinked from list. Undefined behavior if element linked to another list;
	 */
	void unlinkItem(T* aItem);

private:
	T* mFirst; /**< Pointer to first list item. NULL if list is empty */
};

}    //namespace SPhysics;

#include "SPInplaceList.inl"

#endif
