/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPFileLoad.h
 * @brief  File Load
 * @author Arthur Yusupov (a.yusupov@samsung.com)
 */

#ifndef _SPFILE_H_
#define _SPFILE_H_

#include <string>
#include <vector>

#ifdef ANDROID
#include <android/asset_manager_jni.h>
#include "SPAssetManager.h"
#endif

namespace SPhysics
{

/**
 * @class  SPFile
 * @brief  File
 */
class SPFile
{

public:

	/**
	 * @brief  Constructor
	 */
	SPFile();

	/**
	 * @brief  Constructor
	 */
	SPFile(const std::string& aName);

	/**
	 * @brief  Load file
	 */
	void load(const std::string& aName);

	/**
	 * @brief  Get buffer read from file
	 */
	void* getBuffer();

	/**
	 * @brief  Write to file from buffer
	 */
	void write(const void* aBuffer, const unsigned int aSize);

	/**
	 * @brief  Flush
	 */
	void flush(const std::string& aName);

	/**
	 * @brief  Get length
	 */
	unsigned int getLength() const;

#ifdef ANDROID 
	static AAssetManager*& getAssetManager();
#endif

private:

	std::vector<char> mBuffer;

};

} // namespace SPhysics

#endif // _SPFILE_H_

