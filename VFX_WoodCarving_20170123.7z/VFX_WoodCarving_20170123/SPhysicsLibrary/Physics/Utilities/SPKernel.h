/**
* @file SPKernel.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_KERNEL_H_
#define _SP_KERNEL_H_

#include "SPDefines.h"

#include "SPInterpolation.h"
#include "SPTrigonometric.h"
#include "SPObject.h"
#include "SPGlobal.h"

namespace SPhysics
{
	/**
	* @class     SPKernel
	* @brief     Kernel
	*/
	template <typename T>
	class SPKernel : public SPObject
	{
		public:

			SPInt type;	//!< Type

			/**
			* @brief     Constructor
			*/
			SPKernel(): type(SPE_CONSTANT) {}

			/**
			* @brief     Constructor
			* @param     [IN] @b t type of kernel
			*/
			SPKernel( const SPInt t ): type(t) {}

			/**
			* @brief     Destructor
			*/
			virtual ~SPKernel()        {}

			/**
			* @brief     Return kernels from type
			* @param     [IN] @b dist distance
			* @param     [IN] @b support kernel size
			* @return     T
			*/
			T estimate( T dist, T support )
			{
				switch( type )
				{
					case SPE_CONSTANT: { return (T)1;                               }
					case SPE_LINEAR:   { return linear           ( dist, support ); }
					case POLY3:    { return poly3            ( dist, support ); }
					case POLY5:    { return poly5            ( dist, support ); }
					case POLY6:    { return poly6            ( dist, support ); }
					case GAUSSIAN: { return clampedGaussian  ( dist, support ); }
					case SPIKY:    { return spiky			 ( dist, support ); }
					case FRESNEL:  { return fresnel			 ( dist, support ); }
								   
					default:       { std::cout<<"Error@SPKernel::estimate(): Invalid kernel."<<std::endl; return (T)1; }
				}
			}

			/**
			* @brief     Return kernels from type
			* @param     [IN] @b distSQ square root distance
			* @param     [IN] @b support kernel size
			* @return     T
			*/
			T estimateSQ( T distSQ, T support )
			{
				switch( type )
				{
					case SPE_LINEAR:   { return linear              ( distSQ, support ); }
					case POLY6:    { return poly6SQ            ( distSQ, support ); }
					case GAUSSIAN: { return clampedGaussianSQ ( distSQ, support ); }
					default:       { std::cout<<"Error@SPKernel::estimateSQ(): Invalid kernel."<<std::endl; return (T)1; }
				}
			}

		protected:

			/**
			* @brief     
			* @param     [IN] @b dist distance
			* @param     [IN] @b support kernel size
			* @return     T
			*/
			T linear( T dist, T support )
			{
				#ifdef DEBUGGING
				 VERIFY( dist >= 0 );
				 VERIFY( support > 0 );
				#endif

				if( dist > support ) { return (T)0; }
				return ( (T)1 - linearInterpolation( (T)0, support, dist ) );
			}

			/**
			* @brief     
			* @param     [IN] @b dist distance
			* @param     [IN] @b support kernel size
			* @return     T
			*/
			T poly3( T dist, T support )
			{
				#ifdef DEBUGGING
				 VERIFY( dist >= 0 );
				 VERIFY( support > 0 );
				#endif

				return ( (T)1 - scurve3( (T)0, support, dist ) );
			}

			/**
			* @brief     
			* @param     [IN] @b dist distance
			* @param     [IN] @b support kernel size
			* @return     T
			*/
			T poly5( T dist, T support )
			{
				#ifdef DEBUGGING
				 VERIFY( dist >= 0 );
				 VERIFY( support > 0 );
				#endif

				return ( (T)1 - scurve5( (T)0, support, dist ) );
			}

			/**
			* @brief     
			* @param     [IN] @b dist distance
			* @param     [IN] @b support kernel size
			* @return     T
			*/
			T poly6( T dist, T support )
			{
				#ifdef DEBUGGING
				 VERIFY( dist >= 0 );
				 VERIFY( support > 0 );
				#endif

				if( dist > support ) { return (T)0; }

				T r3 = pow3(support);
				T r9 = pow3(r3);
				T result = (T)( (T)315 / ( (T)64 * PI * r9 ) );
				result *= pow3( pow2(support) - pow2(dist) );
				return result;
			}

			/**
			* @brief     
			* @param     [IN] @b dist distance
			* @param     [IN] @b support kernel size
			* @return     T
			*/
			T spiky( T dist, T support )
			{
				#ifdef DEBUGGING
				 VERIFY( dist >= 0 );
				 VERIFY( support > 0 );
				#endif

				if( dist > support ) { return (T)0; }

				T r3 = pow3(support);
				T r6 = pow2(r3);
				T result = (T)( (T)15 / ( PI * r6 ) );
				result *= pow3( support - dist );
				return result;
			}

			/**
			* @brief     
			* @param     [IN] @b distSQ square root of distance
			* @param     [IN] @b support kernel size
			* @return     T
			*/
			T poly6SQ( T distSQ, T support )
			{
				#ifdef DEBUGGING
				 VERIFY( dist >= 0 );
				 VERIFY( support > 0 );
				 VERIFY( dist <= support );
				#endif

				T r3 = pow3(support);
				T r9 = pow3(r3);
				T result = (T)( (T)315 / ( (T)64 * PI * r9 ) );
				result *= pow3( pow2(support) - distSQ );
				return result;
			}

			/**
			* @brief     
			* @param     [IN] @b dist distance
			* @param     [IN] @b support kernel size
			* @return     T
			*/
			T clampedGaussian( T dist, T support )
			{
				#ifdef DEBUGGING
				 VERIFY( dist >= 0 );
				 VERIFY( support > 0 );
				#endif

				T temp = pow2(dist) / (T)(2*pow2(support));
				T result = exp(-temp) / ( pow3(support) * pow( (T)PI2, (T)1.5 ) );
				return result;
			}

			/**
			* @brief     
			* @param     [IN] @b distSQ square root of distance
			* @param     [IN] @b support kernel size
			* @return     T
			*/
			T clampedGaussianSQ( T distSQ, T support )
			{
				#ifdef DEBUGGING
				 VERIFY( dist >= 0 );
				 VERIFY( support > 0 );
				 VERIFY( dist <= support );
				#endif

				T temp = distSQ / (T)(2*pow2(support));
				T result = exp(-temp) / ( pow3(support) * pow( (T)PI2, (T)1.5 ) );
				return result; 
			} 

			/**
			* @brief     
			* @param     [IN] @b dist distance
			* @param     [IN] @b support kernel size
			* @return     T
			*/
			T fresnel( T dist, T support )
			{
				#ifdef DEBUGGING
				 VERIFY( dist >= 0 );
				 VERIFY( support > 0 );
				#endif

				if( dist > support ) { return (T)0; }
				return  pow5(1 - cosine(dist));
			}

	};

}

#endif //_SP_KERNEL_H_
 
