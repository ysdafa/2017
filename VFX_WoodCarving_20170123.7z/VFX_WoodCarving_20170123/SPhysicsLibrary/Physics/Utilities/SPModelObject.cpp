/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPModelObject.cpp
 * @brief  File Model Object
 * @author Author Arthur Yusupov (a.yusupov@samsung.com)
 */

#include "SPModelObject.h"
#include "SPObjectData.h"
#include "SPException.h"

namespace SPhysics
{

SPModelObject::SPModelObject()
{
}

SPModelObject::SPModelObject(const std::string& aName)
{
	load(aName);
}

void SPModelObject::load(const std::string& aName)
{
	mFile.load(aName + ".bin");
}

void SPModelObject::fillObject(SPObjectData& aObject)
{
	ARGUMENT_VALUE_CHECK(&aObject == NULL);

	unsigned int* buffer = reinterpret_cast<unsigned int*>(mFile.getBuffer());

	unsigned int vertexCount = buffer[0];
	unsigned int indexCount = buffer[1];
	glm::vec3* vertexBuff = reinterpret_cast<glm::vec3*>(buffer + 2);
	glm::vec3* normalBuff = vertexBuff + vertexCount;
	glm::vec2* textureBuff = reinterpret_cast<glm::vec2*>(normalBuff + vertexCount);
	unsigned short* indexesBuff = reinterpret_cast<unsigned short*>(textureBuff + vertexCount);


	SPMesh mesh;

	mesh.m_tVertex.resize(vertexCount);
	mesh.m_tNormal.resize(vertexCount);
	mesh.m_tTextureUV.resize(vertexCount);
	mesh.m_tVertexIndex.resize(indexCount);

	memCopy(&mesh.m_tVertex[0],vertexBuff,vertexCount);
	memCopy(&mesh.m_tNormal[0],normalBuff, vertexCount);

	for(unsigned int i = 0; i < vertexCount; ++i)
	{
		mesh.m_tTextureUV[i] = SPVec3f(textureBuff[i].x,textureBuff[i].y,0.f);
	}

	memCopy(&mesh.m_tVertexIndex[0],indexesBuff, indexCount);

	aObject = mesh;

	//aObject.mLightAmbient = 0.2f; // remove material from RefObject
	//aObject.mLightDiffuse = 0.6f; // remove material from RefObject
	//aObject.mLightSpecular = 0.5f; // remove material from RefObject
	//aObject.mLightShininess = 30.f; // remove material from RefObject
	//aObject.mRenderMode = Triangles; // remove material from RefObject
}


ModelLoader::ModelLoader(const std::string& aName)
{
	mModel.load(aName);
	mModel.fillObject(mObject);
}

ModelLoader::~ModelLoader()
{
}

SPObjectData& ModelLoader::getObject()
{
	return mObject;
}

} /* namespace SPhysics */
