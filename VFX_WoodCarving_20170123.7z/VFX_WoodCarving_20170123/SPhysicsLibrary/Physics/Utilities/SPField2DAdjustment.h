/**
* @file SPField2DAdjustment.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_FIELD_2D_ADJUSTMENT_H_
#define _SP_FIELD_2D_ADJUSTMENT_H_

#include "SPDefines.h"

#include "SPScalarField2D.h"
#include "SPVectorField2D.h"
#include "SPField2DOperations.h"
#include "Operations2D.h"

namespace SPhysics
{
	/**
	* @brief     Copy data sets
	* @param     [IN] @b A Field 
	* @param     [IN] @b B Field 
	* @return     SPVoid
	*/
	SPVoid copy( SPField2DTemplate<SPDouble>& A, SPField2DTemplate<SPDouble>& B )
	{
		A.copy( B );
	}

	/**
	* @brief     Copy data sets
	* @param     [IN] @b A Field
	* @param     [IN] @b B Field
	* @return     SPVoid
	*/
	SPVoid copy( SPField2DTemplate<SPVec2d >& A, SPField2DTemplate<SPVec2d >& B )
	{
		A.copy( B );
	}

	/**
	* @brief     A[i] += a
	* @param     [IN] @b A Field
	* @param     [IN] @b a
	* @return     SPVoid
	*/
	SPVoid add( SPField2DTemplate<SPDouble>& A, SPDouble a )
	{
		SPInt size = A.getSize();
		for( SPInt i=0; i<size; ++i )
		{
			A[i] += a;
		}
	}

	/**
	* @brief     A[i] += a
	* @param     [IN] @b A Field
	* @param     [IN] @b a
	* @return     SPVoid
	*/
	SPVoid add( SPField2DTemplate<SPVec2d >& A, SPVec2d const& a )
	{
		SPInt size = A.getSize();
		for( SPInt i=0; i<size; ++i )
		{
			A[i] += a;
		}
	}

	/**
	* @brief     C = A + B
	* @param     [IN] @b C
	* @param     [IN] @b A
	* @param     [IN] @b B
	* @return     SPVoid
	*/
	SPVoid add( SPField2DTemplate<SPDouble>& C, SPField2DTemplate<SPDouble>& A, SPField2DTemplate<SPDouble>& B )
	{
		if( !computable(C,A) || !computable(C,B) )
		{
			std::cout<<"Error@Add(): Not computable."<<std::endl;
			return;
		}

		SPInt size = A.getSize();
		for( SPInt i=0; i<size; ++i )
		{
			C[i] = A[i] + B[i];
		}
	}

	/**
	* @brief     C = A + B
	* @param     [IN] @b C Field
	* @param     [IN] @b A Field
	* @param     [IN] @b B Field
	* @return     SPVoid
	*/
	SPVoid add( SPField2DTemplate<SPVec2d >& C, SPField2DTemplate<SPVec2d >& A, SPField2DTemplate<SPVec2d >& B )
	{
		if( !computable(C,A) || !computable(C,B) ) {
			std::cout<<"Error@Add(): Not computable."<<std::endl;
			return;
		}

		SPInt size = A.getSize();
		for( SPInt i=0; i<size; ++i )
		{
			add( C[i], A[i], B[i] );
		}
	}

	/**
	* @brief     A[i] -= a
	* @param     [IN] @b A Field
	* @param     [IN] @b a
	* @return     SPVoid
	*/
	SPVoid subtract( SPField2DTemplate<SPDouble>& A, SPDouble a )
	{
		SPInt size = A.getSize();
		for( SPInt i=0; i<size; ++i )
		{
			A[i] -= a;
		}
	}

	/**
	* @brief     A[i] -= a
	* @param     [IN] @b A Field
	* @param     [IN] @b a
	* @return     SPVoid
	*/
	SPVoid subtract( SPField2DTemplate<SPVec2d >& A, SPVec2d const& a )
	{
		SPInt size = A.getSize();
		for( SPInt i=0; i<size; ++i )
		{
			A[i] -= a;
		}
	}

	/**
	* @brief     C = A - B
	* @param     [IN] @b C Field
	* @param     [IN] @b A Field
	* @param     [IN] @b B Field
	* @return     SPVoid
	*/
	SPVoid subtract( SPField2DTemplate<SPDouble>& C, SPField2DTemplate<SPDouble>& A, SPField2DTemplate<SPDouble>& B )
	{
		if( !computable(C,A) || !computable(C,B) )
		{
			std::cout<<"Error@Subtract(): Not computable."<<std::endl;
			return;
		}

		SPInt size = A.getSize();
		for( SPInt i=0; i<size; ++i )
		{
			C[i] = A[i] - B[i];
		}
	}

	/**
	* @brief     C = A - B
	* @param     [IN] @b C Field
	* @param     [IN] @b A Field
	* @param     [IN] @b B Field
	* @return     SPVoid
	*/
	SPVoid subtract( SPField2DTemplate<SPVec2d >& C, SPField2DTemplate<SPVec2d >& A, SPField2DTemplate<SPVec2d >& B )
	{
		if( !computable(C,A) || !computable(C,B) )
		{
			std::cout<<"Error@Subtract(): Not computable."<<std::endl;
			return;
		}

		SPInt size = A.getSize();
		for( SPInt i=0; i<size; ++i )
		{
			substract( C[i], A[i], B[i] );
		}
	}

	/**
	* @brief     A[i] *= a
	* @param     [IN] @b A Field
	* @param     [IN] @b a
	* @return     SPVoid
	*/
	SPVoid multiply( SPField2DTemplate<SPDouble>& A, SPDouble a )
	{
		SPInt size = A.getSize();
		for( SPInt i=0; i<size; ++i )
		{
			A[i] *= a;
		}
	}

	/**
	* @brief     A[i] *= a
	* @param     [IN] @b A Field
	* @param     [IN] @b a
	* @return     SPVoid
	*/
	SPVoid multiply( SPField2DTemplate<SPVec2d >& A, SPDouble a )
	{
		SPInt size = A.getSize();
		for( SPInt i=0; i<size; ++i )
		{
			A[i] *= a;
		}
	}

	/**
	* @brief     A[i] += B[i]
	* @param     [IN] @b A Field
	* @param     [IN] @b B Field
	* @return     SPVoid
	*/
	SPVoid increase( SPField2DTemplate<SPDouble>& A, SPField2DTemplate<SPDouble>& B )
	{
		if( computable(A,B) )
		{

			SPInt size = A.getSize();
			for( SPInt i=0; i<size; ++i )
			{
				A[i] += B[i];
			}

		} else {

			if( !definedAtNode(A) )
			{
				std::cout<<"Error@Increase(): Invalid location."<<std::endl;
				return;
			}

		}
	}

	/**
	* @brief     A[i] += B[i]
	* @param     [IN] @b A Field
	* @param     [IN] @b B Field
	* @return     SPVoid
	*/
	SPVoid increase( SPField2DTemplate<SPVec2d >& A, SPField2DTemplate<SPVec2d >& B )
	{
		if( computable(A,B) )
		{
			SPInt size = A.getSize();
			for( SPInt i=0; i<size; ++i )
			{
				A[i] += B[i];
			}

		} else {

			if( !definedAtNode(A) )
			{
				std::cout<<"Error@Increase(): Invalid location."<<std::endl;
				return;
			}

		}
	}

	/**
	* @brief     A[i] -= B[i]
	* @param     [IN] @b A Field
	* @param     [IN] @b B Field
	* @return     SPVoid
	*/
	SPVoid decrease( SPField2DTemplate<SPDouble>& A, SPField2DTemplate<SPDouble>& B )
	{
		if( computable(A,B) )
		{

			SPInt size = A.getSize();
			for( SPInt i=0; i<size; ++i )
			{
				A[i] -= B[i];
			}

		} else {

			if( !definedAtNode(A) )
			{
				std::cout<<"Error@Decrease(): Invalid location."<<std::endl;
				return;
			}
		}
	}

	/**
	* @brief     A[i] -= B[i]
	* @param     [IN] @b A Field
	* @param     [IN] @b B Field
	* @return     SPVoid
	*/
	SPVoid decrease( SPField2DTemplate<SPVec2d >& A, SPField2DTemplate<SPVec2d >& B )
	{
		if( computable(A,B) )
		{
			SPInt size = A.getSize();
			for( SPInt i=0; i<size; ++i )
			{
				A[i] -= B[i];
			}

		} else {

			if( !definedAtNode(A) )
			{
				std::cout<<"Error@Decrease(): Invalid location."<<std::endl;
				return;
			}

		}
	}

	/**
	 * @brief  Normalize
	 */
	SPVoid normalize( SPField2DTemplate<SPDouble>& S )
	{
		// 	SPDouble min = S.GetMinimum();
		// 	SPDouble max = S.Getmaximum();
		// 
		// 	SPDouble diff = max - min;
		// 
		// 	SPInt size = S.getSize();
		// 	#pragma omp parallel for
		// 	for( SPInt i=0; i<size; ++i ) {
		// 		S[i] = ( S[i] - min ) / diff;
		// 	}
	}

	/**
	* @brief     normalize a vector
	* @param     [IN] @b V
	* @return     SPVoid
	*/
	SPVoid normalize( SPField2DTemplate<SPVec2d >& V )
	{
		const SPInt size = V.getSize();
		for( SPInt i=0; i<size; ++i )
		{
			normalize( V[i] );
		}
	}

	/**
	* @brief     S[i] *= M[i]
	* @param     [IN] @b S Field
	* @param     [IN] @b M Field
	* @return     SPVoid
	*/
	SPVoid modulate( SPField2DTemplate<SPDouble>& S, SPField2DTemplate<SPDouble>& M )
	{
		if( computable(S,M) )
		{
			SPInt size = S.getSize();
			for( SPInt i=0; i<size; ++i )
			{
				S[i] *= M[i];
			}

		} else {

			if( !definedAtNode(S) )
			{
				std::cout<<"Error@Modulate(): Invalid location."<<std::endl;
				return;
			}

		}
	}

	/**
	* @brief     S[i] *= M[i]
	* @param     [IN] @b S Field
	* @param     [IN] @b M Field
	* @return     SPVoid
	*/
	SPVoid modulate( SPField2DTemplate<SPVec2d >& S, SPField2DTemplate<SPDouble>& M )
	{
		if( computable(S,M) )
		{

			SPInt size = S.getSize();
			for( SPInt i=0; i<size; ++i )
			{
				S[i] *= M[i];
			}

		} else {

			if( !definedAtNode(S) )
			{
				std::cout<<"Error@Modulate(): Invalid location."<<std::endl;
				return;
			}

		}
	}

}

#endif //_SP_FIELD_2D_ADJUSTMENT_H_