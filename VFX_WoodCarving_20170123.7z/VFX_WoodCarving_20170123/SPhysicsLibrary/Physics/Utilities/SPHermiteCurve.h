/**
* @file SPHermiteCurve.h
* @brief 
*
* @date 2014-01-10
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_HERMITE_CURVE_H_
#define _SP_HERMITE_CURVE_H_

#include "SPDefines.h"
#include "SPMesh.h"

#include <vector>
#include <glm.hpp>

namespace SPhysics
{	
	/**
	* @class     SPHermiteCurve
	* @brief     Hermite Curve
	*/
	template <typename T>
	class SPHermiteCurve : public SPObject
	{
	public:
		/**
		* @brief     Constructor
		*/
		SPHermiteCurve()
		{
			m_bSetFirstPosition = SPFALSE;
			
			m_vFirstPoint         = glm::vec3();
			m_vSecondPoint        = glm::vec3();
			m_vFirstPointTangent  = glm::vec3();
			m_vSecondPointTangent = glm::vec3();
		}
		
		/**
		* @brief     Destructor
		*/
		~SPHermiteCurve(){}

		/**
		* @brief     Generate Hermite Curve
		* @param     [IN] @b points positions of curve
		* @param     [IN] @b ptsOnCurve number of points on curve 
		* @return     SPMesh
		*/		
		SPMesh generateHermiteCurve(const glm::vec3& nextPoint, SPInt ptsOnCurve)
		{
			if(m_bSetFirstPosition == SPFALSE)
				return SPMesh();

			m_vSecondPoint = nextPoint;
			glm::vec3 normalVec = m_vMidPoint - m_vSecondPoint;
			normalVec = glm::normalize(normalVec);
			//normalVec.normalize();
			m_vSecondPointTangent = normalVec * T(50);

			SPMesh mesh = SPMesh();

			SPFloat geometry[4][3] = { 
				{ m_vFirstPoint.x, m_vFirstPoint.y, m_vFirstPoint.z },	                       // Point1
				{ m_vMidPoint.x, m_vMidPoint.y, m_vMidPoint.z },	                   // Point2
				{ -m_vFirstPointTangent.x, -m_vFirstPointTangent.y, -m_vFirstPointTangent.z  },   // Tangent1
				{ m_vSecondPointTangent.x, m_vSecondPointTangent.y, m_vSecondPointTangent.z  } // Tangent2
			};

			// use the parametric time value 0 to 1
			for(SPInt i = 0; i != ptsOnCurve; ++i) {

				T t = (T)i / (ptsOnCurve - 1);

				// calculate blending functions
				T b0 =  2 * t * t  * t - 3 * t * t + 1;
				T b1 = -2 * t * t * t + 3 * t * t;
				T b2 = t * t * t - 2 * t * t + t;
				T b3 = t * t * t - t * t;

				// calculate the x,y and z of the curve point
				T x = b0 * geometry[0][0] + 
					b1 * geometry[1][0] + 
					b2 * geometry[2][0] + 
					b3 * geometry[3][0] ;

				T y = b0 * geometry[0][1] + 
					b1 * geometry[1][1] + 
					b2 * geometry[2][1] + 
					b3 * geometry[3][1] ;

				T z = b0 * geometry[0][2] + 
					b1 * geometry[1][2] + 
					b2 * geometry[2][2] + 
					b3 * geometry[3][2] ;

				// specify the point
				mesh.m_tVertex.push_back(SPVec3t(x, y, z));
			}
						
			m_vFirstPoint        = m_vMidPoint;
			m_vFirstPointTangent = m_vMidPointTangent;
			m_vMidPoint          = m_vSecondPoint;
			m_vMidPointTangent   = m_vSecondPointTangent;

			return mesh;
		}

		/**
		* @brief  Set first point
		*/		
		SPVoid setFirstPoint(const glm::vec3& point)
		{			
			m_vFirstPoint        = point;
			m_vMidPoint          = point;
			m_vFirstPointTangent = glm::vec3();
			m_vMidPointTangent = glm::vec3();
			m_bSetFirstPosition  = SPTRUE;
		}

		/**
		* @brief  Release line draw
		*/		
		SPVoid releaseLineDraw()
		{
			m_bSetFirstPosition = SPFALSE;
		}

		/**
		* @brief  Is available
		*/		
		const SPBool& isAvailable()
		{
			return m_bSetFirstPosition;
		}

	private:
		SPBool	  m_bSetFirstPosition;

		glm::vec3 m_vFirstPoint;
		glm::vec3 m_vMidPoint;
		glm::vec3 m_vSecondPoint;
		
		glm::vec3 m_vFirstPointTangent;
		glm::vec3 m_vMidPointTangent;
		glm::vec3 m_vSecondPointTangent;
	};

}
#endif //_SP_HERMITE_CURVE_H_