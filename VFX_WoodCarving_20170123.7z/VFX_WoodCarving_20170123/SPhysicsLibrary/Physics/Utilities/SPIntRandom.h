/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPIntRandom.h
 * @brief  File Int Random
 * @author Author (a.yusupov@samsung.com)
 */

#ifndef _INTRANDOM_H_
#define _INTRANDOM_H_

#include "SPThread.h"

namespace SPhysics
{

/**
 * @class  IntRandom
 * @brief  Integer random
 */
template<SPUInt Capacity = 8192, SPUInt MaxRandomValue = 8192>
class IntRandom
{
public:

	/**
	 * @brief Constructor.
	 * Fill predefined random array.
	 */
	inline IntRandom();

	/**
	 * @brief Get next random value.
	 * Value range 0 ~ 'MaxRandomValue'.
	 *
	 * @return Random value. Range 0 ~ 'MaxRandomValue'.
	 */
	inline SPUInt get();

private:

	SPUInt mValue[Capacity]; /**<Array of predefined random values.*/
	SPUInt mNumber; /**<Current index in array.*/
};

} /* namespace SPhysics */

#include "SPIntRandom.inl"

#endif /* _INTRANDOM_H_ */

