/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPMeshGenerator.h
 * @brief  Generator of mesh for geometry primitives.
 * @author Andrii Burevych (a.burevych@samsung.com)
 */

#include <glm.hpp>

namespace SPhysics
{

class SPObjectData;

/**
 *  Generates vertices, normals & UV for geometry primitives (Box, Sphere, Capsule, Ellipsoid etc.).
 *
 */
class SPMeshGenerator
{
public:

	/**
	* @brief  Generate sphere
	*/
	static void generateSphere(SPObjectData& aObject, const float aRadius);

	/**
	* @brief  Generate box
	*/
	static void generateBox(SPObjectData& aObject, const glm::vec3& aHalfExt);

	/**
	* @brief  Generate capsule
	*/
	static void generateCapsule(SPObjectData& aObject, const float aRadius, const float aHalfLenght);

	/**
	* @brief  Generate ellipsoid
	*/
	static void generateEllipsoid(SPObjectData& aObject, const glm::vec3& aEllipsoidCoef);

	/**
	* @brief  Generate grid
	*/
	static void generateGrid(SPObjectData& aObject, const unsigned int aWidth, const unsigned int aHeight);
};

}
