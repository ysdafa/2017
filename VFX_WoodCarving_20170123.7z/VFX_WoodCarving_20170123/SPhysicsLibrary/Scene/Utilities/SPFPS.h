/**
* @file SPFPS.h
* @brief 
*
* @date 2013-05-01
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/


#ifndef _SP_FPS_H_
#define _SP_FPS_H_

#include "SPISceneComponent.h"
#include "SPDrawText.h"
#include <string>

#ifdef __ANDROID__
#include <time.h>
#include <unistd.h> 

// struct timeval 
// { 
// 	SPLong tv_sec;       
// 	SPLong tv_usec;      
// };
#endif

#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#endif

namespace SPhysics
{

	class SPFPS : public SPISceneComponent
	{
	public:
		SPFPS();
		virtual ~SPFPS();

	public:
		typedef SPFloat T;
		SPVoid initApp(SPInt width, SPInt height);
		SPVoid updateApp();
		SPVoid drawApp();
		SPVoid onEventKey(KEY_TYPE keyID);
		SPVoid onEventTouch(TOUCH_TYPE eventType, SPInt xPos, SPInt yPos);
		SPVoid onEventMultiTouch(TOUCH_TYPE eventType, SPInt touchID, SPInt touchNum, SPInt *xPos, SPInt *yPos){};
		SPVoid onEventSensor(SENSOR_TYPE sensorType, SPFloat xValue, SPFloat yValue, SPFloat zValue);
		SPVoid resetApp();
		SPVoid setForceApp();	
		
	private:				

#if defined(__ANDROID__) || defined(TIZEN)
 		timeval m_sStartTime;
 		timeval m_sEndTime;
#endif

#ifdef _WIN32
		SPULong m_lStartTickValue;
#endif

		SPInt m_nFrameCnt;
		SPInt m_nFPS;

		SPInt m_nIntervalFrameCnt;

		SPDrawText*  m_pDrawText;

		std::string  m_sStringFPS;
	};

}//namespace SPhysics

#endif //_SP_FPS_H_