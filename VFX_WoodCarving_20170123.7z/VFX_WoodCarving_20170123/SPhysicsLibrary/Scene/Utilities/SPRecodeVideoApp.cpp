/**
* @file SPRecodeVideoApp.cpp
* @brief
*
* @date 2014-03-06
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPRecodeVideoApp.h"

namespace SPhysics
{
	SPRecodeVideoApp::SPRecodeVideoApp()
	{
	}

	SPRecodeVideoApp::~SPRecodeVideoApp()
	{
		m_cRecodeVideo.deinit();
	}

	SPVoid SPRecodeVideoApp::initApp(SPInt width, SPInt height)
	{
		m_cRecodeVideo.init(width, height, "VideoOut", "mp4");
	}

	SPVoid SPRecodeVideoApp::updateApp()
	{
	}

	SPVoid SPRecodeVideoApp::drawApp()
	{
		m_cRecodeVideo.recode();		
	}

	SPVoid SPRecodeVideoApp::onEventTouch(TOUCH_TYPE eventType, SPInt xPos, SPInt yPos)
	{
	}

	SPVoid SPRecodeVideoApp::onEventSensor(SENSOR_TYPE sensorType, SPFloat xValue, SPFloat yValue, SPFloat zValue)
	{
	}

	SPVoid SPRecodeVideoApp::onEventKey(KEY_TYPE keyID)
	{
	}

	SPVoid SPRecodeVideoApp::resetApp()
	{
	}

	SPVoid SPRecodeVideoApp::setForceApp()
	{
	}
}
//namespace SPhysics