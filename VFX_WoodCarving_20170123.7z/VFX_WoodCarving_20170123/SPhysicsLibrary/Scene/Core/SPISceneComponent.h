/**
* @file SPISceneComponent.h
* @brief This file includes the implementations that represent S
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/


#ifndef _SP_I_SCENE_COMPONENT_H_
#define _SP_I_SCENE_COMPONENT_H_

#include "SPDefines.h"
#include "SPLog.h"
#include <vector>
#include <glm.hpp>

namespace SPhysics
{

#define MAX_TOUCH_NUM		10

#define SCENE_VISIBLE 1
#define SCENE_INVISIBLE 0

	//#define	RENDER_LAYER(x)			reinterpret_cast<CVertexBase*>(x.second) 
#define	SCENE_LAYER(x)		reinterpret_cast<SPISceneComponent*>(x.second) 

	typedef enum _MASK_LAYER_TYPE
	{
		MASK_LAYER_SCENE,
		MASK_LAYER_RENDER
	}MASK_LAYER_TYPE;

	typedef std::pair<int, SPVoid*> PAIR_ITEM;


	/**
	* @class     SPISceneComponent
	* @brief     Interface of all application. abstract class
	*/
	class SPISceneComponent
	{
	public:
		SPISceneComponent();
		virtual ~SPISceneComponent();

		// This API must be implemented in child class
		virtual  SPVoid makeSceneLayer(){}

		/**
		* @brief	 Application initialization  
		* @param     [IN] @b width Screen width size
		* @param     [IN] @b height Screen height size
		* @return     SPVoid
		*/
		virtual SPVoid initApp(SPInt width, SPInt height){}

		/**
		* @brief	 Application onEventSurfaceChanged  
		* @param     [IN] @b width Screen width size
		* @param     [IN] @b height Screen height size
		* @return     SPVoid
		*/
		virtual SPVoid onEventSurfaceChanged(SPInt width, SPInt height){}

		/**
		* @brief     Destroy application
		* @return     SPVoid
		*/
		virtual SPVoid destroyApp(){}

		/**
		* @brief     Update application\n
		(event processing, updating Simulation, Generating Rendering meshes, etc.)
		* @return     SPVoid
		*/
		virtual SPVoid updateApp(){}

		/**
		* @brief     Drawing scene
		* @return     SPVoid
		*/
		virtual SPVoid drawApp(){}

		/**
		* @brief     Key event handling
		* @return     SPVoid
		*/
		virtual SPVoid onEventKey(KEY_TYPE keyID){}

		/**
		* @brief     Custom event handling
		* @return     SPVoid
		*/
		virtual SPVoid onEventCustom(SPInt customID, SPFloat customValue){}

		/**
		* @brief     Custom event handling
		* @return     SPVoid
		*/
		virtual SPVoid onEventCustom(SPInt customID, SPFloat xValue, SPFloat yValue, SPFloat zValue){}

		/**
		* @brief     Single Touch event handling
		* @return     SPVoid
		*/
		virtual SPVoid onEventTouch(TOUCH_TYPE eventType, SPInt xPos, SPInt yPos){}

		/**
		* @brief     Hover event handling
		* @return     SPVoid
		*/
		virtual SPVoid onEventHover(HOVER_TYPE eventType, SPInt xPos, SPInt yPos){}

		/**
		* @brief     Multi Touch event handling
		* @return     SPVoid
		*/
		virtual SPVoid onEventMultiTouch(TOUCH_TYPE eventType, SPInt touchID, SPInt touchNum, SPInt *xPos, SPInt *yPos){}

		/**
		* @brief     Sensor event handling
		* @return     SPVoid
		*/
		virtual SPVoid onEventSensor(SENSOR_TYPE sensorType, SPFloat xValue, SPFloat yValue, SPFloat zValue){}

		/**
		* @brief     if SPTextureManager::setTexture is called from java layer to generate a texture, notify the event to the scene layer
		* @param     [IN] @b name Specifies bitmap file's name
		* @return     SPVoid
		*/
		virtual SPVoid onEventSetTexture(const SPChar* name){}

		/**
		* @brief     if SPTextureManager::setTexture is called from java layer to generate a color buffer, notify the event to the scene layer
		* @param     [IN] @b name Specifies bitmap file's name
		* @return     SPVoid
		*/
		virtual SPVoid onEventSetTextureColor(const SPChar* name){}

		/**
		* @brief     Reset application 
		* @return     SPVoid
		*/
		virtual SPVoid resetApp(){}

		/**
		* @brief     Check current draw status which is running with simulation or not 
		* @return     SPVoid
		*/
		virtual SPBool isEmptyDraw(){return SPFALSE;};

		// API with System Event

		/**
		* @brief     create the scene layer
		* @return     SPVoid
		*/
		SPVoid createSceneLayer();

		/**
		* @brief     Scene initialization
		* @param     [IN] @b width Width size of viewport
		* @param     [IN] @b height Height size of viewport
		* @return     SPVoid
		*/
		SPVoid onInitScene(SPInt width, SPInt height);

		/**
		* @brief     Scene onSurfaceChanged
		* @param     [IN] @b width Width size of viewport
		* @param     [IN] @b height Height size of viewport
		* @return     SPVoid
		*/
		SPVoid onSurfaceChanged(SPInt width, SPInt height);

		/**
		* @brief      Update Scene 
		* @return     SPVoid
		*/
		SPVoid onUpdateScene();

		/**
		* @brief     clear the gl_buffer with this API, this API just called once before root scene's onDrawScene (android : JNI Interface, Win32 : S-Physics.cpp)
		* @return    SPVoid
		*/
		SPVoid clearGLBuffer();

		/**
		* @brief     Render Scene
		* @return     SPVoid
		*/
		SPVoid onDrawScene();

		/**
		* @brief     Touch event handling 
		* @param     [IN] @b touchID		Touch id
		* @param     [IN] @b touchNum	Touch number
		* @param     [IN] @b eventType	Touch event type( enum _TOUCH_TYPE )
		* @param     [IN] @b xPos		X position of touch 
		* @param     [IN] @b yPos		Y position of touch
		* @return     SPVoid
		*/
		SPVoid onTouchEvent(SPInt touchID, SPInt touchNum, SPInt eventType, SPInt xPos[], SPInt yPos[]);

		/**
		* @brief     Hover event handling 
		* @param     [IN] @b eventType	Hover event type( enum _HOVER_TYPE )
		* @param     [IN] @b xPos		X position of hover
		* @param     [IN] @b yPos		Y position of hover
		* @return     SPVoid
		*/
		SPVoid onHoverEvent(SPInt eventType, SPInt xPos, SPInt yPos);

		/**
		* @brief     Sensor event handling 
		* @param     [IN] @b sType		Sensor event type( enum _SENSOR_TYPE )
		* @param     [IN] @b xValue		X position of sensor
		* @param     [IN] @b yValue		Y position of sensor
		* @param     [IN] @b zValue		Z position of sensor
		* @return     SPVoid
		*/
		SPVoid onSensorEvent(SPInt sType, SPFloat xValue, SPFloat yValue, SPFloat zValue);

		/**
		* @brief     if SPTextureManager::setTexture is called from java layer to generate a texture, notify the event to the scene layer
		* @param     [IN] @b name Specifies bitmap file's name
		* @return     SPVoid
		*/
		SPVoid onSetTextureEvent(const SPChar* name);

		/**
		* @brief     if SPTextureManager::setTexture is called from java layer to generate a color buffer, notify the event to the scene layer
		* @param     [IN] @b name Specifies bitmap file's name
		* @return     SPVoid
		*/
		SPVoid onSetTextureColorEvent(const SPChar* name);

		/**
		* @brief     check an animation works or not in the current frame
		* @return    SPBool
		*/
		SPBool isEmpty();

		/**
		* @brief     Key event handling 
		* @param     [IN] @b keyID		Key event type( enum _KEY_TYPE )
		* @return     SPVoid
		*/
		SPVoid onKeyEvent(SPInt keyID);

		/**
		* @brief     User Custom event handling 
		* @param     [IN] @b keyID		Custom event type
		* @param     [IN] @b value		Custom event value
		* @return     SPVoid
		*/
		SPVoid onCustomEvent(SPInt eventID, SPFloat value);

		/**
		* @brief     User Custom event handling 
		* @param     [IN] @b keyID		Custom event type
		* @param     [IN] @b xValue		Custom event value
		* @param     [IN] @b yValue		Custom event value
		* @param     [IN] @b zValue		Custom event value
		* @return     SPVoid
		*/
		SPVoid onCustomEvent(SPInt eventID, SPFloat xValue, SPFloat yValue, SPFloat zValue);

		/**
		* @brief     Reset Scene
		* @return     SPVoid
		*/
		SPVoid onResetScene();

		/**
		* @brief     Set force scene 
		* @return     SPVoid
		*/
		SPVoid setForceScene();

		/**
		* @brief     Add to Scene 
		* @param [IN] @b pScene Add to Scene
		* @return     SPVoid
		*/
		SPVoid addSceneLayer(SPISceneComponent *pScene);

		/**
		* @brief     Remove mask layer
		* @param  [IN] @b pItem  
		* @return     SPVoid
		*/
		SPVoid removeMaskLayer(SPVoid *pItem);

		/**
		* @brief     Set visibility
		* @param  [IN] @b flag The flag whether is visible or not
		* @return    SPVoid
		*/
		SPVoid setVisibility(SPInt flag);

		/**
		* @brief     Get visibility
		* @return    SPInt return visibility of scene component
		*/
		SPInt  getVisibility();


// 	public:
// 
// 		SPInt keyID;

		// Component Items
	protected:
		//std::vector <SPISceneComponent*>  m_vSceneLayerItems; // sceneApp array
		std::vector <PAIR_ITEM>  m_vLayerItems; // sceneApp array
		SPInt m_nScreenWidth;
		SPInt m_nScreenHeight;
		SPInt m_nVisibility;
		SPBool mIsTransition;
	};

}  //namespace SPhysics

#endif // _SP_I_SCENE_COMPONENT_H_
