/**
* @file SPTimeLog.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/


#ifndef _SP_TIME_LOG_H_
#define _SP_TIME_LOG_H_

#include "SPDefines.h"
#include "SPLog.h"


#define SP_TIME_LOG				1			//!< if you want disable time log, change to '0'
#define SP_TIME_LOG_FPS			1			//!< time log FPS
#define INTERVAL_LOW_BOUND		1000000		//!< us (if duration is lower than this value then warning message will be printed)

#if defined(_WIN32) || defined(_WIN64)

#ifndef __func__

#if defined(__PRETTY_FUNCTION__)
#define		__func__	__PRETTY_FUNCTION__
#else
#define		__func__	__FUNCTION__
#endif	// __PRETTY_FUNCTION__
#endif	// __func__

#endif	// _WIN32 || _WIN64

namespace SPhysics
{
	#define MAX_TIME_LOG_CHANNEL_COUNT		256		//!< Max time log channel count

	/**
	 * @class SPTimeLog
	 * @brief Time log
	 */
	class SPTimeLog
	{
	public:
		/**
		 * @enum _SP_TIME_LOG_MODE
		 * @brief Time log mode
		 */
		typedef enum _SP_TIME_LOG_MODE
		{
			SP_TIME_LOG_NORMAL_MODE,	/* just use start / end time of lately captured */
			SP_TIME_LOG_AVG_MODE,		/* accumulate time during enalbed */
		} SP_TIME_LOG_MODE;	//!< Time log mode
	
	public:
		/**
		* Setup
		*
		* @param mode of time log.
		*/
		static SPVoid setupTimeLog(SP_TIME_LOG_MODE mode = SP_TIME_LOG_NORMAL_MODE);

	
		/**
		* Enable capturing of time log
		*
		* @param channel of time log. ( -1 is mean enable all channel)
		*/
		static SPVoid enableTimeLog(SPInt channel = -1);
	
		/**
		* Disable capturing of time log
		*
		* @param SPInt channel of time log. (-1 is mean disable all channel)
		*/
		static SPVoid disableTimeLog(SPInt channel = -1);


		/**
		* Set start time
		*
		* @param SPInt Channel for setting start time.
		*/
		static SPInt setStartTimeLog(SPInt channel = 0);

		/**
		* @brief Set start time
		*/
		static SPVoid setStartTimeLog(SPInt channel, SPInt time);

		/**
		* Set end time
		*
		* @param SPInt		Channel for setting end time.
		* @param SPChar*	Tag is setted by user
		* @param SPChar*	Function's Name (you can use __func__)
		* @param SPInt		Sub channel for setting start time. (you don't have to use this channel, you can use for using same channel like case of recursive function)
		* @param SPUInt		bound of interval (if your time log's interval is bigger than this value, warning is printed to your consol with interval.)
		*/
		static SPInt setEndTimeLog(SPInt channel = 0, const  SPChar* tag = SPNULL, const SPChar* functionName = SPNULL, SPUInt IntervalLowBound = INTERVAL_LOW_BOUND /* us */);


		/**
		* Get end time
		*
		* @return time value : us
		*/
		static SPUInt getCurrTime();

		/**
		* print all time logs
		* in the SP_TIME_LOG_NORMAL_MODE : printing value will be peak value of each channel & subChannel
		* in the SP_TIME_LOG_AVG_MODE    : printing value will be average value of each channel & subChannel
		* @param SPVoid
		*/
		static SPVoid printAllTimeLog();


		/**
		* set fps point
		* @param SPVoid
		*/
		static SPVoid setFPSPoint(void);
	};

}  //namespace SPhysics


/*  example

	class classA
	{
	public :
		classA() 
		{
			setupTimeLog(SP_TIME_LOG_NORMAL_MODE);
			enableTimeLog();						// you can enable logging when you want to start logging
		}

		~classA() 
		{
			disableTimeLog();						//  you can disable logging when you want to stop logging
			printAllTimeLog();						// if you didn't disable logging then it will be disabled automatically.
		}

		SPVoid a
		{
			setStartTimeLog(0, 0);

			...

			// some codes
			int a = 1;
			int b = 1 + 1;
			
			...

			setEndTimeLog(0, "my tag", __func__, 0, 10000);
		}

		SPVoid b
		{
			setStartTimeLog(1, 0);

			...

			// some codes
			int a = 1;
			int b = 1 + 1;
			
			...

			setEndTimeLog(1, "my tag", __func__, 0, 10000);
		}
	};

*/


#endif	// _SP_TIME_LOG_H_