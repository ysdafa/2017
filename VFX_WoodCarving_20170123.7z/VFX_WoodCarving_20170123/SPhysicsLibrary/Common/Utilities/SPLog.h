/**
* @file SPLog.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/


#ifndef _SP_LOG_H_
#define _SP_LOG_H_

#ifdef __ANDROID__
#include <android/log.h>
#endif

#ifdef TIZEN
#include <dlog.h>
#endif

#include <stdio.h>


namespace SPhysics
{
	
#ifdef __ANDROID__

#define  LOG_TAG    "S-Physics"

#define  SP_LOGI(...)  { __android_log_print(ANDROID_LOG_INFO, LOG_TAG,__VA_ARGS__); }
#define  SP_LOGW(...)  { __android_log_print(ANDROID_LOG_WARN, LOG_TAG,__VA_ARGS__); }
#define  SP_LOGE(...)  { __android_log_print(ANDROID_LOG_ERROR,LOG_TAG,__VA_ARGS__); }

#else

#ifdef TIZEN
#define  SP_LOGI(...)  { dlog_print(DLOG_INFO, "sphysics_pba", __VA_ARGS__);}
#define  SP_LOGW(...)  { dlog_print(DLOG_WARN, "sphysics_pba", __VA_ARGS__);}
#define  SP_LOGE(...)  { dlog_print(DLOG_ERROR, "sphysics_pba", __VA_ARGS__);}
#else

/**
* @def     SP_LOGI
* @brief     Log about information
*/
#define  SP_LOGI(...)  { printf("S-Physics Info: ");    printf(__VA_ARGS__); printf("\n"); }
/**
* @def     SP_LOGW
* @brief     Log about warning
*/
#define  SP_LOGW(...)  { printf("S-Physics Warning: "); printf(__VA_ARGS__); printf("\n"); }
/**
* @def     SP_LOGE
* @brief     Log about error
*/
#define  SP_LOGE(...)  { printf("S-Physics Error: ");   printf(__VA_ARGS__); printf("\n"); }

#endif
#endif


}  //namespace SPhysics

#endif // _SP_LOG_H_

