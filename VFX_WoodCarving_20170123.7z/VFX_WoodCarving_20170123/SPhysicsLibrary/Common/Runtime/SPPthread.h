/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPPthread.h
 * @brief  Header for pthread functions
 * @author Author Arthur Yusupov (a.yusupov@samsung.com)
 */

#ifndef _SP_PTHREAD_H_
#define _SP_PTHREAD_H_

#ifdef _MSC_VER
#define NOMINMAX
#include <Windows.h>
#endif // _MSC_VER

#ifndef __linux__
#define pthread_setname_np(THREAD, NAME) (void)(NAME)	//!< pthread_setname_np
#endif /* __linux__ */

#ifdef _MSC_VER

#define pthread_t HANDLE

#define pthread_mutex_t CRITICAL_SECTION

#define pthread_cond_t CONDITION_VARIABLE

#define pthread_self() GetCurrentThread()

#define pthread_create(THREAD, ATTR, FUNC, ARG) (*(THREAD) = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)(FUNC), (ARG), 0, NULL), *(THREAD) == INVALID_HANDLE_VALUE)

#define pthread_join(THREAD, RET) WaitForSingleObject((THREAD), INFINITE), GetExitCodeThread((THREAD), (LPDWORD)(RET))

#define pthread_mutex_init(MUTEX, ATTR) InitializeCriticalSection(MUTEX)

#define pthread_mutex_destroy(MUTEX) DeleteCriticalSection(MUTEX)

#define pthread_mutex_lock(MUTEX) EnterCriticalSection(MUTEX)

#define pthread_mutex_unlock(MUTEX) LeaveCriticalSection(MUTEX)

#define pthread_cond_init(COND, ATTR) InitializeConditionVariable(COND)

#define pthread_cond_destroy(COND)

#define pthread_cond_wait(COND, MUTEX) SleepConditionVariableCS(COND, MUTEX, INFINITE)

#define pthread_cond_signal(COND) WakeConditionVariable(COND)

#define pthread_cond_broadcast(COND) WakeAllConditionVariable(COND)

#else /* _MSC_VER */

#if !defined(_MSC_VER)
#include <pthread.h>
#endif /* !defined(_MSC_VER) */

#endif /* _MSC_VER */

#endif /* _SP_PTHREAD_H_ */
