/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPTaskPool.h
 * @brief  File SPTask Pool
 * @author Author Arthur Yusupov (a.yusupov@samsung.com)
 */

#ifndef _SP_TASKPOOL_H_
#define _SP_TASKPOOL_H_

#include "SPTask.h"

#include <vector>

namespace SPhysics
{

/**
 * @class SPTaskPool
 * @brief Task pool
 */
class SPTaskPool: NonCopyable
{

public:

	/**
	 * Constructor.
	 */
	inline SPTaskPool(unsigned int aThreadCount);

	/**
	 * Destructor.
	 */
	inline ~SPTaskPool();

	/**
	 * Wait first free task.
	 *
	 * @return Free task.
	 */
	inline SPTask* select();

	/**
	 * Get first free task. If all tasks is busy, then return 'NULL'.
	 *
	 * @return Free task if present, otherwise 'NULL'.
	 */
	inline SPTask* trySelect();

	/**
	 * @brief Execute 'ClassType' 'aObject' method ('aFunction') with given argument ('aArgument').
	 * If all tasks is busy, then method will be executed in current thread.
	 * @param aObject
	 * @param aFunction
	 * @param aArgument
	 */
	template<typename ClassType, typename FunctionArgumentType>
	inline void execute(ClassType& aObject, void (ClassType::*aFunction)(FunctionArgumentType),
						FunctionArgumentType& aArgument);

	/**
	 * Wait till the end of all tasks.
	 */
	inline void waitAll();

private:

	std::vector<SPTask*> mTasks; /**< SPTask list.*/
	SPEvent mSelectEvent;

};

} /* namespace SPhysics */

#include "SPTaskPool.inl"

#endif /* _SP_TASKPOOL_H_ */

