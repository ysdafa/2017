/**
* @file SPAtomic.h
* @brief This files is the implementation of Button UI Modules.
*
* @date 2013-04-23
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/
#ifndef _SP_ATOMIC_H_
#define _SP_ATOMIC_H_

#include <SPDefines.h>

#if defined(_MSC_VER)
#define NOMINMAX
#include <Windows.h>
#endif

namespace SPhysics
{
#if !defined(_MSC_VER)
	/**
	 * @class SPAtomic
	 * @brief Atomic
	 */
	template <typename T>
	class SPAtomic
	{
	public:
		SPAtomic() : m_value(static_cast<T>(0)) {}
		~SPAtomic() {}

		/**
		 * @brief Load
		 */
		inline T load()
		{
			return __sync_fetch_and_add(&m_value, 0);
		}
		
		/**
		 * @brief Store
		 */
		inline SPVoid store(T value)
		{
			__sync_lock_test_and_set(&m_value, value);
		}

		/**
		 * @brief Exchange
		 */
		inline T exchange(T value)
		{
			return __sync_lock_test_and_set(&m_value, value);
		}

		/**
		 * @brief Compare exchange
		 */
		inline T compare_exchange(T expected, T value)
		{
			return __sync_val_compare_and_swap(&m_value, expected, value);
		}

		/**
		 * @brief Increase
		 */
		inline SPVoid increase()
		{
			__sync_fetch_and_add(&m_value, 1);
		}

		/**
		 * @brief Decrease
		 */
		inline SPVoid decrease()
		{
			__sync_fetch_and_sub(&m_value, 1);
		}

		/**
		 * @brief Add
		 */
		inline SPVoid add(T value)
		{
			__sync_fetch_and_add(&m_value, value);
		}

		/**
		 * @brief Sub
		 */
		inline SPVoid sub(T value)
		{
			__sync_fetch_and_sub(&m_value, value);
		}

	protected:
		volatile T m_value; //!< value
	};

	template <typename T>
	class SPAtomic <T*>
	{
	public:
		SPAtomic() {}
		~SPAtomic() {}

		/**
		 * @brief Load
		 */
		inline T* load()
		{
			return (T*)__sync_fetch_and_add(&m_value, 0);
		}
		
		/**
		 * @brief Store
		 */
		inline SPVoid store(T* value)
		{
			__sync_lock_test_and_set(&m_value, value);
		}

		/**
		 * @brief Exchange
		 */
		inline T* exchange(T* value)
		{
			return (T*)__sync_lock_test_and_set(&m_value, value);
		}

		/**
		 * @brief Compare exchange
		 */
		inline T* compare_exchange(T* expected, T* value)
		{
			return (T*)__sync_val_compare_and_swap(&m_value, expected, value);
		}

		/**
		 * @brief Increase
		 */
		inline SPVoid increase()
		{
			__sync_fetch_and_add(&m_value, sizeof(T*));
		}

		/**
		 * @brief Decrease
		 */
		inline SPVoid decrease()
		{
			__sync_fetch_and_sub(&m_value, sizeof(T*));
		}

		// there is no add, sub, and, or, xor, nand function for pointer preventing error

	protected:
		volatile T* m_value; //!< value
	};
#else
	template <typename T>
	class SPAtomic
	{
	public:
		SPAtomic() {}
		~SPAtomic() {}		

		inline T load()
		{
			return InterlockedExchangeAdd(&m_value, 0);
		}

		inline SPVoid store(T value)
		{
			InterlockedExchange(&m_value, value);
		}

		inline T exchange(T value)
		{
			return InterlockedExchange(&m_value, value);
		}

		inline T compare_exchange(T expected, T value)
		{
			return InterlockedCompareExchange(&m_value, value, expected);
		}

		inline SPVoid increase()
		{
			InterlockedIncrement(&m_value);
		}

		inline SPVoid decrease()
		{
			InterlockedDecrement(&m_value);
		}

		inline SPVoid add(T value)
		{
			InterlockedExchangeAdd(&m_value, value);
		}

		inline SPVoid sub(T value)
		{
			InterlockedExchangeAdd(&m_value, -value);
		}

	protected:
		volatile T m_value;
	};

#ifdef _WIN64
	template <typename T>
	class SPAtomic<T*>
	{
	public:
		SPAtomic() {}
		~SPAtomic() {}		

		inline T* load()
		{
			return InterlockedExchangeAdd(&m_value, 0);
		}

		inline SPVoid store(T* value)
		{
			InterlockedExchange(&m_value, (SPULongLong)value);
		}

		inline T* exchange(T* value)
		{
			return (T*)InterlockedExchange(&m_value, (SPULongLong)value);
		}

		inline T* compare_exchange(T* expected, T* value)
		{
			return (T*)InterlockedCompareExchange(&m_value, (SPULongLong)value, (SPULongLong)expected);
		}

		inline SPVoid increase()
		{
			InterlockedExchangeAdd(&m_value, sizeof(T*));
		}

		inline SPVoid decrease()
		{
			InterlockedExchangeAdd((SPULongLong*)&m_value, - (SPULongLong)sizeof(T*));
		}

		// there is no add & sub function for pointer preventing error

	protected:
		volatile SPULongLong m_value;
	};
#else
	template <typename T>
	class SPAtomic<T*>
	{
	public:
		SPAtomic() {}
		~SPAtomic() {}		

		inline T* load()
		{
			return (T*)InterlockedExchangeAdd(&m_value, 0);
		}

		inline SPVoid store(T* value)
		{
			InterlockedExchange(&m_value, (SPULongLong)value);
		}

		inline T* exchange(T* value)
		{
			return (T*)InterlockedExchange(&m_value, (SPULong)value);
		}

		inline T* compare_exchange(T* expected, T* value)
		{
			return (T*)InterlockedCompareExchange(&m_value, (SPULong)value, (SPULong)expected);
		}

		inline SPVoid increase()
		{
			InterlockedExchangeAdd(&m_value, (SPULong)sizeof(T*));
		}

		inline SPVoid decrease()
		{
			InterlockedExchangeAdd((SPLong*)&m_value, - (SPLong)sizeof(T*));
		}

		// there is no add & sub function for pointer preventing error

	protected:
		volatile SPULong m_value;
	};
#endif

	template<>
	class SPAtomic<SPInt>
	{
	public:
		SPAtomic() {}
		~SPAtomic() {}		

		inline SPInt load()
		{
			return (SPInt)InterlockedExchangeAdd(&m_value, (SPLong)0);
		}

		inline SPVoid store(SPInt value)
		{
			InterlockedExchange(&m_value, (SPLong)value);
		}

		inline SPInt exchange(SPInt value)
		{
			return (SPInt)InterlockedExchange(&m_value, (SPLong)value);
		}

		inline SPInt compare_exchange(SPInt expected, SPInt value)
		{
			return (SPInt)InterlockedCompareExchange(&m_value, (SPLong)value, (SPLong)expected);
		}

		inline SPVoid increase()
		{
			InterlockedIncrement(&m_value);
		}

		inline SPVoid decrease()
		{
			InterlockedDecrement(&m_value);
		}

		inline SPVoid add(SPInt value)
		{
			InterlockedExchangeAdd(&m_value, (SPLong)value);
		}

		inline SPVoid sub(SPInt value)
		{
			InterlockedExchangeAdd(&m_value, - (SPLong)value);
		}

	protected:
		volatile SPLong m_value;
	};

	template<>
	class SPAtomic<SPLong>
	{
	public:
		SPAtomic() {}
		~SPAtomic() {}		

		inline SPLong load()
		{
			return (SPLong)InterlockedExchangeAdd(&m_value, 0);
		}

		inline SPVoid store(SPLong value)
		{
			InterlockedExchange(&m_value, value);
		}

		inline SPLong exchange(SPLong value)
		{
			return (SPLong)InterlockedExchange(&m_value, value);
		}

		inline SPLong compare_exchange(SPLong expected, SPLong value)
		{
			return (SPLong)InterlockedCompareExchange(&m_value, value, expected);
		}

		inline SPVoid increase()
		{
			InterlockedIncrement(&m_value);
		}

		inline SPVoid decrease()
		{
			InterlockedDecrement(&m_value);
		}

		inline SPVoid add(SPInt value)
		{
			InterlockedExchangeAdd(&m_value, value);
		}

		inline SPVoid sub(SPInt value)
		{
			InterlockedExchangeAdd(&m_value, - value);
		}

	protected:
		volatile SPLong m_value;
	};
#endif


}
#endif