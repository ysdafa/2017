/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPSyncParallelFunc.h
 * @brief  TaskPool of multi threading for parallel processing
 * @author Author (jinbong.lee@samsung.com)
 */

#ifndef _SP_SYNC_PARALLEL_FUNC_H_
#define _SP_SYNC_PARALLEL_FUNC_H_

//	if you want to use over 32 threads then you must implement thread's index to support
#define MAX_RUNNING_ASYNC_TASK_COUNT	4	//!< Max running async task count

#include "SPPthread.h"
#include "SPDefines.h"

namespace SPhysics
{
	static inline int ffs_32(int x)
	{
		int r = 0;
		if (!x)
			return -1;

#if (MAX_RUNNING_ASYNC_TASK_COUNT > 16)
		if (!(x & 0xffff)) {
			x >>= 16;
			r += 16;
		}
#endif

#if (MAX_RUNNING_ASYNC_TASK_COUNT > 8)
		if (!(x & 0xff)) {
			x >>= 8;
			r += 8;
		}
#endif
		if (!(x & 0xf)) {
			x >>= 4;
			r += 4;
		}
		if (!(x & 0x3)) {
			x >>= 2;
			r += 2;
		}
		if (!(x & 0x1)) {
			x >>= 1;
			r += 1;
		}
		return r;
	}

	/**
	 * @class SPSyncParallelFunc
	 * @brief Synchronize parallel functions
	 */
	class SPSyncParallelFunc
	{
	public:
		SPSyncParallelFunc();
		virtual ~SPSyncParallelFunc();

		/**
		 * @brief Execute
		 */
		SPVoid execute(SPVoid (*function)(SPVoid*), SPVoid* argment);

		/**
		 * @brief Wait
		 */
		SPVoid	wait();
		/**
		 * @brief Is running
		 */
		SPBool	isRun();

	private:
		SPBool			m_bWaiting;
		SPInt			m_threadCount;		
		SPInt			m_nInitedThread;
		SPInt			m_nAvailableThread;
		pthread_mutex_t m_nThreadMutex;		
		pthread_cond_t	m_nThreadCondWait;
		class SPAsyncLocalThread*			m_pThread[MAX_RUNNING_ASYNC_TASK_COUNT];
	};
}


#endif