/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPCriticalSection.h
 * @brief  File Critical Section
 * @author Author Arthur Yusupov (a.yusupov@samsung.com)
 */

#ifndef _SP_CRITICALSECTION_H_
#define _SP_CRITICALSECTION_H_

#include "SPNonCopyable.h"
#include "SPPthread.h"

namespace SPhysics
{
/**
 * Critical section
 * For organization of separated access to shared resources.
 */
class SPCriticalSection: NonCopyable
{

public:

	/**
	 * Constructor.
	 */
	inline SPCriticalSection();

	/**
	 * Destructor.
	 */
	inline ~SPCriticalSection();

	/**
	 * @brief Enter critical section.
	 * Disallow to enter to critical section from another thread.
	 */
	inline void enter();

	/**
	 * @brief Leave critical section.
	 * Allow to enter to critical section from another thread.
	 */
	inline void leave();

protected:

	pthread_mutex_t mMutex; /**<Mutex*/

};

} /* namespace SPhysics */

#include "SPCriticalSection.inl"

#endif /* _SP_CRITICALSECTION_H_ */

