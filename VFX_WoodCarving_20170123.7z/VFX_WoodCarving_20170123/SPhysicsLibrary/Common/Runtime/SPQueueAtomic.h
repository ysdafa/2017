/**
* @file SPQueueAtomic.h
* @brief This file includes module that queue for thread safe
* @		if you inserted with allocated data then you must delete by yourself
* @		you must not use mixed call through several thread. for example if one thread use push then another thread can't use push but one use push, another use pop is available
* @date 2014-09-15
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_QUEUE_THREAD_SAFE_H_
#define _SP_QUEUE_THREAD_SAFE_H_

#include <assert.h>

#include "SPDefines.h"
#include "SPAtomic.h"
#include "SPLog.h"

#define MAX_SPQUEUE_RECYCLE_NODE_COUNT	64

namespace SPhysics
{
	/**
	* @class     SPQueueAtomicBase
	* @brief     This module support function of thread safe queue : single producer & single consumer model
	*/
	template <typename T>
	class SPQueueAtomicBase
	{
	public:
		/**
		 * @struct _SP_ATOMIC_NODE
		 * @brief Atomic node
		 */
		typedef struct _SP_ATOMIC_NODE
		{
			SPAtomic<_SP_ATOMIC_NODE *>	next;	//!< Next
			T							data;	//!< Data
		} SP_ATOMIC_NODE;	//!< Atomic node

	public:
		/**
		* @brief     Constructor
		*/
		SPQueueAtomicBase()
		{
			m_dummy.next.store(&m_dummy);
			m_pHead.store(&m_dummy);
			m_pTail.store(&m_dummy);
			m_count.store(0);
		}

		/**
		* @brief     Destructor
		*/
		virtual ~SPQueueAtomicBase()
		{
			clear();
		}

		/**
		* @brief     push data
		* @param     [IN] @b inData data what will be push
		* @return    SPVoid
		*/
		SPVoid push(const T & inData)
		{
			SP_ATOMIC_NODE* newNode = alloc(inData);
			if (newNode != SPNULL)
			{
				newNode->next.store(&m_dummy);

				// set tail and connect
				SP_ATOMIC_NODE* oldTail = m_pTail.exchange(newNode);

				if (oldTail != &m_dummy)
					oldTail->next.store(newNode);

				// set head if there is no head
				m_pHead.compare_exchange(&m_dummy, newNode);
				m_count.increase();
			}
			else
			{
				SP_LOGE("there is no memory for SP_ATOMIC_NODE (newNode = %p)", newNode);
			}
		}
		
		/**
		* @brief     push node
		* @param     [IN] @b inNode Input node
		*				(If you want push multiple node than you have to connect node and insert count)
		* @return    SPVoid
		*/
		SPVoid push(SP_ATOMIC_NODE* inNode, SPInt count = 0)
		{
			if (inNode != SPNULL)
			{
				// set data before connect node
				SP_ATOMIC_NODE* inTail = inNode;
				SPInt countCheck = count;
				while (countCheck-- > 0)
				{
					inTail = inTail->next.load();
				}
				inTail->next.store(&m_dummy);

				// set tail and connect
				SP_ATOMIC_NODE* oldTail = m_pTail.exchange(inTail);

				if (oldTail != &m_dummy)
					oldTail->next.store(inNode);

				// set head if there is no head
				m_pHead.compare_exchange(&m_dummy, inNode);

				m_count.add(count);
			}
			else
			{
				SP_LOGE("inNode is NULL pointer");
			}
		}

		/**
		* @brief     pop data
		* @param     [IN] @b outData data what will be pop
		* @return    SPBool		
		*/
		SPBool pop(T& outData)
		{
			SP_ATOMIC_NODE* oldHead;
			for (;;)
			{
				SP_ATOMIC_NODE* recentHead = m_pHead.load();
				if (recentHead != &m_dummy)
				{
					SP_ATOMIC_NODE* nextHead = recentHead->next.load();
					oldHead = m_pHead.compare_exchange(recentHead, nextHead);

					// if oldHead is same with recentHead then exchange is succeed, it mean pop is succeed
					if (oldHead == recentHead)
					{
						break;
					}
				}
				else
					return SPFALSE;
			}
			
			// if poped data is same with tail then set tail is &m_dummy
			m_pTail.compare_exchange(oldHead, &m_dummy);
			m_count.decrease();

			outData = oldHead->data;
			delete oldHead;
			return SPTRUE;
		}

		/**
		* @brief     pop node		
		* @return    SP_ATOMIC_NODE*
		* (fail condition : SPNULL is returnned)
		*/
		SPBool pop(SP_ATOMIC_NODE*& node)
		{
			SP_ATOMIC_NODE* oldHead;
			for (;;)
			{
				SP_ATOMIC_NODE* recentHead = m_pHead.load();
				if (recentHead != &m_dummy)
				{
					SP_ATOMIC_NODE* nextHead = recentHead->next.load();
					oldHead = m_pHead.compare_exchange(recentHead, nextHead);

					// if oldHead is same with recentHead then exchange is succeed, it mean pop is succeed
					if (oldHead == recentHead)
					{
						break;
					}
				}
				else
					return SPFALSE;
			}

			// if poped data is same with tail then set tail is &m_dummy
			m_pTail.compare_exchange(oldHead, &m_dummy);
			m_count.decrease();

			node = oldHead;
			return SPTRUE;
		}

		/**
		* @brief     alloc node
		* @return    SPVoid
		*/
		SP_ATOMIC_NODE* alloc()
		{
			SP_ATOMIC_NODE* newNode = new SP_ATOMIC_NODE;
			assert(newNode != SPNULL);

			return newNode;
		}

		/**
		* @brief     alloc node width data
		* @return    SPVoid
		*/
		SP_ATOMIC_NODE* alloc(T data)
		{
			SP_ATOMIC_NODE* newNode = new SP_ATOMIC_NODE;
			assert(newNode != SPNULL);

			newNode->data = data;		

			return newNode;
		}

		/**
		* @brief     deAlloc node
		* @return    SPVoid
		*/
		SPVoid deAlloc(SP_ATOMIC_NODE* node)
		{
			delete node;
		}
		

		/**
		* @brief     clear data
		* @return    SPVoid
		*/
		SPVoid clear()
		{
			SP_ATOMIC_NODE* node;
			while (pop(node) == SPTRUE)
			{
				deAlloc(node);
			}
		}

		/**
		* @brief     count count of data
		* @return    SPInt
		*/
		SPInt size()
		{
			// for atomic read get data at first			
			return m_count.load();
		}

		/**
		* @brief     isEmpty check empty or not
		* @return    SPBool
		*/
		SPBool empty()
		{
			// for atomic read get data at first
			SP_ATOMIC_NODE* head = m_pHead.load();
			return (head == &m_dummy);
		}

	protected:
		SPAtomic<SPInt>				m_count;	//!< Count
		SPAtomic<SP_ATOMIC_NODE *>	m_pHead;	//!< Head
		SPAtomic<SP_ATOMIC_NODE *>	m_pTail;	//!< Tail
		SP_ATOMIC_NODE				m_dummy;	//!< Dummy
	};

	/**
	 * @class SPQueueAtomic
	 * @brief Safe recycle thread queue
	 */
	template <typename T>
	class SPQueueAtomic : public SPQueueAtomicBase<T>
	{
	public:
		typedef typename SPQueueAtomicBase<T>::SP_ATOMIC_NODE SP_ATOMIC_NODE;	//!< Atomic node

	public:
		/**
		* @brief     Constructor
		*/
		SPQueueAtomic(SPBool flagRecycle = SPFALSE, SPInt count = 0)
		{
			m_bRecycle = flagRecycle;
			if (flagRecycle == SPTRUE && count > 0)
			{				
				for (SPInt pos = 0; pos < count; pos++)
				{
					SP_ATOMIC_NODE* temp = new SP_ATOMIC_NODE;
					if (temp != SPNULL)
						m_cRecycle.push(temp);
					else
						return;
				}
			}
			else
				m_bRecycle = SPFALSE;			
		}

		/**
		* @brief     Destructor
		*/
		virtual ~SPQueueAtomic()
		{
			m_bRecycle = SPFALSE;
			m_cRecycle.clear();
		}
				
		/**
		* @brief     alloc node
		* @return    SPVoid
		*/
		SP_ATOMIC_NODE* alloc()
		{
			SP_ATOMIC_NODE* newNode;
			if (m_bRecycle == SPFALSE || m_cRecycle.pop(newNode) == SPFALSE)
				newNode = new SP_ATOMIC_NODE;

			assert(newNode != SPNULL);

			return newNode;
		}

		/**
		* @brief     alloc node width data
		* @return    SPVoid
		*/
		SP_ATOMIC_NODE* alloc(T data)
		{
			SP_ATOMIC_NODE* newNode;
			if (m_bRecycle == SPFALSE || m_cRecycle.pop(newNode) == SPFALSE)
				newNode = new SP_ATOMIC_NODE;

			assert(newNode != SPNULL);

			newNode->data = data;		

			return newNode;
		}

		/**
		* @brief     deAlloc node
		* @return    SPVoid
		*/
		SPVoid deAlloc(SP_ATOMIC_NODE* node)
		{
			if (m_bRecycle == SPTRUE && m_cRecycle.size() < MAX_SPQUEUE_RECYCLE_NODE_COUNT)
				m_cRecycle.push(node);
			else
				delete node;
		}
		
	protected:
		SPBool							m_bRecycle;	//!< Recycle flag
		class SPQueueAtomicBase<T>	m_cRecycle;	//!< Recycleq queue
	};
}

#endif /* _SP_QUEUE_THREAD_SAFE_H_ */
