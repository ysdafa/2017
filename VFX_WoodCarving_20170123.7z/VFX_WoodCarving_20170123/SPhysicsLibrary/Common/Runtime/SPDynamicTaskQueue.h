/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPDynamicTaskQueue.h
 * @brief  File Dynamic task Queue
 * @author Author Arthur Yusupov (a.yusupov@samsung.com)
 */

#ifndef _SP_DYNAMICTASKQUEUE_H_
#define _SP_DYNAMICTASKQUEUE_H_

#include "SPEvent.h"

#include <vector>

namespace SPhysics
{

class SPThread;

/**
 * @class SPDynamicTaskQueue
 * @brief Dynamic task queue
 */
class SPDynamicTaskQueue: NonCopyable
{

public:

	/**
	 * Constructor.
	 */
	inline SPDynamicTaskQueue(unsigned int aThreadCount);

	/**
	 * Destructor.
	 */
	inline ~SPDynamicTaskQueue();

	/**
	 * @brief Execute 'ClassType' 'aObject' method ('aFunction') with given argument ('aArgument').
	 * If all tasks is busy, then method will be executed in current thread.
	 * @param aObject
	 * @param aFunction
	 * @param aArgument
	 */
	template<typename ClassType, typename FunctionArgumentType>
	inline void addTask(ClassType& aObject, void (ClassType::*aFunction)(FunctionArgumentType),
						FunctionArgumentType& aArgument);

	/**
	 * Wait till the end of all tasks.
	 */
	inline void sync();

private:

	/**
	 * Work function that invoked in new thread.
	 *
	 * @param aThis Pointer to 'this'.
	 */
	inline static void* work(SPDynamicTaskQueue* aThis);

	/**
	 * Make all tasks.
	 */
	inline void makeAllTasks();

	std::vector<SPThread*> mThreads; /**< SPTask list.*/
	std::vector<SPRunnable> mQueue; /**< Queue of all tasks.*/
	SPCriticalSection mCriticalSection1; /**<Critical section for picking of one task from queue.*/
	SPCriticalSection mCriticalSection2; /**<Critical section for determining end of jobs. */
	SPEvent mStartEvent; /**<Start event.*/
	SPEvent mEndEvent; /**<End event.*/
	unsigned int mIncompleteTasks; /**<Count of incomplete tasks.*/
	volatile bool mIsNotTerminated; /**<Indicate is Threads not terminated.*/
};

} /* namespace SPhysics */

#include "SPDynamicTaskQueue.inl"

#endif /* _SP_DYNAMICTASKQUEUE_H_ */

