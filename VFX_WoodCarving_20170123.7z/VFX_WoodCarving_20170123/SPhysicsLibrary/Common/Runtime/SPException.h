/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPException.h
 * @brief  File Exception
 * @author Author Arthur Yusupov (a.yusupov@samsung.com)
 */

#ifndef _SP_EXCEPTION_H_
#define _SP_EXCEPTION_H_

#include "SPLog.h"

#include <new>
#include <string>
#include <stdexcept>
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>

#ifdef __linux
#ifndef ANDROID
#include <execinfo.h>
#endif
#endif

#define DEBUG_BREAK raise(SIGTRAP) //!< Debug break

/**
 * @brief Get stack trace
 */
inline void getStackTrace(std::string& aStr)
{
#ifdef __linux
#ifndef ANDROID
	char num[32];
	aStr += "\nStack trace:\n";
	void* stackTrace[64];
	size_t stackTraceSize = backtrace(stackTrace, 64);
	char** stack = backtrace_symbols(stackTrace, stackTraceSize);

	for (size_t i = 0; i < stackTraceSize; ++i)
	{
		sprintf(num, "%d", int(i + 1));
		aStr += std::string(num);
		aStr += ")\t";
		aStr += stack[i];
		aStr += "\n";
	}

#endif
#endif
}

/**
 * @brief Fill exception location
 */
inline void fillExceptionLocation(std::string& aStr, const unsigned int aLine,
								  const char* const aFunctionName, const char* const aFileName)
{
	char num[32];
	sprintf(num, "%d", int(aLine));
	aStr.reserve(aStr.size() + 8192);
	aStr += "In file : \"";
	aStr += aFileName;
	aStr += "\"\nIn function : \"";
	aStr += aFunctionName;
	aStr += "\"\nIn line : ";
	aStr += std::string(num);
	getStackTrace(aStr);
}

#ifdef _HAS_EXCEPTIONS

#if _HAS_EXCEPTIONS

#define __EXCEPTIONS 1

#endif

#endif

#ifndef _MSC_VER

#ifdef __EXCEPTIONS

#undef __EXCEPTIONS
#define __EXCEPTIONS 1

#endif

#endif

#if __EXCEPTIONS

#define __THROW_EXCP throw

#else

#define try	//!< try

#define __THROW_EXCP(EXCP) exit(__LINE__)	//!< throw exception

#endif

/**
 * @brief Throw exception
 */
#define THROW(MSG, EXCEPTION)												\
	{																		\
		std::string __str;													\
		__str.reserve(8192);												\
		__str += "\"";														\
		__str += MSG;														\
		__str += "\"\n";													\
		fillExceptionLocation(__str, __LINE__, __FUNCTION__, __FILE__);		\
		std::EXCEPTION __excp(__str);										\
		SP_LOGE("Exception: %s", __excp.what());								\
		__THROW_EXCP (__excp);												\
	}

#if defined DEBUG || defined _DEBUG

#define VALUE_CHECK(COND, EXCEPTION)										\
	if(COND)																\
	{																		\
		THROW(#COND, EXCEPTION)												\
	}

#else

#define VALUE_CHECK(COND, EXCEPTION) (void)(COND);	//!< check value

#endif

#define ARGUMENT_VALUE_CHECK(COND) VALUE_CHECK(COND, invalid_argument)	//!< check argument value

#define RUNTIME_VALUE_CHECK(COND) VALUE_CHECK(COND, runtime_error)	//!< check runtime value

#endif /* _SP_EXCEPTION_H_ */
