/**
* @file SPOBJLoader.h
* @brief This file includes module that loads obj formatted data and composes meshes.
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_OBJ_LOADER_H_
#define _SP_OBJ_LOADER_H_

#include "SPDefines.h"
#include "SPMesh.h"

#include <stdio.h>
#include <vector>
#include <string>
#include <glm.hpp>


namespace SPhysics
{

	/**
	* @class     SPOBJLoader
	* @brief     This class manages loading obj format and creation mesh data.
	*/
	class SPOBJLoader
	{
		
		/* Methods */
	public:
		/**
		* @brief     Constructor
		*/
		SPOBJLoader();
		
		/**
		* @brief     Destructor
		*/
		~SPOBJLoader();
		
		/**
		* @brief     Construct mesh data using passed obj-file name
		* @param     [IN] @b fileName Specifies obj-file name
		* @return     SPVoid
		*/
		SPVoid createOBJMesh(const SPChar *fileName); // parsing function
		
		/**
		* @brief     Generate triangle meshes data using parsed obj-file data
		* @return     SPVoid
		*/
		SPVoid generateTrianglesMesh();
		
		/**
		* @brief     Export Obj to file
		* @param     [IN] @b pFileName Specifies file path. User should pass full path(Android SD-Card path)
		* @param     [IN] @b pVertex Specifies Vertex array
		* @param     [IN] @b nVertexNumber Specifies Vertex total number
		* @param     [IN] @b  SPUShort * pIndex Specifies Index array
		* @param     [IN] @b nIndexNumber Specifies Index Total number
		* @return     SPVoid
		*/
		SPVoid exportObjFromArr(const SPChar* pFileName, SPFloat* pVertex, SPInt nVertexNumber, SPUShort* pIndex, SPInt nIndexNumber);

		/**
		* @brief     Export Obj mesh data with file format
		* @param     [IN] @b pFileName Specifies file path. User should pass full path(Android SD-Card path)
		* @return     SPVoid
		*/
		SPVoid exportObjMesh(const SPChar* pFileName);

		/**
		* @brief     Get Mesh Data using SPMesh Type
		* @return     SPMesh * Return mesh data
		*/
		SPMesh* getTriangleMesh();

		/**
		* @brief     Get Mesh Data using SPMesh Type
		* @return     SPMesh * Return mesh data
		*/
		SPMesh* getObjMesh();

		/**
		* @brief     set the Mesh Data for export obj file
		* @return     SPVoid
		*/
		SPVoid setExportMesh(SPMesh* mesh);

	private:

		/**
		* @brief     load and do Parsing Obj-file
		* @param     [IN] @b fileName Specifies obj-file name
		* @return     SPVoid
		*/
		SPVoid parsingOBJFile(const SPChar *fileName);

		/**
		* @brief     Tokenize input string
		* @param     [IN] @b stmt Specifies Input String
		* @param     [IN] @b separators Tokenization separator
		* @param     [OUT] @b Output (Token list) tokenized
		* @return     SPVoid
		*/
		SPVoid getTokens(std::string& stmt, std::string& separators, std::vector<std::string>&token_list);
		
		/**
		* @brief     Get String from obj file
		* @param     [OUT] @b objString Specifies string contains file contents.
		* @param     [IN] @b fileName Specifies obj-format file
		* @return     SPVoid
		*/
		SPVoid getStringFromFile(std::string& objString, const SPChar *fileName);


		/* Member Variables */
	private:
		SPMesh* m_pTriMesh;			//! Mesh Data
		SPMesh* m_pObjMesh;			//! Mesh Data
		SPMesh* m_pExportMesh;			//! Mesh Data

	//private:
		SPChar* mtl; // Name of mtl-type file
		SPChar* faceColor;
	};


}//namespace SPhysics
#endif //_SP_OBJ_LOADER_H_