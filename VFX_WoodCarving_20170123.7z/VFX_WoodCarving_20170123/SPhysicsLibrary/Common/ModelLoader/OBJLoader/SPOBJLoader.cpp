/**
* @file SPOBJLoader.cpp
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifdef __ANDROID__
#include "SPAssetManager.h"
#endif

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#if defined(_WIN32) || defined(__linux__)
#include <iostream>
#include <fstream>
#include <iomanip>
#include <string.h>
#endif

#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#include <WTypes.h>
#endif


#include "SPOBJLoader.h"
#include "SPLog.h"
#include "SPDefines.h"

namespace SPhysics
{

	SPOBJLoader::SPOBJLoader() : m_pTriMesh(SPNULL), m_pObjMesh(SPNULL), m_pExportMesh(SPNULL), mtl(SPNULL), faceColor(SPNULL)
	{

	}

	SPOBJLoader::~SPOBJLoader()
	{

		SP_SAFE_DELETE(mtl);
		SP_SAFE_DELETE(faceColor);
		SP_SAFE_DELETE(m_pTriMesh);
		SP_SAFE_DELETE(m_pObjMesh);
	}

	SPVoid SPOBJLoader::createOBJMesh( const SPChar *fileName )
	{
		parsingOBJFile(fileName);

		generateTrianglesMesh();
	}

	SPVoid SPOBJLoader::parsingOBJFile( const SPChar *fileName )
	{
		SPChar* stopString;
		std::string separators;
		std::vector<std::string> tokenList;

		if(m_pObjMesh == SPNULL)
			m_pObjMesh = new SPMesh();

		m_pObjMesh->reset();

		std::string objString;

		getStringFromFile(objString, fileName);

		std::vector<std::string> lineList;

		separators = "\n";
		getTokens(objString, separators, lineList);

		// Sometimes obj file is not have EOF
		SPInt breakParsingFlag = 0; 

		separators = " ";
		for(SPInt index=0; index < (SPInt)lineList.size(); index++)
		{
			if(breakParsingFlag == 1)
				break;

			tokenList.clear();

			getTokens(lineList[index], separators, tokenList);

			if(tokenList.size() < 3)
				continue;

			std::string token = tokenList[0];

			if(token == "mtllib") {
				std::string mtlName = tokenList[1];
				this->mtl = (SPChar *)malloc(sizeof(SPChar)*(mtlName.size()+1));
				strcpy(mtl, mtlName.c_str());
			}
			else if(token == "v") {

				SPVec3f objVertex;

				objVertex.x = (SPFloat)strtod(tokenList[1].c_str(), &stopString);
				objVertex.y = (SPFloat)strtod(tokenList[2].c_str(), &stopString);
				objVertex.z = (SPFloat)strtod(tokenList[3].c_str(), &stopString);

				this->m_pObjMesh->m_tVertex.push_back(objVertex);
			}
			else if(token == "vn") {

				SPVec3f objVertexNormal;

				objVertexNormal.x = (SPFloat)strtod(tokenList[1].c_str(), &stopString);
				objVertexNormal.y = (SPFloat)strtod(tokenList[2].c_str(), &stopString);
				objVertexNormal.z = (SPFloat)strtod(tokenList[3].c_str(), &stopString);
				
				this->m_pObjMesh->m_tNormal.push_back(objVertexNormal);
			}
			else if(token == "vt") {

				SPVec3f objTexture;

				objTexture.x = (SPFloat)strtod(tokenList[1].c_str(), &stopString);
				objTexture.y = (SPFloat)strtod(tokenList[2].c_str(), &stopString);

				if(tokenList.size() == 3)
					objTexture.z = -1.0;
				else 
					objTexture.z = (SPFloat)strtod(tokenList[3].c_str(), &stopString);

				this->m_pObjMesh->m_tTextureUV.push_back(objTexture);
			}
			else if(token == "usemtl") {

				faceColor = (SPChar *) malloc(sizeof(SPChar)*(tokenList[1].size()+1));
				strcpy(faceColor,tokenList[1].c_str());

			}
			else if(token == "#")
			{
				for(SPInt pos=1; pos < (SPInt)tokenList.size(); pos++)
				{
					if(tokenList[pos] == "faces")
					{
						breakParsingFlag = 1;
					}
				}
			}
			else if(token == "f") {

				//fprintf(fp, "%s\n", lineList[index].c_str());

				std::vector<std::string> vList;

				SPVec3i vertexIdx, textureIdx, normalIdx;

				vertexIdx = SPVec3i(-1, -1, -1); 
				textureIdx = SPVec3i(-1, -1, -1);
				normalIdx = SPVec3i(-1, -1, -1);

				for(SPInt pos=1; pos < (SPInt)tokenList.size(); pos++)
				{
					std::string s = tokenList[pos];
					vList.clear();
					std::string token("/");
					this->getTokens(s,token,vList);

					SPInt idx = s.find("//");

					SPInt vIdx, tidx, nIdx;
					if(idx >= 0 && idx <= (SPInt)s.length()) {
						vIdx = atoi(vList[0].c_str());
						tidx = -1;
						nIdx = atoi(vList[1].c_str());
					}
					else if(vList.size() == 1) {

						vIdx = atoi(vList[0].c_str());
						tidx = -1;
						nIdx = -1;

					}
					else if(vList.size() == 2) {

						vIdx = atoi(vList[0].c_str());
						tidx = atoi(vList[1].c_str());
						nIdx = -1;
					}
					else {
						vIdx = atoi(vList[0].c_str());
						tidx = atoi(vList[1].c_str());
						nIdx = atoi(vList[2].c_str());
					}


					// create index for 3 triangle's points
					if(pos==1)
					{
						vertexIdx.x = vIdx;
						textureIdx.x = tidx;
						normalIdx.x = nIdx;

					}else if(pos == 2)
					{
						vertexIdx.y = vIdx;
						textureIdx.y = tidx;
						normalIdx.y = nIdx;

					}else if(pos == 3)
					{
						vertexIdx.z = vIdx;
						textureIdx.z = tidx;
						normalIdx.z = nIdx;
					}
				}
				this->m_pObjMesh->m_tFaceVertexIdx.push_back(vertexIdx);
				this->m_pObjMesh->m_tFaceTexIdx.push_back(textureIdx);
				this->m_pObjMesh->m_tFaceNorIdx.push_back(normalIdx);
			}		
		}

	}

	SPVoid SPOBJLoader::generateTrianglesMesh()
	{
		SPInt pointIdx;
		SPInt totVertexIdx = m_pObjMesh->m_tFaceVertexIdx.size();

		if(m_pTriMesh == SPNULL)
			m_pTriMesh = new SPMesh();

		m_pTriMesh->reset();

		for(SPInt idx = 0; idx < totVertexIdx; idx++)
		{
			// Point 1
			pointIdx = m_pObjMesh->m_tFaceVertexIdx[idx].x - 1;
			// make mesh
			m_pTriMesh->m_tVertex.push_back(m_pObjMesh->m_tVertex[pointIdx]);

			// Point 2
			pointIdx = m_pObjMesh->m_tFaceVertexIdx[idx].y - 1;
			// make mesh
			m_pTriMesh->m_tVertex.push_back(m_pObjMesh->m_tVertex[pointIdx]);

			// point 3
			pointIdx = m_pObjMesh->m_tFaceVertexIdx[idx].z - 1;
			// make mesh
			m_pTriMesh->m_tVertex.push_back(m_pObjMesh->m_tVertex[pointIdx]);
		}

		SPInt totTextureIdxNum = m_pObjMesh->m_tFaceTexIdx.size();
		if(m_pObjMesh->m_tTextureUV.size() != 0)
		{
			for(SPInt idx = 0; idx < totTextureIdxNum; idx++)
			{
				// Point 1
				pointIdx = m_pObjMesh->m_tFaceTexIdx[idx].x - 1;
				// make mesh
				m_pTriMesh->m_tTextureUV.push_back(m_pObjMesh->m_tTextureUV[pointIdx]);

				// Point 2
				pointIdx = m_pObjMesh->m_tFaceTexIdx[idx].y - 1;
				// make mesh
				m_pTriMesh->m_tTextureUV.push_back(m_pObjMesh->m_tTextureUV[pointIdx]);

				// point 3
				pointIdx = m_pObjMesh->m_tFaceTexIdx[idx].z - 1;
				// make mesh
				m_pTriMesh->m_tTextureUV.push_back(m_pObjMesh->m_tTextureUV[pointIdx]);
			}
		}


		SPInt isCalculateNormal = 0;
		// If can't get the normal vector from OBJ file than generate
		if(m_pObjMesh->m_tNormal.size() == 0)
		{
			isCalculateNormal = 1;
			m_pObjMesh->m_tNormal.resize(totVertexIdx);

			SPVec3f p1, p2, p3, v1, v2, v3;
			for(SPInt idx = 0; idx < totVertexIdx; idx++)
			{
				SPInt pointIdx1 = m_pObjMesh->m_tFaceVertexIdx[idx].x - 1;
				SPInt pointIdx2 = m_pObjMesh->m_tFaceVertexIdx[idx].y - 1;
				SPInt pointIdx3 = m_pObjMesh->m_tFaceVertexIdx[idx].z - 1;

				p1 = m_pObjMesh->m_tVertex[pointIdx1];
				p2 = m_pObjMesh->m_tVertex[pointIdx2];
				p3 = m_pObjMesh->m_tVertex[pointIdx3];

				// Calculate Face Normal
				v1 = p2-p1;
				v2 = p3-p1;
				v3 = glm::cross(v1,v2); 
				v3 = glm::normalize(v3);

				// Generate Vertex Normal
				m_pObjMesh->m_tNormal[pointIdx1] += v3;
				m_pObjMesh->m_tNormal[pointIdx2] += v3;
				m_pObjMesh->m_tNormal[pointIdx3] += v3; 
			}

			SPInt VertexNum = m_pObjMesh->m_tVertex.size();
			for(SPInt idx = 0; idx < VertexNum; idx++)
			{
				m_pObjMesh->m_tNormal[idx] = glm::normalize(m_pObjMesh->m_tNormal[idx]);
			}
		}

		for(SPInt faceIdx = 0; faceIdx < totVertexIdx; faceIdx++)
		{
			// Point 1
			if( isCalculateNormal == 0 )
			{
				pointIdx = m_pObjMesh->m_tFaceNorIdx[faceIdx].x - 1;
			}
			else
			{
				pointIdx = m_pObjMesh->m_tFaceVertexIdx[faceIdx].x - 1;
			}
			// make mesh
			m_pTriMesh->m_tNormal.push_back(m_pObjMesh->m_tNormal[pointIdx]);

			// Point 2
			if( isCalculateNormal == 0 )
			{
				pointIdx = m_pObjMesh->m_tFaceNorIdx[faceIdx].y - 1;
			}
			else
			{
				pointIdx = m_pObjMesh->m_tFaceVertexIdx[faceIdx].y - 1;
			}
			// make mesh
			m_pTriMesh->m_tNormal.push_back(m_pObjMesh->m_tNormal[pointIdx]);

			// point 3
			if( isCalculateNormal == 0 )
			{
				pointIdx = m_pObjMesh->m_tFaceNorIdx[faceIdx].z - 1;
			}
			else
			{
				pointIdx = m_pObjMesh->m_tFaceVertexIdx[faceIdx].z - 1;
			}
			// make mesh
			m_pTriMesh->m_tNormal.push_back(m_pObjMesh->m_tNormal[pointIdx]);
		}
	}

	SPVoid SPOBJLoader::getStringFromFile( std::string& objString, const SPChar *fileName )
	{
	#if defined(_WIN32) || defined(__linux__)

		//FILE *fp = fopen(fileName, "rt");
		//FILE *fp = fopen(fileName, "rb");
		FILE *fp = fopen(fileName, "r");

		if(fp == SPNULL)
		{
			SP_LOGE("file open error. (file name : %s)", fileName);
			return;
		}

		char buffer[1024];
		std::string tempStr;
		
		while(!feof(fp))
		{
			while(fgets(buffer,1024, fp))
			{
				tempStr = std::string(buffer);
				objString += tempStr;
			}
		}

		fclose(fp);

	#else

		AAssetManager *assetManager = SPAssetManager::GetInstancePtr()->GetAAssetManager();

		if(assetManager == SPNULL)
		{
			SP_LOGE("assetManager error.");
			return;
		}

		AAsset* asset = AAssetManager_open(assetManager, fileName, AASSET_MODE_UNKNOWN);


		if (SPNULL == asset) 
		{
			SP_LOGE("assetManager fileopen error.");
			return;
		}

		SPLong fileLength =AAsset_getLength(asset);

		SPChar *pBuf = new SPChar[fileLength + 1];
		memset(pBuf, 0x0, sizeof(SPChar) * (fileLength + 1));
		/*	SPChar pBuf[fileLength + 1] = {0};*/

		AAsset_read(asset, pBuf, fileLength);

		objString = pBuf;

		delete [] pBuf;

		AAsset_close(asset);

	#endif
	}

	SPVoid SPOBJLoader::getTokens(std::string& stmt, std::string& separators, std::vector<std::string>& token_list)
	{
		SPInt n = stmt.length();
		SPInt start, stop;

		start = stmt.find_first_not_of(separators);
		while ((start >= 0) && (start < n)) 
		{
			stop = stmt.find_first_of(separators, start);
			if ((stop < 0) || (stop > n)) 
				stop = n;

			token_list.push_back(stmt.substr(start, stop - start));
			start = stmt.find_first_not_of(separators, stop+1);
		}
	}

	#if 0
	Vertex SPOBJLoader::getVertex( SPInt vertexNum )
	{
		return this->m_pObjMesh->m_tVertex[vertexNum-1];
	}

	VertexNormal SPOBJLoader::getVertexNormal( SPInt normalNum )
	{
		return this->normals[normalNum-1];
	}

	VertexTexture SPOBJLoader::getVertexTexture( SPInt textureNum )
	{
		return this->textures[textureNum-1];
	}

	Face SPOBJLoader::getFace( SPInt faceNum )
	{
		return this->faces[faceNum-1];
	}

	#endif

	SPVoid SPOBJLoader::exportObjFromArr( const SPChar* pFileName, SPFloat* pVertex, SPInt nVertexNumber, SPUShort* pIndex, SPInt nIndexNumber )
	{
	#ifdef _WIN32
		// Must to add android SD-card path
		std::ofstream osf(pFileName, std::ios::trunc);

		if(!osf)
			return;

		osf << "# S-Physics OBJ Exporter v0.1 - (c) 2013" << std::endl;
		//osf << "# File Created: S-Physics OBJ Exporter v0.1 - (c) 2013" << endl;

	#ifndef _WIN32

		osf << std::endl;
	#else
		SYSTEMTIME time;
		::ZeroMemory(reinterpret_cast<SPVoid*>(&time), sizeof(time));
		::GetLocalTime(&time);
		osf << "# File Created : " << time.wMonth << "." << time.wDay << "." << time.wYear << " " << time.wHour << ":" << time.wMinute << ":" << time.wSecond << std::endl;
	#endif

		osf << std::endl <<"#" << std::endl << "# object default" << std::endl << "#" << std::endl << std::endl;

		// Vertex Write
		osf.setf(std::ios::fixed);
		osf.setf(std::ios::right);
		osf.precision(5);

		SPInt tapWidth = 9;

		for(SPInt nIndex = SPInt(); nIndex < nVertexNumber; nIndex += 3)
		{				
			osf << "v " << std::setw(tapWidth) << pVertex[nIndex] << std::setw(tapWidth) << pVertex[nIndex + 1] << std::setw(tapWidth) << pVertex[nIndex + 2] << std::endl;
		}	

		osf.unsetf(std::ios::fixed);

		osf << "# " << nVertexNumber / 3 << " vertices" << std::endl << std::endl;


		// Face Write
		tapWidth = 1;
		SPInt tempVertexNumber = nVertexNumber / 3;
		while(SPTRUE)
		{
			++tapWidth;		
			if(tempVertexNumber < 10)
				break;
			tempVertexNumber /= 10;
		}

		for(SPInt nIndex = SPInt(); nIndex < nIndexNumber; nIndex +=3)
		{
			osf << "f " << std::setw(tapWidth) << pIndex[nIndex] + 1 << std::setw(tapWidth) << pIndex[nIndex + 1] + 1 << std::setw(tapWidth) << pIndex[nIndex + 2] + 1<< std::endl;
			//osf << "f " << pIndex[nIndex] + 1 << " " << pIndex[nIndex + 1] + 1 << " " << pIndex[nIndex + 2] + 1 << endl;
		}

		osf << "# " << nIndexNumber / 3 << " faces" << std::endl << std::endl;

		osf.clear();
		osf.close();
	#endif
	}

	SPVoid SPOBJLoader::exportObjMesh( const SPChar* pFileName )
	{
		if(m_pExportMesh == SPNULL)
			return;

#ifdef _WIN32
		// Must to add android SD-card path
		std::ofstream osf(pFileName, std::ios::trunc);

		if(!osf)
			return;

		osf << "# S-Physics OBJ Exporter v0.1 - (c) 2013" << std::endl;
		//osf << "# File Created: S-Physics OBJ Exporter v0.1 - (c) 2013" << endl;

#ifndef _WIN32

		osf << std::endl;
#else
		SYSTEMTIME time;
		::ZeroMemory(reinterpret_cast<SPVoid*>(&time), sizeof(time));
		::GetLocalTime(&time);
		osf << "# File Created : " << time.wMonth << "." << time.wDay << "." << time.wYear << " " << time.wHour << ":" << time.wMinute << ":" << time.wSecond << std::endl;
#endif

		osf << std::endl <<"#" << std::endl << "# object default" << std::endl << "#" << std::endl << std::endl;

		// Vertex Write
		osf.setf(std::ios::fixed);
		osf.setf(std::ios::right);
		osf.precision(5);
		;
		SPInt vertexCount = m_pExportMesh->m_tVertex.size();
		SPInt tapWidth = 12;

		for(SPInt nIndex = SPInt(); nIndex < vertexCount; nIndex ++)
		{				
			osf << "v " << std::setw(tapWidth) << m_pExportMesh->m_tVertex[nIndex].x << std::setw(tapWidth) << m_pExportMesh->m_tVertex[nIndex].y << std::setw(tapWidth) << m_pExportMesh->m_tVertex[nIndex].z << std::endl;
		}	

		osf.unsetf(std::ios::fixed);

		osf << "# " << vertexCount << " vertices" << std::endl << std::endl;


		SPInt normalCount = m_pExportMesh->m_tNormal.size();
		if(normalCount != 0)
		{
			osf << std::endl <<"#" << std::endl << "# normalvector" << std::endl << "#" << std::endl << std::endl;


			tapWidth = 12;

			for(SPInt nIndex = SPInt(); nIndex < normalCount; nIndex ++)
			{				
				osf << "vn " << std::setw(tapWidth) << m_pExportMesh->m_tNormal[nIndex].x << std::setw(tapWidth) << m_pExportMesh->m_tNormal[nIndex].y << std::setw(tapWidth) << m_pExportMesh->m_tNormal[nIndex].z << std::endl;
			}	

			osf.unsetf(std::ios::fixed);

			osf << "# " << normalCount << " normals" << std::endl << std::endl;

			// Face Write
			tapWidth = 1;
			SPInt indexCount = m_pExportMesh->m_tVertexIndex16.size();

			SPInt tempVertexNumber = indexCount / 3;
			while(SPTRUE)
			{
				++tapWidth;		
				if(tempVertexNumber < 10)
					break;
				tempVertexNumber /= 10;
			}

			for(SPInt nIndex = SPInt(); nIndex < indexCount; nIndex +=3)
			{
				osf << "f " << std::setw(tapWidth) << m_pExportMesh->m_tVertexIndex16[nIndex] << "/0/"<< m_pExportMesh->m_tVertexIndex16[nIndex] << std::setw(tapWidth) << m_pExportMesh->m_tVertexIndex16[nIndex + 1] << "/0/" << m_pExportMesh->m_tVertexIndex16[nIndex + 1] << std::setw(tapWidth) << m_pExportMesh->m_tVertexIndex16[nIndex + 2] << "/0/"<< m_pExportMesh->m_tVertexIndex16[nIndex + 2] << std::endl;
			}

			osf << "# " << indexCount / 3 << " faces" << std::endl << std::endl;

		}else
		{
			// Face Write
			tapWidth = 1;
			SPInt indexCount = m_pExportMesh->m_tVertexIndex16.size();

			SPInt tempVertexNumber = indexCount / 3;
			while(SPTRUE)
			{
				++tapWidth;		
				if(tempVertexNumber < 10)
					break;
				tempVertexNumber /= 10;
			}

			for(SPInt nIndex = SPInt(); nIndex < indexCount; nIndex +=3)
			{
				osf << "f " << std::setw(tapWidth) << m_pExportMesh->m_tVertexIndex16[nIndex] << "/0/0 " << std::setw(tapWidth) << m_pExportMesh->m_tVertexIndex16[nIndex + 1] << "/0/0 " << std::setw(tapWidth) << m_pExportMesh->m_tVertexIndex16[nIndex + 2] << "/0/0 " << std::endl;
			}

			osf << "# " << indexCount / 3 << " faces" << std::endl << std::endl;
		}

		osf.clear();
		osf.close();
#endif
	}

	SPMesh* SPOBJLoader::getTriangleMesh()
	{
		return m_pTriMesh;
	}

	SPMesh* SPOBJLoader::getObjMesh()
	{
		return m_pObjMesh;
	}

	SPVoid SPOBJLoader::setExportMesh( SPMesh* mesh )
	{
		m_pExportMesh = mesh;
	}

}//namespace SPhysics
