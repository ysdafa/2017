/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPObjectData.h
 * @brief  File Object
 * @author Andrii Burevych (a.burevych@samsung.com)
 */

#ifndef _SP_OBJECT_DATA_H_
#define _SP_OBJECT_DATA_H_

#include "SPMesh.h"

#include <string>
#include <glm.hpp>

namespace SPhysics
{

class SPObjectData;

/**
 * @struct TextureType
 * @brief Texture type
 */
struct TextureType
{
	/**
	 * @enum TextureTypeValue
	 * @brief Texture type value
	 */
	typedef enum TextureTypeValue
	{
		Texture1 = 0,
		Texture2,
		TextureCube,
		NormalMap,
		ShadowMap,
		Count
	} Value; //!< Texture type value
};


/**
 * @enum RenderMode
 * @brief Render mode
 */
enum RenderMode
{
	Default = 0,
	TriangleStrip,
	Triangles,
	Points,
	Lines,
	LineStrip,
	TriangleFan,
	MaxValue
};

/**
 * @class SPMaterialData
 * @brief Material data
 */
class SPMaterialData
{
public:
	inline SPMaterialData();
	inline virtual ~SPMaterialData();
	float mOpacity; /**<Opacity coefficient.*/
	float mLightAmbient; /**<Light ambient coefficient.*/
	float mLightDiffuse; /**<Light diffuse coefficient.*/
	float mLightSpecular; /**<Light specular coefficient.*/
	float mLightShininess; /**<Light shininess coefficient.*/
	bool mIsVisible;/**<Determines whether an object is visible */

	RenderMode mRenderMode;/**<Mode of rendering (Modes described in file Renderer.h).*/
	void* mTextures[TextureType::Count]; /**< Array of textures, used for rendering */
	std::string mTextureName;/**<Texture name.*/
};

/**
 * @brief Class for making rendering.
 * @details Contains object geometry and parameters of material.
 * @details Compatible with both SPMesh (S-Physics) and PBA code
 */
class SPObjectData: public SPMesh/*, public SPMaterialData*/
{
public:

	/**
	 * Initialize empty mesh object
	 */
	inline SPObjectData();

	/**
	 * Destructor.
	 */
	inline virtual ~SPObjectData();

	/**
	 * Constructor from RefObject.
	 */
	explicit inline SPObjectData(const SPObjectData& aObject);

	/**
	 * Constructor from SPMesh.
	 */
	explicit inline SPObjectData(SPMesh& aMesh);

	/**
	 * Assigment from RefObject.
	 * All data will be copied into destination object
	 */
	inline SPObjectData& operator =(const SPObjectData& aObject);

	/**
	 * Assigment from SPMesh object.
	 * All data will be copied into destination object
	 */
	inline SPObjectData& operator =(SPMesh& aMesh);

	/**
	 * Translate object.
	 *
	 * @param aValue Vector that describe translation on X, Y, Z coordinates.
	 */
	inline void translateModel(const glm::vec3& aValue);

	/**
	 * Rotate object.
	 *
	 * @param aAngle Angle to rotate.
	 * @param aValue Vector that describe rotation on X, Y, Z coordinates.
	 */
	inline void rotateModel(const float aAngle, const glm::vec3& aValue);

	/**
	 * Set model matrix
	 *
	 * @param aMatrix Model matrix.
	 */
	inline void setModelMatrix(const glm::mat4& aMatrix);

	/**
	 * Update model matrix
	 *
	 * @param aTranform Transformation matrix
	 * @param aTranslate Translation vector
	 */
	inline void updateModelMatrix(const glm::mat3& aTranform, const glm::vec3& aTranslate);

	inline glm::mat4& getModelMatrix();					//!< Get model matrix
	inline unsigned short* getIndexes();				//!< Get indexes
	inline const unsigned short* getIndexes() const;	//!< Get indexes
	inline unsigned int getIndexCount() const;			//!< Get index count
	inline unsigned int getVertexCount() const;			//!< Get vertex count
	inline glm::vec3* getPositions3D();					//!< Get positions 3D
	inline const glm::vec3* getPositions3D() const;		//!< Get positions 3D
	inline glm::vec3* getNormals();						//!< Get normals
	inline const glm::vec3* getNormals() const;			//!< Get normals
	inline glm::vec3* getTangents();					//!< Get tangents
	inline const glm::vec3* getTangents() const;		//!< Get tangents
	inline glm::vec3* getBitangents();					//!< Get bitangents
	inline const glm::vec3* getBitangents() const;		//!< Get bitangents
	inline glm::vec2* getTextureCoords();				//!< Get texture coordinates
	inline const glm::vec2* getTextureCoords() const;	//!< Get texture coordinates

private:

	glm::mat4 mModelMatrix; /**<Model matrix*/
	unsigned int mIndexCount;/**<Size of the index array.*/
	unsigned int mVertexCount;/**<Number of vertices in the model.*/
	glm::vec2* mTextureCoords;/**< Pointer to the array which stores textures coordinates*/
};

} /* namespace SPhysics */

#include "SPObjectData.inl"

#endif /* _SP_OBJECT_DATA_H_ */

