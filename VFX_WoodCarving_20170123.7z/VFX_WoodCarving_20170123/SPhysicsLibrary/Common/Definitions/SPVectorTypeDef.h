/**
* @file SPVectorTypeDef.h
* @brief The header file for Defines.
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/


#ifndef _SP_VECTOR_TYPE_DEF_H_
#define _SP_VECTOR_TYPE_DEF_H_


namespace SPhysics
{
#if 0
#define SPVec2b			SPVector2D<bool>			//!< 2D bool vector
#define SPVec2f			SPVector2D<float>			//!< 2D float vector
#define	SPVec2i			SPVector2D<int>				//!< 2D int vector
#define	SPVec2u			SPVector2D<unsigned int>	//!< 2D unsigned int vector
#define	SPVec2d			SPVector2D<double>			//!< 2D double vector
#define	SPVec2t			SPVector2D<T>				//!< 2D template vector

#define SPVec3f			SPVector3D<float>			//!< 3D float vector
#define	SPVec3i			SPVector3D<int>				//!< 3D int vector
#define	SPVec3u			SPVector3D<unsigned int>	//!< 3D unsigned int  vector
#define	SPVec3d			SPVector3D<double>			//!< 3D double  vector
#define	SPVec3t			SPVector3D<T>				//!< 3D template vector

#define SPVec4f			SPVector4D<float>			//!< 4D float vector
#define	SPVec4i			SPVector4D<int>				//!< 4D int vector
#define	SPVec4u			SPVector4D<unsigned int>	//!< 4D unsigned int vector
#define	SPVec4d			SPVector4D<double>			//!< 4D double vector
#define	SPVec4t			SPVector4D<T>				//!< 4D template vector
#endif

#define SPVec2b			glm::bvec2			        //!< 2D bool vector
#define SPVec2f			glm::vec2			        //!< 2D float vector
#define	SPVec2i			glm::ivec2				    //!< 2D int vector
#define	SPVec2u			glm::uvec2	                //!< 2D unsigned int vector
#define	SPVec2d			glm::dvec2			        //!< 2D double vector
#define	SPVec2t			glm::tvec2<T>				//!< 2D template vector

#define SPVec3f			glm::vec3			        //!< 3D float vector
#define	SPVec3i			glm::ivec3				    //!< 3D int vector
#define	SPVec3u			glm::uvec3	                //!< 3D unsigned int  vector
#define	SPVec3d			glm::dvec3			        //!< 3D double  vector
#define	SPVec3t			glm::tvec3<T>				//!< 3D template vector

#define SPVec4f			glm::vec4			        //!< 4D float vector
#define	SPVec4i			glm::ivec4				    //!< 4D int vector
#define	SPVec4u			glm::uvec4	                //!< 4D unsigned int vector
#define	SPVec4d			glm::dvec4			        //!< 4D double vector
#define	SPVec4t			glm::tvec4<T>				//!< 4D template vector


}  //namespace SPhysics

#endif // _SP_VECTOR_TYPE_DEF_H_

