/**
* @file SPDataTypeDef.h
* @brief The header file for Defines.
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/


#ifndef _SP_DATA_TYPE_DEF_H_
#define _SP_DATA_TYPE_DEF_H_

namespace SPhysics
{
/*-------------------------------------------------------------------------
 * Data type definitions
 *-----------------------------------------------------------------------*/

	typedef void             SPVoid;	//!< void
	typedef unsigned short   SPUShort;	//!< unsigned short
	typedef unsigned char    SPUChar;	//!< unsigned char
	typedef unsigned int     SPUInt;	//!< unsigned int
	typedef unsigned long	 SPULong;	//!< unsigned long
	typedef unsigned long long SPULongLong;	//!< unsigned long long
	typedef short            SPShort;	//!< short
	typedef char             SPChar;	//!< char
	typedef int              SPInt;		//!< int
	typedef long             SPLong;	//!< long
	typedef float			 SPFloat;	//!< float
	typedef double           SPDouble;	//!< double
	
	                                         
#ifndef SPNULL			
#define SPNULL			       0	//!< NULL
#endif

#ifdef __cplusplus

	typedef bool			       SPBool;

#ifndef SPTRUE			
#define SPTRUE			       true
#endif

#ifndef SPFALSE			
#define SPFALSE			       false
#endif

#else

	typedef int			         SPBool;	//!< SPBool


#ifndef SPTRUE			
#define SPTRUE			       1	//!< true
#endif

#ifndef SPFALSE			
#define SPFALSE			       0	//!< false
#endif

#endif //__cplusplus

}  //namespace SPhysics

#endif // _SP_DATA_TYPE_DEF_H_

