/**
* @file SPInterpolation.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_INTERPOLATION_H_
#define _SP_INTERPOLATION_H_

#include "SPDefines.h"

#include <glm.hpp>

namespace SPhysics
{
	/**
	* @brief     Calculate the linear interpolation
	* @param     [IN] @b  t0 input t0
	* @param     [IN] @b  t1 input t0
	* @param     [IN] @b  t  input t
	* @param     [IN] @b  x0 input x0
	* @param     [IN] @b  x1 input x1
	* @return     T
	*/
	template<typename T>
	inline T calculateLinearInterpolation(const T& t0, const T& t1, const T& t, const T& x0, const T& x1) {

		return (x1 - x0) / (t1 - t0) * (t - t0) + x0;

	}

	/**			
	* @brief     Calculate the linear interpolation 
	* @param     [IN] @b  t0 input t0
	* @param     [IN] @b  t1 input t0
	* @param     [IN] @b  t  input t
	* @param     [IN] @b  x0 input x0
	* @param     [IN] @b  x1 input x1
	* @return     SPVec3t
	*/
	template<typename T>
	inline SPVec3t calculateLinearInterpolation(const T& t0, const T& t1, const T& t, const SPVec3t& x0, const SPVec3t& x1) {

		return SPVec3t(
			calculateLinearInterpolation(t0,t1,t,x0.x,x1.x),
			calculateLinearInterpolation(t0,t1,t,x0.y,x1.y),
			calculateLinearInterpolation(t0,t1,t,x0.z,x1.z)
			);

	}

	/**
	* @brief     Calculate the linear interpolation (from a to b)
	* @param     [IN] @b  a input a
	* @param     [IN] @b  b input b
	* @param     [IN] @b  f input f
	* @return     S
	*/
	template <class S, typename T>
	inline S linearInterpolation( const S& a, const S& b, const T& f )
	{
		if( f <= 0 ) { return a; }
		if( f >= 1 ) { return b; }
		return ( (1-f)*a + f*b );
	}

	/**
	* @brief     Calculate the linear interpolation (beta = 1 - alpha)
	* @param     [IN] @b  a input
	* @param     [IN] @b  b input
	* @param     [IN] @b  alpha alpha
	* @param     [IN] @b  beta beta = 1 - alpha
	* @return     S
	*/
	template <class S, typename T>
	inline S linearInterpolation( const S& a, const S& b, const T& alpha, const T& beta )
	{
		#ifdef DEBUGGING
		 VERIFY(isAlmostSame(alpha+beta,(T)1));
		#endif
		return ( beta*a + alpha*b );
	}

	/**
	* @brief     Calculate the S-shaped curve
	* @param     [IN] @b  x input
	* @return     T
	*/
	template <typename T>
	inline T scurve( const T& x )
	{
		if( x <= 0 ) { return (T)0; }
		if( x >= 1 ) { return (T)1; }
		return (T)( 0.5 * ( 1 - cos(PI*x) ) );
	}

	/**
	* @brief     Calculate the S-shaped curve
	[a,b] -> [0,1]
	t: a~b
	* @param     [IN] @b  a input
	* @param     [IN] @b  b input
	* @param     [IN] @b  t input
	* @return     T
	*/
	template <typename T>
	inline T scurve( const T& a, const T& b, const T& t )
	{
		#ifdef DEBUGGING
		 VERIFY(a<b);
		#endif

		if( t <= a ) { return (T)0; }
		if( t >= b ) { return (T)1; }
		T x = (t-a)/(b-a);
		return scurve( x );
	}

	/**
	* @brief     Calculate the S-shaped curve
	polynomial: 3x^2 + 2x^3
	[0,1] -> [0,1]
	x: 0~1
	* @param     [IN] @b  x 0~1
	* @return     T
	*/
	template <typename T>
	inline T scurve3( const T& x )
	{
		if( x <= 0 ) { return (T)0; }
		if( x >= 1 ) { return (T)1; }
		return x*x*(-2*x+3);
	}

	/**
	* @brief     Calculate the S-shaped curve
	[a,b] -> [0,1]
	t: a~b
	* @param     [IN] @b  a [0,1]
	* @param     [IN] @b  b [0,1]
	* @param     [IN] @b  t a~b
	* @return     T
	*/
	template <typename T>
	inline T scurve3( const T& a, const T& b, const T& t )
	{
		#ifdef DEBUGGING
		 VERIFY(a<b);
		#endif

		if( t <= a ) { return (T)0; }
		if( t >= b ) { return (T)1; }
		T x = (t-a)/(b-a);
		return x*x*(-2*x+3);
	}

	/**
	* @brief     Calculate the S-shaped curve
	polynomial: 6x^5 - 15x^4 + 10x^3
	[0,1] -> [0,1]
	x: 0~1
	* @param     [IN] @b  x 0~1
	* @return     T
	*/
	template <typename T>
	inline T scurve5( const T& x )
	{
		SPDouble xx = x*x;
		SPDouble xxx = xx*x;
		return xxx*(6*xx-15*x+10);
	}

	/**
	* @brief     Calculate the S-shaped curve
	[a,b] -> [0,1]
	t: a~b
	* @param     [IN] @b  a [0,1]
	* @param     [IN] @b  b [0,1]
	* @param     [IN] @b  t a~b
	* @return     T
	*/
	template <typename T>
	inline T scurve5( const T& a, const T& b, const T& t )
	{
		#ifdef DEBUGGING
		 VERIFY(a<b);
		#endif

		if( t <= a ) { return (T)0; }
		if( t >= b ) { return (T)1; }
		T x = (t-a)/(b-a);

		SPDouble xx = (SPDouble)x*(SPDouble)x;
		SPDouble xxx = xx*(SPDouble)x;
		return (T)(xxx*(6.0*xx-15.0*x+10.0));
	}

	/**
	* @brief     Calculate the spherical linear interpolation
	* @param     [IN] @b  C input
	* @param     [IN] @b  A input
	* @param     [IN] @b  B input
	* @param     [IN] @b  f input
	* @return     S
	*/
	template <class S, typename T>
	inline S sphericalLinearInterpolation( S& C, const S& A, const S& B, const T f )
	{
		#ifdef DEBUGGING
		 VERIFY(0<=f&&f<=1);
		#endif

		T alpha, beta;
		T dot = dot( A, B );
		if( (1+dot) > EPSILON ) {
			if( (1-dot) > EPSILON ) {
				T theta = (T)acos( dot );
				T denom = (T)sin( theta );
				alpha = (T)sin((1-f)*theta) / denom;
				beta  = sin(f*theta) / denom;
			} else {
				linearInterpolation( C, A, B, f );
				C.normalize();
				return;
			}
		} else {
			alpha = (T)sin((0.5-f)*PI);
			beta  = (T)sin(f*PI);
		}
		return ( alpha*A + beta*B );
	}

	/**
	* @brief     Calculate the bi-linear interpolation
	* @param     [IN] @b  ratio[2] ratio
	* @param     [IN] @b  weight[4] weight
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid biLinearInterpolationWeight( T ratio[2], T weight[4] )
	{
		#ifdef DEBUGGING
		 VERIFY(0<=ratio[0]&&ratio[0]<=1);
		 VERIFY(0<=ratio[1]&&ratio[1]<=1);
		#endif

		T oneMinusRatio[2] = { 1-ratio[0], 1-ratio[1] };

		weight[0] = oneMinusRatio[0] * oneMinusRatio[1];
		weight[1] =         ratio[0] * oneMinusRatio[1];
		weight[2] =         ratio[0] * ratio[1];
		weight[3] = oneMinusRatio[0] * ratio[1];
	}


	/**
	* @brief     Calculate the bi-linear interpolation (ratio: 0~1 per each axis)
	* @param     [IN] @b  ratio[2] ratio
	* @param     [IN] @b  value[4] value
	* @return     T
	*/
	template <typename T>
	inline T biLinearInterpolation( T ratio[2], T value[4] ) // ratio: 0~1 per each axis
	{
		#ifdef DEBUGGING
		 VERIFY(0<=ratio[0]&&ratio[0]<=1);
		 VERIFY(0<=ratio[1]&&ratio[1]<=1);
		#endif

		T weight[4];
		biLinearInterpolationWeight( ratio, weight );
		return ( weight[0] * value[0] + weight[1] * value[1] + weight[2] * value[2] + weight[3] * value[3] );
	}

	/**
	* @brief     Calculate the bi-linear interpolation
	* @param     [IN] @b  v00 input
	* @param     [IN] @b  v10 input
	* @param     [IN] @b  v11 input
	* @param     [IN] @b  v01 input
	* @param     [IN] @b  fx input
	* @param     [IN] @b  fy input
	* @return     S
	*/
	template <class S, typename T>
	inline S biLinearInterpolation( const S& v00, const S& v10,
					 const S& v11, const S& v01,
					 const T fx, const T fy )
	{
		#ifdef DEBUGGING
		 VERIFY(0<=fx&&fx<=1);
		 VERIFY(0<=fy&&fy<=1);
		#endif

		return linearInterpolation( linearInterpolation( v00, v10, fx ),
					 linearInterpolation( v01, v11, fx ),
					 fy );
	}

	/**
	* @brief     Calculate the tri-linear interpolation
	* @param     [IN] @b  ratio[3] ratio
	* @param     [IN] @b  weight[8] weight
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid triLinearInterpolationWeight( T ratio[3], T weight[8] ) // ratio: 0~1 per each axis
	{
		#ifdef DEBUGGING
		 VERIFY(0<=ratio[0]&&ratio[0]<=1);
		 VERIFY(0<=ratio[1]&&ratio[1]<=1);
		 VERIFY(0<=ratio[2]&&ratio[2]<=1);
		#endif

		T oneMinusRatio[3] = { 1-ratio[0], 1-ratio[1], 1-ratio[2] };

		weight[0] = oneMinusRatio[0] * oneMinusRatio[1] * oneMinusRatio[2];
		weight[1] =         ratio[0] * oneMinusRatio[1] * oneMinusRatio[2];
		weight[2] =         ratio[0] * oneMinusRatio[1] *         ratio[2];
		weight[3] = oneMinusRatio[0] * oneMinusRatio[1] *         ratio[2];
		weight[4] = oneMinusRatio[0] *         ratio[1] * oneMinusRatio[2];
		weight[5] =         ratio[0] *         ratio[1] * oneMinusRatio[2];
		weight[6] =         ratio[0] *         ratio[1] *         ratio[2];
		weight[7] = oneMinusRatio[0] *         ratio[1] *         ratio[2];
	}

	/**
	* @brief     Calculate the tri-linear interpolation
	* @param     [IN] @b  ratio[3] ratio
	* @param     [IN] @b  value[8] value
	* @return     T
	*/
	template <typename T>
	inline T triLinearInterpolation( T ratio[3], T value[8] ) // ratio: 0~1 per each axis
	{
		#ifdef DEBUGGING
		 VERIFY(0<=ratio[0]&&ratio[0]<=1);
		 VERIFY(0<=ratio[1]&&ratio[1]<=1);
		 VERIFY(0<=ratio[2]&&ratio[2]<=1);
		#endif

		T weight[8];
		TriLinearInterpolationWeight( ratio, weight );
		return ( weight[0] * value[0] + weight[1] * value[1] + weight[2] * value[2] + weight[3] * value[3]
			   + weight[4] * value[4] + weight[5] * value[5] + weight[6] * value[6] + weight[7] * value[7] );
	}

	/**
	* @brief     Calculate the tri-linear interpolation
	* @param     [IN] @b  v000  input
	* @param     [IN] @b  v100 input
	* @param     [IN] @b  v101 input
	* @param     [IN] @b  v001 input
	* @param     [IN] @b  v010 input
	* @param     [IN] @b  v110 input
	* @param     [IN] @b  v111 input
	* @param     [IN] @b  v011 input
	* @param     [IN] @b  fx input
	* @param     [IN] @b  fy input
	* @param     [IN] @b  fz input
	* @return     S
	*/
	template <class S, typename T>
	inline S triLinearInterpolation( const S& v000, const S& v100, const S& v101, const S& v001,
					  const S& v010, const S& v110, const S& v111, const S& v011,
					  const T fx, const T fy, const T fz )
	{
		#ifdef DEBUGGING
		 VERIFY(0<=fx&&fx<=1);
		 VERIFY(0<=fy&&fy<=1);
		 VERIFY(0<=fz&&fz<=1);
		#endif

		return linearInterpolation( BilinearInterpolation( v000, v100, v110, v010, fx, fy ),
					 BilinearInterpolation( v001, v101, v111, v011, fx, fy ),
					 fz );
	}

	// for triangle
	/**
	* @brief     Calculate the barycentric interpolation for triangle
	* @param     [IN] @b  P   vector
	* @param     [IN] @b  A   vector
	* @param     [IN] @b  B   vector
	* @param     [IN] @b  C   vector
	* @param     [IN] @b  w[3] weight
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid weightSum( SPVec3t& P,
						   const SPVec3t& A, const SPVec3t& B, const SPVec3t& C,
						   const T w[3] )
	{
		P.x = ( w[0] * A.x ) + ( w[1] * B.x ) + ( w[2] * C.x );
		P.y = ( w[0] * A.y ) + ( w[1] * B.y ) + ( w[2] * C.y );
		P.z = ( w[0] * A.z ) + ( w[1] * B.z ) + ( w[2] * C.z );
	}

	/**
	* @brief     Calculate the barycentric interpolation for triangle
	* @param     [IN] @b  P vector
	* @param     [IN] @b  A vector
	* @param     [IN] @b  B vector
	* @param     [IN] @b  C vector
	* @param     [IN] @b  a input
	* @param     [IN] @b  b input
	* @param     [IN] @b  c input
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid weightSum( SPVec3t& P,
						   const SPVec3t& A, const SPVec3t& B, const SPVec3t& C,
						   const T a, const T b, const T c )
	{
		P.x = ( a * A.x ) + ( b * B.x ) + ( c * C.x );
		P.y = ( a * A.y ) + ( b * B.y ) + ( c * C.y );
		P.z = ( a * A.z ) + ( b * B.z ) + ( c * C.z );
	}

	// for tetrahedron
	/**
	* @brief     Calculate the barycentric interpolation for tetrahedron
	* @param     [IN] @b  P vector
	* @param     [IN] @b  A vector
	* @param     [IN] @b  B vector
	* @param     [IN] @b  C vector
	* @param     [IN] @b  D vector
	* @param     [IN] @b  w[4] weight
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid weightSum( SPVec3t& P,
						   const SPVec3t& A, const SPVec3t& B, const SPVec3t& C, const SPVec3t& D,
						   const T w[4] )
	{
		P.x = ( w[0] * A.x ) + ( w[1] * B.x ) + ( w[2] * C.x ) + ( w[3] * D.x );
		P.y = ( w[0] * A.y ) + ( w[1] * B.y ) + ( w[2] * C.y ) + ( w[3] * D.y );
		P.z = ( w[0] * A.z ) + ( w[1] * B.z ) + ( w[2] * C.z ) + ( w[3] * D.z );
	}

	/**
	* @brief     Calculate the barycentric interpolation for tetrahedron
	* @param     [IN] @b  P vector
	* @param     [IN] @b  A vector
	* @param     [IN] @b  B vector
	* @param     [IN] @b  C vector
	* @param     [IN] @b  D vector
	* @param     [IN] @b  a input
	* @param     [IN] @b  b input
	* @param     [IN] @b  c input
	* @param     [IN] @b  d input
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid weightSum( SPVec3t& P,
						   const SPVec3t& A, const SPVec3t& B, const SPVec3t& C, const SPVec3t& D,
						   const T a, const T b, const T c, const T d )
	{
		P.x = ( a * A.x ) + ( b * B.x ) + ( c * C.x ) + ( d * D.x );
		P.y = ( a * A.y ) + ( b * B.y ) + ( c * C.y ) + ( d * D.y );
		P.z = ( a * A.z ) + ( b * B.z ) + ( c * C.z ) + ( d * D.z );
	}
}

#endif //_SP_INTERPOLATION_H_

