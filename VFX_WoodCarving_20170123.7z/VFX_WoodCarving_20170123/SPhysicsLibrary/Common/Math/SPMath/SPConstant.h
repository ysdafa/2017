/**
* @file SPConstant.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_CONSTANT_H_
#define _SP_CONSTANT_H_

#include <float.h>

namespace SPhysics
{

	#undef  NULL
	#define NULL					0									//!< null

	#undef  TRUE
	#define TRUE					1									//!< true

	#undef  FALSE
	#define FALSE					0									//!< false

	#undef  LARGE
	#define LARGE					FLT_MAX								//!< large number

	#undef  SMALL
	#define SMALL					-FLT_MAX							//!< small number

	#undef  EPSILON
	#define EPSILON					(double)1e-30						//!< epsilon

	#undef  MINUS_EPSILON
	#define MINUS_EPSILON				-EPSILON							//!< -epsilon

	#undef  EPSILON_PLUS_ONE
	#define EPSILON_PLUS_ONE				EPSILON+1							//!< epsilon+1

	#undef	ONE_OVER_RAND_MAX		
	#define ONE_OVER_RAND_MAX		1.0/(double)RAND_MAX							//!< epsilon+1


	#undef  PI
	#define PI	   	   				3.141592653589793115997963468544	//!< pi

	#undef  PI2
	#define PI2						6.283185307179586231995926937088	//!< pi*2

	#undef  PI3
	#define PI3						9.424777960769379347993890405633	//!< pi*3

	#undef  PI4
	#define PI4						12.566370614359172463991853874176	//!< pi*4
	
	#undef  PI_2
	#define PI_2					1.570796326794896557998981734272	//!< pi/2

	#undef  PI_3
	#define PI_3					1.047197551196597631317786181171	//!< pi/3

	#undef  PI_INV
	#define PI_INV					0.318309886183790691216444201928	//!< 1/pi				

	#undef  PI_SQ
	#define PI_SQ					1.772453850905515881919427556568	//!< sqrt(pi)


	#undef  NLE
	#define NLE						2.718281828459045090795598298428	//!< natural log e

	#undef  NLE2
	#define NLE2					5.436563656918090181591196596855	//!< e*2

	#undef  NLE3
	#define NLE3					8.154845485377135716476004745346	//!< e*3

	#undef  NLE_2
	#define NLE_2					1.359140914229522545397799149214	//!< e/2

	#undef  NLE_3
	#define NLE_3					0.906093942819681696931866099476	//!< e/3

	#undef  NLE_INV
	#define NLE_INV					0.367879441171442334024277442950	//!< 1/e

	#undef  NLE_SQ
	#define NLE_SQ					1.648721270700128194164335582172	//!< sqrt(e)


	#undef  SQRT2
	#define SQRT2					1.414213562373095145474621858739	//!< sqrt(2)

	#undef  SQRT3
	#define SQRT3					1.732050807568877193176604123437	//!< sqrt(3)

	#undef  SQRT5
	#define SQRT5					2.236067977499789805051477742381	//!< sqrt(5)

	#undef  SQRT6
	#define SQRT6					2.449489742783177881335632264381	//!< sqrt(6)

	#undef  SQRT7
	#define SQRT7					2.645751311064590716171096573817	//!< sqrt(7)

	#undef  SQRT8
	#define SQRT8					2.828427124746190290949243717478	//!< sqrt(8)

	#undef  SQRT10
	#define SQRT10					3.162277660168379522787063251599	//!< sqrt(10)


	#undef  RADIAN_TO_DEGREE
	#define RADIAN_TO_DEGREE				57.295779513082322864647721871734	//!< 180/pi: radian -> degree

	#undef  DEGREE_TO_RADIAN
	#define DEGREE_TO_RADIAN				 0.017453292519943295474371680598	//!< pi/180: degree -> radian

}
#endif //_SP_CONSTANT_H_

