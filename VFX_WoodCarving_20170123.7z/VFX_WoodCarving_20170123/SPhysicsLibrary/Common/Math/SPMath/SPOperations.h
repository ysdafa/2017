/**
* @file SPOperations.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_OPERATIONS_H_
#define _SP_OPERATIONS_H_

#include "SPDefines.h"
#include "SPArithmetic.h"
#include "SPTest.h"

#include <glm.hpp>

namespace SPhysics
{
	//TODO - epsilon value (use std::numeric_limits constnants instead of define)
	//TODO - provide equal operations with give epsilon  
	/**
	* @brief     Return true if the difference of 'A' and 'B' is smaller than EPSILON
	* @param     [IN] @b A two dimensional vector
	* @param     [IN] @b B two dimensional vector
	* @return     SPBool
	*/
	template <typename T>
	inline SPBool isAlmostSame( const SPVec2t &A, const SPVec2t &B )
	{
		if( abs(A.x-B.x) > EPSILON ) return SPFALSE;
		if( abs(A.y-B.y) > EPSILON ) return SPFALSE;
		return SPTRUE;
	}

	/**
	* @brief     Return true if the difference of 'A' and 'B' is smaller than EPSILON
	* @param     [IN] @b A three dimensional vector
	* @param     [IN] @b B three dimensional vector
	* @return     SPBool
	*/
	template <typename T>
	inline SPBool isAlmostSame( const SPVec3t &A, const SPVec3t &B )
	{
		if( abs(A.x-B.x) > EPSILON ) return SPFALSE;
		if( abs(A.y-B.y) > EPSILON ) return SPFALSE;
		if( abs(A.z-B.z) > EPSILON ) return SPFALSE;
		return SPTRUE;
	}

	/**
	* @brief     Return true if the difference of 'A' and 'B' is smaller than EPSILON
	* @param     [IN] @b A four dimensional vector
	* @param     [IN] @b B four dimensional vector
	* @return     SPBool
	*/
	template <typename T>
	inline SPBool isAlmostSame( const SPVec4t &A, const SPVec4t &B )
	{
		if( abs(A.x-B.x) > EPSILON ) return SPFALSE;
		if( abs(A.y-B.y) > EPSILON ) return SPFALSE;
		if( abs(A.z-B.z) > EPSILON ) return SPFALSE;
		if( abs(A.w-B.w) > EPSILON ) return SPFALSE;
		return SPTRUE;
	}

	/**
	* @brief     Return true if the matrix is equal to Identity
	* @param     [IN] @b M two dimensional matrix
	* @return     SPBool
	*/
	template <typename T>
	inline SPBool isIdentity( const SPMat2x2t& M )
	{
		if( M[0][0] != 1 ) return SPFALSE;
		if( M[1][1] != 1 ) return SPFALSE;

		if( M[0][1] != 0 ) return SPFALSE;
		if( M[1][0] != 0 ) return SPFALSE;

		return SPTRUE;
	}

	/**
	* @brief     Return true if the matrix is equal to Identity
	* @param     [IN] @b M three dimensional matrix
	* @return     SPBool
	*/
	template <typename T>
	inline SPBool isIdentity( const SPMat3x3t& M )
	{
		if( M[0][0] != 1 ) return SPFALSE;
		if( M[1][1] != 1 ) return SPFALSE;
		if( M[2][2] != 1 ) return SPFALSE;

		if( M[0][1] != 0 ) return SPFALSE;
		if( M[0][2] != 0 ) return SPFALSE;

		if( M[1][0] != 0 ) return SPFALSE;
		if( M[1][2] != 0 ) return SPFALSE;

		if( M[2][0] != 0 ) return SPFALSE;
		if( M[2][1] != 0 ) return SPFALSE;

		return SPTRUE;
	}

	/**
	* @brief     Return true if the matrix is equal to Identity
	* @param     [IN] @b M four dimensional matrix
	* @return     SPBool
	*/
	template <typename T>
	inline SPBool isIdentity( const SPMat4x4t& M )
	{
		if( M[0][0] != 1 ) return SPFALSE;
		if( M[1][1] != 1 ) return SPFALSE;
		if( M[2][2] != 1 ) return SPFALSE;
		if( M[3][3] != 1 ) return SPFALSE;

		if( M[0][1] != 0 ) return SPFALSE;
		if( M[0][2] != 0 ) return SPFALSE;
		if( M[0][3] != 0 ) return SPFALSE;

		if( M[1][0] != 0 ) return SPFALSE;
		if( M[1][2] != 0 ) return SPFALSE;
		if( M[1][3] != 0 ) return SPFALSE;

		if( M[2][0] != 0 ) return SPFALSE;
		if( M[2][1] != 0 ) return SPFALSE;
		if( M[2][3] != 0 ) return SPFALSE;

		if( M[3][0] != 0 ) return SPFALSE;
		if( M[3][1] != 0 ) return SPFALSE;
		if( M[3][2] != 0 ) return SPFALSE;

		return SPTRUE;
	}

	/**
	* @brief     Return true if all data sets are Zero
	* @param     [IN] @b M three dimensional matrix
	* @return     SPBool
	*/
	template <typename T>
	inline SPBool isZero( const SPMat3x3t& M )
	{
		if( M[0][0] != 0 ) return SPFALSE;
		if( M[0][1] != 0 ) return SPFALSE;
		if( M[0][2] != 0 ) return SPFALSE;

		if( M[1][0] != 0 ) return SPFALSE;
		if( M[1][1] != 0 ) return SPFALSE;
		if( M[1][2] != 0 ) return SPFALSE;

		if( M[2][0] != 0 ) return SPFALSE;
		if( M[2][1] != 0 ) return SPFALSE;
		if( M[2][2] != 0 ) return SPFALSE;

		return SPTRUE;
	}

	// (R^T)R ?= R(R^T) ?= I
	/**
	* @brief     Return true if matrix is equal Ortho normal , (R^T)R ?= R(R^T) ?= I
	* @param     [IN] @b R three dimensional matrix
	* @return     SPBool
	*/
	template <typename T>
	inline SPBool isOrthoNormal( const SPMat3x3t &R )
	{
		if( isAlmostZero( R[0][0]*R[0][1]+R[1][0]*R[1][1]+R[2][0]*R[2][1] ) )
			if( isAlmostZero( R[0][1]*R[0][2]+R[1][1]*R[1][2]+R[2][1]*R[2][2] ) )
				if( isAlmostZero( R[0][2]*R[0][0]+R[1][2]*R[1][0]+R[2][2]*R[2][0] ) )
					if( isAlmostZero( R[0][0]*R[0][0]+R[1][0]*R[1][0]+R[2][0]*R[2][0] - 1 ) )
						if( isAlmostZero( R[0][1]*R[0][1]+R[1][1]*R[1][1]+R[2][1]*R[2][1] - 1 ) )
							if( isAlmostZero( R[0][2]*R[0][2]+R[1][2]*R[1][2]+R[2][2]*R[2][2] - 1 ) ) return SPTRUE;
		return SPFALSE;
	}

	/**
	* @brief     A ?= B
	* @param     [IN] @b A two dimensional matrix
	* @param     [IN] @b B two dimensional matrix
	* @return     SPBool
	*/
	template <typename T>
	inline SPBool isSame( const SPMat2x2t &A, const SPMat2x2t &B )
	{
		if( A[0][0] != B[0][0] ) return SPFALSE;
		if( A[0][1] != B[0][1] ) return SPFALSE;
		if( A[1][0] != B[1][0] ) return SPFALSE;
		if( A[1][1] != B[1][1] ) return SPFALSE;

		return SPTRUE;
	}

	/**
	* @brief     A ?= B
	* @param     [IN] @b A three dimensional matrix
	* @param     [IN] @b B three dimensional matrix
	* @return     SPBool
	*/
	template <typename T>
	inline SPBool isSame( const SPMat3x3t &A, const SPMat3x3t &B )
	{
		if( A[0][0] != B[0][0] ) return SPFALSE;
		if( A[0][1] != B[0][1] ) return SPFALSE;
		if( A[0][2] != B[0][2] ) return SPFALSE;
		if( A[1][0] != B[1][0] ) return SPFALSE;
		if( A[1][1] != B[1][1] ) return SPFALSE;
		if( A[1][2] != B[1][2] ) return SPFALSE;
		if( A[2][0] != B[2][0] ) return SPFALSE;
		if( A[2][1] != B[2][1] ) return SPFALSE;
		if( A[2][2] != B[2][2] ) return SPFALSE;

		return SPTRUE;
	}

	/**
	* @brief     A ?= B
	* @param     [IN] @b A  four dimensional matrix
	* @param     [IN] @b B  four dimensional matrix
	* @return     SPBool
	*/
	template <typename T>
	inline SPBool isSame( const SPMat4x4t &A , const SPMat4x4t &B )
	{
		if( A[0][0] != B[0][0] ) return SPFALSE;
		if( A[0][1] != B[0][1] ) return SPFALSE;
		if( A[0][2] != B[0][2] ) return SPFALSE;
		if( A[0][3] != B[0][3] ) return SPFALSE;
		if( A[1][0] != B[1][0] ) return SPFALSE;
		if( A[1][1] != B[1][1] ) return SPFALSE;
		if( A[1][2] != B[1][2] ) return SPFALSE;
		if( A[1][3] != B[1][3] ) return SPFALSE;
		if( A[2][0] != B[2][0] ) return SPFALSE;
		if( A[2][1] != B[2][1] ) return SPFALSE;
		if( A[2][2] != B[2][2] ) return SPFALSE;
		if( A[2][3] != B[2][3] ) return SPFALSE;
		if( A[3][0] != B[3][0] ) return SPFALSE;
		if( A[3][1] != B[3][1] ) return SPFALSE;
		if( A[3][2] != B[3][2] ) return SPFALSE;
		if( A[3][3] != B[3][3] ) return SPFALSE;

		return SPTRUE;
	}


	/**
	* @brief     P = 0
	* @param     [IN] @b P data array
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid zero2( T P[2] )
	{
		P[0] = P[1] = 0;
	}

	/**
	* @brief     P = 0
	* @param     [IN] @b P data array
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid zero3( T P[3] )
	{
		P[0] = P[1] = P[2] = 0;
	}

	/**
	* @brief     P = 0
	* @param     [IN] @b P two dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid zero( SPVec2t& P )
	{
		P.x = P.y = 0;
	}

	/**
	* @brief     P = 0
	* @param     [IN] @b P three dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid zero( SPVec3t& P )
	{
		P.x = P.y = P.z = 0;
	}

	/**
	* @brief     P = 0
	* @param     [IN] @b P four dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid zero( SPVec4t& P )
	{
		P.x = P.y = P.z = P.w = 0;
	}

	/**
	* @brief     A = -A
	* @param     [IN] @b A two dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid negative( SPVec2t& A )
	{
		A.x = -A.x;
		A.y = -A.y;
	}

	/**
	* @brief     A = -A 
	* @param     [IN] @b A three dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid negative( SPVec3t& A )
	{
		A.x = -A.x;
		A.y = -A.y;
		A.z = -A.z;
	}

	/**
	* @brief     A = -A
	* @param     [IN] @b A four dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid negative( SPVec4t& A )
	{
		A.x = -A.x;
		A.y = -A.y;
		A.z = -A.z;
		A.w = -A.w;
	}

	/**
	* @brief     A = B
	* @param     [IN] @b A two dimensional vector data
	* @param     [IN] @b B two dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid copy( SPVec2t& A, const SPVec2t& B )
	{
		A.x = B.x;
		A.y = B.y;
	}

	/**
	* @brief     A = B
	* @param     [IN] @b A three dimensional vector data
	* @param     [IN] @b B three dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid copy( SPVec3t& A, const SPVec3t& B )
	{
		A.x = B.x;
		A.y = B.y;
		A.z = B.z;
	}

	/**
	* @brief     A = B
	* @param     [IN] @b A four dimensional vector data
	* @param     [IN] @b B four dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid copy( SPVec4t& A, const SPVec4t& B )
	{
		A.x = B.x;
		A.y = B.y;
		A.z = B.z;
		A.w = B.w;
	}

	/**
	* @brief     A = B
	* @param     [IN] @b A four dimensional vector data
	* @param     [IN] @b B four dimensional vector data
	* @return     SPVoid
	*/
	inline SPVoid copy( SPVec4f& A, const SPVec4d& B )
	{
		A.x = (SPFloat)B.x;
		A.y = (SPFloat)B.y;
		A.z = (SPFloat)B.z;
		A.w = (SPFloat)B.w;
	}

	/**
	* @brief     A = B
	* @param     [IN] @b A four dimensional vector data
	* @param     [IN] @b B four dimensional vector data
	* @return     SPVoid
	*/
	inline SPVoid copy( SPVec4d& A, const SPVec4f& B )
	{
		A.x = (SPDouble)B.x;
		A.y = (SPDouble)B.y;
		A.z = (SPDouble)B.z;
		A.w = (SPDouble)B.w;
	}

	/**
	* @brief     A <-> B
	* @param     [IN] @b A two dimensional vector data
	* @param     [IN] @b B two dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid change( SPVec2t& A, SPVec2t& B )
	{
		SPVec2t C; copy( C, A );
		A.x = B.x;  A.y = B.y;
		B.x = C.x;  B.y = C.y;
	}

	/**
	* @brief     A <-> B
	* @param     [IN] @b A three dimensional vector data
	* @param     [IN] @b B three dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid change( SPVec3t& A, SPVec3t& B )
	{
		SPVec3t C; copy( C, A );
		A.x = B.x;  A.y = B.y;  A.z = B.z;
		B.x = C.x;  B.y = C.y;  B.z = C.z;
	}

	/**
	* @brief     A <-> B
	* @param     [IN] @b A four dimensional vector data
	* @param     [IN] @b B four dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid change( SPVec4t& A, SPVec4t& B )
	{
		SPVec4t C; copy( C, A);
		A.x = B.x;  A.y = B.y;  A.z = B.z;  A.w = B.w;
		B.x = C.x;  B.y = C.y;  B.z = C.z;  B.w = C.w;
	}

	/**
	* @brief     A = B + C
	* @param     [IN] @b A two dimensional vector data
	* @param     [IN] @b B two dimensional vector data
	* @param     [IN] @b C two dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid add( SPVec2t& A, const SPVec2t& B, const SPVec2t& C )
	{
		A.x = B.x + C.x;
		A.y = B.y + C.y;
	}

	/**
	* @brief     A = B + C
	* @param     [IN] @b A three dimensional vector data
	* @param     [IN] @b B three dimensional vector data
	* @param     [IN] @b C three dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid add( SPVec3t& A, const SPVec3t& B, const SPVec3t& C )
	{
		A.x = B.x + C.x;
		A.y = B.y + C.y;
		A.z = B.z + C.z;
	}

	/**
	* @brief     A = B + C
	* @param     [IN] @b A four dimensional vector data
	* @param     [IN] @b B four dimensional vector data
	* @param     [IN] @b C four dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid add( SPVec4t& A, const SPVec4t& B, const SPVec4t& C )
	{
		A.x = B.x + C.x;
		A.y = B.y + C.y;
		A.z = B.z + C.z;
		A.w = B.w + C.w;
	}

	/**
	* @brief     A = B - C
	* @param     [IN] @b A two dimensional vector data
	* @param     [IN] @b B two dimensional vector data
	* @param     [IN] @b C two dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid substract( SPVec2t& A, const SPVec2t& B, const SPVec2t& C )
	{
		A.x = B.x - C.x;
		A.y = B.y - C.y;
	}

	/**
	* @brief     A = B - C
	* @param     [IN] @b A three dimensional vector data
	* @param     [IN] @b B three dimensional vector data
	* @param     [IN] @b C three dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid substract( SPVec3t& A, const SPVec3t& B, const SPVec3t& C )
	{
		A.x = B.x - C.x;
		A.y = B.y - C.y;
		A.z = B.z - C.z;
	}

	/**
	* @brief     A = B - C
	* @param     [IN] @b A four dimensional vector data
	* @param     [IN] @b B four dimensional vector data
	* @param     [IN] @b C four dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid substract( SPVec4t& A, const SPVec4t& B, const SPVec4t& C )
	{
		A.x = B.x - C.x;
		A.y = B.y - C.y;
		A.z = B.z - C.z;
		A.w = B.w - C.w;
	}

	/**
	* @brief     A += B
	* @param     [IN] @b A two dimensional vector data
	* @param     [IN] @b B two dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid increase( SPVec2t& A, const SPVec2t& B )
	{
		A.x += B.x;
		A.y += B.y;
	}

	/**
	* @brief     A += B
	* @param     [IN] @b A three dimensional vector data
	* @param     [IN] @b B three dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid increase( SPVec3t& A, const SPVec3t& B )
	{
		A.x += B.x;
		A.y += B.y;
		A.z += B.z;
	}

	/**
	* @brief     A += B
	* @param     [IN] @b A four dimensional vector data
	* @param     [IN] @b B four dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid increase( SPVec4t& A, const SPVec4t& B )
	{
		A.x += B.x;
		A.y += B.y;
		A.z += B.z;
		A.w += B.w;
	}

	/**
	* @brief     A -= B
	* @param     [IN] @b A two dimensional vector data
	* @param     [IN] @b B two dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid decrease( SPVec2t& A, const SPVec2t& B )
	{
		A.x -= B.x;
		A.y -= B.y;
	}

	/**
	* @brief     A -= B
	* @param     [IN] @b A three dimensional vector data
	* @param     [IN] @b B three dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid decrease( SPVec3t& A, const SPVec3t& B )
	{
		A.x -= B.x;
		A.y -= B.y;
		A.z -= B.z;
	}

	/**
	* @brief     A -= B
	* @param     [IN] @b A four dimensional vector data
	* @param     [IN] @b B four dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid decrease( SPVec4t& A, const SPVec4t& B )
	{
		A.x -= B.x;
		A.y -= B.y;
		A.z -= B.z;
		A.w -= B.w;
	}

	/**
	* @brief     A = alpha*B
	* @param     [IN] @b A two dimensional vector data
	* @param     [IN] @b alpha
	* @param     [IN] @b B two dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid multiply( SPVec2t& A, const T& alpha, const SPVec2t& B )
	{
		A.x = alpha * B.x;
		A.y = alpha * B.y;
	}

	/**
	* @brief     A = alpha*B
	* @param     [IN] @b A three dimensional vector data
	* @param     [IN] @b alpha
	* @param     [IN] @b B three dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid multiply( SPVec3t& A, const T& alpha, const SPVec3t& B )
	{
		A.x = alpha * B.x;
		A.y = alpha * B.y;
		A.z = alpha * B.z;
	}

	/**
	* @brief     A = alpha*B
	* @param     [IN] @b A four dimensional vector data
	* @param     [IN] @b alpha
	* @param     [IN] @b B four dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid multiply( SPVec4t& A, const T& alpha, const SPVec4t& B )
	{
		A.x = alpha * B.x;
		A.y = alpha * B.y;
		A.z = alpha * B.z;
		A.w = alpha * B.w;
	}

	/**
	* @brief     A += alpha*B
	* @param     [IN] @b A two dimensional vector data
	* @param     [IN] @b alpha
	* @param     [IN] @b B two dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid addMultiply( SPVec2t& A, const T& alpha, const SPVec2t& B )
	{
		A.x += alpha * B.x;
		A.y += alpha * B.y;
	}

	/**
	* @brief     A += alpha*B
	* @param     [IN] @b A three dimensional vector data
	* @param     [IN] @b alpha
	* @param     [IN] @b B three dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid addMultiply( SPVec3t& A, const T& alpha, const SPVec3t& B )
	{
		A.x += alpha * B.x;
		A.y += alpha * B.y;
		A.z += alpha * B.z;
	}

	/**
	* @brief     A += alpha*B
	* @param     [IN] @b A four dimensional vector data
	* @param     [IN] @b alpha
	* @param     [IN] @b B four dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid addMultiply( SPVec4t& A, const T& alpha, const SPVec4t& B )
	{
		A.x += alpha * B.x;
		A.y += alpha * B.y;
		A.z += alpha * B.z;
		A.w += alpha * B.w;
	}

	/**
	* @brief     A += B+alpha*C
	* @param     [IN] @b A two dimensional vector data
	* @param     [IN] @b B two dimensional vector data
	* @param     [IN] @b alpha
	* @param     [IN] @b C two dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid addMultiply( SPVec2t& A, const SPVec2t& B, const T& alpha, const SPVec2t& C )
	{
		A.x += B.x + alpha * C.x;
		A.y += B.y + alpha * C.y;
	}

	/**
	* @brief     A += B+alpha*C
	* @param     [IN] @b A three dimensional vector data
	* @param     [IN] @b B three dimensional vector data
	* @param     [IN] @b alpha
	* @param     [IN] @b C three dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid addMultiply( SPVec3t& A, const SPVec3t& B, const T& alpha, const SPVec3t& C )
	{
		A.x += B.x + alpha * C.x;
		A.y += B.y + alpha * C.y;
		A.z += B.z + alpha * C.z;
	}

	/**
	* @brief     A += B+alpha*C
	* @param     [IN] @b A four dimensional vector data
	* @param     [IN] @b B four dimensional vector data
	* @param     [IN] @b alpha
	* @param     [IN] @b C four dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid addMultiply( SPVec4t& A, const SPVec4t& B, const T& alpha, const SPVec4t& C )
	{
		A.x += B.x + alpha * C.x;
		A.y += B.y + alpha * C.y;
		A.z += B.z + alpha * C.z;
		A.w += B.w + alpha * C.w;
	}

	/**
	* @brief     A *= alpha
	* @param     [IN] @b A two dimensional vector data
	* @param     [IN] @b alpha
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid multiply( SPVec2t& A, const T& alpha )
	{
		A.x *= alpha;
		A.y *= alpha;
	}

	/**
	* @brief     A *= alpha
	* @param     [IN] @b A three dimensional vector data
	* @param     [IN] @b alpha
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid multiply( SPVec3t& A, const T& alpha )
	{
		A.x *= alpha;
		A.y *= alpha;
		A.z *= alpha;
	}

	/**
	* @brief     A *= alpha
	* @param     [IN] @b A four dimensional vector data
	* @param     [IN] @b alpha
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid multiply( SPVec4t& A, const T& alpha )
	{
		A.x *= alpha;
		A.y *= alpha;
		A.z *= alpha;
		A.w *= alpha;
	}

	/**
	* @brief     Return A dot B
	* @param     [IN] @b A two dimensional vector data
	* @param     [IN] @b B two dimensional vector data
	* @return     T
	*/
	template <typename T>
	inline T dot( const SPVec2t& A, const SPVec2t& B )
	{
		return ( A.x*B.x + A.y*B.y );
	}

	/**
	* @brief     Return A dot B
	* @param     [IN] @b A three dimensional vector data
	* @param     [IN] @b B three dimensional vector data
	* @return     T
	*/
	template <typename T>
	inline T dot( const SPVec3t& A, const SPVec3t& B )
	{
		return ( A.x*B.x + A.y*B.y + A.z*B.z );
	}

	/**
	* @brief     Return A dot B
	* @param     [IN] @b A four dimensional vector data
	* @param     [IN] @b B four dimensional vector data
	* @return     T
	*/
	template <typename T>
	inline T dot( const SPVec4t& A, const SPVec4t& B )
	{
		return ( A.x*B.x + A.y*B.y + A.z*B.z + A.w*B.w );
	}

	/**
	* @brief     cross = A x B
	* @param     [IN] @b cross
	* @param     [IN] @b A three dimensional vector data
	* @param     [IN] @b B three dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid cross( SPVec3t& cross, const SPVec3t& A, const SPVec3t& B )
	{
		cross.x = A.y*B.z - A.z*B.y;
		cross.y = A.z*B.x - A.x*B.z;
		cross.z = A.x*B.y - A.y*B.x;
	}

	/**
	* @brief     cross = A x B
	* @param     [IN] @b cross three dimensional vector data
	* @param     [IN] @b A three dimensional vector data
	* @param     [IN] @b B three dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid cross( SPVec3t& cross, const SPVec2t& A, const SPVec2t& B )
	{
		cross.x = 0;
		cross.y = 0;
		cross.z = A.x*B.y - A.y*B.x;
	}

	/**
	* @brief     cross = A x B
	* @param     [IN] @b A two dimensional vector data
	* @param     [IN] @b B two dimensional vector data
	* @return     T
	*/
	template <typename T>
	inline T cross( const SPVec2t& A, const SPVec2t& B )
	{
		return ( A.x*B.y - A.y*B.x );
	}

	/**
	* @brief     mid = (A+B)/2
	* @param     [IN] @b mid two dimensional vector data
	* @param     [IN] @b A two dimensional vector data
	* @param     [IN] @b B two dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid medium( SPVec2t& mid, const SPVec2t& A, const SPVec2t& B )
	{
		mid.x = (T)0.5 * ( A.x + B.x );
		mid.y = (T)0.5 * ( A.y + B.y );
	}

	/**
	* @brief     mid = (A+B)/2
	* @param     [IN] @b mid three dimensional vector data
	* @param     [IN] @b A three dimensional vector data
	* @param     [IN] @b B three dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid medium( SPVec3t& mid, const SPVec3t& A, const SPVec3t& B )
	{
		mid.x = (T)0.5 * ( A.x + B.x );
		mid.y = (T)0.5 * ( A.y + B.y );
		mid.z = (T)0.5 * ( A.z + B.z );
	}


	/**
	* @brief     mid = (A+B)/2
	* @param     [IN] @b mid four dimensional vector data
	* @param     [IN] @b A four dimensional vector data
	* @param     [IN] @b B four dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid medium( SPVec4t& mid, const SPVec4t& A, const SPVec4t& B )
	{
		mid.x = (T)0.5 * ( A.x + B.x );
		mid.y = (T)0.5 * ( A.y + B.y );
		mid.z = (T)0.5 * ( A.z + B.z );
		mid.w = (T)0.5 * ( A.w + B.w );
	}


	/**
	* @brief     center = (A+B+C)/3
	* @param     [IN] @b center
	* @param     [IN] @b A two dimensional vector data
	* @param     [IN] @b B two dimensional vector data
	* @param     [IN] @b C two dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid center( SPVec2t& center, const SPVec2t& A, const SPVec2t& B, const SPVec2t& C )
	{
		center.x = (T)( ( A.x + B.x + C.x ) / 3.0 );
		center.y = (T)( ( A.y + B.y + C.y ) / 3.0 );
	}

	/**
	* @brief     center = (A+B+C)/3
	* @param     [IN] @b center three dimensional vector data
	* @param     [IN] @b A three dimensional vector data
	* @param     [IN] @b B three dimensional vector data
	* @param     [IN] @b C three dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid center( SPVec3t& center, const SPVec3t& A, const SPVec3t& B, const SPVec3t& C )
	{
		center.x = (T)( ( A.x + B.x + C.x ) / 3.0 );
		center.y = (T)( ( A.y + B.y + C.y ) / 3.0 );
		center.z = (T)( ( A.z + B.z + C.z ) / 3.0 );
	}


	/**
	* @brief	center = (A+B+C+D)/4     
	* @param     [IN] @b center three dimensional vector data
	* @param     [IN] @b A three dimensional vector data
	* @param     [IN] @b B three dimensional vector data
	* @param     [IN] @b C three dimensional vector data
	* @param     [IN] @b D three dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid center( SPVec3t& center, const SPVec3t& A, const SPVec3t& B,
											 const SPVec3t& C, const SPVec3t& D )
	{
		center.x = (T)0.25 * ( A.x + B.x + C.x + D.x );
		center.y = (T)0.25 * ( A.y + B.y + C.y + D.y );
		center.z = (T)0.25 * ( A.z + B.z + C.z + D.z );
	}

	/**
	* @brief     C = (1-alpha)*A+alpha*B
	* @param     [IN] @b C two dimensional vector data
	* @param     [IN] @b A two dimensional vector data
	* @param     [IN] @b B two dimensional vector data
	* @param     [IN] @b alpha 
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid divide( SPVec2t& C, const SPVec2t& A, const SPVec2t& B, const T& alpha )
	{
		#ifdef DEBUGGING
		 VERIFY(0<=alpha&&alpha<=1);
		#endif

		T beta = 1 - alpha;

		C.x = beta * A.x + alpha * B.x;
		C.y = beta * A.y + alpha * B.y;
	}

	/**
	* @brief     C = (1-alpha)*A+alpha*B
	* @param     [IN] @b C three dimensional vector data
	* @param     [IN] @b A three dimensional vector data
	* @param     [IN] @b B three dimensional vector data
	* @param     [IN] @b alpha 
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid divide( SPVec3t& C, const SPVec3t& A, const SPVec3t& B, const T& alpha )
	{
		#ifdef DEBUGGING
		 VERIFY(0<=alpha&&alpha<=1);
		#endif

		T beta = 1 - alpha;

		C.x = beta * A.x + alpha * B.x;
		C.y = beta * A.y + alpha * B.y;
		C.z = beta * A.z + alpha * B.z;
	}

	/**
	* @brief     C = (1-alpha)*A+alpha*B
	* @param     [IN] @b C four dimensional vector data
	* @param     [IN] @b A four dimensional vector data
	* @param     [IN] @b B four dimensional vector data
	* @param     [IN] @b alpha 
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid divide( SPVec4t& C, const SPVec4t& A, const SPVec4t& B, const T& alpha )
	{
		#ifdef DEBUGGING
		 VERIFY(0<=alpha&&alpha<=1);
		#endif

		T beta = 1 - alpha;

		C.x = beta * A.x + alpha * B.x;
		C.y = beta * A.y + alpha * B.y;
		C.z = beta * A.z + alpha * B.z;
		C.w = beta * A.w + alpha * B.w;
	}

	// beta = 1 - alpha   //
	/**
	* @brief     C = beta*A+alpha*B , beta = 1 - alpha
	* @param     [IN] @b C two dimensional vector data
	* @param     [IN] @b A two dimensional vector data
	* @param     [IN] @b B two dimensional vector data
	* @param     [IN] @b alpha 
	* @param     [IN] @b beta 
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid divide( SPVec2t& C, const SPVec2t& A, const SPVec2t& B, const T& alpha, const T& beta )
	{
		#ifdef DEBUGGING
		 VERIFY(0<=alpha&&alpha<=1);
		 VERIFY(0<=beta &&beta <=1);
		 VERIFY(isAlmostSame(alpha+beta,(T)1));
		#endif

		C.x = beta * A.x + alpha * B.x;
		C.y = beta * A.y + alpha * B.y;
	}

	/**
	* @brief     C = beta*A+alpha*B , beta = 1 - alpha
	* @param     [IN] @b C three dimensional vector data
	* @param     [IN] @b A three dimensional vector data
	* @param     [IN] @b B three dimensional vector data
	* @param     [IN] @b alpha
	* @param     [IN] @b beta
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid divide( SPVec3t& C, const SPVec3t& A, const SPVec3t& B, const T& alpha, const T& beta )
	{
		#ifdef DEBUGGING
		 VERIFY(0<=alpha&&alpha<=1);
		 VERIFY(0<=beta &&beta <=1);
		 VERIFY(isAlmostSame(alpha+beta,(T)1));
		#endif

		C.x = beta * A.x + alpha * B.x;
		C.y = beta * A.y + alpha * B.y;
		C.z = beta * A.z + alpha * B.z;
	}

	/**
	* @brief     C = beta*A+alpha*B , beta = 1 - alpha
	* @param     [IN] @b C four dimensional vector data
	* @param     [IN] @b A four dimensional vector data
	* @param     [IN] @b B four dimensional vector data
	* @param     [IN] @b alpha
	* @param     [IN] @b beta
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid divide( SPVec4t& C, const SPVec4t& A, const SPVec4t& B, const T& alpha, const T& beta )
	{
		#ifdef DEBUGGING
		 VERIFY(0<=alpha&&alpha<=1);
		 VERIFY(0<=beta &&beta <=1);
		 VERIFY(isAlmostSame(alpha+beta,(T)1));
		#endif

		C.x = beta * A.x + alpha * B.x;
		C.y = beta * A.y + alpha * B.y;
		C.z = beta * A.z + alpha * B.z;
		C.w = beta * A.w + alpha * B.w;
	}

	/**
	* @brief     x = normalize(x)
	* @param     [IN] @b x two dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid normalize( SPVec2t& x )
	{
		T lenSQ = glm::dot(x, x);
		if( isAlmostZero( lenSQ ) ) { zero( x ); return; }
		if( isAlmostSame( lenSQ, (T)1 ) ) { return; }
		T denom = (T)( 1 / sqrt( lenSQ ) );
		multiply( x, denom );
	}

	/**
	* @brief     x = normalize(x)
	* @param     [IN] @b x three dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid normalize( SPVec3t& x )
	{
		T lenSQ = x.lengthSQ();
		if( isAlmostZero( lenSQ ) ) { zero( x ); return; }
		if( isAlmostSame( lenSQ, (T)1 ) ) { return; }
		T denom = (T)( 1 / sqrt( lenSQ ) );
		multiply( x, denom );
	}

	/**
	* @brief     x = normalize(x)
	* @param     [IN] @b x four dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid normalize( SPVec4t& x )
	{
		T lenSQ = x.lengthSQ();
		if( isAlmostZero( lenSQ ) ) { zero( x ); return; }
		if( isAlmostSame( lenSQ, (T)1 ) ) { return; }
		T denom = (T)( 1 / sqrt( lenSQ ) );
		multiply( x, denom );
	}

	/**
	* @brief     N = normalize(A)
	* @param     [IN] @b N three dimensional vector data
	* @param     [IN] @b A three dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid normalize( SPVec3t& N, const SPVec3t& A )
	{
		T length2 = A.x*A.x + A.y*A.y + A.z*A.z;
		if( isAlmostZero( length2 ) ) {
			zero( N );
			return;
		}
		T denom = (T)( 1 / sqrt( length2 ) );
		multiply( N, denom, A );
	}

	/**
	* @brief     N = normalize(A)
	* @param     [IN] @b N two dimensional vector data
	* @param     [IN] @b A two dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid normalize( SPVec2t& N, const SPVec2t& A )
	{
		T length2 = A.x*A.x + A.y*A.y;
		if( isAlmostZero( length2 ) ) {
			zero( N );
			return;
		}
		T denom = (T)( (T)1 / sqrt( length2 ) );
		multiply( N, denom, A );
	}

	/**
	* @brief     N = (ABxAC)/|ABxAC|
	* @param     [IN] @b N three dimensional vector data
	* @param     [IN] @b A three dimensional vector data
	* @param     [IN] @b B three dimensional vector data
	* @param     [IN] @b C three dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid TriNormal( SPVec3t& N, const SPVec3t& A, const SPVec3t& B, const SPVec3t& C )
	{
		SPVec3t AB;   substract( AB, B, A );
		SPVec3t AC;   substract( AC, C, A );
		cross( N, AB, AC );
		normalize( N );
	}

	/**
	* @brief     Return |A|
	* @param     [IN] @b A two dimensional vector data
	* @return     T
	*/
	template <typename T>
	inline T length( const SPVec2t& A )
	{
		return (T)sqrt( A.x*A.x + A.y*A.y );
	}

	/**
	* @brief     Return |A|
	* @param     [IN] @b A three dimensional vector data
	* @return     T
	*/
	template <typename T>
	inline T length( const SPVec3t& A )
	{
		return (T)sqrt( A.x*A.x + A.y*A.y + A.z*A.z );
	}

	/**
	* @brief     Return |A|
	* @param     [IN] @b A four dimensional vector data
	* @return     T
	*/
	template <typename T>
	inline T length( const SPVec4t& A )
	{
		return (T)sqrt( A.x*A.x + A.y*A.y + A.z*A.z + A.w*A.w );
	}

	/**
	* @brief     Return |A|
	* @param     [IN] @b A two dimensional vector data
	* @return     T
	*/
	template <typename T>
	inline T lengthSquare( const SPVec2t& A )
	{
		return ( A.x*A.x + A.y*A.y );
	}

	/**
	* @brief     Return |A|
	* @param     [IN] @b A three dimensional vector data
	* @return     T
	*/
	template <typename T>
	inline T lengthSquare( const SPVec3t& A )
	{
		return ( A.x*A.x + A.y*A.y + A.z*A.z );
	}

	/**
	* @brief     Return |A|
	* @param     [IN] @b A four dimensional vector data
	* @return     T
	*/
	template <typename T>
	inline T lengthSquare( const SPVec4t& A )
	{
		return ( A.x*A.x + A.y*A.y + A.z*A.z + A.w*A.w );
	}

	/**
	* @brief     Return |A-B|
	* @param     [IN] @b A two dimensional vector data
	* @param     [IN] @b B two dimensional vector data
	* @return     T
	*/
	template <typename T>
	inline T distance( const SPVec2t& A, const SPVec2t& B )
	{
		return sqrt( pow2(A.x-B.x) + pow2(A.y-B.y) );
	}

	/**
	* @brief     Return |A-B|
	* @param     [IN] @b A three dimensional vector data
	* @param     [IN] @b B three dimensional vector data
	* @return     T
	*/
	template <typename T>
	inline T distance( const SPVec3t& A, const SPVec3t& B )
	{
		return sqrt( pow2(A.x-B.x) + pow2(A.y-B.y) + pow2(A.z-B.z) );
	}

	/**
	* @brief     Return |A-B|
	* @param     [IN] @b A four dimensional vector data
	* @param     [IN] @b B four dimensional vector data
	* @return     T
	*/
	template <typename T>
	inline T distance( const SPVec4t& A, const SPVec4t& B )
	{
		return sqrt( pow2(A.x-B.x) + pow2(A.y-B.y) + pow2(A.z-B.z) + pow2(A.w-B.w) );
	}

	/**
	* @brief     Return |A-B|^2
	* @param     [IN] @b A two dimensional vector data
	* @param     [IN] @b B two dimensional vector data
	* @return     T
	*/
	template <typename T>
	inline T distanceSquare( const SPVec2t& A, const SPVec2t& B )
	{
		return ( pow2(A.x-B.x) + pow2(A.y-B.y) );
	}

	/**
	* @brief     Return |A-B|^2
	* @param     [IN] @b A three dimensional vector data
	* @param     [IN] @b B three dimensional vector data
	* @return     T
	*/
	template <typename T>
	inline T distanceSquare( const SPVec3t& A, const SPVec3t& B )
	{
		return ( pow2(A.x-B.x) + pow2(A.y-B.y) + pow2(A.z-B.z) );
	}

	/**
	* @brief     Return |A-B|^2
	* @param     [IN] @b A four dimensional vector data
	* @param     [IN] @b B four dimensional vector data
	* @return     T
	*/
	template <typename T>
	inline T distanceSquare( const SPVec4t& A, const SPVec4t& B )
	{
		return ( pow2(A.x-B.x) + pow2(A.y-B.y) + pow2(A.z-B.z) + pow2(A.w-B.w) );
	}

	/**
	* @brief     angle(radian)=AB & AC
	* @param     [IN] @b AB three dimensional vector data
	* @param     [IN] @b AC three dimensional vector data
	* @return     T
	*/
	template <typename T>
	inline T angle( const SPVec3t& AB, const SPVec3t& AC )
	{
		SPVec3t AB_N;   normalize( AB_N, AB );
		SPVec3t AC_N;   normalize( AC_N, AB );
		T angle = acos( dot( AB_N, AC_N ) );

		if( _isnan(angle) ) { return (T)0; }

		return angle;
	}

	/**
	* @brief     angle(radian)=AB & AC
	* @param     [IN] @b A three dimensional vector data
	* @param     [IN] @b B three dimensional vector data
	* @param     [IN] @b C three dimensional vector data
	* @return     T
	*/
	template <typename T>
	inline T angle( const SPVec3t& A, const SPVec3t& B, const SPVec3t& C )
	{
		SPVec3t AB;   substract( AB, B, A );   normalize( AB );
		SPVec3t AC;   substract( AC, C, A );   normalize( AC );
		T angle = acos( dot( AB, AC ) );

		if( _isnan(angle) ) { return (T)0; }

		return angle;
	}

	/**
	* @brief     angle & rotation on the 2D plane
	* @param     [IN] @b p two dimensional vector data
	* @param     [IN] @b zero2twoPi
	* @return     T
	*/
	template <typename T>
	inline T angle( const SPVec2t& p, SPBool zero2twoPi=SPTRUE )
	{
		T theta;

		T x = p.x;
		T y = p.y;

		if( zero2twoPi ) { // theta = [0,2pi]

			if( isAlmostZero(x) ) {
				if( isAlmostZero(y) ) {
					theta = 0;
				} else {
					theta = PI_2;
					if( y < 0 ) { theta += PI; }
				}
			} else {
				theta = atan(y/x);
				if( x > 0 ) {
					if( y < 0 ) { theta += PI2; }
				} else if( x < 0 ) {
					theta += PI;
				}
			}

		} else { // theta = [-pi,pi]

			if( isAlmostZero(x) ) {
				if( isAlmostZero(y) ) {
					theta = 0;
				} else {
					if( y > 0 ) { theta =  PI_2; }
					else        { theta = -PI_2; }
				}
			} else {
				theta = atan(y/x);
				if( x < 0 ) {
					if( y < 0 ) { theta -= PI; }
					else        { theta += PI; }
				}
			}

		}

		return theta;
	}

	/**
	* @brief     =|ABC|
	* @param     [IN] @b A two dimensional vector data
	* @param     [IN] @b B two dimensional vector data
	* @param     [IN] @b C two dimensional vector data
	* @return     T
	*/
	template <typename T>
	inline T area( const SPVec2t& A, const SPVec2t& B, const SPVec2t& C )
	{
		return (T)( 0.5 * abs( (A.x*B.y+B.x*C.y+C.x*A.y)-(B.x*A.y+C.x*B.y+A.x*C.y) ) );
	}

	/**
	* @brief     =|ABC|
	* @param     [IN] @b A three dimensional vector data
	* @param     [IN] @b B three dimensional vector data
	* @param     [IN] @b C three dimensional vector data
	* @return     T
	*/
	template <typename T>
	inline T area( const SPVec3t& A, const SPVec3t& B, const SPVec3t& C )
	{
		SPVec3t AB;     substract( AB, B, A );
		SPVec3t AC;     substract( AC, C, A );
		SPVec3t cross;  cross( cross, AB, AC );
		return (T)( 0.5 * length(cross) );
	}


	/**
	* @brief     M = 0
	* @param     [IN] @b M two dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid zero( SPMat2x2t& M )
	{
		M[0][0] = M[0][1] = (T)0;
		M[1][0] = M[1][1] = (T)0;
	}

	/**
	* @brief     M = 0
	* @param     [IN] @b M three dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid zero( SPMat3x3t& M )
	{
		M[0][0] = M[0][1] = M[0][2] = (T)0;
		M[1][0] = M[1][1] = M[1][2] = (T)0;
		M[2][0] = M[2][1] = M[2][2] = (T)0;
	}

	/**
	* @brief     M = 0
	* @param     [IN] @b M four dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid zero( SPMat4x4t& M )
	{
		M[0][0] = M[0][1] = M[0][2] = M[0][3] = (T)0;
		M[1][0] = M[1][1] = M[1][2] = M[1][3] = (T)0;
		M[2][0] = M[2][1] = M[2][2] = M[2][3] = (T)0;
		M[3][0] = M[3][1] = M[3][2] = M[3][3] = (T)0;
	}

	/**
	* @brief     M = I
	* @param     [IN] @b M two dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid identity( SPMat2x2t& M )
	{
		M[0][0] = (T)1; M[0][1] = (T)0;
		M[1][0] = (T)0; M[1][1] = (T)1;
	}

	/**
	* @brief     M = I
	* @param     [IN] @b M three dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid identity( SPMat3x3t& M )
	{
		M[0][0] = (T)1; M[0][1] = (T)0; M[0][2] = (T)0;
		M[1][0] = (T)0; M[1][1] = (T)1; M[1][2] = (T)0;
		M[2][0] = (T)0; M[2][1] = (T)0; M[2][2] = (T)1;
	}

	/**
	* @brief     M = I
	* @param     [IN] @b M four dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid identity( SPMat4x4t& M )
	{
		M[0][0] = (T)1; M[0][1] = (T)0; M[0][2] = (T)0; M[0][3] = (T)0;
		M[1][0] = (T)0; M[1][1] = (T)1; M[1][2] = (T)0; M[1][3] = (T)0;
		M[2][0] = (T)0; M[2][1] = (T)0; M[2][2] = (T)1; M[2][3] = (T)0;
		M[3][0] = (T)0; M[3][1] = (T)0; M[3][2] = (T)0; M[3][3] = (T)1;
	}

	/**
	* @brief     A = B + C
	* @param     [IN] @b A two dimensional matrix data
	* @param     [IN] @b B two dimensional matrix data
	* @param     [IN] @b C two dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid add( SPMat2x2t& A, const SPMat2x2t& B, const SPMat2x2t& C )
	{
		A[0][0]=B[0][0]+C[0][0]; A[0][1]=B[0][1]+C[0][1];
		A[1][0]=B[1][0]+C[1][0]; A[1][1]=B[1][1]+C[1][1];
	}

	/**
	* @brief     A = B + C
	* @param     [IN] @b A three dimensional matrix data
	* @param     [IN] @b B three dimensional matrix data
	* @param     [IN] @b C three dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid add( SPMat3x3t& A, const SPMat3x3t& B, const SPMat3x3t& C )
	{
		A[0][0]=B[0][0]+C[0][0]; A[0][1]=B[0][1]+C[0][1]; A[0][2]=B[0][2]+C[0][2];
		A[1][0]=B[1][0]+C[1][0]; A[1][1]=B[1][1]+C[1][1]; A[1][2]=B[1][2]+C[1][2];
		A[2][0]=B[2][0]+C[2][0]; A[2][1]=B[2][1]+C[2][1]; A[2][2]=B[2][2]+C[2][2];
	}

	/**
	* @brief     A = B + C
	* @param     [IN] @b A four dimensional matrix data
	* @param     [IN] @b B four dimensional matrix data
	* @param     [IN] @b C four dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid add( SPMat4x4t& A, const SPMat4x4t& B, const SPMat4x4t& C )
	{
		A[0][0]=B[0][0]+C[0][0]; A[0][1]=B[0][1]+C[0][1]; A[0][2]=B[0][2]+C[0][2]; A[0][3]=B[0][3]+C[0][3];
		A[1][0]=B[1][0]+C[1][0]; A[1][1]=B[1][1]+C[1][1]; A[1][2]=B[1][2]+C[1][2]; A[1][3]=B[1][3]+C[1][3];
		A[2][0]=B[2][0]+C[2][0]; A[2][1]=B[2][1]+C[2][1]; A[2][2]=B[2][2]+C[2][2]; A[2][3]=B[2][3]+C[2][3];
		A[3][0]=B[3][0]+C[3][0]; A[3][1]=B[3][1]+C[3][1]; A[3][2]=B[3][2]+C[3][2]; A[3][3]=B[3][3]+C[3][3];
	}

	/**
	* @brief     A = B - C
	* @param     [IN] @b A two dimensional matrix data
	* @param     [IN] @b B two dimensional matrix data
	* @param     [IN] @b C two dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid substract( SPMat2x2t& A, const SPMat2x2t& B, const SPMat2x2t& C )
	{
		A[0][0]=B[0][0]-C[0][0]; A[0][1]=B[0][1]-C[0][1];
		A[1][0]=B[1][0]-C[1][0]; A[1][1]=B[1][1]-C[1][1];
	}

	/**
	* @brief     A = B - C
	* @param     [IN] @b A three dimensional matrix data
	* @param     [IN] @b B three dimensional matrix data
	* @param     [IN] @b C three dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid substract( SPMat3x3t& A, const SPMat3x3t& B, const SPMat3x3t& C )
	{
		A[0][0]=B[0][0]-C[0][0]; A[0][1]=B[0][1]-C[0][1]; A[0][2]=B[0][2]-C[0][2];
		A[1][0]=B[1][0]-C[1][0]; A[1][1]=B[1][1]-C[1][1]; A[1][2]=B[1][2]-C[1][2];
		A[2][0]=B[2][0]-C[2][0]; A[2][1]=B[2][1]-C[2][1]; A[2][2]=B[2][2]-C[2][2];
	}

	/**
	* @brief     A = B - C
	* @param     [IN] @b A four dimensional matrix data
	* @param     [IN] @b B four dimensional matrix data
	* @param     [IN] @b C four dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid substract( SPMat4x4t& A, const SPMat4x4t& B, const SPMat4x4t& C )
	{
		A[0][0]=B[0][0]-C[0][0]; A[0][1]=B[0][1]-C[0][1]; A[0][2]=B[0][2]-C[0][2]; A[0][3]=B[0][3]-C[0][3];
		A[1][0]=B[1][0]-C[1][0]; A[1][1]=B[1][1]-C[1][1]; A[1][2]=B[1][2]-C[1][2]; A[1][3]=B[1][3]-C[1][3];
		A[2][0]=B[2][0]-C[2][0]; A[2][1]=B[2][1]-C[2][1]; A[2][2]=B[2][2]-C[2][2]; A[2][3]=B[2][3]-C[2][3];
		A[3][0]=B[3][0]-C[3][0]; A[3][1]=B[3][1]-C[3][1]; A[3][2]=B[3][2]-C[3][2]; A[3][3]=B[3][3]-C[3][3];
	}

	/**
	* @brief     A += B
	* @param     [IN] @b A two dimensional matrix data
	* @param     [IN] @b B two dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid increase( SPMat2x2t& A, const SPMat2x2t& B )
	{
		A[0][0]+=B[0][0]; A[0][1]+=B[0][1];
		A[1][0]+=B[1][0]; A[1][1]+=B[1][1];
	}

	/**
	* @brief     A += B
	* @param     [IN] @b A three dimensional matrix data
	* @param     [IN] @b B three dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid increase( SPMat3x3t& A, const SPMat3x3t& B )
	{
		A[0][0]+=B[0][0]; A[0][1]+=B[0][1]; A[0][2]+=B[0][2];
		A[1][0]+=B[1][0]; A[1][1]+=B[1][1]; A[1][2]+=B[1][2];
		A[2][0]+=B[2][0]; A[2][1]+=B[2][1]; A[2][2]+=B[2][2];
	}

	/**
	* @brief     A += B
	* @param     [IN] @b A four dimensional matrix data
	* @param     [IN] @b B four dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid increase( SPMat4x4t& A, const SPMat4x4t& B )
	{
		A[0][0]+=B[0][0]; A[0][1]+=B[0][1]; A[0][2]+=B[0][2]; A[0][3]+=B[0][3];
		A[1][0]+=B[1][0]; A[1][1]+=B[1][1]; A[1][2]+=B[1][2]; A[1][3]+=B[1][3];
		A[2][0]+=B[2][0]; A[2][1]+=B[2][1]; A[2][2]+=B[2][2]; A[2][3]+=B[2][3];
		A[3][0]+=B[3][0]; A[3][1]+=B[3][1]; A[3][2]+=B[3][2]; A[3][3]+=B[3][3];
	}

	/**
	* @brief     A -= B
	* @param     [IN] @b A two dimensional matrix data
	* @param     [IN] @b B two dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid decrease( SPMat2x2t& A, const SPMat2x2t& B )
	{
		A[0][0]-=B[0][0]; A[0][1]-=B[0][1];
		A[1][0]-=B[1][0]; A[1][1]-=B[1][1];
	}

	/**
	* @brief     A -= B
	* @param     [IN] @b A three dimensional matrix data
	* @param     [IN] @b B three dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid decrease( SPMat3x3t& A, const SPMat3x3t& B )
	{
		A[0][0]-=B[0][0]; A[0][1]-=B[0][1]; A[0][2]-=B[0][2];
		A[1][0]-=B[1][0]; A[1][1]-=B[1][1]; A[1][2]-=B[1][2];
		A[2][0]-=B[2][0]; A[2][1]-=B[2][1]; A[2][2]-=B[2][2];
	}

	/**
	* @brief     A -= B
	* @param     [IN] @b A four dimensional matrix data
	* @param     [IN] @b B four dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid decrease( SPMat4x4t& A, const SPMat4x4t& B )
	{
		A[0][0]-=B[0][0]; A[0][1]-=B[0][1]; A[0][2]-=B[0][2]; A[0][3]-=B[0][3];
		A[1][0]-=B[1][0]; A[1][1]-=B[1][1]; A[1][2]-=B[1][2]; A[1][3]-=B[1][3];
		A[2][0]-=B[2][0]; A[2][1]-=B[2][1]; A[2][2]-=B[2][2]; A[2][3]-=B[2][3];
		A[3][0]-=B[3][0]; A[3][1]-=B[3][1]; A[3][2]-=B[3][2]; A[3][3]-=B[3][3];
	}

	/**
	* @brief     -A
	* @param     [IN] @b A two dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid negative( SPMat2x2t& A )
	{
		A[0][0]=-A[0][0]; A[0][1]=-A[0][1];
		A[1][0]=-A[1][0]; A[1][1]=-A[1][1];
	}

	/**
	* @brief     -A
	* @param     [IN] @b A three dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid negative( SPMat3x3t& A )
	{
		A[0][0]=-A[0][0]; A[0][1]=-A[0][1]; A[0][2]=-A[0][2];
		A[1][0]=-A[1][0]; A[1][1]=-A[1][1]; A[1][2]=-A[1][2];
		A[2][0]=-A[2][0]; A[2][1]=-A[2][1]; A[2][2]=-A[2][2];
	}

	/**
	* @brief     -A
	* @param     [IN] @b A four dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid negative( SPMat4x4t& A )
	{
		A[0][0]=-A[0][0]; A[0][1]=-A[0][1]; A[0][2]=-A[0][2]; A[0][3]=-A[0][3];
		A[1][0]=-A[1][0]; A[1][1]=-A[1][1]; A[1][2]=-A[1][2]; A[1][3]=-A[1][3];
		A[2][0]=-A[2][0]; A[2][1]=-A[2][1]; A[2][2]=-A[2][2]; A[2][3]=-A[2][3];
		A[3][0]=-A[3][0]; A[3][1]=-A[3][1]; A[3][2]=-A[3][2]; A[3][3]=-A[3][3];
	}

	/**
	* @brief     
	* @param     [IN] @b A two dimensional matrix data
	* @param     [IN] @b B two dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid copy( SPMat2x2t& A, const SPMat2x2t& B )
	{
		A[0][0]=B[0][0]; A[0][1]=B[0][1];
		A[1][0]=B[1][0]; A[1][1]=B[1][1];
	}

	/**
	* @brief     A = B
	* @param     [IN] @b A three dimensional matrix data
	* @param     [IN] @b B three dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid copy( SPMat3x3t& A, const SPMat3x3t& B )
	{
		A[0][0]=B[0][0]; A[0][1]=B[0][1]; A[0][2]=B[0][2];
		A[1][0]=B[1][0]; A[1][1]=B[1][1]; A[1][2]=B[1][2];
		A[2][0]=B[2][0]; A[2][1]=B[2][1]; A[2][2]=B[2][2];
	}

	/**
	* @brief     A = B
	* @param     [IN] @b A four dimensional matrix data
	* @param     [IN] @b B four dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid copy( SPMat4x4t& A, const SPMat4x4t& B )
	{
		A[0][0]=B[0][0]; A[0][1]=B[0][1]; A[0][2]=B[0][2]; A[0][3]=B[0][3];
		A[1][0]=B[1][0]; A[1][1]=B[1][1]; A[1][2]=B[1][2]; A[1][3]=B[1][3];
		A[2][0]=B[2][0]; A[2][1]=B[2][1]; A[2][2]=B[2][2]; A[2][3]=B[2][3];
		A[3][0]=B[3][0]; A[3][1]=B[3][1]; A[3][2]=B[3][2]; A[3][3]=B[3][3];
	}

	/**
	* @brief     A = B
	* @param     [IN] @b A three dimensional matrix data
	* @param     [IN] @b B three dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid copy( SPMat3x3t& A, const SPMat4x4t& B )
	{
		A[0][0]=B[0][0]; A[0][1]=B[0][1]; A[0][2]=B[0][2];
		A[1][0]=B[1][0]; A[1][1]=B[1][1]; A[1][2]=B[1][2];
		A[2][0]=B[2][0]; A[2][1]=B[2][1]; A[2][2]=B[2][2];
	}

	/**
	* @brief     A = B^T
	* @param     [IN] @b A two dimensional matrix data
	* @param     [IN] @b B two dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid transpose( SPMat2x2t& A, const SPMat2x2t& B )
	{
		A[0][0]=B[0][0]; A[0][1]=B[1][0];
		A[1][0]=B[0][1]; A[1][1]=B[1][1];
	}

	/**
	* @brief     A = B^T
	* @param     [IN] @b A three dimensional matrix data
	* @param     [IN] @b B three dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid transpose( SPMat3x3t& A, const SPMat3x3t& B )
	{
		A[0][0]=B[0][0]; A[0][1]=B[1][0]; A[0][2]=B[2][0];
		A[1][0]=B[0][1]; A[1][1]=B[1][1]; A[1][2]=B[2][1];
		A[2][0]=B[0][2]; A[2][1]=B[1][2]; A[2][2]=B[2][2];
	}

	/**
	* @brief     A = B^T
	* @param     [IN] @b A four dimensional matrix data
	* @param     [IN] @b B four dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid transpose( SPMat4x4t& A, const SPMat4x4t& B )
	{
		A[0][0]=B[0][0]; A[0][1]=B[1][0]; A[0][2]=B[2][0]; A[0][3]=B[3][0];
		A[1][0]=B[0][1]; A[1][1]=B[1][1]; A[1][2]=B[2][1]; A[1][3]=B[3][1];
		A[2][0]=B[0][2]; A[2][1]=B[1][2]; A[2][2]=B[2][2]; A[2][3]=B[3][2];
		A[3][0]=B[0][3]; A[3][1]=B[1][3]; A[3][2]=B[2][3]; A[3][3]=B[3][3];
	}

	/**
	* @brief     A^T
	* @param     [IN] @b A two dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid transpose( SPMat2x2t& A )
	{
		SPMat2x2t B;
		copy(B,A);
		transpose(A,B);
	}

	/**
	* @brief     A^T
	* @param     [IN] @b A three dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid transpose( SPMat3x3t& A )
	{
		SPMat3x3t B;
		copy(B,A);
		transpose(A,B);
	}

	/**
	* @brief     A^T
	* @param     [IN] @b A four dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid transpose( SPMat4x4t& A )
	{
		SPMat4x4t B;
		copy(B,A);
		transpose(A,B);
	}

	/**
	* @brief     b = Ax
	* @param     [IN] @b b two dimensional matrix data
	* @param     [IN] @b A two dimensional matrix data
	* @param     [IN] @b x two dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid multiply( SPVec2t& b, const SPMat2x2t& A, const SPVec2t& x )
	{
		b.x=A[0][0]*x.x+A[0][1]*x.y;
		b.y=A[1][0]*x.x+A[1][1]*x.y;
	}

	/**
	* @brief     b = Ax
	* @param     [IN] @b b three dimensional matrix data
	* @param     [IN] @b A three dimensional matrix data
	* @param     [IN] @b x three dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid multiply( SPVec3t& b, const SPMat3x3t& A, const SPVec3t& x )
	{
		b.x=A[0][0]*x.x+A[0][1]*x.y+A[0][2]*x.z;
		b.y=A[1][0]*x.x+A[1][1]*x.y+A[1][2]*x.z;
		b.z=A[2][0]*x.x+A[2][1]*x.y+A[2][2]*x.z;
	}

	/**
	* @brief     b = Ax
	* @param     [IN] @b b four dimensional matrix data
	* @param     [IN] @b A four dimensional matrix data
	* @param     [IN] @b x four dimensional vector data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid multiply( SPVec4t& b, const SPMat4x4t& A, const SPVec4t& x )
	{
		b.x=A[0][0]*x.x+A[0][1]*x.y+A[0][2]*x.z+A[0][3]*x.w;
		b.y=A[1][0]*x.x+A[1][1]*x.y+A[1][2]*x.z+A[1][3]*x.w;
		b.z=A[2][0]*x.x+A[2][1]*x.y+A[2][2]*x.z+A[2][3]*x.w;
		b.w=A[3][0]*x.x+A[3][1]*x.y+A[3][2]*x.z+A[3][3]*x.w;
	}

	/**
	* @brief     b = (A^t)*x
	* @param     [IN] @b A three dimensional matrix data
	* @param     [IN] @b x three dimensional vector data
	* @return     SPVec3t
	*/
	template <typename T>
	inline SPVoid multiplyTransposed( SPVec4t& b, const SPMat4x4t& A, const SPVec4t& x )
	{
		b.x=A[0][0]*x.x+A[1][0]*x.y+A[2][0]*x.z+A[3][0]*x.w;
		b.y=A[0][1]*x.x+A[1][1]*x.y+A[2][1]*x.z+A[3][1]*x.w;
		b.z=A[0][2]*x.x+A[1][2]*x.y+A[2][2]*x.z+A[3][2]*x.w;
		b.w=A[0][3]*x.x+A[1][3]*x.y+A[2][3]*x.z+A[3][3]*x.w;
	}

	/**
	* @brief     b = Ax
	* @param     [IN] @b A two dimensional matrix data
	* @param     [IN] @b x two dimensional vector data
	* @return     SPVec2t
	*/
	template <typename T>
	inline SPVec2t multiply( const SPMat2x2t& A, const SPVec2t& x )
	{
		SPVec2t b;
		b.x=A[0][0]*x.x+A[0][1]*x.y;
		b.y=A[1][0]*x.x+A[1][1]*x.y;

		return b;
	}

	/**
	* @brief     b = Ax
	* @param     [IN] @b A three dimensional matrix data
	* @param     [IN] @b x three dimensional vector data
	* @return     SPVec3t
	*/
	template <typename T>
	inline SPVec3t multiply( const SPMat3x3t& A, const SPVec3t& x )
	{
		SPVec3t b;
		b.x=A[0][0]*x.x+A[0][1]*x.y+A[0][2]*x.z;
		b.y=A[1][0]*x.x+A[1][1]*x.y+A[1][2]*x.z;
		b.z=A[2][0]*x.x+A[2][1]*x.y+A[2][2]*x.z;
		return b;
	}

	/**
	* @brief     b = Ax
	* @param     [IN] @b A four dimensional matrix data
	* @param     [IN] @b x four dimensional vector data
	* @return     SPVec4t
	*/
	template <typename T>
	inline SPVec4t multiply( const SPMat4x4t& A, const SPVec4t& x )
	{
		SPVec4t b;
		b.x=A[0][0]*x.x+A[0][1]*x.y+A[0][2]*x.z+A[0][3]*x.w;
		b.y=A[1][0]*x.x+A[1][1]*x.y+A[1][2]*x.z+A[1][3]*x.w;
		b.z=A[2][0]*x.x+A[2][1]*x.y+A[2][2]*x.z+A[2][3]*x.w;
		b.w=A[3][0]*x.x+A[3][1]*x.y+A[3][2]*x.z+A[3][3]*x.w;
		return b;
	}

	/**
	* @brief     A = alpha*B
	* @param     [IN] @b A two dimensional matrix data
	* @param     [IN] @b alpha 
	* @param     [IN] @b B two dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid multiply( SPMat2x2t& A, const T& alpha, const SPMat2x2t& B )
	{
		A[0][0]=alpha*B[0][0]; A[0][1]=alpha*B[0][1];
		A[1][0]=alpha*B[1][0]; A[1][1]=alpha*B[1][1];
	}

	/**
	* @brief     A = alpha*B
	* @param     [IN] @b A three dimensional matrix data
	* @param     [IN] @b alpha
	* @param     [IN] @b B three dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid multiply( SPMat3x3t& A, const T& alpha, const SPMat3x3t& B )
	{
		A[0][0]=alpha*B[0][0]; A[0][1]=alpha*B[0][1]; A[0][2]=alpha*B[0][2];
		A[1][0]=alpha*B[1][0]; A[1][1]=alpha*B[1][1]; A[1][2]=alpha*B[1][2];
		A[2][0]=alpha*B[2][0]; A[2][1]=alpha*B[2][1]; A[2][2]=alpha*B[2][2];
	}

	/**
	* @brief     A = alpha*B
	* @param     [IN] @b A four dimensional matrix data
	* @param     [IN] @b alpha
	* @param     [IN] @b B four dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid multiply( SPMat4x4t& A, const T& alpha, const SPMat4x4t& B )
	{
		A[0][0]=alpha*B[0][0]; A[0][1]=alpha*B[0][1]; A[0][2]=alpha*B[0][2]; A[0][3]=alpha*B[0][2];
		A[1][0]=alpha*B[1][0]; A[1][1]=alpha*B[1][1]; A[1][2]=alpha*B[1][2]; A[1][3]=alpha*B[1][2];
		A[2][0]=alpha*B[2][0]; A[2][1]=alpha*B[2][1]; A[2][2]=alpha*B[2][2]; A[2][3]=alpha*B[2][2];
		A[3][0]=alpha*B[3][0]; A[3][1]=alpha*B[3][1]; A[3][2]=alpha*B[3][2]; A[3][3]=alpha*B[3][2];
	}

	/**
	* @brief     A *= alpha
	* @param     [IN] @b A two dimensional matrix data
	* @param     [IN] @b alpha
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid multiply( SPMat2x2t& A, const T& alpha )
	{
		A[0][0]*=alpha; A[0][1]*=alpha;
		A[1][0]*=alpha; A[1][1]*=alpha;
	}

	/**
	* @brief     A *= alpha
	* @param     [IN] @b A three dimensional matrix data
	* @param     [IN] @b alpha
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid multiply( SPMat3x3t& A, const T& alpha )
	{
		A[0][0]*=alpha; A[0][1]*=alpha; A[0][2]*=alpha;
		A[1][0]*=alpha; A[1][1]*=alpha; A[1][2]*=alpha;
		A[2][0]*=alpha; A[2][1]*=alpha;	A[2][2]*=alpha;
	}

	/**
	* @brief     A *= alpha
	* @param     [IN] @b A four dimensional matrix data
	* @param     [IN] @b alpha
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid multiply( SPMat4x4t& A, const T& alpha )
	{
		A[0][0]*=alpha; A[0][1]*=alpha; A[0][2]*=alpha; A[0][3]*=alpha;
		A[1][0]*=alpha; A[1][1]*=alpha; A[1][2]*=alpha; A[1][3]*=alpha;
		A[2][0]*=alpha; A[2][1]*=alpha;	A[2][2]*=alpha; A[2][3]*=alpha;
		A[3][0]*=alpha; A[3][1]*=alpha;	A[3][2]*=alpha; A[3][3]*=alpha;
	}

	/**
	* @brief     A = B * C
	* @param     [IN] @b A two dimensional matrix data
	* @param     [IN] @b B two dimensional matrix data
	* @param     [IN] @b C two dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid multiply( SPMat2x2t& A, const SPMat2x2t& B, const SPMat2x2t& C )
	{
		A[0][0]=B[0][0]*C[0][0]+B[0][1]*C[1][0];
		A[0][1]=B[0][0]*C[0][1]+B[0][1]*C[1][1];

		A[1][0]=B[1][0]*C[0][0]+B[1][1]*C[1][0];
		A[1][1]=B[1][0]*C[0][1]+B[1][1]*C[1][1];
	}

	/**
	* @brief     A = B * C
	* @param     [IN] @b A three dimensional matrix data
	* @param     [IN] @b B three dimensional matrix data
	* @param     [IN] @b C three dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid multiply( SPMat3x3t& A, const SPMat3x3t& B, const SPMat3x3t& C )
	{
		A[0][0]=B[0][0]*C[0][0]+B[0][1]*C[1][0]+B[0][2]*C[2][0];
		A[0][1]=B[0][0]*C[0][1]+B[0][1]*C[1][1]+B[0][2]*C[2][1];
		A[0][2]=B[0][0]*C[0][2]+B[0][1]*C[1][2]+B[0][2]*C[2][2];

		A[1][0]=B[1][0]*C[0][0]+B[1][1]*C[1][0]+B[1][2]*C[2][0];
		A[1][1]=B[1][0]*C[0][1]+B[1][1]*C[1][1]+B[1][2]*C[2][1];
		A[1][2]=B[1][0]*C[0][2]+B[1][1]*C[1][2]+B[1][2]*C[2][2];

		A[2][0]=B[2][0]*C[0][0]+B[2][1]*C[1][0]+B[2][2]*C[2][0];
		A[2][1]=B[2][0]*C[0][1]+B[2][1]*C[1][1]+B[2][2]*C[2][1];
		A[2][2]=B[2][0]*C[0][2]+B[2][1]*C[1][2]+B[2][2]*C[2][2];
	}

	/**
	* @brief     A = B * C
	* @param     [IN] @b B three dimensional matrix data
	* @param     [IN] @b C three dimensional matrix data
	* @return     SPMat3x3t
	*/
	template <typename T>
	inline SPMat3x3t multiply( const SPMat3x3t& B, const SPMat3x3t& C )
	{
		SPMat3x3t A;
		A[0][0]=B[0][0]*C[0][0]+B[0][1]*C[1][0]+B[0][2]*C[2][0];
		A[0][1]=B[0][0]*C[0][1]+B[0][1]*C[1][1]+B[0][2]*C[2][1];
		A[0][2]=B[0][0]*C[0][2]+B[0][1]*C[1][2]+B[0][2]*C[2][2];

		A[1][0]=B[1][0]*C[0][0]+B[1][1]*C[1][0]+B[1][2]*C[2][0];
		A[1][1]=B[1][0]*C[0][1]+B[1][1]*C[1][1]+B[1][2]*C[2][1];
		A[1][2]=B[1][0]*C[0][2]+B[1][1]*C[1][2]+B[1][2]*C[2][2];

		A[2][0]=B[2][0]*C[0][0]+B[2][1]*C[1][0]+B[2][2]*C[2][0];
		A[2][1]=B[2][0]*C[0][1]+B[2][1]*C[1][1]+B[2][2]*C[2][1];
		A[2][2]=B[2][0]*C[0][2]+B[2][1]*C[1][2]+B[2][2]*C[2][2];
		return A;
	}

	/**
	* @brief     A = B * C
	* @param     [IN] @b A four dimensional matrix data
	* @param     [IN] @b B four dimensional matrix data
	* @param     [IN] @b C four dimensional matrix data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid multiply( SPMat4x4t& A, const SPMat4x4t& B, const SPMat4x4t& C )
	{
		A[0][0]=B[0][0]*C[0][0]+B[0][1]*C[1][0]+B[0][2]*C[2][0]+B[0][3]*C[3][0];
		A[0][1]=B[0][0]*C[0][1]+B[0][1]*C[1][1]+B[0][2]*C[2][1]+B[0][3]*C[3][1];
		A[0][2]=B[0][0]*C[0][2]+B[0][1]*C[1][2]+B[0][2]*C[2][2]+B[0][3]*C[3][2];
		A[0][3]=B[0][0]*C[0][3]+B[0][1]*C[1][3]+B[0][2]*C[2][3]+B[0][3]*C[3][3];

		A[1][0]=B[1][0]*C[0][0]+B[1][1]*C[1][0]+B[1][2]*C[2][0]+B[1][3]*C[3][0];
		A[1][1]=B[1][0]*C[0][1]+B[1][1]*C[1][1]+B[1][2]*C[2][1]+B[1][3]*C[3][1];
		A[1][2]=B[1][0]*C[0][2]+B[1][1]*C[1][2]+B[1][2]*C[2][2]+B[1][3]*C[3][2];
		A[1][3]=B[1][0]*C[0][3]+B[1][1]*C[1][3]+B[1][2]*C[2][3]+B[1][3]*C[3][3];

		A[2][0]=B[2][0]*C[0][0]+B[2][1]*C[1][0]+B[2][2]*C[2][0]+B[2][3]*C[3][0];
		A[2][1]=B[2][0]*C[0][1]+B[2][1]*C[1][1]+B[2][2]*C[2][1]+B[2][3]*C[3][1];
		A[2][2]=B[2][0]*C[0][2]+B[2][1]*C[1][2]+B[2][2]*C[2][2]+B[2][3]*C[3][2];
		A[2][3]=B[2][0]*C[0][3]+B[2][1]*C[1][3]+B[2][2]*C[2][3]+B[2][3]*C[3][3];

		A[3][0]=B[3][0]*C[0][0]+B[3][1]*C[1][0]+B[3][2]*C[2][0]+B[3][3]*C[3][0];
		A[3][1]=B[3][0]*C[0][1]+B[3][1]*C[1][1]+B[3][2]*C[2][1]+B[3][3]*C[3][1];
		A[3][2]=B[3][0]*C[0][2]+B[3][1]*C[1][2]+B[3][2]*C[2][2]+B[3][3]*C[3][2];
		A[3][3]=B[3][0]*C[0][3]+B[3][1]*C[1][3]+B[3][2]*C[2][3]+B[3][3]*C[3][3];
	}

	/**
	* @brief     Calculate the matrix of Outer Product
	* @param     [IN] @b u four dimensional vector data
	* @param     [IN] @b v four dimensional vector data
	* @return     SPMat3x3t
	*/
	template <typename T>
	inline SPMat3x3t matrixOuterProduct(const SPVec3t &u, const SPVec3t &v)
	{
		return SPMat3x3t(
			u.x*v.x, u.x*v.y, u.x*v.z,
			u.y*v.x, u.y*v.y, u.y*v.z,
			u.z*v.x, u.z*v.y, u.z*v.z );
	}
}

#endif //_SP_OPERATIONS_H_

