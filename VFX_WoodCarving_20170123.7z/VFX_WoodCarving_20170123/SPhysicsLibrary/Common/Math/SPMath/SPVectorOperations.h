/**
* @file SPVectorOperations.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_VECTOR_OPERATION_H_
#define _SP_VECTOR_OPERATION_H_

#include "SPDefines.h"

namespace SPhysics
{

	/**
	* @brief     Set all data of array to Zero
	* @param     [IN] @b x data of array
	* @param     [IN] @b n size of data
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid zero( T*& x, const SPInt& n )
	{
		for(SPInt i=0;i<n;++i) x[i]=(T)0;
	}

	/**
	* @brief     a = b + c
	* @param     [IN] @b a result
	* @param     [IN] @b b add variable 1
	* @param     [IN] @b c add variable 2
	* @param     [IN] @b n size of data
	* @return     SPVoid
	*/
	template <typename T>
	SPVoid add( T*& a, const T*& b, const T*& c, const SPInt& n )
	{
		for( SPInt i=0; i<n; ++i ) {
			a[i] = b[i] + c[i];
		}
	}

	/**
	* @brief     a = b + c ( add operation for omp parallel )
	* @param     [IN] @b a result
	* @param     [IN] @b b add variable 1
	* @param     [IN] @b c add variable 2
	* @param     [IN] @b n size of data
	* @return     SPVoid
	*/
	template <typename T>
	SPVoid add_omp( T*& a, const T*& b, const T*& c, const SPInt& n )
	{
		#pragma omp parallel for
		for( SPInt i=0; i<n; ++i )
		{
			a[i] = b[i] + c[i];
		}
	}

	/**
	* @brief     a += b
	* @param     [IN] @b a result 
	* @param     [IN] @b b increased variable
	* @param     [IN] @b n size of data
	* @return     SPVoid
	*/
	template <typename T>
	SPVoid increase( T*& a, const T*& b, const SPInt& n )
	{
		for( SPInt i=0; i<n; ++i )
		{
			a[i] += b[i];
		}
	}

	/**
	* @brief     a += b ( increase for omp parallel )
	* @param     [IN] @b a result 
	* @param     [IN] @b b increased variable
	* @param     [IN] @b n size of data
	* @return     SPVoid
	*/
	template <typename T>
	SPVoid increase_omp( T*& a, const T*& b, const SPInt& n )
	{
		#pragma omp parallel for
		for( SPInt i=0; i<n; ++i )
		{
			a[i] += b[i];
		}
	}

	/**
	* @brief     a += alpha
	* @param     [IN] @b a result 
	* @param     [IN] @b alpha increased variable
	* @param     [IN] @b n size of data
	* @return     SPVoid
	*/
	template <typename T>
	SPVoid increase( T*& a, const T& alpha, const SPInt& n )
	{
		for( SPInt i=0; i<n; ++i )
		{
			a[i] += alpha;
		}
	}

	/**
	* @brief     a += alpha , for omp parallel
	* @param     [IN] @b a result 
	* @param     [IN] @b alpha increased variable
	* @param     [IN] @b n size of data
	* @return     SPVoid
	*/
	template <typename T>
	SPVoid increase_omp( T*& a, const T& alpha, const SPInt& n )
	{
		#pragma omp parallel for
		for( SPInt i=0; i<n; ++i )
		{
			a[i] += alpha;
		}
	}

	/**
	* @brief     a = b - c
	* @param     [IN] @b a result 
	* @param     [IN] @b b minus value 1
	* @param     [IN] @b c minus value 2
	* @param     [IN] @b n size of data
	* @return     SPVoid
	*/
	template <typename T>
	SPVoid substract( T*& a, T*& b, T*& c, const SPInt& n )
	{
		for( SPInt i=0; i<n; ++i )
		{
			a[i] = b[i] - c[i];
		}
	}

	/**
	* @brief     a = b - c , for omp parallel
	* @param     [IN] @b a result 
	* @param     [IN] @b b minus value 1
	* @param     [IN] @b c minus value 2
	* @param     [IN] @b n size of data
	* @return     SPVoid
	*/
	template <typename T>
	SPVoid subtract_omp( T*& a, T*& b, T*& c, const SPInt& n )
	{
		#pragma omp parallel for
		for( SPInt i=0; i<n; ++i )
		{
			a[i] = b[i] - c[i];
		}
	}

	/**
	* @brief     a -= b
	* @param     [IN] @b a result 
	* @param     [IN] @b b  decreased value 
	* @param     [IN] @b n size of data
	* @return     SPVoid
	*/
	template <typename T>
	SPVoid decrease( T*& a, T*& b, const SPInt& n )
	{
		for( SPInt i=0; i<n; ++i )
		{
			a[i] -= b[i];
		}
	}

	/**
	* @brief     a -= b , for omp parallel
	* @param     [IN] @b a result 
	* @param     [IN] @b b  decreased
	* @param     [IN] @b n size of data
	* @return     SPVoid
	*/
	template <typename T>
	SPVoid decrease_omp( T*& a, T*& b, const SPInt& n )
	{
		#pragma omp parallel for
		for( SPInt i=0; i<n; ++i )
		{
			a[i] -= b[i];
		}
	}

	/**
	* @brief     a -= alpha
	* @param     [IN] @b a result 
	* @param     [IN] @b alpha  decreased
	* @param     [IN] @b n size of data
	* @return     SPVoid
	*/
	template <typename T>
	SPVoid decrease( T*& a, const T& alpha, const SPInt& n )
	{
		for( SPInt i=0; i<n; ++i )
		{
			a[i] -= alpha;
		}
	}

	/**
	* @brief     a -= alpha ( decrease for omp parallel )
	* @param     [IN] @b a result 
	* @param     [IN] @b alpha  decreased
	* @param     [IN] @b n size of data
	* @return     SPVoid
	*/
	template <typename T>
	SPVoid decrease_omp( T*& a, const T& alpha, const SPInt& n )
	{
		#pragma omp parallel for
		for( SPInt i=0; i<n; ++i )
		{
			a[i] -= alpha;
		}
	}

	/**
	* @brief     x += a * z
	* @param     [IN] @b x result 
	* @param     [IN] @b a value 1
	* @param     [IN] @b z value 2
	* @param     [IN] @b n size of data
	* @return     SPVoid
	*/
	template <typename T>
	SPVoid addMultiply( T*& x, T a, T*&z, const SPInt& n )
	{
		for( SPInt i=0; i<n; ++i )
		{
			x[i] += a * z[i];
		}
	}

	/**
	* @brief     x += a * z ( for omp parallel )
	* @param     [IN] @b x result 
	* @param     [IN] @b a  value 1
	* @param     [IN] @b z value 2
	* @param     [IN] @b n size of data
	* @return     SPVoid
	*/
	template <typename T>
	SPVoid addMultiply_omp( T*& x, const T& a, T*&z, const SPInt& n )
	{
		#pragma omp parallel for
		for( SPInt i=0; i<n; ++i )
		{
			x[i] += a * z[i];
		}
	}

	/**
	* @brief     x += a * y + z
	* @param     [IN] @b x result 
	* @param     [IN] @b a  value 1
	* @param     [IN] @b y value 2
	* @param     [IN] @b z value 3
	* @param     [IN] @b n size of data
	* @return     SPVoid
	*/
	template <typename T>
	SPVoid addMultiply( T*& x, T a, T*& y, T*& z, const SPInt& n )
	{
		for( SPInt i=0; i<n; ++i )
		{
			x[i] = a * y[i] + z[i];
		}
	}

	/**
	* @brief     x += a * y + z ( for omp parallel  )
	* @param     [IN] @b x result
	* @param     [IN] @b a value 1
	* @param     [IN] @b y value 2
	* @param     [IN] @b z value 3
	* @param     [IN] @b n size of data
	* @return     SPVoid
	*/
	template <typename T>
	SPVoid addMultiply_omp( T*& x, T a, T*& y, T*& z, const SPInt& n )
	{
		#pragma omp parallel for
		for( SPInt i=0; i<n; ++i )
		{
			x[i] = a * y[i] + z[i];
		}
	}

	/**
	* @brief     Calculate inner product
	* @param     [IN] @b a dot value 1
	* @param     [IN] @b b dot value 2
	* @param     [IN] @b n size of data
	* @return     T
	*/
	template <typename T>
	T dot( T*& a, T*& b, const SPInt& n )
	{
		T sum = 0;
		for( SPInt i=0; i<n; ++i )
		{
			sum += a[i] * b[i];
		}
		return sum;
	}

	/**
	* @brief     inner product ( for omp parallel )
	* @param     [IN] @b a dot_omp value 1
	* @param     [IN] @b b dot_omp value 1
	* @param     [IN] @b n size of data
	* @return     T
	*/
	template <typename T>
	T dot_omp( T*& a, T*& b, const SPInt& n )
	{
		T sum = 0;
		#pragma omp parallel for reduction(+:sum)
		for( SPInt i=0; i<n; ++i )
		{
			sum = sum + a[i] * b[i];
		}
		return sum;
	}

	/**
	* @brief     Summerize all data
	* @param     [IN] @b a sum result 
	* @param     [IN] @b n size of data
	* @return     T
	*/
	template <typename T>
	T sum( T*& a, const SPInt& n )
	{
		T sum = 0;
		for( SPInt i=0; i<n; ++i )
		{
			sum += a[i];
		}
		return sum;
	}

	/**
	* @brief     Summation ( for omp parallel )
	* @param     [IN] @b a sum_omp result 
	* @param     [IN] @b n size of data
	* @return     T
	*/
	template <typename T>
	T sum_omp( T*& a, const SPInt& n )
	{
		T sum = 0;
		#pragma omp parallel for reduction(+:sum)
		for( SPInt i=0; i<n; ++i )
		{
			sum = sum + a[i];
		}
		return sum;
	}

	//////////////////
	// infinit norm //
	//template <typename T>
	//T INFNORM( T*& a, const SPInt& n )
	//{
	//	T infnorm = -LARGE;
	//	for( SPInt i=0; i<n; ++i )
	//	{
	//		infnorm = maximum( infnorm, abs(a[i]) );
	//	}
	//	return infnorm;
	//}

}

#endif //_SP_VECTOR_OPERATION_H_

