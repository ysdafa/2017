/**
* @file SPTest.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_TEST_H_
#define _SP_TEST_H_

#include "SPDefines.h"
#include "SPConstant.h"
#include <glm.hpp>

namespace SPhysics
{
	/**
	* @brief     abs
	* @param     [IN] @b x input value
	* @return     T
	*/
	template <typename T>
	inline T abs( const T& x )
	{
		return ( (x>0) ? (x) : (-x) );
	}

	/**
	* @brief     Return true if abs(X) is smaller than EPSILON
	* @param     [IN] @b x input value
	* @return     SPBool
	*/
	template <typename T>
	inline SPBool isAlmostZero( const T& x )
	{
		return ( ( abs(x) <= (T)EPSILON ) ? SPTRUE : SPFALSE );
	}

	/**
	* @brief     Return true if abs(X) is smaller than EPSILON
	* @param     [IN] @b x input value
	* @param     [IN] @b epsilon epsilon
	* @return     SPBool
	*/
	template <typename T>
	inline SPBool isAlmostZero( const T& x, const T& epsilon )
	{
		return ( ( abs(x) <= epsilon ) ? SPTRUE : SPFALSE );
	}

	/**
	* @brief     Convert the sign 'x'
	* @param     [IN] @b x input value
	* @return     SPInt
	*/
	template <typename T>
	inline SPInt sign( const T& x )
	{
		if( x>0 ) { return 1; }
		return -1;
	}

	/**
	* @brief     Convert the sign 'x'
	* @param     [IN] @b x input value
	* @return     SPInt
	*/
	template <typename T>
	inline SPInt Sign( const T& x )
	{
		if( isAlmostZero(x) ) return 0;
		return sign(x);
	}

	/**
	* @brief     Return true if the difference of 'A','B' is smaller than EPSILON
	* @param     [IN] @b A value 1 
	* @param     [IN] @b B value 2 
	* @return     SPBool
	*/
	template <typename T>
	inline SPBool isAlmostSame( const T& A, const T& B )
	{
		return ( ( abs(A-B) <= (T)EPSILON ) ? SPTRUE : SPFALSE );
	}

	/**
	* @brief     Return true if the difference of 'A','B' is smaller than EPSILON
	* @param     [IN] @b A value 1 
	* @param     [IN] @b B value 1 
	* @param     [IN] @b epsilon empsilon
	* @return     SPBool
	*/
	template <typename T>
	inline SPBool isAlmostSame( const T& A, const T& B, const T& epsilon )
	{
		return ( ( abs(A-B) <= epsilon ) ? SPTRUE : SPFALSE );
	}

	/**
	* @brief     Return true if n is power of two
	* @param     [IN] @b n input
	* @return     SPBool
	*/
	inline SPBool powersOfTwo( const SPInt& n )
	{
		return ( n&(n-1) ? SPFALSE : SPTRUE );
	}

	/**
	* @brief     Return true if position is inside L
	* @param     [IN] @b pos position
	* @param     [IN] @b L limitation range
	* @return     SPBool
	*/
	template<typename T>
	inline SPBool isInside( const SPVec2t& pos, const SPVec2t& L ) {

		if( (T)0>pos.x || pos.x>L.x || 
			(T)0>pos.y || pos.y>L.y ) return SPFALSE; 
		else return SPTRUE;

	}

	/**
	* @brief     Return true if position is inside L and radius
	* @param     [IN] @b pos position
	* @param     [IN] @b radius radius
	* @param     [IN] @b L limitation range
	* @return     SPBool
	*/
	template<typename T>
	inline SPBool isInside( const SPVec2t& pos, const T& radius, const SPVec2t& L )
	{
		T x0, x1, y0, y1;
		x0 = pos.x - radius;   if( x0 > (T)L.x ) return SPFALSE;
		x1 = pos.x + radius;   if( x1 < (T)0 )   return SPFALSE;
		y0 = pos.y - radius;   if( y0 > (T)L.y ) return SPFALSE;
		y1 = pos.y + radius;   if( y1 < (T)0 )   return SPFALSE;

		return SPTRUE;
	}

	/**
	* @brief     Return true if position is inside minimum and maximum
	* @param     [IN] @b pos position
	* @param     [IN] @b p_min min range
	* @param     [IN] @b p_max max range
	* @return     SPBool
	*/
	template<typename T>
	inline SPBool isInside( const SPVec2t& pos, const SPVec2t& p_min, const SPVec2t& p_max ) {

		if( p_min.x>pos.x || pos.x>p_max.x || 
			p_min.y>pos.y || pos.y>p_max.y ) return SPFALSE; 
		else return SPTRUE;

	}

	/**
	* @brief     Return true if position is inside L
	* @param     [IN] @b pos position
	* @param     [IN] @b L limitation range
	* @return     SPBool
	*/
	template<typename T>
	inline SPBool isInside( const SPVec3t& pos, const SPVec3t& L ) {

		if( (T)0>pos.x || pos.x>L.x || 
			(T)0>pos.y || pos.y>L.y || 
			(T)0>pos.z || pos.z>L.z ) return SPFALSE; 
		else return SPTRUE;

	}

	/**
	* @brief     Return true if abs(x) is bigger than EPSILON
	* @param     [IN] @b input value x input
	* @param     [IN] @b epsilon epsilon
	* @return     SPBool
	*/
	template <typename T>
	inline SPBool isAlmostZeroVec( const SPVec3t& x, const T& epsilon=EPSILON )
	{
		if( abs(x.x) > epsilon ) { return SPFALSE; }
		if( abs(x.y) > epsilon ) { return SPFALSE; }
		if( abs(x.z) > epsilon ) { return SPFALSE; }
		return SPTRUE;
	}

	/**
	* @brief     Return true if the difference of 'A','B' is bigger than EPSILON	
	* @param     [IN] @b A value 1
	* @param     [IN] @b B value 2
	* @param     [IN] @b epsilon epsilon
	* @return     SPBool
	*/
	template <typename T>
	inline SPBool isAlmostSameVec( const SPVec3t& A, const SPVec3t& B, const T& epsilon=EPSILON )
	{
		if( abs(A.x-B.x) > epsilon ) { return SPFALSE; }
		if( abs(A.y-B.y) > epsilon ) { return SPFALSE; }
		if( abs(A.z-B.z) > epsilon ) { return SPFALSE; }
		return SPTRUE;
	}

}

#endif //_SP_TEST_H_

