/**
* @file SPGeometry.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_GEOMETRY_H_
#define _SP_GEOMETRY_H_

#include "SPDefines.h"
#if 0
namespace SPhysics
{
	/**
	* @brief     Calculate the barycentric coordinate. 	P = uA + vB + wC (u+v+w=1) In fact, P is not equal to uA+vB+wC, but equal to (projP on the plane of ABC) It's a least square solution.
	* @param     [IN] @b P value SPVec3t 1 
	* @param     [IN] @b A value SPVec3t 2 
	* @param     [IN] @b B value SPVec3t 3 
	* @param     [IN] @b C value SPVec3t 4 
	* @param     [OUT] @b uvw[3] result 
	* @return     SPBool
	*/
	template <typename T>
	inline SPBool calculateBaryCoords( SPVec3t& P, SPVec3t& A, SPVec3t& B, SPVec3t& C, T uvw[3] )
	{
		SPVec3d AB;   SUB(AB,B,A);
		SPVec3d BC;   SUB(BC,C,B);

		SPVec3d n;    CROSS(n,AB,BC);

		SPDouble u1,u2,u3,u4;
		SPDouble v1,v2,v3,v4;

		// TODO - Remove same multiple oerations
		// Fpr example: SPDouble absX = ABS(n.x);
		if( (ABS(n.x) >= ABS(n.y)) && ( ABS(n.x) >= ABS(n.z) ) ) {

			u1 = A.y - C.y;
			u2 = B.y - C.y;
			u3 = P.y - A.y;
			u4 = P.y - C.y;

			v1 = A.z - C.z;
			v2 = B.z - C.z;
			v3 = P.z - A.z;
			v4 = P.z - C.z;

		} else if( ABS(n.y) >= ABS(n.z) ) {

			u1 = A.z - C.z;
			u2 = B.z - C.z;
			u3 = P.z - A.z;
			u4 = P.z - C.z;

			v1 = A.x - C.x;
			v2 = B.x - C.x;
			v3 = P.x - A.x;
			v4 = P.x - C.x;

		} else {

			u1 = A.x - C.x;
			u2 = B.x - C.x;
			u3 = P.x - A.x;
			u4 = P.x - C.x;

			v1 = A.y - C.y;
			v2 = B.y - C.y;
			v3 = P.y - A.y;
			v4 = P.y - C.y;

		}

		SPDouble denom = v1*u2 - v2*u1;
		if( isAlmostZero( denom ) )
		{
			return SPFALSE;
		}

		uvw[0] = (v4*u2-v2*u4)/denom;
		uvw[1] = (v1*u3-v3*u1)/denom;
		uvw[2] = 1 - uvw[0] - uvw[1];

		return SPTRUE;
	}

	/**
	* @brief     Calculate the barycentric coordinate. barycentric coordinate for tetrahedron. P = b0*A + b1*B + b2*C + b3*D (b0+b1+b2+b3=1)
	* @param     [IN] @b P value SPVec3t 1 
	* @param     [IN] @b A value SPVec3t 2 
	* @param     [IN] @b B value SPVec3t 3 
	* @param     [IN] @b C value SPVec3t 4 
	* @param     [IN] @b C value SPVec3t 5 
	* @param     [OUT] @b b[4] result 
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid calculateBaryCoords
	( SPVec3t& P,
	  SPVec3t& A, SPVec3t& B, SPVec3t& C, SPVec3t& D,
	  T b[4] )
	{
		SPMat3x3t X( A.x-D.x, B.x-D.x, C.x-D.x,
						A.y-D.y, B.y-D.y, C.y-D.y,
						A.z-D.z, B.z-D.z, C.z-D.z );

		SPMat3x3t invX;
		INV( invX, X );

		SPVec3t x( P.x-D.x, P.y-D.y, P.z-D.z );

		b[0] = invX(0,0) * x.x + invX(0,1) * x.y + invX(0,2) * x.z;
		b[1] = invX(1,0) * x.x + invX(1,1) * x.y + invX(1,2) * x.z;
		b[2] = invX(2,0) * x.x + invX(2,1) * x.y + invX(2,2) * x.z;
		b[3] = 1 - b[0] - b[1] - b[2];
	}

	/**
	* @brief     Calculate the closest point on infinite line
	* @param     [IN] @b closestPt closest point on AB from P
	* @param     [IN] @b P a point p
	* @param     [IN] @b A a line AB
	* @param     [IN] @b B a line AB
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid calculateClosestPtOnInfiniteLine
	( SPVec3t& closestPt,				
	  SPVec3t& P,						
	  SPVec3t& A, SPVec3t& B )	
	{
		SPVec3t AB;   SUB( AB, B, A );
		SPVec3t AP;   SUB( AP, P, A );
		NORMALIZE( AB );
		T inner = DOT( AB, AP );
		ADDMUL( closestPt, A, inner, AB );
	}

	/**
	* @brief     Calculate the distance to infinite line
	* @param     [IN] @b P a point P
	* @param     [IN] @b A a line AB
	* @param     [IN] @b B a line AB
	* @return     T
	*/
	template <typename T>
	inline T calculateDistToInfiniteLine
	( SPVec3t& P,						
	  SPVec3t& A, SPVec3t& B )		
	{
		SPVec3t closestPt;
		ClosestPointOnInfiniteLine( closestPt, P, A,B );
		return DIST( P, closestPt );
	}

	/**
	* @brief     Calculate the closest on finite line
	* @param     [IN] @b closestPt closest point on AB from P
	* @param     [IN] @b P a point 
	* @param     [IN] @b A a line AB
	* @param     [IN] @b B a line AB
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid calculateClosestPtOnFiniteLine
	( SPVec3t& closestPt,				
	  SPVec3t& P,						
	  SPVec3t& A, SPVec3t& B )	
	{
		SPVec3t AB;   SUB( AB, B, A );
		SPVec3t AP;   SUB( AP, P, A );
		NORMALIZE( AB );
		T inner = DOT( AB, AP );
		if( inner < MINUS_EPSILON )      { CPY(closestPt,A); }
		else if( inner > EPSILON_PLUS_ONE ) { CPY(closestPt,B); }
		else { ADDMUL( closestPt, A, inner, AB ); }
	}

	/**
	* @brief     Calculate the distance to finite line
	* @param     [IN] @b P a point P
	* @param     [IN] @b A a line AB
	* @param     [IN] @b B a line AB
	* @return     T
	*/
	template <typename T>
	inline T calculateDistToFiniteLine
	( SPVec3t& P, SPVec3t& A, SPVec3t& B ) 
	{
		SPVec3t closestPt;
		calculateClosestPtOnFiniteLine( closestPt, P, A,B );
		return DIST(P,closestPt);
	}

	/**
	* @brief     Calculate the closest point on Plane
	* @param     [IN] @b closestPt SPVec3t
	* @param     [IN] @b P SPVec3t& P of Plane
	* @param     [IN] @b A SPVec3t& A of Plane
	* @param     [IN] @b B SPVec3t& B of Plane
	* @param     [IN] @b C SPVec3t& C of Plane
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid calculateClosestPtOnPlane
	( SPVec3t& closestPt,
	  SPVec3t& P,
	  SPVec3t& A, SPVec3t& B, SPVec3t& C )
	{
		SPVec3t AB;   SUB( AB, B, A );
		SPVec3t AC;   SUB( AC, C, A );
		SPVec3t AP;   SUB( AP, P, A );
		SPVec3t N;    TRINORMAL( N, A,B,C );
		T inner = DOT( N, AP );
		ADDMUL( closestPt, P, -inner, N );
	}

	/**
	* @brief     Calculate the Distance to Plane
	* @param     [IN] @b P SPVec3t& P of Plane
	* @param     [IN] @b A SPVec3t& A of Plane
	* @param     [IN] @b B SPVec3t& B of Plane
	* @param     [IN] @b C SPVec3t& C of Plane
	* @return     T
	*/
	template <typename T>
	inline T calculateDistToPlane
	( SPVec3t& P,
	  SPVec3t& A, SPVec3t& B, SPVec3t& C )
	{
		SPVec3t closestPt;
		ClosestPtOnPlane( closestPt, P, A,B,C );
		return DIST( P, closestPt );
	}

	/**
	* @brief     Calculate the closest point on triangle
	* @param     [IN] @b closestPt result 
	* @param     [IN] @b P a point
	* @param     [IN] @b A A of triangle ABC
	* @param     [IN] @b B B of triangle ABC
	* @param     [IN] @b C C of triangle ABC
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid calculateClosestPtOnTriangle( SPVec3t& closestPt,					
									 SPVec3t& P,									    
									 SPVec3t& A, SPVec3t& B, SPVec3t& C )
	{
		T uvw[3] = { 0, 0, 0 };
		calculateBaryCoords( P, A,B,C, uvw );

		if( ( MINUS_EPSILON < uvw[0] ) && ( uvw[0] < EPSILON_PLUS_ONE )
		 && ( MINUS_EPSILON < uvw[1] ) && ( uvw[1] < EPSILON_PLUS_ONE )
		 && ( MINUS_EPSILON < uvw[2] ) && ( uvw[2] < EPSILON_PLUS_ONE ) )
		{ WEIGHTSUM( closestPt, A,B,C, uvw ); return; }

		// to edge
		SPVec3t tmp[3];
		calculateClosestPtOnFiniteLine( tmp[0], P, A,B );
		SPDouble dist0 = DIST( P, tmp[0] );

		calculateClosestPtOnFiniteLine( tmp[1], P, B,C );
		SPDouble dist1 = DIST( P, tmp[1] );

		calculateClosestPtOnFiniteLine( tmp[2], P, C,A );
		SPDouble dist2 = DIST( P, tmp[2] );

		SPDouble minDist = minimum( dist0, dist1, dist2 );

		if( minDist == dist0 ) {
			CPY( closestPt, tmp[0] ); return;
		}

		if( minDist == dist1 ) {
			CPY( closestPt, tmp[1] ); return;
		}

		if( minDist == dist2 ) {
			CPY( closestPt, tmp[2] ); return;
		}
	}

	/**
	* @brief     Calculate the Distance to triangle
	* @param     [IN] @b P a point
	* @param     [IN] @b A A of triangle ABC
	* @param     [IN] @b B B of triangle ABC
	* @param     [IN] @b C C of triangle ABC
	* @return     T
	*/
	template <typename T>
	inline T calculateDistToTriangle
	( SPVec3t& P,
	  SPVec3t& A, SPVec3t& B, SPVec3t& C )
	{
		T uvw[3] = { (T)0, (T)0, (T)0 };
		calculateBaryCoords( P, A,B,C, uvw );

		if( ( MINUS_EPSILON < uvw[0] ) && ( uvw[0] < EPSILON_PLUS_ONE )
		 && ( MINUS_EPSILON < uvw[1] ) && ( uvw[1] < EPSILON_PLUS_ONE )
		 && ( MINUS_EPSILON < uvw[2] ) && ( uvw[2] < EPSILON_PLUS_ONE ) )
		{
			SPVec3t closestPt;
			WEIGHTSUM( closestPt, A,B,C, uvw );
			return DIST( P, closestPt );
		}

		// to edge
		SPVec3t tmp[3];
		calculateClosestPtOnFiniteLine( tmp[0], P, A,B );
		SPDouble dist0 = DIST( P, tmp[0] );

		calculateClosestPtOnFiniteLine( tmp[1], P, B,C );
		SPDouble dist1 = DIST( P, tmp[1] );

		calculateClosestPtOnFiniteLine( tmp[2], P, C,A );
		SPDouble dist2 = DIST( P, tmp[2] );

		SPDouble minDist = minimum( dist0, dist1, dist2 );

		if( minDist == dist0 ) { return DIST( P, tmp[0] ); }
		if( minDist == dist1 ) { return DIST( P, tmp[1] ); }
		if( minDist == dist2 ) { return DIST( P, tmp[2] ); }

		return minDist;
	}

	/**
	* @brief     triangle ABC with point P: (position) = p
				A: (position,normal) = (p0,n0)
				B: (position,normal) = (p1,n1)
				C: (position,normal) = (p2,n2)
	* @param     [IN] @b p SPVec3t& p
	* @param     [IN] @b p0 SPVec3t& p0
	* @param     [IN] @b p1 SPVec3t& p1
	* @param     [IN] @b p2 SPVec3t& p2
	* @param     [IN] @b n0 SPVec3t& n0
	* @param     [IN] @b n1 SPVec3t& n1
	* @param     [IN] @b n2 SPVec3t& n2
	* @return     T
	*/
	template <typename T>
	inline T checkInsideVolumeTest
	( SPVec3t& p,
	  SPVec3t& p0, SPVec3t& p1, SPVec3t& p2,
	  SPVec3t& n0, SPVec3t& n1, SPVec3t& n2 )
	{
		SPVec3d closestPt[4];

		// to triangle
		T uvw[3];
		calculateBaryCoords( p, p0,p1,p2, uvw );
		WEIGHTSUM( closestPt[0], p0,p1,p2, uvw );

		SPDouble P2ABC;
		if( ( uvw[0] < MINUS_EPSILON ) || ( uvw[0] > EPSILON_PLUS_ONE )
		 || ( uvw[1] < MINUS_EPSILON ) || ( uvw[1] > EPSILON_PLUS_ONE )
		 || ( uvw[2] < MINUS_EPSILON ) || ( uvw[2] > EPSILON_PLUS_ONE ) ) { P2ABC = LARGE; }
		else { P2ABC = DIST( p, closestPt[0] ); }

		// to edge
		calculateClosestPtOnFiniteLine( closestPt[1], p, p0, p1 );
		SPDouble P2AB = DIST( p, closestPt[1] );

		calculateClosestPtOnFiniteLine( closestPt[2], p, p1, p2 );
		SPDouble P2BC = DIST( p, closestPt[2] );

		calculateClosestPtOnFiniteLine( closestPt[3], p, p2, p0 );
		SPDouble P2CA = DIST( p, closestPt[3] );

		// to vertex
		SPDouble P2A = DIST( p, p0 ); // P ~ A
		SPDouble P2B = DIST( p, p1 ); // P ~ B
		SPDouble P2C = DIST( p, p2 ); // P ~ C

		SPInt ID = 0;
		SPDouble dist = LARGE;

		if( P2ABC < dist ) { dist = P2ABC; ID = 1; }
		if( P2AB  < dist ) { dist = P2AB;  ID = 2; }
		if( P2BC  < dist ) { dist = P2BC;  ID = 3; }
		if( P2CA  < dist ) { dist = P2CA;  ID = 4; }
		if( P2A   < dist ) { dist = P2A;   ID = 5; }
		if( P2B   < dist ) { dist = P2B;   ID = 6; }
		if( P2C   < dist ) { dist = P2C;   ID = 7; }

		// pseudo normal & closest point 
		SPVec3d n, c;

		switch( ID )
		{
			case 1: { CENTER(n,n0,n1,n2); CPY(c,closestPt[0]); break; }
			case 2: { MID(n,n0,n1);       CPY(c,closestPt[1]); break; }
			case 3: { MID(n,n1,n2);       CPY(c,closestPt[2]); break; }
			case 4: { MID(n,n2,n0);       CPY(c,closestPt[3]); break; }
			case 5: { CPY(n,n0);          CPY(c,p0);           break; }
			case 6: { CPY(n,n1);          CPY(c,p1);           break; }
			case 7: { CPY(n,n2);          CPY(c,p2);           break; }
		}

		// inside/outside test
		SPVec3d dir;
		SUB( dir, p, c );

		return sign( DOT(n,dir) ) * dist;
	}

	/**
	* @brief     
	* @param     [IN] @b P SPVec3t& P
	* @param     [IN] @b Q SPVec3t& Q
	* @param     [IN] @b A SPVec3t& A
	* @param     [IN] @b B SPVec3t& B
	* @param     [IN] @b C SPVec3t& C
	* @return     SPBool
	*/
	template <typename T>
	inline SPBool checkSameSide
	( SPVec3t& P, SPVec3t& Q,
	  SPVec3t& A, SPVec3t& B, SPVec3t& C )
	{
		SPVec3t N;
		TRINORMAL( N, A,B,C );

		SPVec3t c;
		CENTER( c, A,B,C );

		SPVec3t cP;   SUB( cP, P,c );
		SPVec3t cQ;   SUB( cQ, Q,c );

		if( sign( DOT(N,cP) ) == sign( DOT(N,cQ) ) ) return SPTRUE;

		return SPFALSE;
	}

};
#endif
#endif //_SP_GEOMETRY_H_