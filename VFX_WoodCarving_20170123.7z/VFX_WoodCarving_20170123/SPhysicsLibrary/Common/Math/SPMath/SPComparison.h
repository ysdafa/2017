/**
* @file SPComparison.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_COMPARISON_H_
#define _SP_COMPARISON_H_

#include "SPDefines.h"

#include <glm.hpp>

namespace SPhysics
{

	//template <typename T>
	//inline SPVoid clamp( T& x, const T& min, const T& max ) // x = [min,max]
	//{
	//	if( x < min ) { x = min; return; }
	//	if( x > max ) { x = max; return; }
	//}

	/**
	* @brief     Clamp the minimum or maximum of 'x' , x = [min,max]
	* @param     [IN] @b  x input  value
	* @param     [IN] @b  min minimum of boundary
	* @param     [IN] @b  max maximum of boundary
	* @return     T
	*/
	template <typename T>
	inline T clamp( const T& x, const T& min, const T& max ) // x = [min,max]
	{
		if( x < min ) { return min; }
		if( x > max ) { return max; }
		return x;
	}

	/**
	* @brief     Clamp the minimum or maximum of the vector 'v'
	* @param     [IN] @b  v input  value
	* @param     [IN] @b  min minimum of boundary
	* @param     [IN] @b  max maximum of boundary
	* @return     SPVec2t
	*/
	template <typename T>
	inline SPVec2t clamp( const SPVec2t& v, const SPVec2t& min, const SPVec2t& max )
	{
		SPVec2t clamped_v;
		clamped_v.x = clamp<T>(v.x, min.x, max.x);
		clamped_v.y = clamp<T>(v.y, min.y, max.y);
		return clamped_v;
	}

	/**
	* @brief     Calculate the minimum value of 'x','y'
	* @param     [IN] @b  x input  value
	* @param     [IN] @b  y input  value
	* @return     T
	*/
	template <typename T>
	inline T minimum( const T& x, const T& y )
	{
		return ( (x<y) ? x : y );
	}

	/**
	* @brief     Calculate the maximum value of 'x','y'
	* @param     [IN] @b  x input  value
	* @param     [IN] @b  y input  value
	* @return     T
	*/
	template <typename T>
	inline T maximum( const T& x, const T& y )
	{
		return ( (x>y) ? x : y );
	}

	/**
	* @brief     Calculate the minimum and the maximum of 'x','y'
	* @param     [IN] @b  x input  value
	* @param     [IN] @b  y input  value
	* @param     [IN] @b  min minimum
	* @param     [IN] @b  max maximum
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid minimumMaximum( const T& x, const T& y, T& min, T& max )
	{
		if( x < y ) { min = x; max = y; }
		else        { min = y; max = x; }
	}

	/**
	* @brief     Calculate the minimum and the maximum of 'x','y','z' 
	* @param     [IN] @b  x input  value
	* @param     [IN] @b  y input  value
	* @param     [IN] @b  z input  value
	* @param     [IN] @b  min minimum
	* @param     [IN] @b  max maximum
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid minimumMaximum( const T& x, const T& y, const T& z, T& min, T& max )
	{
		min = max = x;
		if( y < min ) { min = y; }
		if( y > max ) { max = y; }
		if( z < min ) { min = z; }
		if( z > max ) { max = z; }
	}

	/**
	* @brief     Calculate the minimum of 'a','b','c'
	* @param     [IN] @b  a input  value
	* @param     [IN] @b  b input  value
	* @param     [IN] @b  c input  value
	* @return     T
	*/
	template <typename T>
	inline T minimum( const T& a, const T& b, const T& c )
	{
		//if( a<b && a<c ) return a;
		//if( b<c ) return b;
		//return c;
		return minimum<T>(a,minimum<T>(b,c));
	}

	/**
	* @brief     Calculate the maximum of 'a','b','c'
	* @param     [IN] @b  a input  value
	* @param     [IN] @b  b input  value
	* @param     [IN] @b  c input  value
	* @return     T
	*/
	template <typename T>
	inline T maximum( const T& a, const T& b, const T& c )
	{
		//if( a > b && a>c ) return a;
		//if( b > c) return b;
		//return c;
		return maximum<T>(a,maximum<T>(b,c));
	}

	/**
	* @brief     Calculate the minimum of 'a','b','c','d'
	* @param     [IN] @b  a input  value
	* @param     [IN] @b  b input  value
	* @param     [IN] @b  c input  value
	* @param     [IN] @b  d input  value
	* @return     T
	*/
	template <typename T>
	inline T minimum( const T& a, const T& b, const T& c, const T& d )
	{
		//if( a<b && a<c && a<d ) return a;
		//if( b<c && b<d ) return b;
		//if( c<d ) return c;
		//return d;
		return minimum<T>(a,minimum<T>(b,minimum<T>(c,d)));
	}

	/**
	* @brief     Calculate the maximum of 'a','b','c','d'
	* @param     [IN] @b  a input  value
	* @param     [IN] @b  b input  value
	* @param     [IN] @b  c input  value
	* @param     [IN] @b  d input  value
	* @return     T
	*/
	template <typename T>
	inline T maximum( const T& a, const T& b, const T& c, const T& d )
	{
		//if( a>b && a>c && a>d ) return a;
		//if( b>c && b>d ) return b;
		//if( c>d ) return c;
		//return d;
		return maximum<T>(a,maximum<T>(b,maximum<T>(c,d)));
	}

	/**
	* @brief     Swap the value of 'a','b'
	* @param     [IN] @b  a input  value
	* @param     [IN] @b  b input  value
	* @return     SPVoid
	*/
	template<typename T> inline SPVoid SPswap(T& a, T& b)
	{
		T tmp = a;
		a = b;
		b = tmp;
	}
}
#endif //_SP_COMPARISON_H_

