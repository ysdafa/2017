/**
* @file SPDivergence.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_DIVERGENCE_H_
#define _SP_DIVERGENCE_H_

#include "SPDefines.h"

#include "SPScalarField2D.h"
#include "SPVectorField2D.h"

namespace SPhysics
{		
	/**
	* @brief     compute the divergence
	* @param     [IN] @b div  scalar field
	* @param     [IN] @b vel  vector field
	* @param     [IN] @b useCellSize	
	* @return     SPVoid
	*/
	SPVoid computeDivergence( SPField2DTemplate<SPDouble>& div, SPField2DTemplate<SPVec2d >& vel, const SPBool useCellSize )
	{

		if( !DefinedAtCell( div ) || !DefinedAtNode( vel ) )
		{
			std::cout<<"Error@computeDivergence: Invalid location."<<std::endl;
			return;
		}

		if( !Computable( div, vel ) )
		{
			std::cout<<"Error@computeDivergence(): Not computable."<<std::endl;
			return;
		}

		div.setZero();

		const SPVec2i resolution = div.getResolution();
		const SPVec2d cellSize = div.getCellSize();
		const SPVec2d gridSize = div.getDimension();


		const SPDouble one_over_dx = (SPDouble)1/cellSize.x;
		const SPDouble one_over_dy = (SPDouble)1/cellSize.y;

		if( useCellSize )
		{ 
			for( SPInt j=0; j<resolution.y; ++j )
			{
				for( SPInt i=0; i<resolution.x; ++i )
				{ 
					SPInt node[4];
					vel.getNodesOfCell( i, j, node );

					SPDouble temp_div=0;
					temp_div += (SPDouble)0.5 * one_over_dx * 
						( ( vel[node[1]].x + vel[node[2]].x )
						- ( vel[node[0]].x + vel[node[3]].x ) );

					temp_div += (SPDouble)0.5 * one_over_dy * 
						( ( vel[node[2]].y + vel[node[3]].y )
						- ( vel[node[0]].y + vel[node[1]].y ) );

					if( temp_div == 0 ) div(i,j) = EPSILON;
					else div(i,j) = temp_div;

				}
			} 
		} else {

		}

	}

	/**
	* @brief     Compute the divergence
	*/
	SPVoid computeDivergence( SPField2DTemplate<SPDouble>& div, SPField2DTemplate<SPVec2d >& vel, const SPField2DTemplate<SPChar>& state, const SPDouble dt )
	{
	}

	/**
	* @brief     Compute the divergence
	*/
	SPVoid computeDivergence( SPField2DTemplate<SPDouble>& div, SPFaceGrid2D<SPDouble>& vel, const SPField2DTemplate<SPChar>& state, const SPDouble dt )
	{
	}

	/**
	* @brief     Compute the divergence
	* @param     [IN] @b  div scalar field
	* @param     [IN] @b  vel vector field
	* @return     SPVoid
	*/
	SPVoid computeDivergence( SPField2DTemplate<SPDouble>& div, SPFaceGrid2D<SPDouble>& vel )
	{
		if( DefinedAtCell( div )==SPFALSE )
		{
			std::cout<<"Error@computeDivergence: Invalid location."<<std::endl;
			return;
		}

		const SPDouble one_over_dx = (SPDouble)1/div.getCellSize().x;
		const SPDouble one_over_dy = (SPDouble)1/div.getCellSize().y;

		div.setZero();

		for( SPInt j=0; j<div.getResolution().y; ++j )
		{
			for( SPInt i=0; i<div.getResolution().x; ++i )
			{
				const SPFaces2D<SPDouble> face = vel.getFaces(i,j);

				SPDouble temp_div=0;
				temp_div += one_over_dx * (face.upper.x-face.lower.x);
				temp_div += one_over_dy * (face.upper.y-face.lower.y);
				div(i,j) = temp_div;
			}
		}
	}
}

#endif //_SP_DIVERGENCE_H_