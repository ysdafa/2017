/**
* @file SPDrawSmoke.cpp
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPTextureManager.h"
#include "SPDrawSmoke.h"
#include <string.h>
#include <stdio.h>

namespace SPhysics
{
	SPDrawSmoke::SPDrawSmoke() : m_pMesh(SPNULL), m_pMVPMG(SPNULL), m_pShaderMG(SPNULL), m_TextureId(-1),  m_TextureId2(-1), m_pData(SPNULL)
	{
		m_ObjectColor = SPVec4f(1.0f, 1.0f, 1.0f, 1.0f);
		m_nDrawMode = 0;
	}
	SPDrawSmoke::~SPDrawSmoke()
	{
		SP_SAFE_DELETE(m_pMesh);
		SP_SAFE_DELETE(m_pMVPMG);
		SP_SAFE_DELETE(m_pShaderMG);
		SP_SAFE_DELETE_ARRAY(m_pData);
	}
	SPVoid SPDrawSmoke::init( SPFloat width, SPFloat height, SPInt cameraAlgin )
	{
		if(m_pMesh == SPNULL)
			m_pMesh = new SPMesh();
		if(m_pMVPMG == SPNULL)
			m_pMVPMG = new SPMVPManager();
		if(cameraAlgin == POSTIVE_CAMERA_ALIGN) // POSTIVE_CAMERA_ALIGN
		{
			m_pMVPMG->setOrtho( 0.0f, width, 0, height, -5000.0f, 5000.0f);
		}else	//CENTER_CAMERA_ALIGN
		{
			m_pMVPMG->setOrtho( -width * 0.5f, width * 0.5f, -height * 0.5f, height * 0.5f, -5000.0f, 5000.0f);
		}
		// create shader program and atrribute, uniform location
		createRectColorShader();
		createRectVertex(width, height);
	}
	SPVoid SPDrawSmoke::draw()
	{
		glUseProgram(m_pShaderMG->getProgram());
		if(m_nDrawMode == 1) //If draw texture mode
		{
			glVertexAttribPointer(m_pShaderMG->getAttribute(ATTRIBUTE1), 3, GL_FLOAT, GL_FALSE, 3 * sizeof(SPFloat), &m_pMesh->m_tTextureUV[0]);
			glEnableVertexAttribArray(m_pShaderMG->getAttribute(ATTRIBUTE1));
			// Bind the base map
			glActiveTexture ( GL_TEXTURE0 );
			glBindTexture ( GL_TEXTURE_2D, m_TextureId );
			// Set the base map sampler to texture unit to 0
			glUniform1i( m_pShaderMG->getUniform(UNIFORM2), 0 );
			glActiveTexture ( GL_TEXTURE1 );
			glBindTexture ( GL_TEXTURE_2D, m_TextureId2 );
			// Set the base map sampler to texture unit to 0
			glUniform1i( m_pShaderMG->getUniform(UNIFORM3), 1 );
		}
		//set Vertex Postion
		glVertexAttribPointer(m_pShaderMG->getAttribute(ATTRIBUTE0), 3, GL_FLOAT, GL_FALSE, 3 * sizeof(SPFloat), &m_pMesh->m_tVertex[0]);
		glEnableVertexAttribArray(m_pShaderMG->getAttribute(ATTRIBUTE0));
		// set MVP Matrix
		glUniformMatrix4fv(m_pShaderMG->getUniform(UNIFORM0), 1, GL_FALSE, m_pMVPMG->getMVPMatrix());
		// set Color
		glUniform4fv(m_pShaderMG->getUniform(UNIFORM1), 1, (SPFloat*)&m_ObjectColor[0]);
		glDrawElements(GL_TRIANGLE_STRIP, 4, GL_UNSIGNED_SHORT, &m_pMesh->m_tVertexIndex[0]);
		glDisableVertexAttribArray(m_pShaderMG->getAttribute(ATTRIBUTE0));
		if(m_nDrawMode == 1)
			glDisableVertexAttribArray(m_pShaderMG->getAttribute(ATTRIBUTE1));
	}
	// API for control the rect size
	SPVoid SPDrawSmoke::setSize( SPFloat width, SPFloat height )
	{
		m_pMesh->m_tVertex.clear();
		SPVec3f vertex;
		// Default Center Align Rect Vertex
		// point 1
		vertex = SPVec3f(-width*0.5f, -height*0.5f, 0.0f);
		m_pMesh->m_tVertex.push_back(vertex);
		// point 2
		vertex = SPVec3f(width*0.5f, -height*0.5f, 0.0f);
		m_pMesh->m_tVertex.push_back(vertex);

		// point 3
		vertex = SPVec3f(-width*0.5f, height*0.5f, 0.0f);
		m_pMesh->m_tVertex.push_back(vertex);
		// point 4
		vertex = SPVec3f(width*0.5f, height*0.5f, 0.0f);
		m_pMesh->m_tVertex.push_back(vertex);
	}
	SPVoid SPDrawSmoke::setColor( SPFloat red, SPFloat green, SPFloat blue, SPFloat alpha )
	{
		m_ObjectColor = SPVec4f(red, green, blue, alpha);
	}
	SPVoid SPDrawSmoke::setMesh( SPMesh* mesh )
	{
		m_pMesh = mesh;
	}
	SPVoid SPDrawSmoke::setTranslate( SPFloat x, SPFloat y, SPFloat z )
	{
		if(m_pMVPMG != SPNULL)
			m_pMVPMG->setTranslate(x, y, z);
	}
	SPVoid SPDrawSmoke::setRotate( SPFloat angle, SPFloat x, SPFloat y, SPFloat z )
	{
		if(m_pMVPMG != SPNULL)
			m_pMVPMG->setRotate(angle, x, y, z);
	}
	SPVoid SPDrawSmoke::setScale( SPFloat x, SPFloat y, SPFloat z )
	{
		if(m_pMVPMG != SPNULL)
			m_pMVPMG->setScale(x, y, z);
	}
	SPVoid SPDrawSmoke::setTexture( SPChar *fileName )
	{
		createRectTextureShader();
		createTextureUV();
		m_TextureId = SPTextureManager::getInstancePtr()->loadTexture(fileName);
	}
	SPVoid SPDrawSmoke::setTexture2( SPChar* fileName )
	{
		m_TextureId2 = SPTextureManager::getInstancePtr()->loadTexture(fileName);
	}
	SPVoid SPDrawSmoke::setTextureFromMemory( SPInt width, SPInt height )
	{
		createRectTextureShader();
		createTextureUV(width, height);
		//SPInt size = (width ) * (height );
		SPInt size = (width + 2) * (height + 2);
		m_pData = new SPUChar[ size * 4];
		memset(m_pData, 0, sizeof(SPUChar) * size * 4);
		//
		//width = width +2 ;
		//height = height +2;
		//for(SPInt i =0; i< (height) ; i++)
		//{				
		//	for(SPInt j =0; j< (width) ; j++)
		//	{
		//	
		//		m_pData[(i*width + j)*4 + 0] = (SPUChar)( ((float)j/(float)(width - 1)) * 255  );//(i / (height ) * 255); // R
		//		m_pData[(i*width + j)*4 + 1] = (SPUChar)( ((float)i/(float)(height - 1)) * 255  );//(j / (width ) * 255); // G
		//		m_pData[(i*width + j)*4 + 2] = (SPUChar)0; // B
		//		m_pData[(i*width + j)*4 + 3] =(SPUChar) 255; // Alpha
		//	
		//	}
		//}
		glPixelStorei(GL_UNPACK_ALIGNMENT,1);
		glGenTextures(1, &m_TextureId);
		glBindTexture(GL_TEXTURE_2D, m_TextureId);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);	
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width + 2, height + 2, 0, GL_RGBA, GL_UNSIGNED_BYTE, (SPUChar*)m_pData);
		//glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width , height , 0, GL_RGBA, GL_UNSIGNED_BYTE, (SPUChar*)m_pData);
	}
	// private Method
	SPVoid SPDrawSmoke::createRectVertex(SPFloat width, SPFloat height)
	{
		// Rect Vertex
		//     P3                  P4
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1                  P2
		// create rect vertex position
		SPVec3f vertex;
// 		// case Center Align Rect Vertex
// 		// point 1
// 		vertex = SPVec3f(-width*0.5f, -height*0.5f, 0.0f);
// 		m_pMesh->m_tVertex.push_back(vertex);
// 
// 		vertex = SPVec3f(width*0.5f, -height*0.5f, 0.0f);
// 		m_pMesh->m_tVertex.push_back(vertex);
// 
// 		vertex = SPVec3f(-width*0.5f, height*0.5f, 0.0f);
// 		m_pMesh->m_tVertex.push_back(vertex);
// 
// 		vertex = SPVec3f(width*0.5f, height*0.5f, 0.0f);
// 		m_pMesh->m_tVertex.push_back(vertex);
		// Default LeftTop Align Rect Vertex
		// point 1
		vertex = SPVec3f(0.0f, 0.0f, 0.0f);
		m_pMesh->m_tVertex.push_back(vertex);
		vertex = SPVec3f(width, 0.0f, 0.0f);
		m_pMesh->m_tVertex.push_back(vertex);
		vertex = SPVec3f(0.0f, height, 0.0f);
		m_pMesh->m_tVertex.push_back(vertex);
		vertex = SPVec3f(width, height, 0.0f);
		m_pMesh->m_tVertex.push_back(vertex);
		//create rect vertex index
		m_pMesh->m_tVertexIndex.push_back(0);
		m_pMesh->m_tVertexIndex.push_back(1);
		m_pMesh->m_tVertexIndex.push_back(2);
		m_pMesh->m_tVertexIndex.push_back(3);
	}
	SPVoid SPDrawSmoke::createTextureUV()
	{
		// Rect Vertex
		//     P3(0,0)            P4(1,0)
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1(0,1)            P2(1.1)
		SPVec3f textureUV;
		textureUV = SPVec3f(0.0f, 1.0f, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);
		textureUV = SPVec3f(1.0f, 1.0f, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);
		textureUV = SPVec3f(0.0f, 0.0f, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);
		textureUV = SPVec3f(1.0f, 0.0f, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);
		//     P3(0,0)            P4(1,0)
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1(0,1)            P2(1.1)
// 		textureUV = SPVec3f(0.0f, 1.0f);
// 		m_pMesh->m_tTextureUV.push_back(textureUV);
// 
// 		textureUV = SPVec3f(1.0f, 1.0f);
// 		m_pMesh->m_tTextureUV.push_back(textureUV);
// 
// 		textureUV = SPVec3f(0.0f, 0.0f);
// 		m_pMesh->m_tTextureUV.push_back(textureUV);
// 
// 		textureUV = SPVec3f(1.0f, 0.0f);
// 		m_pMesh->m_tTextureUV.push_back(textureUV);
	}
	SPVoid SPDrawSmoke::createTextureUV(SPInt width, SPInt height)
	{
		// Rect Vertex
		//     P3(0,0)            P4(1,0)
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1(0,1)            P2(1.1)
		SPVec3f textureUV;
		//SPFloat gridX = 1.0f / (width + 2);		
		//SPFloat gridY = 1.0f / (height + 2);		
		SPFloat gridX = 1.0f / (width);		
		SPFloat gridY = 1.0f / (height);		
		textureUV = SPVec3f(gridX, 1.0f-gridY, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);
		textureUV = SPVec3f(1.0f-gridX, 1.0f-gridY, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);
		textureUV = SPVec3f(gridX, gridY, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);
		textureUV = SPVec3f(1.0f-gridX, gridY, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);
		//     P3(0,0)            P4(1,0)
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1(0,1)            P2(1.1)
		// 		textureUV = SPVec3f(0.0f, 1.0f);
		// 		m_pMesh->m_tTextureUV.push_back(textureUV);
		// 
		// 		textureUV = SPVec3f(1.0f, 1.0f);
		// 		m_pMesh->m_tTextureUV.push_back(textureUV);
		// 
		// 		textureUV = SPVec3f(0.0f, 0.0f);
		// 		m_pMesh->m_tTextureUV.push_back(textureUV);
		// 
		// 		textureUV = SPVec3f(1.0f, 0.0f);
		// 		m_pMesh->m_tTextureUV.push_back(textureUV);
	}
	SPVoid SPDrawSmoke::createRectColorShader()
	{
		// Shader Program for DrawRect
		SPChar VertexShader[] =  
			"uniform mediump mat4 u_PMVMatrix;			\n"
			"attribute vec4 a_position;					\n"
			"void main()								\n"
			"{											\n"
			"   gl_Position = u_PMVMatrix * a_position; \n"
			"}											\n";
		SPChar FragmentShader[] =  
			"precision mediump float;                           \n"
			"uniform vec4 u_color;								\n"
			"void main()                                        \n"
			"{                                                  \n"
			"   gl_FragColor = u_color;							\n"
			"}                                                  \n";
		if(m_pShaderMG == SPNULL)
			m_pShaderMG = new SPShaderManager();
		m_pShaderMG->reset();
		// create the shader location handler and linked program object
		m_pShaderMG->createProgram(VertexShader, FragmentShader);
		m_pShaderMG->addAttribute(ATTRIBUTE0, "a_position");
		m_pShaderMG->addUniform(UNIFORM0, "u_PMVMatrix");
		m_pShaderMG->addUniform(UNIFORM1, "u_color");
		m_nDrawMode = 0;
		
	}

	SPVoid SPDrawSmoke::createRectTextureShader()
	{
		// Shader Program for DrawRect
		SPChar VertexShader[] =  
			"uniform mediump mat4 u_PMVMatrix;				\n"
			"attribute vec4 a_position;						\n"
			"attribute vec2 a_texUV;						\n"
			"varying vec2 v_texUV;							\n"
			"void main()									\n"
			"{												\n"
			"   v_texUV = a_texUV;							\n"
			"   gl_Position = u_PMVMatrix * a_position;		\n"
			"}												\n";

		SPChar FragmentShader[] =  
			"precision mediump float;                           \n"
			"uniform vec4 u_color;								\n"
			"uniform sampler2D u_TexMap;                        \n"
			"uniform sampler2D u_TexMap2;                        \n"
			"varying vec2 v_texUV;								\n"
			"void main()                                        \n"
			"{                                                  \n"
			"  vec4 TexColor = texture2D( u_TexMap, v_texUV );  \n"
			" vec2 tempa ;"
			" tempa.x = TexColor.x +  TexColor.y/255.0 ; "
			" tempa.y = TexColor.z +  TexColor.a/255.0 ; "
	
			"  vec4 TexColor2 = texture2D( u_TexMap2, tempa );  \n"
			"  \n"
			"  gl_FragColor = TexColor2  ;	\n"
			//"  gl_FragColor = vec4(vec3(tempa.x),1.0) ;	\n"
			"}                                                  \n";
		if(m_pShaderMG == SPNULL)
			m_pShaderMG = new SPShaderManager();
		m_pShaderMG->reset();
		glDisable (GL_DEPTH_TEST);
		glEnable (GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		// create the shader location handler and linked program object
		m_pShaderMG->createProgram(VertexShader, FragmentShader);
		m_pShaderMG->addAttribute(ATTRIBUTE0, "a_position");
		m_pShaderMG->addAttribute(ATTRIBUTE1, "a_texUV");
		m_pShaderMG->addUniform(UNIFORM0, "u_PMVMatrix");
		m_pShaderMG->addUniform(UNIFORM1, "u_color");
		m_pShaderMG->addUniform(UNIFORM2, "u_TexMap");
		m_pShaderMG->addUniform(UNIFORM3, "u_TexMap2");
		m_nDrawMode = 1;
	}

	SPVoid SPDrawSmoke::updateTexture(SPInt width, SPInt height, SPFloat* data)
	{
		//for(SPInt i =0; i< (width+2) * (height+2) ; i++)
		for(SPInt i =0; i< (width) * (height) ; i++)
		{				
			if(data[i] >= 0)
			{
				m_pData[i*4 + 0] = (SPUChar)(data[i] * 255); // R
				if(data[i] >= 1.0) 
					m_pData[i*4 + 0] = 0;
				m_pData[i*4 + 1] = (SPUChar)(data[i] * 255); // G
				// if(abs(data[i]) < 0.001)
					 m_pData[i*4 + 1] = 0; 
				m_pData[i*4 + 2] = 0; // B
				//  if(abs(data[i]) < 0.001)
				m_pData[i*4 + 2] = 0; 
				m_pData[i*4 + 3] = 255; // Alpha
			}
			if(data[i] < 0)
			{
				m_pData[i*4 + 0] = 0; // R
				m_pData[i*4 + 1] = 0; // G
				m_pData[i*4 + 2] = (SPUChar)((data[i]) * 255) ;  // B
				if(data[i] <= -2.0) 
					m_pData[i*4 + 2] = 0;
				m_pData[i*4 + 3] = 255; // Alpha
			}
		if(data[i]>0)
				printf("%f\n",data[i]);
		}
		if(m_TextureId == SPUInt(-1))
		{
			glPixelStorei(GL_UNPACK_ALIGNMENT,1);
			glGenTextures(1, &m_TextureId);
			glBindTexture(GL_TEXTURE_2D, m_TextureId);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);	
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width + 2, height + 2, 0, GL_RGBA, GL_UNSIGNED_BYTE, (SPUChar*)m_pData);
			//glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width , height , 0, GL_RGBA, GL_UNSIGNED_BYTE, (SPUChar*)m_pData);
		}else
		{
			glBindTexture(GL_TEXTURE_2D, m_TextureId);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);	
			glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, width + 2, height + 2, GL_RGBA, GL_UNSIGNED_BYTE, (SPUChar*)m_pData);
			//glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, width , height , GL_RGBA, GL_UNSIGNED_BYTE, (SPUChar*)m_pData);
		}		
	}
	SPVoid SPDrawSmoke::updateTexture2(SPInt width, SPInt height, SPFloat* data1, SPFloat* data2)
	{
		//width = width + 2;
		//height = height + 5;
		for(SPInt i =0; i< (width) * (height) + width*5 ; i++)
		{				
			    if ( data1[i] == 0 || data2[i] == 0 )
					break;
			    float temp = data1[i] * 255 ;
			    SPUChar d1 = (SPUChar)temp;
				float temp2 = temp - (float)d1;
				SPUChar d2 = (SPUChar)(temp2 * 255);
				m_pData[i*4 + 0] = d1; // R
				m_pData[i*4 + 1] = d2; // G
			    temp = data2[i] * 255 ;
			    d1 = (SPUChar)temp;
				temp2 = temp - (float)d1;
				d2 = (SPUChar)(temp2 * 255);
				m_pData[i*4 + 2] = d1; // B
				m_pData[i*4 + 3] = d2; // Alpha
		}
		if(m_TextureId == SPUInt(-1))
		{
			glPixelStorei(GL_UNPACK_ALIGNMENT,1);
			glGenTextures(1, &m_TextureId);
			glBindTexture(GL_TEXTURE_2D, m_TextureId);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);	
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width + 2, height + 2, 0, GL_RGBA, GL_UNSIGNED_BYTE, (SPUChar*)m_pData);
			//glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width , height , 0, GL_RGBA, GL_UNSIGNED_BYTE, (SPUChar*)m_pData);
		}else
		{
			glBindTexture(GL_TEXTURE_2D, m_TextureId);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);	
			glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, width + 2, height + 2, GL_RGBA, GL_UNSIGNED_BYTE, (SPUChar*)m_pData);
			//glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, width , height , GL_RGBA, GL_UNSIGNED_BYTE, (SPUChar*)m_pData);
		}	
	}
}//namespace SPhysics
