/**
* @file SPDrawTextureToFBO.h
* @brief This file includes module that draws background image
*
* @date 2014-06-19
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_DRAW_TEXTURE_TO_FBO_H_
#define _SP_DRAW_TEXTURE_TO_FBO_H_

#include "SPDefines.h"
#include "SPIRenderer.h"

#include <glm.hpp>
#include <gtc/constants.hpp>

namespace SPhysics
{

	/**
	* @class     SPDrawTextureToFBO
	* @brief     This class is mainly for draw texture on FBO like background or something.
	*/
	class SPDrawTextureToFBO : public SPIRenderer
	{
	public:
		/**
		* @brief     Constructor
		*/
		SPDrawTextureToFBO(const SPUInt aTextureId);
		/**
		* @brief     Destructor
		*/
		~SPDrawTextureToFBO();

	public:

		/**
		* @brief     Initialize and Prepare rendering\n
		(set camera setting, initialize shader , create rectangle mesh)
		* @param     [IN] SPFloat width Clipping Plane's width size
		* @param     [IN] SPFloat height Clipping Plane's height size
		* @return     SPVoid
		*/
		SPVoid initRender(SPFloat width, SPFloat height); // virtual

		/**
		* @brief     Mesh setting & binding shader variables for drawing.
		* @return     SPVoid
		 */
		SPVoid drawRender(); // virtual

		/**
		* @brief     Set texture for drawing to FBO.
		* @param     [IN] SPUInt aTextureId Texture id
		* @return     SPVoid
		 */
		SPVoid setTexture(const SPUInt aTextureId);

	private:
		SPUInt mTextureId;
	};

}//namespace SPhysics

#endif //_SP_DRAW_FIREWORKS_COLOR_H_