/**
* @file SPDrawUIComponent.cpp
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/


#include "SPDrawUIComponent.h"
#include "SPTextureManager.h"
#include "SPVBOManager.h"

namespace SPhysics
{
	SPDrawUIComponent::SPDrawUIComponent() : m_TextureId(-1)
	{
		uniform0 = 0;
		uniform1 = 1;
		uniform2 = 2;
		uniform3 = 3;

		attribute0 = 0;	attribute1 = 1;	attribute2 = 2;	attribute3 = 3;

		m_bPerspective = SPFALSE;

	}

	SPDrawUIComponent::~SPDrawUIComponent()
	{
	}

	SPVoid SPDrawUIComponent::initRender( SPFloat width, SPFloat height )
	{

		if(m_bPerspective)
		{
			setPerspectiveCameraView(45.0f, width/height, 1.0f, 500.0f);
			//setLookAt(2,0,60,0,0,-1,0,1,0);
			setLookAt(0,0,60,0,0,0,0,1,0);
		}
		else
		{
			setOrthogonalCameraView(0.0f, width, 0.0f, height, -5000, 5000.0f);
		}
		//setOrthogonalCameraView(0.0f, width, 0.0f, height, -5000, 5000.0f);
		//setOrthogonalCameraView( -width * 0.5f, width * 0.5f, -height * 0.5f, height * 0.5f, -5000.0f, 5000.0f);
		
		createTriangleTextureShader();
	}

	SPVoid SPDrawUIComponent::drawRender()
	{
		glVertexAttribPointer(attribute0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(SPFloat), &m_pRenderMesh->m_tVertex[0]);
		glEnableVertexAttribArray(attribute0);

		glVertexAttribPointer(attribute1, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(SPFloat), &m_pRenderMesh->m_tTextureUV[0]);
		glEnableVertexAttribArray(attribute1);

		glUniformMatrix4fv(uniform0, 1, GL_FALSE, m_pRenderMVP->getMVPMatrix());

		glUniform4fv(uniform1, 1, (SPFloat*)&m_ObjectColor[0]);
		glActiveTexture ( GL_TEXTURE0 + 0 );
		glBindTexture ( GL_TEXTURE_2D, m_TextureId );
		glUniform1i(uniform2,0);

		setDrawArraysWithOption(DRAW_TRIANGLES);
	}


	SPVoid SPDrawUIComponent::setTexture(const SPChar *fileName, SPBool isMipMapMode )
	{
		createTriangleTextureShader();
		m_TextureId = SPTextureManager::getInstancePtr()->loadTexture(fileName, isMipMapMode);		
	}

	SPVoid SPDrawUIComponent::changeTexture( const SPChar *fileName)
	{
		m_TextureId = SPTextureManager::getInstancePtr()->loadTexture(fileName);
	}

	SPVoid SPDrawUIComponent::createTriangleTextureShader()
	{
		// Shader Program for DrawTriangle
		SPChar VertexShader[] =  
			"uniform mediump mat4 uMVPMatrix;			\n"
			"attribute vec4 aPosition;					\n"
			"attribute vec2 aTexUV;					\n"
			"varying vec2 vTexUV;						\n"
			"void main()								\n"
			"{											\n"
			"   vTexUV = aTexUV;						\n"
			"   gl_Position = uMVPMatrix * aPosition; \n"
			"}											\n";

		SPChar FragmentShader[] =  
			"precision mediump float;                           \n"
			"uniform vec4 uColor;								\n"
			"uniform sampler2D uTexMap;                        \n"
			"varying vec2 vTexUV;								\n"
			"void main()                                        \n"
			"{                                                  \n"			
			"  vec4 TexColor = texture2D( uTexMap, vTexUV);  \n"
			"  gl_FragColor = vec4(TexColor.rgb * uColor.rgb, TexColor.w);				\n"
			"  if(gl_FragColor.a < 0.5) discard; \n"
			//"  gl_FragColor = TexColor;							\n"
			"}                                                  \n";

		createShaderProgram(VertexShader, FragmentShader);

		attribute0 = glGetAttribLocation(m_pRenderShader->getProgram(),"aPosition");
		attribute1 = glGetAttribLocation(m_pRenderShader->getProgram(),"aTexUV");

		uniform0 = glGetUniformLocation(m_pRenderShader->getProgram(),"uMVPMatrix");
		uniform1 = glGetUniformLocation(m_pRenderShader->getProgram(),"uColor");
		uniform2 = glGetUniformLocation(m_pRenderShader->getProgram(),"uTexMap");
	}

	//////////////////////////////////////////////////////////////////////////

	SPDrawUIComponentBackground::SPDrawUIComponentBackground() : m_pMesh(SPNULL), m_TextureId(-1), m_nDrawMode(-1), m_nRectAlign(0), m_nRectWidth(1024),m_nRectHeight(768)
	{
		m_ObjectPosition = SPVec3f();
	}

	SPDrawUIComponentBackground::~SPDrawUIComponentBackground()
	{
		SP_SAFE_DELETE(m_pMesh);
	}

	SPVoid SPDrawUIComponentBackground::setDepth(SPFloat _z)
	{
		for(SPUInt i = 0 ; i < m_pMesh->m_tVertex.size() ; ++i ) 
		{
			m_pMesh->m_tVertex[i].z = _z;
		}
	}

	SPVoid SPDrawUIComponentBackground::initRender( SPFloat width, SPFloat height )
	{
		// Initialize RectSize
		m_nRectWidth = (SPInt)width;
		m_nRectHeight = (SPInt)height;



		setPerspectiveCameraView(45.0f, width/height, 1.0f, 500.0f);
		setLookAt(0,0,60,0,0,0,0,1,0);


		//setOrthogonalCameraView(0.0f, width, 0.0f, height, -5000, 5000.0f);
		//setOrthogonalCameraView( -width * 0.5f, width * 0.5f, -height * 0.5f, height * 0.5f, -5000.0f, 5000.0f);

		// create shader program and atrribute, uniform location
		createRectColorShader();

		createRectVertex(width, height);
	}



	SPVoid SPDrawUIComponentBackground::drawRender()
	{
		setShaderArrayMeshVertex("aPosition");
		setShaderUniformMVPMatrix("uMVPMatrix");

		setShaderUnformColor("uColor");

		if(m_nDrawMode != 0)
		{
			setShaderArrayMeshUV("aTexUV");
			setShaderUnifromTexture("uTexMap", m_TextureId);
		}

		setDrawElementsWithOption(SPhysics::DRAW_TRIANGLES_STRIP);

	}

	SPVoid SPDrawUIComponentBackground::setPosition( SPFloat x, SPFloat y, SPFloat z /*= 0*/ )
	{
		m_ObjectPosition = SPVec3f(x, y, z);

		createRectVertex((SPFloat)m_nRectWidth, (SPFloat)m_nRectHeight);
	}

	SPVoid SPDrawUIComponentBackground::setRectAlign( SPInt align )
	{
		m_nRectAlign = align;
	}

	// API for control the rect size
	SPVoid SPDrawUIComponentBackground::setSize( SPFloat width, SPFloat height )
	{
		m_nRectWidth = (SPInt)width;
		m_nRectHeight = (SPInt)height;

		createRectVertex(width, height);
	}

	SPVoid SPDrawUIComponentBackground::setTexture( const SPChar *fileName, SPBool isMipMapMode )
	{
		m_TextureId = SPTextureManager::getInstancePtr()->loadTexture(fileName, isMipMapMode);

		if(m_nDrawMode == 1)
			return;

		createRectTextureShader();
		createTextureUV();

	}

	// 	SPVoid SPDrawRect::setXenTexture(const SPChar *fileName)
	// 	{
	// 	#ifndef _WIN32
	// 		m_TextureId = SPTextureManager::getInstancePtr()->loadTextureCallback(fileName);
	// 
	// 		if(m_nDrawMode == 1)
	// 			return;
	// 
	// 		createRectTextureShader();
	// 		createTextureUV();
	// 	#endif	
	// 	}

	SPVoid SPDrawUIComponentBackground::setTextureID(SPUInt texID)
	{
		m_TextureId = texID;

		if(m_nDrawMode == 1)
			return;

		createRectTextureShader();
		createTextureUV();
	}

	SPVoid SPDrawUIComponentBackground::setFontTexture( const SPChar *fileName )
	{
		m_TextureId = SPTextureManager::getInstancePtr()->loadTexture(fileName);

		if(m_nDrawMode == 2)
			return;

		createRectFontShader();
		createTextureUV();
	}

	SPVoid SPDrawUIComponentBackground::createRectVertex( SPFloat width, SPFloat height )
	{

		if(m_pMesh == SPNULL)
			m_pMesh = new SPMesh();


		m_pMesh->m_tVertex.clear();

		//     P3                  P4
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1                  P2

		SPVec3f vertex;

		SPFloat p1_x, p1_y;

		if(m_nRectAlign == 1)
		{
			p1_x = m_ObjectPosition.x - (width*0.5f);
			p1_y = m_ObjectPosition.y - (height*0.5f);
			//Default Center Align Rect Vertex

			// point 1
			vertex = SPVec3f(p1_x, p1_y, -100.0f);
			m_pMesh->m_tVertex.push_back(vertex);

			// point 2
			vertex = SPVec3f(p1_x + width, p1_y, -100.0f);
			m_pMesh->m_tVertex.push_back(vertex);

			// point 3
			vertex = SPVec3f(p1_x, p1_y + height, -100.0f);
			m_pMesh->m_tVertex.push_back(vertex);

			// point 4
			vertex = SPVec3f(p1_x + width, p1_y + height, -100.0f);
			m_pMesh->m_tVertex.push_back(vertex);

		}else
		{
			// Default LeftTop Align Rect Vertex

			p1_x = m_ObjectPosition.x;
			p1_y = m_ObjectPosition.y;


			// point 1
			vertex = SPVec3f(p1_x, p1_y, -100.0f);
			m_pMesh->m_tVertex.push_back(vertex);

			// point 2
			vertex = SPVec3f(p1_x + width, p1_y, -100.0f);
			m_pMesh->m_tVertex.push_back(vertex);

			// point 3
			vertex = SPVec3f(p1_x, p1_y + height, -100.0f);
			m_pMesh->m_tVertex.push_back(vertex);

			// point 4
			vertex = SPVec3f(p1_x + width, p1_y + height, -100.0f);
			m_pMesh->m_tVertex.push_back(vertex);

			// 			// point 1
			// 			vertex = SPVec3f(0.0f, 0.0f, 0.0f);
			// 			m_pMesh->m_tVertex.push_back(vertex);
			// 
			// 			// point 2
			// 			vertex = SPVec3f(width, 0.0f, 0.0f);
			// 			m_pMesh->m_tVertex.push_back(vertex);
			// 
			// 			// point 3
			// 			vertex = SPVec3f(0.0f, height, 0.0f);
			// 			m_pMesh->m_tVertex.push_back(vertex);
			// 
			// 			// point 4
			// 			vertex = SPVec3f(width, height, 0.0f);
			// 			m_pMesh->m_tVertex.push_back(vertex);

			// 			// point 1
			// 			vertex = SPVec3f(0.0f, 0.0f, 0.0f);
			// 			m_pMesh->m_tVertex.push_back(vertex);
			// 
			// 			// point 2
			// 			vertex = SPVec3f(width, 0.0f, 0.0f);
			// 			m_pMesh->m_tVertex.push_back(vertex);
			// 
			// 			// point 3
			// 			vertex = SPVec3f(0.0f, height, 0.0f);
			// 			m_pMesh->m_tVertex.push_back(vertex);
			// 
			// 			// point 4
			// 			vertex = SPVec3f(width, height, 0.0f);
			// 			m_pMesh->m_tVertex.push_back(vertex);
		}


		//create rect vertex index
		m_pMesh->m_tVertexIndex.clear();
		m_pMesh->m_tVertexIndex.push_back(0);
		m_pMesh->m_tVertexIndex.push_back(1);
		m_pMesh->m_tVertexIndex.push_back(2);
		m_pMesh->m_tVertexIndex.push_back(3);

		setMesh(m_pMesh);
	}

	SPVoid SPDrawUIComponentBackground::createTextureUV()
	{
		// Rect Vertex
		//     P3(0,0)            P4(1,0)
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1(0,1)            P2(1.1)

		m_pMesh->m_tTextureUV.clear();
		SPVec3f textureUV;

		textureUV = SPVec3f(0.0f, 1.0f, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);

		textureUV = SPVec3f(1.0f, 1.0f, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);

		textureUV = SPVec3f(0.0f, 0.0f, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);

		textureUV = SPVec3f(1.0f, 0.0f, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);


		//     P3(0,0)            P4(1,0)
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1(0,1)            P2(1.1)

		// 		textureUV = SPVec3f(0.0f, 1.0f);
		// 		m_pMesh->m_tTextureUV.push_back(textureUV);
		// 
		// 		textureUV = SPVec3f(1.0f, 1.0f);
		// 		m_pMesh->m_tTextureUV.push_back(textureUV);
		// 
		// 		textureUV = SPVec3f(0.0f, 0.0f);
		// 		m_pMesh->m_tTextureUV.push_back(textureUV);
		// 
		// 		textureUV = SPVec3f(1.0f, 0.0f);
		// 		m_pMesh->m_tTextureUV.push_back(textureUV);

		setMesh(m_pMesh);
	}

	SPVoid SPDrawUIComponentBackground::flipTextureV()
	{
		SPFloat temp = m_pMesh->m_tTextureUV[0].y;
		m_pMesh->m_tTextureUV[0].y = m_pMesh->m_tTextureUV[2].y;
		m_pMesh->m_tTextureUV[2].y = temp;

		temp = m_pMesh->m_tTextureUV[1].y;
		m_pMesh->m_tTextureUV[1].y = m_pMesh->m_tTextureUV[3].y;
		m_pMesh->m_tTextureUV[3].y = temp;
	}

	SPVoid SPDrawUIComponentBackground::createRectColorShader()
	{
		// Shader Program for DrawRect
		SPChar VertexShader[] =  
			"uniform mediump mat4 uMVPMatrix;			\n"
			"attribute vec4 aPosition;					\n"
			"void main()								\n"
			"{											\n"
			"   gl_Position = uMVPMatrix * aPosition; \n"
			"}											\n";

		SPChar FragmentShader[] =  
			"precision mediump float;                           \n"
			"uniform vec4 uColor;								\n"
			"void main()                                        \n"
			"{                                                  \n"
			"   gl_FragColor = uColor;							\n"
			"}                                                  \n";

		m_nDrawMode = 0;

		createShaderProgram(VertexShader, FragmentShader);
	}

	SPVoid SPDrawUIComponentBackground::createRectTextureShader()
	{
		// Shader Program for DrawRect
		SPChar VertexShader[] =  
			"uniform mediump mat4 uMVPMatrix;				\n"
			"attribute vec4 aPosition;						\n"
			"attribute vec2 aTexUV;							\n"
			"varying vec2 vTexUV;							\n"
			"void main()									\n"
			"{												\n"
			"   vTexUV = aTexUV;							\n"
			"   gl_Position = uMVPMatrix * aPosition;		\n"
			"}												\n";

		SPChar FragmentShader[] =  
			"precision mediump float;                           \n"
			"uniform vec4 uColor;								\n"
			"uniform sampler2D uTexMap;                         \n"
			"varying vec2 vTexUV;								\n"
			"void main()                                        \n"
			"{                                                  \n"
			"  vec4 TexColor = texture2D( uTexMap, vTexUV );    \n"
			"  gl_FragColor = TexColor * uColor;				\n"
			"}                                                  \n";

		m_nDrawMode = 1;

		createShaderProgram(VertexShader, FragmentShader);
	}

	SPVoid SPDrawUIComponentBackground::createRectFontShader()
	{
		// Shader Program for DrawRect
		SPChar VertexShader[] =  
			"uniform mediump mat4 uMVPMatrix;				\n"
			"attribute vec4 aPosition;						\n"
			"attribute vec2 aTexUV;						    \n"
			"varying vec2 vTexUV;							\n"
			"void main()									\n"
			"{												\n"
			"   vTexUV = aTexUV;							\n"
			"   gl_Position = uMVPMatrix * aPosition;		\n"
			"}												\n";

		SPChar FragmentShader[] =  
			"precision mediump float;                           \n"
			"uniform vec4 uColor;								\n"
			"uniform sampler2D uTexMap;                         \n"
			"varying vec2 vTexUV;								\n"
			"void main()                                        \n"
			"{                                                  \n"
			"  vec4 TexColor = texture2D( uTexMap, vTexUV );    \n"
			"  gl_FragColor = vec4(uColor.rgb, TexColor.a);     \n"
			"}                                                  \n";

		m_nDrawMode = 2;

		createShaderProgram(VertexShader, FragmentShader);
	}	


}//namespace SPhysics
