/**
* @file SPDraw3D.cpp
* @brief
*
* @date 2013-02-24
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPTextureManager.h"
#include "SPDraw3D.h"

namespace SPhysics
{
	SPDraw3D::SPDraw3D() : m_TextureId(0), m_nCubeMapId(0)
	{
		// 		m_vLightPos
		// 		m_vCameraPos
	}

	SPDraw3D::~SPDraw3D()
	{
	}

	SPVoid SPDraw3D::initRender(SPFloat width, SPFloat height)
	{
		setOrthogonalCameraView(0, width, 0, height, -200.0f, 5000.0f);
		createShader();
	}

	SPVoid SPDraw3D::drawRender()
	{
		setShaderArrayMeshVertex("aPosition");
		setShaderArrayMeshUV("aTexUV");
		setShaderArrayMeshNormal("aNormal");
		setShaderUniformMVPMatrix("uMVPMatrix");
		setShaderUniformITMMatrix("uNMatrix");
		setShaderUniformMMatrix("uMMatrix");

		//setShaderUnformColor("uColor");
		setShaderUniformVector("uLightPos", glm::value_ptr(m_vLightPos), 3);
		setShaderUniformVector("uCameraPos", glm::value_ptr(m_vCameraPos), 3);

		setShaderUnifromTexture("uTexMap", m_TextureId);
		setShaderUniformCubeMapTexture("uSkyMap", m_nCubeMapId);

		setDrawElementsWithOption(SPhysics::DRAW_TRIANGLES);
	}

	SPVoid SPDraw3D::setTexture(const SPChar *fileName, SPBool isMipMapMode)
	{
		m_TextureId = SPTextureManager::getInstancePtr()->loadTexture(fileName, isMipMapMode);
	}

	SPVoid SPDraw3D::setTextureID(SPUInt texID)
	{
		m_TextureId = texID;
	}

	SPhysics::SPVoid SPDraw3D::setCubeTextureID(SPUInt texID)
	{
		m_nCubeMapId = texID;
	}

	SPVoid SPDraw3D::createShader()
	{
		// Shader Program for DrawRect
		SPChar VertexShader[] =
			"uniform mediump mat4 uMVPMatrix;				                                            \n"
			"uniform mediump mat4 uMMatrix;									                            \n"
			"uniform mediump mat4 uNMatrix;									                            \n"
			"attribute vec4 aPosition;						                                            \n"
			"attribute vec2 aTexUV;							                                            \n"
			"attribute vec4 aNormal;						                                            \n"
			"varying vec2 vTexUV;							                                            \n"
			"varying vec3 vPosition;					                                                \n"
			"varying vec3 vNormal;						                                                \n"
			"void main()									                                            \n"
			"{												                                            \n"
			"   vTexUV = aTexUV;							                                            \n"
			"   vNormal = (uNMatrix * aNormal).xyz;			                                            \n"
			"	vPosition = vec3(uMMatrix * aPosition);	\n"
			//"   vNormal = aNormal.xyz;			                                                    \n"
			"   gl_Position = uMVPMatrix * aPosition;		                                            \n"
			"}												                                            \n";

		SPChar FragmentShader[] =
			"precision mediump float;                                                                   \n"
			"uniform vec3 uLightPos;								                                    \n"
			"uniform vec3 uCameraPos;								                                    \n"
			"uniform sampler2D uTexMap;                                                                 \n"
			"uniform samplerCube uSkyMap;						                                        \n"
			"varying vec2 vTexUV;							                                            \n"
			"varying vec3 vPosition;					                                                \n"
			"varying vec3 vNormal;						                                                \n"
			"void main()                                                                                \n"
			"{                                                                                          \n"
			"	if(gl_FrontFacing == true)		\n"
			"	{\n"
			"	vec3 N = normalize(vNormal);						                                    \n"
			"	vec3 I = uCameraPos ;							                            \n"
			"	vec3 L = uLightPos;											                            \n"
			"	vec4 texColor = texture2D( uTexMap, vTexUV );                                           \n"
			"	vec4 skymapColor = textureCube( uSkyMap, reflect(N, I));		                        \n"
			"	float diffuse = max(dot(N, normalize(L)),0.0);				                            \n"
			"	float ambient = 0.3;										                            \n"
			"	float NdotHV = max(dot(N, normalize(L + I)),0.0);			                            \n"
			"	vec3 specular = pow(NdotHV, 70.0) * vec3(1, 0.6, 0.3);	                                \n"
			"	vec3 light = ambient + diffuse + specular;					                            \n"
			"	float r0 = 0.2;												                            \n"
			"	float fresnel = r0 + (1.0 - r0) * pow(1.0 - dot(N, normalize(I)), 3.0);					\n"
			"	gl_FragColor = vec4(mix(texColor.rgb, skymapColor.rgb, fresnel) * light, 1.0);			\n"
			//"	gl_FragColor.rgb = mix(texColor.rgb, light, 0.5);			\n"
			"	gl_FragColor.a = 1.0;			\n"
			"	} else {\n"
			"	gl_FragColor = vec4(0.3, 0.3, 0.3, 1.0);			\n"
			"	}\n"
			"}                                                                                          \n";


		createShaderProgram(VertexShader, FragmentShader);
	}

	SPVoid SPDraw3D::setLightPosition(const SPFloat& x, const SPFloat& y, const SPFloat& z)
	{
		m_vLightPos = glm::vec3(x, y, z);
	}

	SPVoid SPDraw3D::setCameraPosition(const SPFloat& x, const SPFloat& y, const SPFloat& z)
	{
		m_vCameraPos = glm::vec3(x, y, z);
	}

}//namespace SPhysics
