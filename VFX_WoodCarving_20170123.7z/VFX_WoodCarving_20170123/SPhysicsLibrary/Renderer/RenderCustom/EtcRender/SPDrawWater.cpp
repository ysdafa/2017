/**
* @file SPDrawWater.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/
#include "SPTextureManager.h"
#include "SPDrawWater.h"
namespace SPhysics
{
	SPDrawWater::SPDrawWater() : m_nWidth(720), m_nHeight(1280), m_hBackground(0), m_hEnvironment(0), m_nDrawMode(-1)
	{
	}


	SPDrawWater::~SPDrawWater()
	{
	}

	SPVoid SPDrawWater::initRender( SPFloat width, SPFloat height )
	{
		setOrthogonalCameraView(0.0f, width, 0.0f, height, -5000, 5000.0f);

		// create shader program and atrribute, uniform location
		if(m_pRenderShader == NULL){
			createWaterShader();
		}
		
	}

	SPVoid SPDrawWater::drawRender()
	{
		switch(m_nDrawMode)
		{
		case ATTRIBUTE_COLOR_DRAW:
			{
				drawWaterAttributeColorShader();
			}
			break;
		case UNIFORM_COLOR_DRAW:
			{
				drawWaterShader();
			}
			break;
		case NOMAL_VECTOR_DRAW:
			{
				drawWaterShader_withNormal();
			}
			break;
		}
	}

	

	SPVoid SPDrawWater::setScreenSize(const SPUInt &nWidth, const SPUInt &nHeight )
	{
		m_nWidth = nWidth;
		m_nHeight = nHeight;
	}

	SPVoid SPDrawWater::setTexture(const SPChar* bgFileName, const SPChar* envFileName)
	{
// 		m_hBackground = SPTextureManager::getInstancePtr()->loadTexture("01.png");
// 		m_hEnvironment = SPTextureManager::getInstancePtr()->loadTexture("environment.png");
		m_hBackground = SPTextureManager::getInstancePtr()->loadTexture(bgFileName, SPFALSE);
		m_hEnvironment = SPTextureManager::getInstancePtr()->loadTexture(envFileName, SPFALSE);
	}

	SPhysics::SPVoid SPDrawWater::setDrawMode( SPInt mode )
	{
		if(m_nDrawMode != mode)
		{
			switch(mode)
			{
			case ATTRIBUTE_COLOR_DRAW:
				{
					createWaterAttributeColorShader();
				}
				break;
			case UNIFORM_COLOR_DRAW:
				{
					createWaterShader();
				}
				break;
			case NOMAL_VECTOR_DRAW:
				{
					createWaterShader_withNormal();
				}
				break;
			}
		}
	}

	SPVoid SPDrawWater::createWaterShader()
	{

		if(m_nDrawMode == UNIFORM_COLOR_DRAW)
		{
			return;
		}

		const SPChar VertexShader[] = 
			"uniform mat4 uMVPMatrix;						\n"
			"attribute vec4 aPosition;						\n"
			"attribute vec3 aHeights;						\n"
			"varying float vAlpha;							\n"
			"varying vec3 vNormal;							\n"
			"varying vec3 vVertex;							\n"
			"void main() {									\n"
			"vAlpha = aHeights.x;							\n"
			"vec3 Heights = aHeights;						\n"
			"float len = Heights.x;							\n"
			"vec3 dx = vec3(1.0, 0.0, Heights.y - len);		\n"
			"vec3 dy = vec3(0.0, 1.0, len - Heights.z);		\n"
			"vNormal = cross(dx,dy);						\n"			
			"vVertex = aPosition.xyz;						\n"
			"gl_Position = uMVPMatrix * aPosition;			\n"
			"}\n";

		const SPChar FragmentShader[] =
			"precision mediump float;						\n"
			"varying float vAlpha;							\n"
			"varying vec3 vVertex;							\n"
			"varying vec3 vNormal;							\n"
			"uniform sampler2D uBackgroundTexture;          \n"
			"uniform sampler2D uEnvironmentTexture;         \n"
			"uniform float uScreenWidth;					\n"
			"uniform float uScreenHeight;					\n"
			"uniform vec4 uColor;					\n"
			"void main() {									\n"	
 			"vec3 N = normalize(vNormal);					\n"
 			"vec3 halfVec = normalize(vec3(0.0, 0.0, 1.0) - vVertex) + normalize(vec3(1.5, 1.5, 1.0) - vVertex);\n"	
 			"float NdotHV = max(dot(N, normalize(halfVec)),0.0); \n"
 			"float NdotL = max(dot(N, normalize(vec3(1.0, 1.0, 1.0))),0.0); \n"	
 			"float specular = max(0.0, pow(NdotHV, 140.0));\n"	
 			"vec3 refract = (refract(vec3(0.0, 0.0, -1.0), N, 0.5) + 0.2) * 75.0 ;\n"	
 			"vec3 reflect = reflect(vec3(0.0, 0.0, -1.0), N) * 15.0 ;\n"	
 			"vec4 TexColor = texture2D( uBackgroundTexture, vec2((gl_FragCoord.x + refract.x) / uScreenWidth , 1.0 - (gl_FragCoord.y+ refract.y) / uScreenHeight) );   \n"	
 			//"vec4 TexColorG = texture2D( uBackgroundTexture, vec2((gl_FragCoord.x + refract.x * 1.1) / uScreenWidth , 1.0 - (gl_FragCoord.y+ refract.y * 1.1) / uScreenHeight) );   \n"	
 			//"vec4 TexColorB = texture2D( uBackgroundTexture, vec2((gl_FragCoord.x + refract.x * 1.2) / uScreenWidth , 1.0 - (gl_FragCoord.y+ refract.y * 1.2) / uScreenHeight) );   \n"	
 			"vec4 TexColor2;\n"
 			"TexColor2 = texture2D( uEnvironmentTexture, vec2((gl_FragCoord.x + reflect.x) / uScreenWidth , (gl_FragCoord.y+ reflect.y) / uScreenHeight) );   \n"	
 			"float NdotI = max(dot(N, vec3(0.0, 0.0, 1.0)), 0.0);"
 			"vec3 diffuseL = vec3(1.0,1.0,1.0) * NdotL * 0.5;\n"
 			"float ratio = (1.0 - clamp((1.0 - NdotI), 0.13, 0.3));\n"
 			//"gl_FragColor.rgb = vec3(TexColorR.r, TexColorG.g, TexColorB.b) * (0.87) + TexColor2.rgb * (1.0 -ratio) + specular + diffuseL * max(1.3 - vAlpha, 0.0);\n"
 			"gl_FragColor.rgb = vec3(TexColor) * (0.87) + TexColor2.rgb * (1.0 -ratio) + specular + diffuseL * max(1.3 - vAlpha, 0.0);\n"
 			"gl_FragColor.rgb *= uColor.rgb;\n"
			"gl_FragColor.a = 1.0;\n"
 			//"gl_FragColor.a = 0.85;\n"
			"}\n";


		m_nDrawMode = UNIFORM_COLOR_DRAW;


		createShaderProgram(VertexShader, FragmentShader);
	}

	SPVoid SPDrawWater::drawWaterShader()
	{
		setShaderArrayMeshVertex("aPosition");
		setShaderArrayMeshHeight("aHeights");
		setShaderUniformMVPMatrix("uMVPMatrix");

		setShaderUnifromTexture("uBackgroundTexture", m_hBackground);
		setShaderUnifromTexture("uEnvironmentTexture", m_hEnvironment);

		setShaderUniformValue("uScreenWidth", (SPFloat) m_nWidth);
		setShaderUniformValue("uScreenHeight", (SPFloat) m_nHeight);

		setShaderUnformColor("uColor");

	}

	SPVoid SPDrawWater::createWaterAttributeColorShader()
	{
		if(m_nDrawMode == ATTRIBUTE_COLOR_DRAW)
		{
			return;
		}

		const SPChar VertexShader[] = 
			"uniform mat4 uMVPMatrix;						\n"
			"attribute vec4 aPosition;						\n"
			"attribute vec3 aHeights;						\n"
			"attribute vec4 aColor;						\n"
			"varying float vAlpha;							\n"
			"varying vec3 vNormal;							\n"
			"varying vec4 vColor;							\n"
			"varying vec3 vVertex;							\n"
			"void main() {									\n"
			"vColor = aColor;								\n"
			"vAlpha = aHeights.x;							\n"
			"vec3 Heights = aHeights;						\n"	
			"float len = Heights.x;							\n"
			"vec3 dx = vec3(1.0, 0.0, Heights.y - len);		\n"
			"vec3 dy = vec3(0.0, 1.0, len - Heights.z);		\n"
			"vNormal = cross(dx,dy);						\n"			
			"vVertex = aPosition.xyz;						\n"
			"gl_Position = uMVPMatrix * aPosition;			\n"
			"}\n";

		const SPChar FragmentShader[] = 
			"precision mediump float;						\n"
			"varying float vAlpha;							\n"
			"varying vec3 vVertex;							\n"
			"varying vec3 vNormal;							\n"
			"varying vec4 vColor;							\n"
			"uniform sampler2D uBackgroundTexture;          \n"
			"uniform sampler2D uEnvironmentTexture;         \n"
			"uniform float uScreenWidth;					\n"
			"uniform float uScreenHeight;					\n"			
			"void main() {									\n"	
			"vec3 N = normalize(vNormal);					\n"
			"vec3 halfVec = normalize(vec3(0.0, 0.0, 1.0) - vVertex) + normalize(vec3(1.5, 1.5, 1.0) - vVertex);\n"	
			"float NdotHV = max(dot(N, normalize(halfVec)),0.0); \n"
			"float NdotL = max(dot(N, normalize(vec3(1.0, 1.0, 1.0))),0.0); \n"	
			"float specular = max(0.0, pow(NdotHV, 140.0));\n"	
			"vec3 refract = (refract(vec3(0.0, 0.0, -1.0), N, 0.5) + 0.2) * 75.0 ;\n"	
			"vec3 reflect = reflect(vec3(0.0, 0.0, -1.0), N) * 15.0 ;\n"	
			"vec4 TexColorR = texture2D( uBackgroundTexture, vec2((gl_FragCoord.x + refract.x) / uScreenWidth , 1.0 - (gl_FragCoord.y+ refract.y) / uScreenHeight) );   \n"	
			"vec4 TexColorG = texture2D( uBackgroundTexture, vec2((gl_FragCoord.x + refract.x * 1.1) / uScreenWidth , 1.0 - (gl_FragCoord.y+ refract.y * 1.1) / uScreenHeight) );   \n"	
			"vec4 TexColorB = texture2D( uBackgroundTexture, vec2((gl_FragCoord.x + refract.x * 1.2) / uScreenWidth , 1.0 - (gl_FragCoord.y+ refract.y * 1.2) / uScreenHeight) );   \n"	
			"vec4 TexColor2;\n"
			"TexColor2 = texture2D( uEnvironmentTexture, vec2((gl_FragCoord.x + reflect.x) / uScreenWidth , (gl_FragCoord.y+ reflect.y) / uScreenHeight) );   \n"	
			"float NdotI = max(dot(N, vec3(0.0, 0.0, 1.0)), 0.0);"
			"vec3 diffuseL = vec3(1.0,1.0,1.0) * NdotL * 0.5;\n"
			"float ratio = (1.0 - clamp((1.0 - NdotI), 0.13, 0.3));\n"
			"	gl_FragColor.rgb = (vec3(TexColorR.r, TexColorG.g, TexColorB.b) + vColor.rgb)  * (0.87) + TexColor2.rgb * (1.0 -ratio) + specular + diffuseL * max(1.3 - vAlpha, 0.0);\n"
			"	gl_FragColor.rgb *= vColor.rgb;// * 0.5  + vec3(TexColorR.r, TexColorG.g, TexColorB.b) * 0.7;\n"
			"gl_FragColor.a = 0.75;\n"
			"}\n";



		m_nDrawMode = ATTRIBUTE_COLOR_DRAW;
		createShaderProgram(VertexShader, FragmentShader);
	}

	SPVoid SPDrawWater::drawWaterAttributeColorShader()
	{
		setShaderArrayMeshVertex("aPosition");
		setShaderArrayMeshHeight("aHeights");
		setShaderArrayMeshColor("aColor");
		setShaderUniformMVPMatrix("uMVPMatrix");

		setShaderUnifromTexture("uBackgroundTexture", m_hBackground);
		setShaderUnifromTexture("uEnvironmentTexture", m_hEnvironment);

		setShaderUniformValue("uScreenWidth", (SPFloat) m_nWidth);
		setShaderUniformValue("uScreenHeight", (SPFloat) m_nHeight);
	}

	SPVoid SPDrawWater::createWaterShader_withNormal()
	{
		if(m_nDrawMode == NOMAL_VECTOR_DRAW)
		{
			return;
		}

		const SPChar VertexShader[] = 
			"uniform mat4 uMVPMatrix;						\n"
			"attribute vec4 aPosition;						\n"
			"attribute vec3 aNormal;						\n"
			"varying float vAlpha;							\n"
			"varying vec3 vNormal;							\n"
			"varying vec3 vVertex;							\n"
			"void main() {									\n"
			"vAlpha = aNormal.x;							\n"
			"vNormal = aNormal;						\n"
			"vVertex = aPosition.xyz;						\n"
			"gl_Position = uMVPMatrix * aPosition;			\n"
			"}\n";

		const SPChar FragmentShader[] = 
			"precision mediump float;						\n"
			"varying float vAlpha;							\n"
			"varying vec3 vVertex;							\n"
			"varying vec3 vNormal;							\n"
			"uniform sampler2D uBackgroundTexture;          \n"
			"uniform sampler2D uEnvironmentTexture;         \n"
			"uniform float uScreenWidth;					\n"
			"uniform float uScreenHeight;					\n"
			"void main() {									\n"	
			"vec3 N = normalize(vNormal);					\n"	
			"vec3 halfVec = normalize(vec3(0.0, 0.0, 1.0) - vVertex) + normalize(vec3(1.5, 1.5, 1.0) - vVertex);\n"	
			"float NdotHV = max(dot(N, normalize(halfVec)),0.0); \n"
			"float NdotL = max(dot(N, normalize(vec3(1.0, 1.0, 1.0))),0.0); \n"	
			"float specular = max(0.0, pow(NdotHV, 140.0));\n"	
			"vec3 refract = (refract(vec3(0.0, 0.0, -1.0), N, 1.0 / 1.99) + 0.2) * 75.0 ;\n"	
			"vec3 reflect = reflect(vec3(0.0, 0.0, -1.0), N) * 15.0 ;\n"	
			"vec4 TexColor1 = texture2D( uBackgroundTexture, vec2((gl_FragCoord.x + refract.x) / uScreenWidth , 1.0 - (gl_FragCoord.y+ refract.y) / uScreenHeight) );   \n"	
			"vec4 TexColor2;\n"
			"TexColor2 = texture2D( uEnvironmentTexture, vec2((gl_FragCoord.x + reflect.x) / uScreenWidth , (gl_FragCoord.y+ reflect.y) / uScreenHeight) );   \n"	
			"float NdotI = max(dot(N, vec3(0.0, 0.0, 1.0)), 0.0);"
			"vec3 diffuseL = vec3(1.0,1.0,1.0) * NdotL * 0.5;\n"
			"float ratio = (1.0 - clamp((1.0 - NdotI), 0.13, 0.3));\n"
			"	gl_FragColor.rgb = TexColor1.rgb * (0.87) + TexColor2.rgb * (1.0 -ratio) + specular;// + diffuseL * max(1.3 - vAlpha, 0.0);\n"
			//"	gl_FragColor.rgb = vec3(0.1,0.1,0.1);//TexColor1.rgb * (0.87) + TexColor2.rgb * (1.0 -ratio) + specular;// + diffuseL * max(1.3 - vAlpha, 0.0);\n"
			"gl_FragColor.a = 1.0;\n"
			"}\n";

// 		// Load the shaders and get a linked program object
// 		m_pShaderMng->createProgram(Water_VertexShader, Water_FragmentShader);
// 
// 		// Get Background Shader Attribute & Uniform Location
// 		m_pShaderMng->addAttribute(ATTRIBUTE0, "aPosition");
// 		m_pShaderMng->addAttribute(ATTRIBUTE1, "aNormal");
// 
// 		m_pShaderMng->addUniform(UNIFORM0, "uMVPMatrix");
// 		m_pShaderMng->addUniform(UNIFORM1, "uBackgroundTexture");
// 		m_pShaderMng->addUniform(UNIFORM2, "uEnvironmentTexture");
// 		m_pShaderMng->addUniform(UNIFORM3, "uScreenWidth");
// 		m_pShaderMng->addUniform(UNIFORM4, "uScreenHeight");
// 		m_pShaderMng->addUniform(UNIFORM5, "uColor");

		m_nDrawMode = NOMAL_VECTOR_DRAW;
		createShaderProgram(VertexShader, FragmentShader);
	}

	SPVoid SPDrawWater::drawWaterShader_withNormal()
	{
		setShaderArrayMeshVertex("aPosition");
		setShaderArrayMeshNormal("aNormal");
		setShaderUniformMVPMatrix("uMVPMatrix");

		setShaderUnifromTexture("uBackgroundTexture", m_hBackground);
		setShaderUnifromTexture("uEnvironmentTexture", m_hEnvironment);

		setShaderUniformValue("uScreenWidth", (SPFloat) m_nWidth);
		setShaderUniformValue("uScreenHeight", (SPFloat) m_nHeight);
	}

}//namespace SPhysics