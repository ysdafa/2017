/**
* @file SPDrawWater.h
* @brief This file includes module that draws water
*
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.action when mouse down event 
*draw button left to right 
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_DRAW_WATER_H_
#define _SP_DRAW_WATER_H_

#include "SPIRenderer.h"


namespace SPhysics
{
	//! @brief Mode for Drawing line
	typedef enum _DRAW_WATER_MODE
	{
		UNIFORM_COLOR_DRAW,				/*!< drawing with height field vector and uniform color */
		ATTRIBUTE_COLOR_DRAW,			/*!< drawing with height field vector and attribute color */
		NOMAL_VECTOR_DRAW			    /*!< drawing with normal vector */
	}DRAW_WATER_MODE;

	/**
	* @class     SPDrawWater
	* @brief     Draws water
	*/
	class SPDrawWater : public SPIRenderer
	{
	public:
		SPDrawWater();
		~SPDrawWater();
	
	public:

		/**
		* @brief     Initialize and Prepare rendering\n
		(set camera setting, initialize shader , create rectangle mesh)
		* @param     [IN] SPFloat width Clipping Plane's width size
		* @param     [IN] SPFloat height Clipping Plane's height size
		* @return     SPVoid
		*/
		SPVoid initRender(SPFloat width, SPFloat height); // virtual

		/**
		* @brief     Mesh setting & binding shader variables for drawing.
		* @return     SPVoid
		 */
		SPVoid drawRender(); // virtual

		/**
		* @brief Set size of a window 
		* @param [IN] @b nWidth Width size of screen
		* @param [IN] @b nHeight Height size of screen
		* @return    SPVoid
		*/
		SPVoid setScreenSize(const SPUInt &nWidth, const SPUInt &nHeight);

		/**
		* @brief Set texture of object.
		* @param [IN] @b bgFileName Background texture 
		* @param [IN] @b envFileName Enviroment texture 
		* @return    SPVoid
		 */
		SPVoid setTexture(const SPChar* bgFileName, const SPChar* envFileName);

		/**
		* @brief Set drawing mode  \n
		           (0 : draw height + uniform color, 1 : draw height + attribute color, 2 : draw normal + uniform color)
		* @param [IN] @b mode mode value
		*/
		SPVoid setDrawMode(SPInt mode);    // 

	private:
		/**
		* @brief	  Create Vertex and pixel shader
		* @return     SPVoid
		*/
		SPVoid createWaterShader();

		/**
		* @brief	  draw water effect
		* @return     SPVoid
		*/
		SPVoid drawWaterShader();

		/**
		* @brief      Create Vertex and pixel shader( attribute color option )
		* @return     SPVoid
		*/
		SPVoid createWaterAttributeColorShader();

		/**
		* @brief      draw water effect( attribute color option )
		* @return     SPVoid
		*/
		SPVoid drawWaterAttributeColorShader();

		/**
		* @brief	  Create Vertex and pixel shader( with normal option )
		* @return     SPVoid
		*/
		SPVoid createWaterShader_withNormal();

		/**
		* @brief	  draw water effect( with normal option )
		* @return     SPVoid
		*/
		SPVoid drawWaterShader_withNormal();

	private:
		// screen size
		SPUInt m_nWidth;
		SPUInt m_nHeight;

		// Texture Handle
		SPUInt m_hBackground;
		SPUInt m_hEnvironment;

		SPInt m_nDrawMode;		// 0 : drawing with height field vector and uniform color,  
		                        // 1 : drawing with height field vector and attribute color
		                        // 2 : drawing with normal vector
	};

}//namespace SPhysics

#endif //_SP_DRAW_WATER_H_