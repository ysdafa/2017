/**
* @file SPDraw3D.h
* @brief This file includes module that draws rectangle.
*
* @date 2013-02-24
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_DRAW_3D_H_
#define _SP_DRAW_3D_H_

#include "SPDefines.h"
#include "SPIRenderer.h"
#include "SPMesh.h"

#include <glm.hpp>
#include <gtc/type_ptr.hpp>

namespace SPhysics
{
	/**
	* @class     SPDraw3D
	* @brief     Draw 3D object
	*/
	class SPDraw3D : public SPIRenderer
	{
	public:

		/**
		* @brief     Constructor
		*/
		SPDraw3D();
		/**
		* @brief     Destructor
		*/
		~SPDraw3D();

	public:

		/**
		* @brief     Initialize and Prepare rendering\n
		(set camera setting, initialize shader , create rectangle mesh)
		* @param     [IN] SPFloat width Clipping Plane's width size
		* @param     [IN] SPFloat height Clipping Plane's height size
		* @return     SPVoid
		*/
		SPVoid initRender(SPFloat width, SPFloat height); // virtual

		/**
		* @brief     Mesh setting & binding shader variables for drawing.
		* @return     SPVoid
		 */
		SPVoid drawRender(); // virtual

		/**
		* @brief     Set Rectangle Alignment mode \n
					(RECT_ALIGN_CENTER or RECT_ALIGN_LEFT_TOP)
		* @param     [IN] @b align alignment mode
		* @return     SPVoid
		*/
		SPVoid setRectAlign(SPInt align);

		/**
		* @brief     Adjust rectangle mesh size
		* @param     [IN] @b width Rectangle width size
		* @param     [IN] @b height Rectangle height size
		* @return     SPVoid
		*/
		SPVoid setSize(SPFloat width, SPFloat height);

		/**
		* @brief     Set the texture to rectangle
		* @param     [IN] @b fileName File name of texture
		* @param     [IN] @b isMipMapMode The flag whether to use mipmap
		* @return     SPVoid
		*/
		SPVoid setTexture(const SPChar *fileName, SPBool isMipMapMode = SPFALSE);

		/**
		* @brief   Use other platform(android)'s texture
		* @param     [IN] @b fileName File name for texturing.
		* @return     SPVoid
		*/
		//SPVoid setXenTexture(const SPChar *fileName);

		/**
		* @brief     Set texture id for image texturing.
		* @param     [IN] @b texID Texture's ID
		* @return     SPVoid
		*/
		SPVoid setTextureID(SPUInt texID);
		/**
		* @brief     Set cube texture id for image texturing.
		*/
		SPVoid setCubeTextureID(SPUInt texID);

		/**
		* @brief     Set alpha value.
		*/
		SPVoid setAlpha(SPFloat alpha);

		/**
		* @brief     Set light position.
		*/
		SPVoid setLightPosition(const SPFloat& x, const SPFloat& y, const SPFloat& z);
		/**
		* @brief     Set camera position.
		*/
		SPVoid setCameraPosition( const SPFloat& x, const SPFloat& y, const SPFloat& z );
	private:
		/**
		* @brief     Create Texture's UV Coordinates to rendering image
		* @return     SPVoid
		*/
		SPVoid createTextureUV();

		/**
		* @brief     Create rectangle-texturing shader program
		* @return     SPVoid
		*/
		SPVoid createShader();

	private:
		SPUInt m_TextureId;
		SPUInt m_nCubeMapId;
		glm::vec3 m_vLightPos;
		glm::vec3 m_vCameraPos;
	};
}//namespace SPhysics

#endif // _SP_DRAW_3D_OBJ_H_