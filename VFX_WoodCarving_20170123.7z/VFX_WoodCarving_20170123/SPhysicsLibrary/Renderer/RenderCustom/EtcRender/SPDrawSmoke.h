/**
* @file SPDrawSmoke.h
* @brief This file includes module that draws smoke.
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/
#ifndef _SP_DRAW_SMOKE_H_
#define _SP_DRAW_SMOKE_H_

#include "SPDefines.h"
#include "SPShaderManager.h"
#include "SPMVPManager.h"
#include "SPMesh.h"

#include <glm.hpp>

namespace SPhysics
{
	/**
	* @class     SPDrawSmoke
	* @brief     This class is for drawing smoke.
	*/
	class SPDrawSmoke
	{
	public:
		/**
		* @brief     Constructor
		*/
		SPDrawSmoke();
		/**
		* @brief     Destructor
		*/
		~SPDrawSmoke();
		/**
		* @brief     Initialize and Prepare rendering\n
						(set camera setting, initialize shader)
		* @param     [IN] @b width Clipping Plane's width size
		* @param     [IN] @b height Clipping Plane's height size
		* @param     [IN] @b cameraAlign This value determines how to align camera (POSTIVE_CAMERA_ALIGN or CENTER_CAMERA_ALIGN)
		* @return     SPVoid
		*/
		SPVoid init(SPFloat width, SPFloat height, SPInt cameraAlign = POSTIVE_CAMERA_ALIGN);
		/**
		* @brief     Draws the Smoke. Set the values which is essential in rendering \n
						(i.e, the matrix, color, mesh data. etc.)
		* @return     SPVoid
		*/
		SPVoid draw();
		/**
		* @brief     Adjust smoke mesh size
		* @param     [IN] @b width smoke width size
		* @param     [IN] @b height smoke height size
		* @return     SPVoid
		*/
		SPVoid setSize(SPFloat width, SPFloat height);
		/**
		* @brief     Set smoke's color
		* @param     [IN] @b red Red color value of smoke (0~1.f)
		* @param     [IN] @b green Green color value of smoke (0~1.f)
		* @param     [IN] @b blue Blue color value of smoke (0~1.f)
		* @param     [IN] @b alpha Alpha value of smoke (0~1.f)
		* @return     SPVoid
		*/
		SPVoid setColor(SPFloat red, SPFloat green, SPFloat blue, SPFloat alpha);
		/**
		* @brief     Set translated position of smoke
		* @param     [IN] @b x X position 
		* @param     [IN] @b y Y position 
		* @param     [IN] @b z Z position
		* @return     SPVoid
		*/
		SPVoid setTranslate(SPFloat x, SPFloat y, SPFloat z);
		/**
		* @brief     Set the rotation angle and axis of smoke object.
		* @param     [IN] @b angle The angle of rotation
		* @param     [IN] @b x Rotation Axis - X value
		* @param     [IN] @b y Rotation Axis - Y value
		* @param     [IN] @b z Rotation Axis - Z value
		* @return     SPVoid
		*/
		SPVoid setRotate(SPFloat angle, SPFloat x, SPFloat y, SPFloat z);
		/**
		* @brief     Set scale proportions. \n
						(Ref. 1.0 - current value)
		* @param     [IN] @b x X ratio
		* @param     [IN] @b y Y ratio
		* @param     [IN] @b z Z ratio
		* @return     SPVoid
		*/
		SPVoid setScale(SPFloat x, SPFloat y, SPFloat z);
		/**
		* @brief     Set the texture using image file
		* @param     [IN] @b fileName File name of texture
		* @return     SPVoid
		*/
		SPVoid setTexture(SPChar *fileName);
				/**
		* @brief     Set the texture using image file
		* @param     [IN] @b fileName File name of texture
		* @return     SPVoid
		*/
		SPVoid setTexture2(SPChar* fileName);
		/**
		* @brief     Set the texture using memory buffer
		* @param     [IN] @b width Buffer's width size
		* @param     [IN] @b height Buffer's height size
		* @return     SPVoid
		*/
		SPVoid setTextureFromMemory(SPInt width, SPInt height);
		/**
		* @brief     change texture's alpha channel and update partially
		* @param     [IN] @b width texture's width
		* @param     [IN] @b height texture's height
		* @param     [IN] @b data alpha channel values
		* @return     SPVoid
		*/
		SPVoid updateTexture(SPInt width, SPInt height, SPFloat* data);
				/**
		* @brief     change texture's alpha channel and update partially
		* @param     [IN] @b width texture's width
		* @param     [IN] @b height texture's height
		* @param     [IN] @b data alpha channel values
		* @param     [IN] @b data2 alpha channel values 2
		* @return     SPVoid
		*/
		SPVoid updateTexture2(SPInt width, SPInt height, SPFloat* data1, SPFloat* data2);
		/**
		* @brief     Set object's mesh data 
		* @param     [IN] @b mesh Mesh data instance
		* @return     SPVoid
		*/
		SPVoid setMesh( SPMesh* mesh );
	private:
		/**
		* @brief     Create mesh data
		* @param     [IN] @b width Rectangle width size
		* @param     [IN] @b height Rectangle height size
		* @return     SPVoid
		*/
		SPVoid createRectVertex(SPFloat width, SPFloat height);
		/**
		* @brief     Create Texture's UV Coordinates to rendering image
		* @return     SPVoid
		*/
		SPVoid createTextureUV();
		/**
		* @brief     Create Texture's UV Coordinates to rendering image. Set scaling using parameter
		* @param     [IN] @b widht UV's Grid width size
		* @param     [IN] @b height UV's Grid height size
		* @return     SPVoid
		*/
		SPVoid createTextureUV(SPInt widht, SPInt height);
		/**
		* @brief     Create rectangle-color shader program 
		* @return     SPVoid
		*/
		SPVoid createRectColorShader();
		/**
		* @brief     Create rectangle-texturing shader program 
		* @return     SPVoid
		*/
		SPVoid createRectTextureShader();
	private:
		SPMesh* m_pMesh;
		SPMVPManager* m_pMVPMG;
		SPShaderManager* m_pShaderMG;
		SPUInt   m_TextureId;		
		SPUInt   m_TextureId2;		
		SPUChar* m_pData; // for texture from Memory
		SPVec4f  m_ObjectColor;		
		SPInt    m_nDrawMode;			// 0 : Color Draw, 1 : Texture Draw
	};
}//namespace SPhysics
#endif //_SP_DRAW_SMOKE_H_