/**
* @file SPDrawBlurFilter.cpp
* @brief 
*
* @date 2013-10-24
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPTextureManager.h"
#include "SPDrawBlurFilter.h"


namespace SPhysics
{
	SPDrawBlurFilter::SPDrawBlurFilter() : m_pMesh(SPNULL), m_TextureId(0)
	{
	}

	SPDrawBlurFilter::~SPDrawBlurFilter()
	{
		SP_SAFE_DELETE(m_pMesh);
	}

	SPVoid SPDrawBlurFilter::initRender( SPFloat width, SPFloat height )
	{
		setOrthogonalCameraView(0.0f, width, 0.0f, height, -5000, 5000.0f);

		// create shader program and atrribute, uniform location
		createRectTextureShader();

		createRectVertex(width, height);		
		createTextureUV();
		m_vInvResolution = SPVec2f(1.0f / width, 1.0f / height);
	}

	SPVoid SPDrawBlurFilter::drawRender()
	{
		setShaderArrayMeshVertex("aPosition");
		setShaderUniformMVPMatrix("uMVPMatrix");

		setShaderArrayMeshUV("aTexUV");
		setShaderUnifromTexture("uTexMap", m_TextureId);
		setShaderUniformVector("uInvResolution", &m_vInvResolution[0], 2);

		setDrawElementsWithOption(SPhysics::DRAW_TRIANGLES_STRIP);
	}	

	SPVoid SPDrawBlurFilter::setTextureID(SPUInt texID)
	{
		m_TextureId = texID;
	}

	SPVoid SPDrawBlurFilter::createRectVertex( SPFloat width, SPFloat height )
	{

		if(m_pMesh == SPNULL)
			m_pMesh = new SPMesh();

		m_pMesh->m_tVertex.clear();

		//     P3                  P4
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1                  P2

		SPVec3f vertex;

		// point 1
		vertex = SPVec3f(0.0f, 0.0f, 0.0f);
		m_pMesh->m_tVertex.push_back(vertex);

		// point 2
		vertex = SPVec3f(width, 0.0f, 0.0f);
		m_pMesh->m_tVertex.push_back(vertex);

		// point 3
		vertex = SPVec3f(0.0f, height, 0.0f);
		m_pMesh->m_tVertex.push_back(vertex);

		// point 4
		vertex = SPVec3f(width, height, 0.0f);
		m_pMesh->m_tVertex.push_back(vertex);

		//create rect vertex index
		m_pMesh->m_tVertexIndex.clear();
		m_pMesh->m_tVertexIndex.push_back(0);
		m_pMesh->m_tVertexIndex.push_back(1);
		m_pMesh->m_tVertexIndex.push_back(2);
		m_pMesh->m_tVertexIndex.push_back(3);

		setMesh(m_pMesh);
	}

	SPVoid SPDrawBlurFilter::createTextureUV()
	{
		// Rect Vertex
		//     P3(0,0)            P4(1,0)
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1(0,1)            P2(1.1)

		m_pMesh->m_tTextureUV.clear();
		SPVec3f textureUV;

		textureUV = SPVec3f(0.0f, 0.0f, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);

		textureUV = SPVec3f(1.0f, 0.0f, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);

		textureUV = SPVec3f(0.0f, 1.0f, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);

		textureUV = SPVec3f(1.0f, 1.0f, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);

		setMesh(m_pMesh);
	}

	SPVoid SPDrawBlurFilter::createRectTextureShader()
	{
		// Shader Program for DrawRect
		SPChar VertexShader[] =  
			"uniform mediump mat4 uMVPMatrix;				    \n"
			"attribute vec4 aPosition;						    \n"
			"attribute vec2 aTexUV;						        \n"
			"varying vec2 vTexUV;							    \n"
			"void main()									    \n"
			"{												    \n"
			"   vTexUV = vec2(aTexUV.x, aTexUV.y);			\n"
			"   gl_Position = uMVPMatrix * aPosition;		    \n"
			"}												    \n";

		SPChar FragmentShader[] =  
			"precision highp float;                                              \n"			
			"uniform sampler2D uTexMap;                                          \n"
			"uniform vec2 uInvResolution;                                          \n"
			"varying vec2 vTexUV;								                 \n"

			"void main()                                                         \n"
			"{                                                                   \n"
			"float offset[8];                                                    \n"
			"	offset[0] = 0.0;                                                 \n"
			"	offset[1] = 1.0;                                                 \n"
			"	offset[2] = 2.0;                                                 \n"
			"	offset[3] = 3.0;                                                 \n"
			"	offset[4] = 4.0;                                                 \n"
			"	offset[5] = 5.0;                                                 \n"
			"	offset[6] = 6.0;                                                 \n"
			"	offset[7] = 7.0;                                                 \n"
			
			"float weight[8];                                                    \n"
// 			"	weight[0] = 0.159576912161;                                                 \n"
// 			"	weight[1] = 0.147308056121;                                               \n"			
// 			"	weight[2] = 0.115876621105;                                               \n"
// 			"	weight[3] = 0.0776744219933;                                               \n"
// 			"	weight[4] = 0.0443683338718;                                               \n"
// 			"	weight[5] = 0.0215963866053;                                               \n"
// 			"	weight[6] = 0.00895781211794;                                               \n"
// 			"	weight[7] = 0.0044299121055113265;                                               \n"
"	weight[0] = 0.2;                                                 \n"
"	weight[1] = 0.1;                                               \n"			
"	weight[2] = 0.025;                                               \n"
"	weight[3] = 0.025;                                               \n"
"	weight[4] = 0.025;                                               \n"
"	weight[5] = 0.03333333333;                                               \n"
"	weight[6] = 0.03333333333;                                               \n"
"	weight[7] = 0.03333333333;                                               \n"

			// 3x3
			// "float offset[2];                                                    \n"
			// "	offset[0] = 0.0;                                                 \n"
			// "	offset[1] = 1.0;                                                 \n"
			// "float weight[2];                                                    \n"
			// "	weight[0] = 0.2;                                                 \n"
			// "	weight[1] = 0.1;												\n"
			"vec2 uv = vTexUV;                                                   \n"
			"vec4 current = texture2D(uTexMap, uv);                       \n"
			//"float sum = (current.r + current.g + current.b+ current.a) * 0.25;\n"
			//"vec4 dst;"
			//"float dstSum;                                                     \n"
			"float alpha = current.a ;                                      \n"
			"vec4 tc = current * weight[0];                                      \n"			
			"for (int i = 1; i < 2; i++)                                         \n"
			"{                                                                   \n"
			"	float x = offset[i] * uInvResolution.x;                                     \n"
			"	float y = offset[i] * uInvResolution.y;                                    \n"

			"	tc += texture2D(uTexMap, uv + vec2(0.0, y)) * weight[i];         \n"
			"	tc += texture2D(uTexMap, uv + vec2(0.0, -y)) * weight[i];        \n"

			"	tc += texture2D(uTexMap, uv + vec2(x, 0.0)) * weight[i];         \n"
			"	tc += texture2D(uTexMap, uv + vec2(-x, 0.0)) * weight[i];        \n"

			"	tc += texture2D(uTexMap, uv + vec2(x, y)) * weight[i];           \n"
			"	tc += texture2D(uTexMap, uv - vec2(x, y)) * weight[i];           \n"

			"	tc += texture2D(uTexMap, uv + vec2(x, -y)) * weight[i];          \n"
			"	tc += texture2D(uTexMap, uv - vec2(x, -y)) * weight[i];          \n"
			"}                                                                   \n"
			"	gl_FragColor = vec4(vec3(tc.rgb), alpha);							\n"
			//"	gl_FragColor = tc;							\n"
			// #if 0
			// 			"	vec4 tc = texture2D(uTexMap, uv) * 0.5;                              \n"
			// 			"	float alpha = tc.a * 2.0;		                              \n"
			//  			"	const float x = 1.0 / 720.0;                                     \n"
			//  			"	const float y = 1.0 / 1280.0;                                    \n"
			// 			"	tc += texture2D(uTexMap, uv + vec2(0.0, y)) * 0.125;             \n"
			// 			"	tc += texture2D(uTexMap, uv + vec2(0.0, -y)) * 0.125;            \n"
			// 			"	tc += texture2D(uTexMap, uv + vec2(x, 0.0)) * 0.125;             \n"
			// 			"	tc += texture2D(uTexMap, uv + vec2(-x, 0.0)) * 0.125;            \n"
			// // 			"	tc += texture2D(uTexMap, uv + vec2(x, y)) * 0.125;               \n"
			// // 			"	tc += texture2D(uTexMap, uv - vec2(x, y)) * 0.125;               \n"
			// // 			"	tc += texture2D(uTexMap, uv + vec2(x, -y)) * 0.125;             \n"
			// // 			"	tc += texture2D(uTexMap, uv - vec2(x, -y)) * 0.125;             \n"
			// 
			// #else
			// 			"	vec4 tc = texture2D(uTexMap, uv) * 0.2;                              \n"
			// 			"	float alpha = tc.a * 5.0;		                              \n"
			// 			"	const float x = 1.0 / 720.0;                                     \n"
			// 			"	const float y = 1.0 / 1280.0;                                    \n"
			// 			"	tc += texture2D(uTexMap, uv + vec2(0.0, y)) * 0.1;             \n"
			// 			"	tc += texture2D(uTexMap, uv + vec2(0.0, -y)) * 0.1;            \n"
			// 			"	tc += texture2D(uTexMap, uv + vec2(x, 0.0)) * 0.1;             \n"
			// 			"	tc += texture2D(uTexMap, uv + vec2(-x, 0.0)) * 0.1;            \n"
			// 			"	tc += texture2D(uTexMap, uv + vec2(x, y)) * 0.1;               \n"
			// 			"	tc += texture2D(uTexMap, uv - vec2(x, y)) * 0.1;               \n"
			// 			"	tc += texture2D(uTexMap, uv + vec2(x, -y)) * 0.1;             \n"
			// 			"	tc += texture2D(uTexMap, uv - vec2(x, -y)) * 0.1;             \n"
			// #endif
			//			"	gl_FragColor = vec4(vec3(tc.r), alpha);												\n"
			"}																	\n";

		createShaderProgram(VertexShader, FragmentShader);
	}

}//namespace SPhysics
