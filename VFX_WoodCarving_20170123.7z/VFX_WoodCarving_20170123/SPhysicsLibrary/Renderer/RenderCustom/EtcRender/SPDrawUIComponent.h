/**
* @file SPDrawUIComponent.h
* @brief This file includes module that represent triangle
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_DRAW_UI_COMPONENT_H_
#define _SP_DRAW_UI_COMPONENT_H_

#include "SPDefines.h"
#include "SPIRenderer.h"

#include <glm.hpp>

namespace SPhysics
{
	/**
	* @class     SPDrawUIComponent
	* @brief	 Draw SPDrawUIComponent
	*/
	class SPDrawUIComponent : public SPIRenderer
	{

	public:
		SPDrawUIComponent();
		~SPDrawUIComponent();

	public:
		/**
		* @brief     Initialize and Prepare rendering\n
		(set camera setting, initialize shader , create rectangle mesh)
		* @param     [IN] SPFloat width Clipping Plane's width size
		* @param     [IN] SPFloat height Clipping Plane's height size
		* @return     SPVoid
		*/
		SPVoid initRender(SPFloat width, SPFloat height); // virtual

		/**
		* @brief     Mesh setting & binding shader variables for drawing.
		* @return     SPVoid
		 */
		SPVoid drawRender(); // virtual


		/**
		* @brief Set texture of object
		* @param [IN] @b fileName File path of object texture 
		* @param [IN] @b isMipMapMode Mipmap mode select
		* @return    SPVoid
		*/
		SPVoid setTexture(const SPChar *fileName, SPBool isMipMapMode = SPFALSE);

		/**
		* @brief Change texture of object
		* @param [IN] @b fileName File path of object texture 
		* @return    SPVoid
		*/
		SPVoid changeTexture( const SPChar *fileName);

		/**
		* @brief   Use other platform(android)'s texture  
		* @param     [IN] @b fileName File name for texturing. 
		* @return     SPVoid
		*/
		//SPVoid setXenTexture(const SPChar *fileName);

		SPVoid setbPerspective( SPBool _b ){ m_bPerspective = _b; }


	private:
		/**
		* @brief	 Create Vertex and pixel shader( texture apply option )
		* @return    SPVoid
		*/
		SPVoid createTriangleTextureShader();


	private:
		SPUInt m_TextureId;

		SPUInt	uniform0, uniform1, uniform2, uniform3;
		SPUInt	attribute0, attribute1, attribute2, attribute3;

		SPBool m_bPerspective;
	};

	class SPDrawUIComponentBackground : public SPIRenderer
	{
	public:
		SPDrawUIComponentBackground();
		~SPDrawUIComponentBackground();
		/**
		* @brief     Init render data
		* @return     SPVoid
		*/
		SPVoid initRender(SPFloat width, SPFloat height); // virtual

		/**
		* @brief     Mesh setting & binding shader variables for drawing.
		* @return     SPVoid
		*/
		SPVoid drawRender(); // virtual

		/**
		* @brief     Set vertice's position which is used to construct rectangle.
		* @param     [IN] @b x X Position
		* @param     [IN] @b y Y Position
		* @param     [IN] @b z Z Position
		* @return     SPVoid
		*/
		SPVoid setPosition(SPFloat x, SPFloat y, SPFloat z = 0);

		/**
		* @brief     Set Rectangle Alignment mode \n
		(RECT_ALIGN_CENTER or RECT_ALIGN_LEFT_TOP)
		* @param     [IN] @b align alignment mode
		* @return     SPVoid
		*/
		SPVoid setRectAlign(SPInt align);

		/**
		* @brief     Adjust rectangle mesh size
		* @param     [IN] @b width Rectangle width size
		* @param     [IN] @b height Rectangle height size
		* @return     SPVoid
		*/
		SPVoid setSize(SPFloat width, SPFloat height);

		/**
		* @brief     Set the texture to rectangle
		* @param     [IN] @b fileName File name of texture
		* @param     [IN] @b isMipMapMode The flag whether to use mipmap 
		* @return     SPVoid
		*/
		SPVoid setTexture(const SPChar *fileName, SPBool isMipMapMode = SPFALSE);

		/**
		* @brief   Use other platform(android)'s texture  
		* @param     [IN] @b fileName File name for texturing. 
		* @return     SPVoid
		*/
		//SPVoid setXenTexture(const SPChar *fileName);

		/**
		* @brief     Set texture id for image texturing.
		* @param     [IN] @b texID Texture's ID
		* @return     SPVoid
		*/
		SPVoid setTextureID(SPUInt texID);

		/**
		* @brief   Use other platform(android)'s font texture  
		* @param     [IN] @b fileName File name for font texturing. 
		* @return     SPVoid
		*/
		SPVoid setFontTexture(const SPChar *fileName);

		/**
		* @brief   Flip Texture V Coordinate		
		* @return     SPVoid
		*/
		SPVoid flipTextureV();
	private:
		/**
		* @brief     Create mesh data
		* @param     [IN] @b width Rectangle width size
		* @param     [IN] @b height Rectangle height size
		* @return     SPVoid
		*/
		SPVoid createRectVertex(SPFloat width, SPFloat height);

		/**
		* @brief     Create Texture's UV Coordinates to rendering image
		* @return     SPVoid
		*/
		SPVoid createTextureUV();

		/**
		* @brief     Create rectangle-color shader program 
		* @return     SPVoid
		*/
		SPVoid createRectColorShader();

		/**
		* @brief     Create rectangle-texturing shader program 
		* @return     SPVoid
		*/
		SPVoid createRectTextureShader();

		/**
		* @brief     Create rectangle-font shader program 
		* @return     SPVoid
		*/
		SPVoid createRectFontShader();

	public:
		/**
		* @brief     Set depth
		*/
		SPVoid setDepth(SPFloat _z);
	private:
		SPMesh* m_pMesh;

		SPVec3f  m_ObjectPosition;
		SPUInt   m_TextureId;
		SPInt    m_nDrawMode;			// 0 : Color Draw, 1 : Texture Draw
		SPInt    m_nRectAlign;
		SPInt    m_nRectWidth;
		SPInt    m_nRectHeight;
	};
}//namespace SPhysics

#endif //_SP_DRAW_TRIANGLE_H_