/**
* @file SPDrawObjMesh.cpp
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPLog.h"
#include "SPDrawObjMesh.h"
#include "SPTextureManager.h"



namespace SPhysics
{
	/** choose draw type, can draw object using VBO and OBJ Loader on DRAW_OBJ_MESH mode */
	#define  DRAW_OBJ_MESH true


	SPDrawObjMesh::SPDrawObjMesh() : m_fTextureStep(SPFloat()), m_ScreenWidth(720), m_ScreenHeight(1280), m_BubbleRadius(1), m_pMVP(SPNULL), m_pShader(SPNULL), m_pOBJMesh(SPNULL), m_hBackground(0), m_hSkymap(0)
	{
		glGenBuffers(1, &v_buf);
		glGenBuffers(1, &n_buf);
		glGenBuffers(1, &i_buf);
		glGenBuffers(1, &t_buf);
	}


	SPDrawObjMesh::~SPDrawObjMesh()
	{
		SP_SAFE_DELETE(m_pMVP);
		SP_SAFE_DELETE(m_pShader);
		SP_SAFE_DELETE(m_pOBJMesh);

		glDeleteBuffers(1, &v_buf);
		glDeleteBuffers(1, &n_buf);
		glDeleteBuffers(1, &i_buf);
		glDeleteBuffers(1, &t_buf);
	}

	SPVoid SPDrawObjMesh::init( SPFloat width, SPFloat height, SPInt cameraAlign /*= POSTIVE_CAMERA_ALIGN*/ )
	{
		if(m_pMVP == SPNULL)
			m_pMVP = new SPMVPManager();

		// Init Matrix
		m_pMVP->setLookAt(0.0f, 0.0f, 1.0f, 0.0f, 0.0f, -100.0f, 0.0f, 1.0f, 0.0f);
		m_pMVP->setOrtho( 0.0f, width, 0.0f, height, -500, 500.0f);
//		float aspect = width / height;

		//m_pMVP->setPerspective(60.0f,aspect,-1000.0f,1000.0f);
		//m_pMVP->setFrustum(0.0f, width, 0.0f, height, -500, 500);
		// create shader program and atrribute, uniform location
		createShader();

		createMesh();
	}

	SPVoid SPDrawObjMesh::draw()
	{
		glDisable (GL_DEPTH_TEST);
		glEnable (GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

		glUseProgram(m_pShader->getProgram());

		

		// set vertex position
#ifndef DRAW_OBJ_MESH
		glBindBuffer(GL_ARRAY_BUFFER, v_buf);
		glBufferData(GL_ARRAY_BUFFER, sizeof(arrBubbleVertex), arrBubbleVertex, GL_STATIC_DRAW);
		glVertexAttribPointer(m_pShader->getAttribute(ATTRIBUTE0), 3, GL_FLOAT, SPFALSE, 0, 0);
		glEnableVertexAttribArray(m_pShader->getAttribute(ATTRIBUTE0));
#else
		glVertexAttribPointer(m_pShader->getAttribute(ATTRIBUTE0), 3, GL_FLOAT, GL_FALSE, 3 * sizeof(SPFloat),  &m_pOBJMesh->getTriangleMesh()->m_tVertex[0]);
		glEnableVertexAttribArray(m_pShader->getAttribute(ATTRIBUTE0));
#endif

		// set vertex  normal
#ifndef DRAW_OBJ_MESH
		glBindBuffer(GL_ARRAY_BUFFER, n_buf);
		glBufferData(GL_ARRAY_BUFFER, sizeof(arrBubbleVertex), arrBubbleNormal, GL_STATIC_DRAW);
		glVertexAttribPointer(m_pShader->getAttribute(ATTRIBUTE1), 3, GL_FLOAT, SPFALSE, 0, 0);
		glEnableVertexAttribArray(m_pShader->getAttribute(ATTRIBUTE1));
#else
		glVertexAttribPointer(m_pShader->getAttribute(ATTRIBUTE1), 3, GL_FLOAT, GL_FALSE, 3 * sizeof(SPFloat), &m_pOBJMesh->getTriangleMesh()->m_tNormal[0]);
		glEnableVertexAttribArray(m_pShader->getAttribute(ATTRIBUTE1));
#endif

		// set vertex texture
#ifndef DRAW_OBJ_MESH
		glBindBuffer(GL_ARRAY_BUFFER, t_buf);
		glBufferData(GL_ARRAY_BUFFER, sizeof(arrBubbleTexcoord), arrBubbleTexcoord, GL_STATIC_DRAW);
		glVertexAttribPointer(m_pShader->getAttribute(ATTRIBUTE2), 3, GL_FLOAT, SPFALSE, 0, 0);
		glEnableVertexAttribArray(m_pShader->getAttribute(ATTRIBUTE2));
		glBindBuffer(GL_ARRAY_BUFFER, 0);
#else
		glVertexAttribPointer(m_pShader->getAttribute(ATTRIBUTE2), 3, GL_FLOAT, GL_FALSE, 3 * sizeof(SPFloat), &m_pOBJMesh->getTriangleMesh()->m_tTextureUV[0]);
		glEnableVertexAttribArray(m_pShader->getAttribute(ATTRIBUTE2));
#endif
		glUniformMatrix4fv(m_pShader->getUniform(UNIFORM0), 1, SPFALSE, m_pMVP->getMVPMatrix());
		glUniformMatrix4fv(m_pShader->getUniform(UNIFORM1), 1, SPFALSE, m_pMVP->getMVMatrix());

		glBindTexture(GL_TEXTURE_CUBE_MAP, m_hSkymap);
		glActiveTexture (GL_TEXTURE0);
		glUniform1i(m_pShader->getUniform(UNIFORM2), 0);


		glUniform1f(m_pShader->getUniform(UNIFORM3), m_ScreenWidth);
		glUniform1f(m_pShader->getUniform(UNIFORM4), m_ScreenHeight);


#ifndef DRAW_OBJ_MESH
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, i_buf);
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(arrBubbleIndex), arrBubbleIndex, GL_STATIC_DRAW);
		glDrawElements(GL_TRIANGLES, sizeof(arrBubbleIndex) / 2, GL_UNSIGNED_SHORT, 0);
#else
		//glDrawArrays(GL_TRIANGLES, 0, m_pOBJMesh->getNumOfFaces() * 3);
		glDrawArrays(GL_TRIANGLES, 0, m_pOBJMesh->getTriangleMesh()->getNumOfVertex());
#endif

		glDisableVertexAttribArray(m_pShader->getAttribute(ATTRIBUTE0));
		glDisableVertexAttribArray(m_pShader->getAttribute(ATTRIBUTE1));
		glDisableVertexAttribArray(m_pShader->getAttribute(ATTRIBUTE2));
#ifndef DRAW_OBJ_MESH
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
#endif
	}

	SPVoid SPDrawObjMesh::setTranslate( SPFloat x, SPFloat y, SPFloat z )
	{
		if(m_pMVP != SPNULL)
			m_pMVP->setTranslate(x, (SPFloat) y, z);
	}

	SPVoid SPDrawObjMesh::setRotate( SPFloat angle, SPFloat x, SPFloat y, SPFloat z )
	{
		if(m_pMVP != SPNULL)
			m_pMVP->setRotate(angle, x, y, z);
	}

	SPVoid SPDrawObjMesh::setScale( SPFloat x, SPFloat y, SPFloat z )
	{
		if(m_pMVP != SPNULL)
			m_pMVP->setScale(x, y, z);
	}

	SPVoid SPDrawObjMesh::setScreenSize( SPFloat width, SPFloat height )
	{
		m_ScreenWidth = width;
		m_ScreenHeight = height;
	}

	SPVoid SPDrawObjMesh::setTexture(const SPChar* bgFileName)
	{
		m_hBackground = SPTextureManager::getInstancePtr()->loadTexture(bgFileName);

		setRainBowTexture();
	}


	SPVoid SPDrawObjMesh::createShader()
	{
#if 0
		const SPChar VertexShader[] = 
			"attribute vec4 aPosition;\n"
			"attribute vec3 aNormal;						\n"
			"attribute vec2 aTexcoord;						\n"
			"uniform mat4 uMVPMatrix;						\n"
			"uniform mat4 uMVMatrix;						\n"
			"varying vec3 vNormal;							\n"
			"varying vec3 vViewVec;							\n"
			"varying vec2 vTexcoord;						\n"
			"varying float vHeight;							\n" // z 0.0011
			"void main()									\n"
			"{												\n"
			"	vNormal = aNormal;							\n"
			"	vViewVec = vec3(0.225, 0.4, 1.0) - (uMVMatrix * aPosition).xyz;\n"
			"	vHeight = aPosition.z;						\n"
			"	vTexcoord = aTexcoord;						\n"
			"	gl_Position = uMVPMatrix * aPosition;		\n"
			"}												\n";

		const SPChar FragmentShader[] = 
			"precision mediump float;\n"
			"varying vec3 vNormal;											\n"
			"varying vec3 vViewVec;											\n"
			"varying vec2 vTexcoord;										\n"
			"varying float vHeight;											\n"
			"uniform sampler2D uTextureBackground;							\n"
			"uniform sampler2D uTextureRainbow;								\n"
			"uniform samplerCube uTextureSkymap;							\n"
			"uniform float uWidth;											\n"
			"uniform float uHeight;											\n"
			"uniform float uTextureTimeStep;								\n"
			"uniform float uRadius;											\n"
			"void main() {													\n"
			"	float NdotHV;												\n"
			"	vec4 color = vec4(0.0, 0.0, 0.0, 0.0);						\n"		
			"	vec3 N = normalize(vNormal);								\n"
			"	vec4 RainbowColor = texture2D(uTextureRainbow, vec2(vTexcoord.x + uTextureTimeStep + uRadius, vTexcoord.y + uTextureTimeStep + uRadius ));"
			//	sqrt must be improved
			"	float NdotI = sqrt(dot(N, vViewVec));						\n"
			"	float angle = (gl_FragCoord.x / uWidth + gl_FragCoord.y / uHeight )* 12.0;\n"
			"	mat3 rotateMatrix = mat3(cos(angle), 0, -sin(angle), 0, 1, 0, sin(angle), 0, cos(angle));"	//y
			"	vec3 test = rotateMatrix * -normalize(vViewVec);			\n"
			"	vec3 test1 = rotateMatrix * N;								\n"
			"	vec3 reflect = reflect( test, test1);						\n"
			"	vec4 ReflectionColor = textureCube(uTextureSkymap, reflect );\n"
			"	gl_FragColor =  max((0.45 - vHeight) + 0.2, 0.0) * (RainbowColor)  + (ReflectionColor - max((0.1 - vHeight),0.0) * 2.5  ) * 0.9;\n"//  +  0.15 * RefractionColor * min((pow(NdotI, 2.0)), 1.0)
			"	gl_FragColor.xyz += vec3(0.1, 0.1, 0.15);					\n"
			"	gl_FragColor.a = max((0.3 - vHeight), 0.0) + max(max(ReflectionColor.r, ReflectionColor.g),ReflectionColor.b)-0.1;\n;"		
			"}																\n";	

#endif

		const SPChar VertexShader[] = 
			"attribute vec4 aPosition;\n"
			"attribute vec3 aNormal;						\n"
			"attribute vec2 aTexcoord;						\n"
			"uniform mat4 uMVPMatrix;						\n"
			"uniform mat4 uMVMatrix;						\n"
			"varying vec3 vNormal;							\n"
			"varying vec3 vViewVec;							\n"
			"varying vec2 vTexcoord;						\n"
			"varying float vHeight;							\n" // z 0.0011
			"void main()									\n"
			"{												\n"
			"	vNormal = aNormal;							\n"
			"	vViewVec = vec3(0.225, 0.4, 1.0) - (uMVMatrix * aPosition).xyz;\n"
			"	vHeight = aPosition.z;						\n"
			"	vTexcoord = aTexcoord;						\n"
			"	gl_Position = uMVPMatrix * aPosition;		\n"
			"}												\n";

		const SPChar FragmentShader[] = 
			"precision mediump float;\n"
			"varying vec3 vNormal;											\n"
			"varying vec3 vViewVec;											\n"
			"varying vec2 vTexcoord;										\n"
			"varying float vHeight;											\n"
			"uniform sampler2D uTextureBackground;							\n"
			"uniform samplerCube uTextureSkymap;							\n"
			"uniform float uWidth;											\n"
			"uniform float uHeight;											\n"
			"void main() {													\n"
			"	float NdotHV;												\n"
			"	vec4 color = vec4(0.0, 0.0, 0.0, 0.0);						\n"		
			"	vec3 N = normalize(vNormal);								\n"
			//	sqrt must be improved
			"	float NdotI = sqrt(dot(N, vViewVec));						\n"
			"	float angle = (gl_FragCoord.x / uWidth + gl_FragCoord.y / uHeight )* 12.0;\n"
			"	mat3 rotateMatrix = mat3(cos(angle), 0, -sin(angle), 0, 1, 0, sin(angle), 0, cos(angle));"	//y
			"	vec3 test = rotateMatrix * -normalize(vViewVec);			\n"
			"	vec3 test1 = rotateMatrix * N;								\n"
			"	vec3 reflect = reflect( test, test1);						\n"
			"	vec4 ReflectionColor = textureCube(uTextureSkymap, reflect );\n"
			"	gl_FragColor =  (ReflectionColor - max((0.1 - vHeight),0.0) * 2.5  ) * 0.9;\n"//  +  0.15 * RefractionColor * min((pow(NdotI, 2.0)), 1.0)
			"	gl_FragColor.xyz += vec3(0.1, 0.1, 0.15);					\n"
			"	gl_FragColor.a = max((0.3 - vHeight), 0.0) + max(max(ReflectionColor.r, ReflectionColor.g),ReflectionColor.b)-0.1;\n;"		
			"}	                                                            \n";	

		if(m_pShader == SPNULL)
			m_pShader = new SPShaderManager();

		// Load the shaders and get a linked program object
		m_pShader->createProgram(VertexShader, FragmentShader);

		// Get Bubble Shader Attribute & Uniform Location
		m_pShader->addAttribute(ATTRIBUTE0, "aPosition");
		m_pShader->addAttribute(ATTRIBUTE1, "aNormal");
		m_pShader->addAttribute(ATTRIBUTE2, "aTexcoord");


		m_pShader->addUniform(UNIFORM0, "uMVPMatrix");
		m_pShader->addUniform(UNIFORM1, "uMVMatrix");
		m_pShader->addUniform(UNIFORM2, "uTextureSkymap");
		m_pShader->addUniform(UNIFORM3, "uWidth");
		m_pShader->addUniform(UNIFORM4, "uHeight");
	}

	SPVoid SPDrawObjMesh::createMesh()
	{
		if(m_pOBJMesh == SPNULL)
			m_pOBJMesh = new SPOBJLoader();

		m_pOBJMesh->createOBJMesh("teapot.obj");
	}

	SPVoid SPDrawObjMesh::setRainBowTexture()
	{
		m_hSkymap = SPTextureManager::getInstancePtr()->loadCubeTexture("posx.png","negx.png","posy.png","negy.png","posz.png","negz.png");
	}

}//namespace SPhysics