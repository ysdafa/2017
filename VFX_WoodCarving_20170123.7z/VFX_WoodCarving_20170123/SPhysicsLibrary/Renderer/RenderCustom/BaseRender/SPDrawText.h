/**
* @file SPDrawText.h
* @brief This file includes module that represent text
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_DRAW_TEXT_H_
#define _SP_DRAW_TEXT_H_

#include "SPDefines.h"
#include "SPMesh.h"
#include "SPDrawRect.h"

#include <string>
#include <glm.hpp>

namespace SPhysics
{

	/**
	* @class     SPDrawText
	* @brief     Draw text
	*/
	class SPDrawText
	{

	public:
		SPDrawText();
		~SPDrawText();

	public:
		/**
		* @brief Class Initialization 
		* @param [IN] @b width  Width size of viewport
		* @param [IN] @b height Height size of viewport
		* @return    SPVoid
		*/
		SPVoid initialize(SPFloat width, SPFloat height);

		/**
		* @brief Draws object. Set different options, depending on the setting of the shader and mesh data
		* @return     SPVoid
		*/
		SPVoid draw();

		/**
		* @brief Set color of object  
		* @param [IN] @b red Red color value of  object
		* @param [IN] @b green  Green color value of  object
		* @param [IN] @b blue Blue color value of  object
		* @param [IN] @b alpha  Aplah value of  object
		* @return    SPVoid
		*/
		SPVoid setColor(SPFloat red, SPFloat green, SPFloat blue, SPFloat alpha);

		/**
		* @brief Set translate position of object. 
		* @param [IN] @b x X position 
		* @param [IN] @b y Y position 
		* @param [IN] @b z Z position 
		* @return    SPVoid
		*/
		SPVoid setTranslate(SPFloat x, SPFloat y, SPFloat z);

		/**
		* @brief Set rotation angle of object. 
		* @param [IN] @b Angle object will be rotated to any angle
		* @param [IN] @b x X rotation axis
		* @param [IN] @b y Y rotation axis
		* @param [IN] @b z Z rotation axis
		* @return    SPVoid
		*/
		SPVoid setRotate(SPFloat angle, SPFloat x, SPFloat y, SPFloat z);

		/**
		* @brief Set size of object. 
		* @param [IN] @b x X Size 
		* @param [IN] @b y Y Size 
		* @param [IN] @b z Z Size 
		* @return    SPVoid
		*/
		SPVoid setScale(SPFloat x, SPFloat y, SPFloat z);

		/**
		* @brief Set content of the text
		* @param [IN] @b drawText Content of the text
		* @return     SPVoid
		*/
		SPVoid setText(const SPChar *drawText);

		/**
		* @brief Set font size
		* @param [IN] @b fontSize Font size
		* @return     SPVoid
		*/
		SPVoid setFontSize(SPFloat fontSize);

	private:
		/**
		* @brief     Create character vertex
		* @param     [IN] @b  charPos character position
		* @return    SPVoid
		*/
		SPVoid createCharacterVertex(SPInt charPos);
		/**
		* @brief     Create character texture UV
		* @param     [IN] @b  asciiIdx UV index
		* @return    SPVoid
		*/
		SPVoid createCharacterTextureUV(SPInt asciiIdx);

	private:
		SPDrawRect* m_pDraw;
		SPMesh* m_pMesh;
		std::string m_pTextBuff;

		SPInt    m_StringLength;
		SPFloat  m_FontWidth;
		SPFloat  m_FontHeight;
	};

}//namespace SPhysics

#endif //_SP_DRAW_TEXT_H_