/**
* @file SPDrawLine.cpp
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/


#include "SPDrawLine.h"


namespace SPhysics
{
	SPDrawLine::SPDrawLine() : m_nDrawMode(0), m_bDrawArray(SPTRUE)
	{
	}

	SPDrawLine::~SPDrawLine()
	{
	}

	SPVoid SPDrawLine::initRender( SPFloat width, SPFloat height )
	{
		// create shader program and atrribute, uniform location
		createLineShader();

		setOrthogonalCameraView(0.0f, width, 0.0f, height, -5000, 5000.0f);
		//setOrthogonalCameraView( -width * 0.5f, width * 0.5f, -height * 0.5f, height * 0.5f, -5000.0f, 5000.0f);

	}

	SPVoid SPDrawLine::drawRender()
	{
		setShaderArrayMeshVertex("aPosition");
		setShaderUniformMVPMatrix("uMVPMatrix");
		setShaderUnformColor("uColor");

		if (m_bDrawArray == SPTRUE)
		{
			switch (m_nDrawMode)
			{
			case SHAPE_LINES:
				setDrawArraysWithOption(SPhysics::DRAW_LINES);
				break;
			case SHAPE_LINE_STRIP:
				setDrawArraysWithOption(SPhysics::DRAW_LINE_STRIP);
				break;
			case SHAPE_LINE_LOOP:
				setDrawArraysWithOption(SPhysics::DRAW_LINE_LOOP);
				break;
			}
		}
		else
		{
			switch (m_nDrawMode)
			{
			case SHAPE_LINES:
				setDrawElementsWithOption(SPhysics::DRAW_LINES);
				break;
			case SHAPE_LINE_STRIP:
				setDrawElementsWithOption(SPhysics::DRAW_LINE_STRIP);
				break;
			case SHAPE_LINE_LOOP:
				setDrawElementsWithOption(SPhysics::DRAW_LINE_LOOP);
				break;
			}
		}
		
	}

	SPVoid SPDrawLine::createLineShader()
	{
		// Shader Program for DrawLine
		SPChar VertexShader[] =  
			"uniform mediump mat4 uMVPMatrix;			\n"
			"attribute vec4 aPosition;					\n"
			"void main()								\n"
			"{											\n"
			"   gl_Position = uMVPMatrix * aPosition; \n"			
			"}											\n";

		SPChar FragmentShader[] =  
			"precision mediump float;                           \n"
			"uniform vec4 uColor;								\n"
			"void main()                                        \n"
			"{                                                  \n"
			"   gl_FragColor = uColor;							\n"
			"}                                                  \n";

		m_nDrawMode = SHAPE_LINES;

		createShaderProgram(VertexShader, FragmentShader);
		
	}

	// mode ::  0 : draw lines, 1 : draw line strip, 2 : draw line loop
	SPVoid SPDrawLine::setDrawMode( SPInt mode )
	{
		m_nDrawMode = mode;
	}

	SPVoid SPDrawLine::setDrawArray(SPBool bEnable)
	{
		m_bDrawArray = bEnable;
	}
}//namespace SPhysics
