/**
* @file SPDrawObject.cpp
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPTextureManager.h"
#include "SPDrawObject.h"
#include "SPLog.h"


namespace SPhysics
{
	SPShaderManager*		SPDrawObject::m_pShader = NULL;;
	SPLightProperty*		SPDrawObject::m_pLight = NULL;;

	SPDrawObject::SPDrawObject(void) : m_pMVP(NULL), mMesh(NULL), m_TextureId(-1), m_RenderMode(0)
	{
	}


	SPDrawObject::~SPDrawObject(void)
	{
		SP_SAFE_DELETE(m_pShader);
		SP_SAFE_DELETE(m_pMVP);
	}

	SPVoid SPDrawObject::init(int width, int height) //= POSTIVE_CAMERA_ALIGN
	{
		if(m_pMVP == SPNULL)
			m_pMVP = new SPMVPManager();

		// Init Matrix
		m_pMVP->setPerspective( 45.0f, float(width) / float(height), 1.0f, 2000.0f);

		if(m_pLight == NULL)
		{
			m_pLight = new SPLightProperty();
		}

		createSpherePhongShading();

		//m_pLight->setLightPosition(400,400,45);

		//m_pLight.setLightPosition(0.4f,0.4f,2.0f);
		m_pLight->setLightDirection(0.0f,-5.0f,-3.0f);
		m_pLight->setLightSpecularColor(0,0,0,0);
		//m_pLight->setLightAmbientColor(0.85,0.85,0.85,1.0);
		//m_pLight->setLightDiffuseColor(0.8,0.8,0.8,1.0);
		//m_pLight.setLightDirection(0.2f,0.2f,-2.0f);
		m_pLight->setLightCutoffAngle(13);
		m_pLight->setLightSpotExp(10.0f);

		m_pLight->setAttenuationProperty(0.5f, 0.3f, 0.1f);
	}

	SPVoid SPDrawObject::setMesh(SPMesh* aMesh)
	{
		mMesh = aMesh;
	}
	
	SPVoid SPDrawObject::setRenderMode(SPUInt aRenderMode)
	{
		m_RenderMode = aRenderMode;
	}

	SPVoid SPDrawObject::setModelMatrix(float* aMatrix)
	{
		m_pMVP->setModelMatrix(aMatrix);
	}

	SPVoid SPDrawObject::setViewMatrix(const float* aMatrix)
	{
		m_pMVP->setViewMatrix(aMatrix);
	}

	SPVoid SPDrawObject::setLookAt(float aEx, float aEy, float aEz, float aCx, float aCy, float aCz, float aUx, float aUy,float aUz)
	{
		m_pMVP->setLookAt(aEx, aEy, aEz, aCx, aCy, aCz, aUx, aUy, aUz);
	}

	SPLightProperty* SPDrawObject::getLight()
	{
		if(m_pLight == NULL)
		{
			m_pLight = new SPLightProperty();
		}

		return m_pLight;
	}

	SPVoid SPDrawObject::draw()
	{
		glEnable (GL_DEPTH_TEST);
		glEnable (GL_CULL_FACE);
		glDisable (GL_BLEND);

		glUseProgram(m_pShader->getProgram());

		// set vertex position
		glVertexAttribPointer(m_pShader->getAttribute(ATTRIBUTE0), 3, GL_FLOAT, GL_FALSE,  3 * sizeof(SPFloat), &mMesh->m_tVertex[0]);
		glEnableVertexAttribArray(m_pShader->getAttribute(ATTRIBUTE0));


		// set vertex  normal
		glVertexAttribPointer(m_pShader->getAttribute(ATTRIBUTE1), 3, GL_FLOAT, GL_FALSE, 3 * sizeof(SPFloat), &mMesh->m_tNormal[0]);
		glEnableVertexAttribArray(m_pShader->getAttribute(ATTRIBUTE1));

		glVertexAttribPointer(m_pShader->getAttribute(ATTRIBUTE2), 3, GL_FLOAT, GL_FALSE, 3 * sizeof(SPFloat), &mMesh->m_tTextureUV[0]);
		glEnableVertexAttribArray(m_pShader->getAttribute(ATTRIBUTE2));

		// Bind the base map
		glActiveTexture ( GL_TEXTURE0 );
		glBindTexture ( GL_TEXTURE_2D, m_TextureId );

		// Set the base map sampler to texture unit to 0
		glUniform1i( m_pShader->getUniform(UNIFORM18), 0 );
		
		glUniformMatrix4fv(m_pShader->getUniform(UNIFORM0), 1, SPFALSE, m_pMVP->getMVPMatrix());
		glUniformMatrix4fv(m_pShader->getUniform(UNIFORM1), 1, SPFALSE, m_pMVP->getMVMatrix());
		//SPFloat campos[3] = {0.1f,0.1f,3.0f};
		SPFloat campos[3] = {0.1f,0.1f,1.0f};
		glUniform3fv(m_pShader->getUniform(UNIFORM2), 1, campos);


		SPFloat materialambientcolor[4] = {1.0f, 1.0f, 1.0f, 1.0f};
		SPFloat materialdiffusecolor[4] = {1.0f, 1.0f, 1.0f, 1.0f};
		SPFloat materialspecularcolor[4] = {1.0f, 1.0f, 1.0f, 1.0f};
		SPFloat materialexponent = 10.0f;
		glUniform4fv(m_pShader->getUniform(UNIFORM3), 1,  materialambientcolor);
		glUniform4fv(m_pShader->getUniform(UNIFORM4), 1,  materialdiffusecolor);
		glUniform4fv(m_pShader->getUniform(UNIFORM5), 1,  materialspecularcolor);
		glUniform1f(m_pShader->getUniform(UNIFORM6), materialexponent);


		glUniform3fv(m_pShader->getUniform(UNIFORM7), 1, m_pLight->getLightPosition());
		//glUniform3fv(m_pShader->getUniform(UNIFORM8), 1, lighthalflane);
		glUniform4fv(m_pShader->getUniform(UNIFORM9), 1, m_pLight->getLightAmbientColor());
		glUniform4fv(m_pShader->getUniform(UNIFORM10), 1, m_pLight->getLightDiffuseColor());
		glUniform4fv(m_pShader->getUniform(UNIFORM11), 1, m_pLight->getLightSpecularColor());

		glUniform1f(m_pShader->getUniform(UNIFORM12), m_pLight->getConstAttenuation());
		glUniform1f(m_pShader->getUniform(UNIFORM13), m_pLight->getLinearAttenuation());
		glUniform1f(m_pShader->getUniform(UNIFORM14), m_pLight->getQuadraticAttenuation());

		glUniform3fv(m_pShader->getUniform(UNIFORM15), 1,  m_pLight->getLightDirection());
		glUniform1f(m_pShader->getUniform(UNIFORM16), m_pLight->getLightCutoffAngle());
		glUniform1f(m_pShader->getUniform(UNIFORM17), m_pLight->getLightSpotExp());


		//glDrawElements(m_RenderMode, mMesh->getNumOfVertexIndex(), GL_UNSIGNED_SHORT, &mMesh->m_tVertexIndex[0]);
		if(mMesh->m_tVertexIndex.empty())
		{
			glDrawArrays(m_RenderMode, 0, mMesh->m_tVertex.size());
		}
		else
		{
			glDrawElements(m_RenderMode, mMesh->getNumOfVertexIndex(), GL_UNSIGNED_SHORT, &mMesh->m_tVertexIndex[0]);
		}

		glDisableVertexAttribArray(m_pShader->getAttribute(ATTRIBUTE0));
		glDisableVertexAttribArray(m_pShader->getAttribute(ATTRIBUTE1));
		glDisableVertexAttribArray(m_pShader->getAttribute(ATTRIBUTE2));
		
	}

	SPVoid SPDrawObject::setTexture(const SPChar* aFileName)
	{
		m_TextureId = SPTextureManager::getInstancePtr()->loadTexture(aFileName);
	}

// 	SPVoid SPDrawObject::setTextureCallback(SPChar* aFileName)
// 	{
// 		//m_TextureId = SPTextureManager::getInstancePtr()->loadTexture(aFileName);
// 		m_TextureId = SPTextureManager::getInstancePtr()->loadTextureCallback(aFileName);
// 	}

	SPVoid SPDrawObject::createSpherePhongShading()
	{
		const char vShaderStr[] =
			"precision mediump float;										\n"
			"struct light_properties {										\n"
			"	vec3 position;												\n"
			"	vec4 ambient_color;											\n"
			"	vec4 diffuse_color;											\n"
			"	vec4 specular_color;										\n"
			"};																\n"
			"struct material_properties {									\n"
			"	vec4 ambient_color;											\n"
			"	vec4 diffuse_color;											\n"
			"	vec4 specular_color;										\n"
			"	float specular_exponent;									\n"
			"};																\n"
			"																\n"
			
			"uniform mat4 uMVPMatrix;										\n"
			"uniform mat4 uMVMatrix;										\n"
			"uniform vec3 ucameraPosition;									\n"
			"uniform material_properties u_material;						\n"
			"uniform light_properties u_light;								\n"
			"																\n"
			"attribute vec4 aPosition;										\n"
			"attribute vec3 aNormal;										\n"
			"																\n"
			"varying vec4 v_Color;											\n"
			"																\n"
			"varying vec4 v_diffuse, v_ambient, v_position;					\n"
			"varying vec3 v_normal, v_lightDir;								\n"
			"																\n"
			"attribute vec2 a_texUV;										\n"
			"varying vec2 v_texUV;											\n"

			"void main() {													\n"
			"																\n"
			"																\n"
			"   v_texUV = a_texUV;							                \n"
			"	v_normal = aNormal;							   			    \n"
			"	v_lightDir = normalize(u_light.position - (uMVMatrix * aPosition).xyz);\n"
			"	// diffuse 												\n"
			"	v_diffuse = u_material.diffuse_color * u_light.diffuse_color;\n"
			"	// ambient 												\n"
			"	v_ambient = u_material.ambient_color * u_light.ambient_color;\n"		
			"																\n"
			"	v_position = uMVMatrix * aPosition;						\n"
			"	gl_Position = uMVPMatrix * aPosition;						\n"
			"}																\n";

		const char fShaderStr[] =
			"precision mediump float;										\n"
			"																\n"
			"struct light_properties {										\n"
			"	vec3 position;												\n"
			//"	vec3 halfplane;												\n"
			"	vec4 ambient_color;											\n"
			"	vec4 diffuse_color;											\n"
			"	vec4 specular_color;										\n"
			"};																\n"
			"																\n"
			"struct material_properties {									\n"
			"	vec4 ambient_color;											\n"
			"	vec4 diffuse_color;											\n"
			"	vec4 specular_color;										\n"
			"	float specular_exponent;									\n"
			"};																\n"
			"																\n"
			"varying vec4 v_diffuse, v_ambient, v_position;					\n"		
			"varying vec3 v_normal, v_lightDir;								\n"	
			"																\n"
			"uniform material_properties u_material;						\n"
			"uniform light_properties u_light;								\n"
			"uniform sampler2D u_texture1, u_texture2;						\n"
			"uniform vec3 ucameraPosition;									\n"
			"uniform mat3 u_normalMatrix;									\n"
			"uniform sampler2D u_TexMap;									\n"
			"varying vec2 v_texUV;											\n"
			"																\n"
			"void main()                               						\n"
			"{																\n"		
			"	float NdotL;											    \n"
			"  vec4 TexColor = texture2D( u_TexMap, v_texUV );				\n"
			"	vec4 color = TexColor;							\n"    
			"																\n"		
 			"	vec3 N =  v_normal;											\n"
			"	vec3 L = v_lightDir;										\n"
			"	NdotL = max(dot(N, L),0.0);									\n"
			"   vec3 reflectVec = normalize(-reflect(L, N)); \n" //by lsk
			"	float specular = 0.0;"
			"																\n"
 			"	if (NdotL > 0.0) {											\n"
 			"		specular = (u_material.specular_color *					\n"
 			"			u_light.specular_color *							\n"
 			"	        pow(max(dot(reflectVec,normalize(ucameraPosition)),0.0), u_material.specular_exponent)).x;	\n"//by lsk
 			"	}															\n"
			"																\n"
			"  gl_FragColor = vec4(color.rgb * (v_ambient.x + (v_diffuse.x * NdotL)) + specular, color.a);							    \n"
			"}																\n";

		if(m_pShader == NULL)
		{
			m_pShader = new SPShaderManager();

		}
		

		// Load the shaders and get a linked program object
		m_pShader->createProgram(vShaderStr, fShaderStr);
		
		// Get the attribute locations
		m_pShader->addAttribute(ATTRIBUTE0, "aPosition");
		m_pShader->addAttribute(ATTRIBUTE1, "aNormal");
		m_pShader->addAttribute(ATTRIBUTE2, "a_texUV"); 
		
		// Get the uniform locations
		m_pShader->addUniform(UNIFORM0, "uMVPMatrix");
		m_pShader->addUniform(UNIFORM1, "uMVMatrix");
		//m_pShader->addUniform(UNIFORM2, "unormalMatrix");
		m_pShader->addUniform(UNIFORM2, "ucameraPosition"); 

		m_pShader->addUniform(UNIFORM3, "u_material.ambient_color");
		m_pShader->addUniform(UNIFORM4, "u_material.diffuse_color");
		m_pShader->addUniform(UNIFORM5, "u_material.specular_color");
		m_pShader->addUniform(UNIFORM6, "u_material.specular_exponent");

		m_pShader->addUniform(UNIFORM7, "u_light.position");
		m_pShader->addUniform(UNIFORM8, "u_light.halfplane");
		m_pShader->addUniform(UNIFORM9, "u_light.ambient_color");
		m_pShader->addUniform(UNIFORM10, "u_light.diffuse_color");
		m_pShader->addUniform(UNIFORM11, "u_light.specular_color");

		//attenuation
		m_pShader->addUniform(UNIFORM12, "u_attenuation.constant_attenuation");
		m_pShader->addUniform(UNIFORM13, "u_attenuation.linear_attenuation");
		m_pShader->addUniform(UNIFORM14, "u_attenuation.quadratic_attenuation");

		//spot light 
		m_pShader->addUniform(UNIFORM15, "u_light.spot_directon");
		m_pShader->addUniform(UNIFORM16, "u_light.spot_cutoff_angle");
		m_pShader->addUniform(UNIFORM17, "u_light.spot_exponent");

		m_pShader->addUniform(UNIFORM18, "u_TexMap");

	}
}//namespace SPhysics 
