/**
* @file SPDrawObjMesh.h
* @brief This file include module that drawing obj format contents.
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_DRAW_OJBMESH_H_
#define _SP_DRAW_OJBMESH_H_

#include "SPDefines.h"

#include "SPParticleSet2D.h"
#include "SPMVPManager.h"
#include "SPShaderManager.h"
#include "SPOBJLoader.h"



namespace SPhysics
{
	/**
	* @class     SPDrawObjMesh
	* @brief     Drawing object using Obj file 
	* @par Features:
	*	  - This module use 3d-obj(wavefront) format
	*/
	class SPDrawObjMesh
	{
	public:

		/**
		* @brief     Constructor
		*/
		SPDrawObjMesh();

		/**
		* @brief     Destructor
		*/
		~SPDrawObjMesh();

		/**
		* @brief     Initialize and Prepare rendering\n
						(set camera setting, initialize shader)
		* @param     [IN] @b width Clipping Plane's width size
		* @param     [IN] @b height Clipping Plane's height size
		* @param     [IN] @b cameraAlign This value determines how to align camera \n
													(POSTIVE_CAMERA_ALIGN or CENTER_CAMERA_ALIGN)
		* @return     SPVoid
		*/
		SPVoid init(SPFloat width, SPFloat height, SPInt cameraAlign = POSTIVE_CAMERA_ALIGN);
		
		/**
		* @brief      Draws the circle. Set the values which is essential in rendering \n
						(i.e, the matrix, color, mesh data. etc.)
		* @return     SPVoid
		*/
		SPVoid draw();

		/**
		* @brief     Set translated position of object
		* @param     [IN] @b x X position 
		* @param     [IN] @b y Y position
		* @param     [IN] @b z Z position
		* @return     SPVoid
		*/
		SPVoid setTranslate(SPFloat x, SPFloat y, SPFloat z);

		/**
		* @brief     Set the rotation angle and axis of object.
		* @param     [IN] @b angle The angle of rotation
		* @param     [IN] @b x Rotation Axis - X value
		* @param     [IN] @b y Rotation Axis - Y value
		* @param     [IN] @b z Rotation Axis - Z value
		* @return     SPVoid
		*/
		SPVoid setRotate(SPFloat angle, SPFloat x, SPFloat y, SPFloat z);

		/**
		* @brief     Set scale proportions. \n
						(Ref. 1.0 - current value)
		* @param     [IN] @b x X ratio
		* @param     [IN] @b y Y ratio
		* @param     [IN] @b z Z ratio
		* @return     SPVoid
		*/
		SPVoid setScale(SPFloat x, SPFloat y, SPFloat z);

		/**
		* @brief     Set Screen size
		* @param     [IN] @b width Width size
		* @param     [IN] @b height Height size
		* @return     SPVoid
		*/
		SPVoid setScreenSize(SPFloat width, SPFloat height);
		/**
		* @brief     Set the texture to Obj Meshes.
		* @param     [IN] @b bgFileName Specifies filename to do texturing
		* @return     SPVoid
		*/
		SPVoid setTexture(const SPChar* bgFileName);

	private:

		/**
		* @brief     Create shader program and linking
		* @return     SPVoid
		*/
		SPVoid createShader();

		/**
		* @brief     Create mesh data using obj data
		* @return     SPVoid
		*/
		SPVoid createMesh();

		/**
		* @brief     Load rainbow texture and Prepare for cube-mapping
		* @return     SPVoid
		*/
		SPVoid setRainBowTexture();

	private:

		// State Var
		SPFloat m_fTextureStep;

		// Texture Handle
		SPUInt m_hBackground;	
		SPUInt m_hSkymap;

		SPFloat m_ScreenWidth;
		SPFloat m_ScreenHeight;

		SPFloat m_BubbleRadius;

		// pointer of Manager
		SPMVPManager*			m_pMVP;
		SPShaderManager*		m_pShader;
		SPOBJLoader*				m_pOBJMesh;

		// Buffer Handle
		SPUInt v_buf;
		SPUInt n_buf;
		SPUInt i_buf;
		SPUInt t_buf;
	};


}//namespace SPhysics
#endif //_SP_DRAW_OJBMESH_H_