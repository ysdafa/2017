/**
* @file SPDrawCircle.h
* @brief  This file includes module that draws circle.
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_DRAW_CIRCLE_H_
#define _SP_DRAW_CIRCLE_H_

#include "SPDefines.h"
#include "SPIRenderer.h"
#include "SPShaderManager.h"
#include "SPMVPManager.h"
#include "SPMesh.h"

#include <glm.hpp>

namespace SPhysics
{

	/**
	* @enum   _DRAW_CIRCLE_MODE
	* @brief    Drawing mode for circle
	*/
	typedef enum _DRAW_CIRCLE_MODE
	{
		WIRE_DRAW,
		FILL_DRAW
	}DRAW_CIRCLE_MODE;	//!< Drawing mode for circle

	/**
	* @class     SPDrawCircle
	* @brief     This class is mainly for Drawing Circle and supports Mesh setting, color setting, etc,.
	* @par Features:
	*    - Support various drawing mode : wireframe, fill
	*/
	class SPDrawCircle : public SPIRenderer
	{
	  
	public:
		/**
		* @brief     Constructor
		*/
		SPDrawCircle();
		/**
		* @brief     Destructor
		*/
		~SPDrawCircle();

	public:

		/**
		* @brief     Initialize and Prepare rendering\n
		(set camera setting, initialize shader , create rectangle mesh)
		* @param     [IN] SPFloat width Clipping Plane's width size
		* @param     [IN] SPFloat height Clipping Plane's height size
		* @return     SPVoid
		*/
		SPVoid initRender(SPFloat width, SPFloat height); // virtual

		/**
		* @brief     Mesh setting & binding shader variables for drawing.
		* @return     SPVoid
		 */
		SPVoid drawRender(); // virtual

		/**
		* @brief     Set Drawing mode \n
						(WIRE_DRAW , FILL_DRAW)
		* @param     [IN] @b mode mode value
		* @return     SPVoid
		*/
		SPVoid setDrawMode(SPInt mode);    // mode :: 0 -> Wire, 1-> Fill

	private:
		/**
		* @brief     convert degree type value to radian type value
		* @param     [IN] @b x degree
		* @return     SPFloat radian value
		*/
		inline SPFloat convertDegreesToRadians(SPFloat x);
		/**
		* @brief     
		* @return     SPVoid
		*/
		SPVoid createCircleVertex();

	private:
		SPMesh* m_pMesh;

		SPInt    m_nDrawMode;			// 0 : Wire Draw, 1 : Fill Draw
	};

}//namespace SPhysics

#endif //_SP_DRAW_CIRCLE_H_