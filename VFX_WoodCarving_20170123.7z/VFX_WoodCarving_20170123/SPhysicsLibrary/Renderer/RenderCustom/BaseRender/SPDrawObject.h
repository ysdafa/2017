/**
* @file SPDrawObject.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_DRAW_OBJECT_H_
#define _SP_DRAW_OBJECT_H_



#include "SPMesh.h"
#include "SPMVPManager.h"
#include "SPShaderManager.h"
#include "SPDefines.h"
#include "SPOBJLoader.h"
#include "SPLightProperty.h"


namespace SPhysics
{

	/**
	* @class     SPDrawObject
	* @brief     Drawing object with texture and light
	*/
	class SPDrawObject
	{
	public:
		SPDrawObject(void);
		~SPDrawObject(void);

		/**
		* @brief     Rendering init
		*/
		SPVoid init(int width, int height);
		/**
		* @brief     Draw the object
		*/
		SPVoid draw();
		/**
		* @brief     Set texture
		*/
		SPVoid setTexture(const SPChar* aFileName);
		//SPVoid setTextureCallback(SPChar* aFileName); 
		/**
		* @brief     Set mesh
		*/
		SPVoid setMesh(SPMesh* aMesh);
		/**
		* @brief     Set rendering mode
		*/
		SPVoid setRenderMode(SPUInt aRenderMode);
		/**
		* @brief     Get pointer to light properties data
		*/
		static SPLightProperty* getLight();
		/**
		* @brief     Set model matrix
		*/
		SPVoid setModelMatrix(float* aMatrix);
		/**
		* @brief     Set view matrxi
		*/
		SPVoid setViewMatrix(const float* aMatrix);
		/**
		* @brief     Set "look at" data
		*/
		SPVoid setLookAt(float aEx, float aEy, float aEz, float aCx, float aCy, float aCz, float aUx, float aUy,float aUz);

	private:
		SPVoid createSpherePhongShading();

		//light
    	static SPLightProperty* m_pLight;

		// pointer of Manager
		SPMVPManager*			m_pMVP;
		static SPShaderManager*		m_pShader;

		SPMesh* mMesh;

		GLuint m_TextureId;

		SPUInt m_RenderMode;
	};

}//namespace SPhysics

#endif //_SP_DRAW_OBJECT_H_