/**
* @file SPDrawCircle.cpp
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPDrawCircle.h"


namespace SPhysics
{

	//inline  DEGREES_TO_RADIANS(x) (3.14159265358979323846 * x / 180.0)

	SPDrawCircle::SPDrawCircle() : m_pMesh(SPNULL), m_nDrawMode(1)
	{
	}

	SPDrawCircle::~SPDrawCircle()
	{
		SP_SAFE_DELETE(m_pMesh);
	}

	SPVoid SPDrawCircle::initRender( SPFloat width, SPFloat height )
	{
		// Shader Program for DrawCircle
		static const SPChar VertexShader[] = 
			"uniform mat4 uMVPMatrix;					\n"
			"attribute vec4 aPosition;					\n"
			"void main() {								\n"
			"   gl_Position = uMVPMatrix * aPosition;	\n"
			"}											\n";

		static const SPChar FragmentShader[] = 
			"precision mediump float;					\n"
			"uniform vec4 uColor;						\n"
			"void main() {								\n"
			"   gl_FragColor = uColor;					\n"
			"}											\n";


		setOrthogonalCameraView(0.0f, width, 0.0f, height, -5000, 5000.0f);
		//setOrthogonalCameraView( -width * 0.5f, width * 0.5f, -height * 0.5f, height * 0.5f, -5000.0f, 5000.0f);

		createCircleVertex();

		createShaderProgram(VertexShader, FragmentShader);


		m_nDrawMode = WIRE_DRAW;
	}

	SPVoid SPDrawCircle::drawRender()
	{
		setMesh(m_pMesh);

		setShaderArrayMeshVertex("aPosition");
		setShaderUniformMVPMatrix("uMVPMatrix");
		setShaderUnformColor("uColor");

		if(m_nDrawMode == WIRE_DRAW) // Wire Frame
		{
			setDrawArraysWithOption(SPhysics::DRAW_LINE_LOOP);
		}
		else				 // Fill Color
		{
			setDrawArraysWithOption(SPhysics::DRAW_TRIANGLES_FAN);
		}
	}

	SPVoid SPDrawCircle::setDrawMode( SPInt mode )
	{
		m_nDrawMode = mode;
	}

	// private Method
	SPVoid SPDrawCircle::createCircleVertex()
	{
		if(m_pMesh == SPNULL)
			m_pMesh = new SPMesh();


		// Create Circle Vertex Position
		SPVec3f vertex;
		for (SPInt i = 0; i < 720; i += 2) {
			vertex = SPVec3f(cos(convertDegreesToRadians(i)), sin(convertDegreesToRadians(i)), 0.0f);
			m_pMesh->m_tVertex.push_back(vertex);
		}
	}

	SPFloat SPDrawCircle::convertDegreesToRadians( SPFloat x )
	{
		return (3.14159265358979323846 * x / 180.0);
	}
}//namespace SPhysics
