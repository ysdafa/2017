/**
* @file SPDrawImage.cpp
* @brief 
*
* @date 2013-05-08
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPTextureManager.h"
#include "SPDrawImage.h"

//#define DEBUG_TEST

namespace SPhysics
{
	SPDrawImage::SPDrawImage() : m_pMesh(SPNULL), m_TextureId(-1), m_nRectAlign(0), m_fRectWidth(720.0f), m_fRectHeight(1280.0f), m_bEnableFBODraw(SPFALSE)
	{
	}

	SPDrawImage::~SPDrawImage()
	{
		SP_SAFE_DELETE(m_pMesh);
	}

	SPVoid SPDrawImage::initRender(SPFloat width, SPFloat height)
	{
		// Shader Program for DrawRect
		SPChar VertexShader[] =  
			"uniform mediump mat4 uMVPMatrix;				\n"
			"attribute vec4 aPosition;						\n"
			"attribute vec2 aTexUV;						\n"
			"varying vec2 v_texUV;							\n"
			"void main()									\n"
			"{												\n"
			"   v_texUV = aTexUV;							\n"
			"   gl_Position = uMVPMatrix * aPosition;		\n"
			"}												\n";

		SPChar FragmentShader[] =  
			"precision mediump float;                           \n"
			"uniform vec4 uColor;								\n"
			"uniform sampler2D uTexMap;                        \n"
			"varying vec2 v_texUV;								\n"
			"void main()                                        \n"
			"{                                                  \n"
			"  vec4 TexColor = texture2D( uTexMap, v_texUV );  \n"
			"  gl_FragColor = TexColor * uColor;				\n"
			//"  gl_FragColor = TexColor;				\n"
			//"  gl_FragColor = vec4(1.0, 0.0, 0.0, 1.0);				\n"
			"}                                                  \n";


		#ifndef DEBUG_TEST
		setOrthogonalCameraView( 0.0f, width, 0, height, -5000.0f, 5000.0f);
		#else
		setOrthogonalCameraView( -100, 100, -100, 100, -500, 500);
		//setLookAt(100, -50, 100,  0, 0, 0,  0, 1, 0);
		setLookAt(50, -50, 200,  0, 0, 0,  0, 1, 0);
		#endif
		createShaderProgram(VertexShader, FragmentShader);

		m_fRectWidth = width;
		m_fRectHeight = height;
		createRectVertex(width, height);
		createTextureUV();
	}

	SPVoid SPDrawImage::drawRender()
	{
		#ifndef DEBUG_TEST
		setMesh(m_pMesh);
		#endif

		setShaderArrayMeshVertex("aPosition");
		setShaderArrayMeshUV("aTexUV");
		setShaderUniformMVPMatrix("uMVPMatrix");
		setShaderUnformColor("uColor");
		setShaderUnifromTexture("uTexMap", m_TextureId);
		
		setDrawElementsWithOption(DRAW_TRIANGLES_STRIP);
	}

	// API for control the rect size
	SPVoid SPDrawImage::setSize( SPFloat width, SPFloat height )
	{
		m_fRectWidth = width;
		m_fRectHeight = height;

		m_pMesh->m_tVertex.clear();

		SPVec3f vertex;

		// Default Center Align Rect Vertex
		if(m_nRectAlign == RECT_ALIGN_CENTER)
		{
			// case Center Align Rect Vertex
			// point 1
			vertex = SPVec3f(-width*0.5f, -height*0.5f, 0.0f);
			m_pMesh->m_tVertex.push_back(vertex);

			vertex = SPVec3f(width*0.5f, -height*0.5f, 0.0f);
			m_pMesh->m_tVertex.push_back(vertex);

			vertex = SPVec3f(-width*0.5f, height*0.5f, 0.0f);
			m_pMesh->m_tVertex.push_back(vertex);

			vertex = SPVec3f(width*0.5f, height*0.5f, 0.0f);
			m_pMesh->m_tVertex.push_back(vertex);

		}else		// RECT_ALIGN_LEFT_TOP
		{
			// Default LeftTop Align Rect Vertex
			// point 1
			vertex = SPVec3f(0.0f, 0.0f, 0.0f);
			m_pMesh->m_tVertex.push_back(vertex);

			// point 2
			vertex = SPVec3f(width, 0.0f, 0.0f);
			m_pMesh->m_tVertex.push_back(vertex);

			// point 3
			vertex = SPVec3f(0.0f, height, 0.0f);
			m_pMesh->m_tVertex.push_back(vertex);

			// point 4
			vertex = SPVec3f(width, height, 0.0f);
			m_pMesh->m_tVertex.push_back(vertex);
		}

		// point 1
// 		vertex = SPVec3f(-width*0.5f, -height*0.5f, 0.0f);
// 		m_pMesh->m_tVertex.push_back(vertex);
// 
// 		// point 2
// 		vertex = SPVec3f(width*0.5f, -height*0.5f, 0.0f);
// 		m_pMesh->m_tVertex.push_back(vertex);
// 
// 		// point 3
// 		vertex = SPVec3f(-width*0.5f, height*0.5f, 0.0f);
// 		m_pMesh->m_tVertex.push_back(vertex);
// 
// 		// point 4
// 		vertex = SPVec3f(width*0.5f, height*0.5f, 0.0f);
// 		m_pMesh->m_tVertex.push_back(vertex);
	}

	SPVoid SPDrawImage::setRectAlign( SPUInt align )
	{
		if(m_nRectAlign != align)
		{
			m_nRectAlign = align;
			createRectVertex(m_fRectWidth, m_fRectHeight);
		}
	}

	SPVoid SPDrawImage::enableFBOImageDraw()
	{
		m_bEnableFBODraw = SPTRUE;

		createFBOTextureUV();
	}

	SPVoid SPDrawImage::setTexture( const SPChar *fileName )
	{
#if (ANDROID_PORTING_MODE)
		m_TextureId = SPTextureManager::getInstancePtr()->getTextureID(fileName);
#else
		m_TextureId = SPTextureManager::getInstancePtr()->loadTexture(fileName);
#endif
	}


	SPhysics::SPVoid SPDrawImage::setTextureID( SPUInt texID )
	{
		m_TextureId = texID;
	}

	// private Method
	SPVoid SPDrawImage::createRectVertex(SPFloat width, SPFloat height)
	{
		if(m_pMesh == SPNULL)
			m_pMesh = new SPMesh();

		// Rect Vertex
		//     P3                  P4
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1                  P2

		// create rect vertex position
		SPVec3f vertex;

		m_pMesh->m_tVertex.clear();

		if(m_nRectAlign == RECT_ALIGN_CENTER)
		{
			// case Center Align Rect Vertex
			// point 1
			vertex = SPVec3f(-width*0.5f, -height*0.5f, 0.0f);
			m_pMesh->m_tVertex.push_back(vertex);

			vertex = SPVec3f(width*0.5f, -height*0.5f, 0.0f);
			m_pMesh->m_tVertex.push_back(vertex);

			vertex = SPVec3f(-width*0.5f, height*0.5f, 0.0f);
			m_pMesh->m_tVertex.push_back(vertex);

			vertex = SPVec3f(width*0.5f, height*0.5f, 0.0f);
			m_pMesh->m_tVertex.push_back(vertex);

		}else		// RECT_ALIGN_LEFT_TOP
		{
			// Default LeftTop Align Rect Vertex
			// point 1
			vertex = SPVec3f(0.0f, 0.0f, 0.0f);
			m_pMesh->m_tVertex.push_back(vertex);

			// point 2
			vertex = SPVec3f(width, 0.0f, 0.0f);
			m_pMesh->m_tVertex.push_back(vertex);

			// point 3
			vertex = SPVec3f(0.0f, height, 0.0f);
			m_pMesh->m_tVertex.push_back(vertex);

			// point 4
			vertex = SPVec3f(width, height, 0.0f);
			m_pMesh->m_tVertex.push_back(vertex);
		}


		m_pMesh->m_tVertexIndex.clear();
		//create rect vertex index
		m_pMesh->m_tVertexIndex.push_back(0);
		m_pMesh->m_tVertexIndex.push_back(1);
		m_pMesh->m_tVertexIndex.push_back(2);
		m_pMesh->m_tVertexIndex.push_back(3);
	}

	SPVoid SPDrawImage::createTextureUV()
	{

		if(m_bEnableFBODraw == SPTRUE)
		{
			createFBOTextureUV();
			return;
		}

		if(m_pMesh == SPNULL)
			m_pMesh = new SPMesh();

		m_pMesh->m_tTextureUV.clear();

		// Rect Vertex
		//     P3(0,0)            P4(1,0)
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1(0,1)            P2(1.1)

		SPVec3f textureUV;

		textureUV = SPVec3f(0.0f, 1.0f, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);

		textureUV = SPVec3f(1.0f, 1.0f, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);

		textureUV = SPVec3f(0.0f, 0.0f, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);

		textureUV = SPVec3f(1.0f, 0.0f, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);


		//     P3(0,0)            P4(1,0)
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1(0,1)            P2(1.1)

// 		textureUV = SPVec3f(0.0f, 1.0f, 0.0f);
// 		m_pMesh->m_tTextureUV.push_back(textureUV);
// 
// 		textureUV = SPVec3f(1.0f, 1.0f, 0.0f);
// 		m_pMesh->m_tTextureUV.push_back(textureUV);
// 
// 		textureUV = SPVec3f(0.0f, 0.0f, 0.0f);
// 		m_pMesh->m_tTextureUV.push_back(textureUV);
// 
// 		textureUV = SPVec3f(1.0f, 0.0f, 0.0f);
// 		m_pMesh->m_tTextureUV.push_back(textureUV);
	}

	SPVoid SPDrawImage::createFBOTextureUV()
	{
		if(m_pMesh == SPNULL)
			m_pMesh = new SPMesh();

		m_pMesh->m_tTextureUV.clear();

		// Rect Vertex
		//     P3(0,0)            P4(1,0)
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1(0,1)            P2(1.1)

		SPVec3f textureUV;

		//textureUV = SPVec3f(0.0f, 1.0f, 0.0f);
		textureUV = SPVec3f(0.0f, 0.0f, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);

		//textureUV = SPVec3f(1.0f, 1.0f, 0.0f);
		textureUV = SPVec3f(1.0f, 0.0f, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);

		//textureUV = SPVec3f(0.0f, 0.0f, 0.0f);
		textureUV = SPVec3f(0.0f, 1.0f, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);

		//textureUV = SPVec3f(1.0f, 0.0f, 0.0f);
		textureUV = SPVec3f(1.0f, 1.0f, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);
	}


}//namespace SPhysics
