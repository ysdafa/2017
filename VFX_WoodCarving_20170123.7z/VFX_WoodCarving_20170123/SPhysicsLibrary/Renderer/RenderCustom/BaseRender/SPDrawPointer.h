/**
* @file SPDrawPointer.h
* @brief  This file includes module that draws point.
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_DRAW_POINTER_H_
#define _SP_DRAW_POINTER_H_

#include "SPIRenderer.h"

namespace SPhysics
{

	/**
	* @class     SPDrawPointer
	* @brief     This class is mainly for Drawing Point and supports color setting, texturing, etc,.
	*/
	class SPDrawPointer : public SPIRenderer
	{
	  
	public:
		/**
		* @brief     Constructor
		*/
		SPDrawPointer();

		/**
		* @brief     Destructor
		*/
		~SPDrawPointer();

	public:
		/**
		* @brief     Initialize and Prepare rendering\n
		(set camera setting, initialize shader , create rectangle mesh)
		* @param     [IN] SPFloat width Clipping Plane's width size
		* @param     [IN] SPFloat height Clipping Plane's height size
		* @return     SPVoid
		*/
		SPVoid initRender(SPFloat width, SPFloat height); // virtual

		/**
		* @brief     Mesh setting & binding shader variables for drawing.
		* @return     SPVoid
		 */
		SPVoid drawRender(); // virtual

		/**
		* @brief     Adjust point mesh size
		* @param     [IN] @b pointerSize Point's size
		* @return     SPVoid
		*/
		SPVoid setSize(SPFloat pointerSize);

		/**
		* @brief     Set the texture to Object
		* @param     [IN] @b fileName Specifies filename to do texturing
		* @return     SPVoid
		*/
		SPVoid setTexture(const SPChar *fileName, const SPBool& isMipMap);

		/**
		* @brief     Set attribute pointer
		*/
		SPVoid setAttributePointer();

		/**
		* @brief     Set sphere pointer
		*/
		SPVoid setSpherePointer();

	private:
		/**
		* @brief     Create color-shader program and linking
		* @return     SPVoid
		*/
		SPVoid createPointerColorShader();

		/**
		* @brief     Create texturing-shader program and linking
		* @return     SPVoid
		*/
		SPVoid createPointerTextureShader();

		/**
		* @brief     Create sphere-shader program and linking
		* @return     SPVoid
		*/
		SPVoid createPointerSphereShader();


		SPVoid createPointerAttributeColorSizeShader();
	private:

		SPUInt m_TextureId;
		SPInt    m_nDrawMode;			// 0 : Color Draw, 1 : Texture Draw
		SPInt    m_nPointerSize;
	};

}//namespace SPhysics

#endif //_SP_DRAW_POINTER_H_