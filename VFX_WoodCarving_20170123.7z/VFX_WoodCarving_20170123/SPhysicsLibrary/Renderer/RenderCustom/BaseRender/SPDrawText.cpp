/**
* @file SPDrawText.cpp
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPTextureManager.h"
#include "SPDrawText.h"


namespace SPhysics
{
	SPDrawText::SPDrawText() :  m_pDraw(SPNULL), m_pMesh(SPNULL), m_StringLength(0), m_FontWidth(17), m_FontHeight(20)
	{
		m_pTextBuff.clear();
	}

	SPDrawText::~SPDrawText()
	{
		SP_SAFE_DELETE(m_pDraw);
		SP_SAFE_DELETE(m_pMesh);

		m_pTextBuff.clear();
	}

	SPVoid SPDrawText::initialize( SPFloat width, SPFloat height)
	{
		if(m_pDraw == SPNULL)
		{
			m_pDraw = new SPDrawRect();
		}

		m_pDraw->initialize(width, height);
		m_pDraw->setFontTexture("Res/font/fontbitmap.png");
	}

	SPVoid SPDrawText::draw()
	{
		if(m_StringLength == 0)
			return;
		
		SPInt asciiIdx = 0;
		for(SPInt i = 0; i < m_StringLength; i++)
		{
			asciiIdx = (SPInt)m_pTextBuff.c_str()[i];

			if(asciiIdx != 32) // " "
			{
				createCharacterVertex(i);
				createCharacterTextureUV(asciiIdx - 33);

				m_pDraw->setMesh(m_pMesh);

				m_pDraw->draw();

				m_pMesh->reset();
			}
		}
		
	}

	// API for control the rect size
// 	SPVoid SPDrawText::setSize( SPFloat width, SPFloat height )
// 	{
// 		m_pMesh->m_tVertex.clear();
// 
// 		SPVec3f vertex;
// 
// 		// Default Center Align Rect Vertex
// 
// 		// point 1
// 		vertex = SPVec3f(-width*0.5f, -height*0.5f, 0.0f);
// 		m_pMesh->m_tVertex.push_back(vertex);
// 
// 		// point 2
// 		vertex = SPVec3f(width*0.5f, -height*0.5f, 0.0f);
// 		m_pMesh->m_tVertex.push_back(vertex);
// 
// 		// point 3
// 		vertex = SPVec3f(-width*0.5f, height*0.5f, 0.0f);
// 		m_pMesh->m_tVertex.push_back(vertex);
// 
// 		// point 4
// 		vertex = SPVec3f(width*0.5f, height*0.5f, 0.0f);
// 		m_pMesh->m_tVertex.push_back(vertex);
// 	}

	SPVoid SPDrawText::setColor( SPFloat red, SPFloat green, SPFloat blue, SPFloat alpha )
	{
		if(m_pDraw != SPNULL)
		{
			m_pDraw->setColor(red, green, blue, alpha);
		}
	}

	SPVoid SPDrawText::setTranslate( SPFloat x, SPFloat y, SPFloat z )
	{
		if(m_pDraw != SPNULL)
		{
			m_pDraw->setTranslate(x, y, z);
		}
	}

	SPVoid SPDrawText::setRotate( SPFloat angle, SPFloat x, SPFloat y, SPFloat z )
	{
		if(m_pDraw != SPNULL)
		{
			m_pDraw->setRotate(angle, x, y, z);
		}
	}

	SPVoid SPDrawText::setScale( SPFloat x, SPFloat y, SPFloat z )
	{
		if(m_pDraw != SPNULL)
		{
			m_pDraw->setScale(x, y, z);
		}
	}

	SPVoid SPDrawText::setText(const SPChar *drawText )
	{
		m_pTextBuff.clear();

		m_pTextBuff = drawText;
		m_StringLength = m_pTextBuff.length();
	}

	SPVoid SPDrawText::setFontSize( SPFloat fontSize )
	{
		m_FontWidth = 17 * fontSize * 0.05f;
		m_FontHeight = fontSize;

	}

	// private Method
	SPVoid SPDrawText::createCharacterVertex(SPInt charPos)
	{

		if(m_pMesh == SPNULL)
			m_pMesh = new SPMesh();

		// Rect Vertex
		//     P3                  P4
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1                  P2

		SPFloat leftX = charPos * m_FontWidth;
		SPFloat rightX = leftX + m_FontWidth;

		// create rect vertex position
		SPVec3f vertex;

		// Default LeftTop Align Rect Vertex
		// point 1
		//vertex = SPVec3f(0.0f, 0.0f, 0.0f);
		vertex = SPVec3f(leftX, 0.0f, 0.0f);
		m_pMesh->m_tVertex.push_back(vertex);

		// point 2
		vertex = SPVec3f(rightX, 0.0f, 0.0f);
		m_pMesh->m_tVertex.push_back(vertex);

		// point 3
		//vertex = SPVec3f(0.0f, m_FontHeight, 0.0f);
		vertex = SPVec3f(leftX, m_FontHeight, 0.0f);
		m_pMesh->m_tVertex.push_back(vertex);

		// point 4
		//vertex = SPVec3f(m_FontWidth, m_FontHeight, 0.0f);
		vertex = SPVec3f(rightX, m_FontHeight, 0.0f);
		m_pMesh->m_tVertex.push_back(vertex);

		// 		// case Center Align Rect Vertex
		// 		// point 1
		// 		vertex = SPVec3f(-width*0.5f, -height*0.5f, 0.0f);
		// 		m_pMesh->m_tVertex.push_back(vertex);
		// 
		// 		vertex = SPVec3f(width*0.5f, -height*0.5f, 0.0f);
		// 		m_pMesh->m_tVertex.push_back(vertex);
		// 
		// 		vertex = SPVec3f(-width*0.5f, height*0.5f, 0.0f);
		// 		m_pMesh->m_tVertex.push_back(vertex);
		// 
		// 		vertex = SPVec3f(width*0.5f, height*0.5f, 0.0f);
		// 		m_pMesh->m_tVertex.push_back(vertex);

// 		// Default LeftTop Align Rect Vertex
// 		// point 1
// 		vertex = SPVec3f(0.0f, 0.0f, 0.0f);
// 		m_pMesh->m_tVertex.push_back(vertex);
// 
// 		// point 2
// 		vertex = SPVec3f(width, 0.0f, 0.0f);
// 		m_pMesh->m_tVertex.push_back(vertex);
// 
// 		// point 3
// 		vertex = SPVec3f(0.0f, height, 0.0f);
// 		m_pMesh->m_tVertex.push_back(vertex);
// 
// 		// point 4
// 		vertex = SPVec3f(width, height, 0.0f);
// 		m_pMesh->m_tVertex.push_back(vertex);

		//create rect vertex index
		m_pMesh->m_tVertexIndex.push_back(0);
		m_pMesh->m_tVertexIndex.push_back(1);
		m_pMesh->m_tVertexIndex.push_back(2);
		m_pMesh->m_tVertexIndex.push_back(3);
	}

	SPVoid SPDrawText::createCharacterTextureUV(SPInt asciiIdx)
	{
		SPFloat characterUV[] = {
			0.1f,0.0f, 0.2f,0.0f, 0.3f,0.0f, 0.4f,0.0f, 0.5f,0.0f, 0.6f,0.0f, 0.7f,0.0f, 0.8f,0.0f, 0.9f,0.0f, 1.0f,0.0f,
			0.1f,0.1f, 0.2f,0.1f, 0.3f,0.1f, 0.4f,0.1f, 0.5f,0.1f, 0.6f,0.1f, 0.7f,0.1f, 0.8f,0.1f, 0.9f,0.1f, 1.0f,0.1f,
			0.1f,0.2f, 0.2f,0.2f, 0.3f,0.2f, 0.4f,0.2f, 0.5f,0.2f, 0.6f,0.2f, 0.7f,0.2f, 0.8f,0.2f, 0.9f,0.2f, 1.0f,0.2f,
			0.1f,0.3f, 0.2f,0.3f, 0.3f,0.3f, 0.4f,0.3f, 0.5f,0.3f, 0.6f,0.3f, 0.7f,0.3f, 0.8f,0.3f, 0.9f,0.3f, 1.0f,0.3f,
			0.1f,0.4f, 0.2f,0.4f, 0.3f,0.4f, 0.4f,0.4f, 0.5f,0.4f, 0.6f,0.4f, 0.7f,0.4f, 0.8f,0.4f, 0.9f,0.4f, 1.0f,0.4f,
			0.1f,0.5f, 0.2f,0.5f, 0.3f,0.5f, 0.4f,0.5f, 0.5f,0.5f, 0.6f,0.5f, 0.7f,0.5f, 0.8f,0.5f, 0.9f,0.5f, 1.0f,0.5f,
			0.1f,0.6f, 0.2f,0.6f, 0.3f,0.6f, 0.4f,0.6f, 0.5f,0.6f, 0.6f,0.6f, 0.7f,0.6f, 0.8f,0.6f, 0.9f,0.6f, 1.0f,0.6f,
			0.1f,0.7f, 0.2f,0.7f, 0.3f,0.7f, 0.4f,0.7f, 0.5f,0.7f, 0.6f,0.7f, 0.7f,0.7f, 0.8f,0.7f, 0.9f,0.7f, 1.0f,0.7f,
			0.1f,0.8f, 0.2f,0.8f, 0.3f,0.8f, 0.4f,0.8f, 0.5f,0.8f, 0.6f,0.8f, 0.7f,0.8f, 0.8f,0.8f, 0.9f,0.8f, 1.0f,0.8f,
			0.1f,0.9f, 0.2f,0.9f, 0.3f,0.9f, 0.4f,0.9f, 0.5f,0.9f, 0.6f,0.9f, 0.7f,0.9f, 0.8f,0.9f, 0.9f,0.9f, 1.0f,0.9f,


		};

		// Rect Vertex
		//     P3(0,0)            P4(1,0)
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1(0,1)            P2(1.1)

		SPFloat p4UV_x = characterUV[2 * asciiIdx];
		SPFloat p4UV_y = characterUV[2 * asciiIdx + 1];

		SPVec3f textureUV;

		textureUV = SPVec3f(p4UV_x - 0.1f, p4UV_y + 0.1f, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);

		textureUV = SPVec3f(p4UV_x, p4UV_y + 0.1f, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);

		textureUV = SPVec3f(p4UV_x - 0.1f, p4UV_y, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);

		textureUV = SPVec3f(p4UV_x, p4UV_y, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);

// 		textureUV = SPVec3f(0.0f, 0.1f, 0.0f);
// 		m_pMesh->m_tTextureUV.push_back(textureUV);
// 
// 		textureUV = SPVec3f(0.1f, 0.1f, 0.0f);
// 		m_pMesh->m_tTextureUV.push_back(textureUV);
// 
// 		textureUV = SPVec3f(0.0f, 0.0f, 0.0f);
// 		m_pMesh->m_tTextureUV.push_back(textureUV);
// 
// 		textureUV = SPVec3f(0.1f, 0.0f, 0.0f);
// 		m_pMesh->m_tTextureUV.push_back(textureUV);

// 		textureUV = SPVec3f(0.0f, 1.0f, 0.0f);
// 		m_pMesh->m_tTextureUV.push_back(textureUV);
// 
// 		textureUV = SPVec3f(1.0f, 1.0f, 0.0f);
// 		m_pMesh->m_tTextureUV.push_back(textureUV);
// 
// 		textureUV = SPVec3f(0.0f, 0.0f, 0.0f);
// 		m_pMesh->m_tTextureUV.push_back(textureUV);
// 
// 		textureUV = SPVec3f(1.0f, 0.0f, 0.0f);
// 		m_pMesh->m_tTextureUV.push_back(textureUV);


		//     P3(0,0)            P4(1,0)
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1(0,1)            P2(1.1)

		// 		textureUV = SPVec3f(0.0f, 1.0f);
		// 		m_pMesh->m_tTextureUV.push_back(textureUV);
		// 
		// 		textureUV = SPVec3f(1.0f, 1.0f);
		// 		m_pMesh->m_tTextureUV.push_back(textureUV);
		// 
		// 		textureUV = SPVec3f(0.0f, 0.0f);
		// 		m_pMesh->m_tTextureUV.push_back(textureUV);
		// 
		// 		textureUV = SPVec3f(1.0f, 0.0f);
		// 		m_pMesh->m_tTextureUV.push_back(textureUV);
	}
}//namespace SPhysics
