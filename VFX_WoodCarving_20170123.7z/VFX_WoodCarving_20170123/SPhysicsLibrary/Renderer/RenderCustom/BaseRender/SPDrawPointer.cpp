/**
* @file SPDrawPointer.cpp
* @brief This file includes module that represent pointer.
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPTextureManager.h"
#include "SPDrawPointer.h"

namespace SPhysics
{
	SPDrawPointer::SPDrawPointer() : m_TextureId(-1), m_nDrawMode(-1), m_nPointerSize(3)
	{
	}

	SPDrawPointer::~SPDrawPointer()
	{
	}

	SPVoid SPDrawPointer::initRender( SPFloat width, SPFloat height )
	{
		setOrthogonalCameraView(0.0f, width, 0.0f, height, -5000, 5000.0f);
		//setOrthogonalCameraView( -width * 0.5f, width * 0.5f, -height * 0.5f, height * 0.5f, -5000.0f, 5000.0f);

		createPointerColorShader();
	}

	SPVoid SPDrawPointer::drawRender()
	{
		setShaderArrayMeshVertex("aPosition");
		setShaderUniformMVPMatrix("uMVPMatrix");

		setShaderUniformValue("uPointSize", m_nPointerSize);
		setShaderUnformColor("uColor");

		switch(m_nDrawMode)
		{		
		case 1:
			setShaderUnifromTexture("uTexMap", m_TextureId);
			break;		
		case 3:
			setShaderArrayMeshColor("aColor");
			setShaderArrayMeshCustom("aPointSize");
			break;
		}

		setDrawArraysWithOption(SPhysics::DRAW_POINT);
	}

	// API for control the pointer size
	SPVoid SPDrawPointer::setSize( SPFloat pointerSize )
	{
		m_nPointerSize = pointerSize;
	}

	SPVoid SPDrawPointer::setTexture( const SPChar *fileName, const SPBool& isMipMap )
	{
		createPointerTextureShader();

		//m_TextureId = SPTextureManager::getInstancePtr()->loadTexture(fileName, isMipMap);
	}

	SPVoid SPDrawPointer::createPointerColorShader()
	{
		if(m_nDrawMode == 0)
			return;

		// Shader Program for DrawPointer
		SPChar VertexShader[] =
			"uniform mediump mat4 uMVPMatrix;			\n"
			"attribute vec4 aPosition;					\n"
			"uniform float uPointSize;                 \n"
			"void main()								\n"
			"{											\n"
			"   gl_PointSize = uPointSize;				\n"
			"   gl_Position = uMVPMatrix * aPosition; \n"
			"}											\n";

		SPChar FragmentShader[] =
			"precision mediump float;                           \n"
			"uniform vec4 uColor;								\n"
			"void main()                                        \n"
			"{                                                  \n"
			"   gl_FragColor = uColor;							\n"
			"}                                                  \n";

		m_nDrawMode = 0;

		createShaderProgram(VertexShader, FragmentShader);
	}

	SPVoid SPDrawPointer::createPointerTextureShader()
	{
		if(m_nDrawMode == 1)
			return;

		// Shader Program for DrawPointer
		SPChar VertexShader[] =
			"uniform mediump mat4 uMVPMatrix;			\n"
			"attribute vec4 aPosition;					\n"
			"uniform float uPointSize;                 \n"
			"void main()								\n"
			"{											\n"
			"   gl_PointSize = uPointSize;				\n"
			"   gl_Position = uMVPMatrix * aPosition; \n"
			"}											\n";

		SPChar FragmentShader[] =
			"precision mediump float;									\n"
			"uniform vec4 uColor;										\n"
			"uniform sampler2D uTexMap;								\n"
			"void main()												\n"
			"{															\n"
			"   vec4 TexColor = texture2D( uTexMap, gl_PointCoord );	\n"
			"   gl_FragColor = TexColor * uColor;						\n"
			"}															\n";

		m_nDrawMode = 1;

		createShaderProgram(VertexShader, FragmentShader);
	}

	SPVoid SPDrawPointer::createPointerAttributeColorSizeShader()
	{
		if(m_nDrawMode == 3)
			return;

		// Shader Program for DrawPointer
		SPChar VertexShader[] =
			"uniform mediump mat4 uMVPMatrix;			\n"
			"attribute vec4 aPosition;					\n"
			"attribute float aPointSize;				\n"
			"attribute vec4 aColor;						\n"
			"varying vec4 vColor;						\n"
			"void main()								\n"
			"{											\n"
			"	vColor = aColor;						\n"
			"   gl_PointSize = aPointSize;				\n"
			"   gl_Position = uMVPMatrix * aPosition;	\n"
			"}											\n";

		SPChar FragmentShader[] =
			"precision mediump float;                           \n"
			"varying vec4 vColor;						        \n"
			"void main()                                        \n"
			"{                                                  \n"
			"	highp vec2 N;							        \n"
			"	N = (gl_PointCoord * 2.0 - vec2(1.0));	        \n"
			"	float mag = dot(N, N);					        \n"
			"	if(mag > 1.0) discard;					        \n"
			"   gl_FragColor.rgb = vColor.rgb * (mag + 1.0);	\n"
			"   gl_FragColor.a = vColor.a;				        \n"
			"}                                                  \n";

		m_nDrawMode = 3;

		createShaderProgram(VertexShader, FragmentShader);
	}

	SPVoid SPDrawPointer::createPointerSphereShader()
	{
		if(m_nDrawMode == 2)
			return;

		// Shader Program for DrawPointer
		SPChar VertexShader[] =
			"uniform mediump mat4 uMVPMatrix;			\n"
			"attribute vec4 aPosition;					\n"
			"uniform float uPointSize;                  \n"
			"void main()								\n"
			"{											\n"
			"   gl_PointSize = uPointSize;				\n"
			"   gl_Position = uMVPMatrix * aPosition;   \n"
			"}											\n";

		SPChar FragmentShader[] =
			"precision lowp float;												\n"
			"uniform vec4 uColor;										\n"
			"void main()														\n"
			"{																	\n"
			"	highp vec3 N;													\n"
			"	N.xy = (gl_PointCoord * 2.0 - vec2(1.0));							\n"
			"	float mag = dot(N.xy, N.xy);									\n"
			"	if(mag > 1.0) discard;"
			//"	float ratio = 0.6;	\n"
			//"	float minValue = 0.0;	\n"
			//"	if (mag > ratio) N.z = 1.0; 	else 		\n"// kill pixels outside circle
			//"	N.z = pow(1.0 - mag, 2.0);										\n"
			//"	N.z = 0.0;										\n"
			//			"	N.z = (1.0 - pow(N.x, 2.0)) * (1.0 - pow(N.y, 2.0));				\n"
			//"	float diffuse = max(0.0, dot(vec3(0.0, 0.0, 1.0), N));			\n"	// calculate lighting
			"	N.z = sqrt(1.0 - mag);											\n"
			//"	gl_FragColor = vec4(N, 1.0);				\n"
			//"	gl_FragColor = vec4(uColor.xyz, 1.0 - mag);				\n"
			//"	gl_FragColor = vec4(vec3(1.0), max(pow(1.0 - mag, 2.0), 0.0 ));				\n"
			//"	gl_FragColor = vec4(vec3(1.0), max(pow(1.0 - mag, 2.0), 0.0 ));				\n"
			//"	N.y = -N.y;				\n"
			"	gl_FragColor = vec4(vec3(gl_PointCoord.xy, N.z), 1.0);				\n"
			"}																	\n";

		m_nDrawMode = 2;

		createShaderProgram(VertexShader, FragmentShader);
	}

	SPhysics::SPVoid SPDrawPointer::setSpherePointer()
	{
		createPointerSphereShader();
	}

	SPhysics::SPVoid SPDrawPointer::setAttributePointer()
	{
		createPointerAttributeColorSizeShader();
	}
}//namespace SPhysics