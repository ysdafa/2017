/**
* @file SPDrawRect.cpp
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPMesh.h"
#include "SPTextureManager.h"
#include "SPDrawRect.h"


namespace SPhysics
{
	SPDrawRect::SPDrawRect() : m_pMesh(SPNULL), m_TextureId(-1), m_nDrawMode(-1), m_nRectAlign(0),m_nRectWidth(1024),m_nRectHeight(768)
	{
		m_ObjectPosition = SPVec3f();
	}

	SPDrawRect::~SPDrawRect()
	{
		SP_SAFE_DELETE(m_pMesh);
	}

	SPVoid SPDrawRect::initRender( SPFloat width, SPFloat height )
	{
		// Initialize RectSize
		m_nRectWidth = (SPInt)width;
		m_nRectHeight = (SPInt)height;

		setOrthogonalCameraView(0.0f, width, 0.0f, height, -5000, 5000.0f);
		//setOrthogonalCameraView( -width * 0.5f, width * 0.5f, -height * 0.5f, height * 0.5f, -5000.0f, 5000.0f);

		// create shader program and atrribute, uniform location
		createRectColorShader();

		createRectVertex(width, height);
	}

	SPVoid SPDrawRect::drawRender()
	{
		setShaderArrayMeshVertex("aPosition");
		setShaderUniformMVPMatrix("uMVPMatrix");

		setShaderUnformColor("uColor");

		if(m_nDrawMode != 0)
		{
			setShaderArrayMeshUV("aTexUV");
			setShaderUnifromTexture("uTexMap", m_TextureId);
		}

		setDrawElementsWithOption(SPhysics::DRAW_TRIANGLES_STRIP);

	}

	SPVoid SPDrawRect::setPosition( SPFloat x, SPFloat y, SPFloat z /*= 0*/ )
	{
		m_ObjectPosition = SPVec3f(x, y, z);

		createRectVertex((SPFloat)m_nRectWidth, (SPFloat)m_nRectHeight);
	}

	SPVoid SPDrawRect::setRectAlign( SPInt align )
	{
		m_nRectAlign = align;
	}

	// API for control the rect size
	SPVoid SPDrawRect::setSize( SPFloat width, SPFloat height )
	{
		m_nRectWidth = (SPInt)width;
		m_nRectHeight = (SPInt)height;

		createRectVertex(width, height);
	}

	SPVoid SPDrawRect::setTexture( const SPChar *fileName, SPBool isMipMapMode )
	{
#if (ANDROID_PORTING_MODE)
		m_TextureId = SPTextureManager::getInstancePtr()->getTextureID(fileName);
#else
		m_TextureId = SPTextureManager::getInstancePtr()->loadTexture(fileName, isMipMapMode);
#endif

		if(m_nDrawMode == 1)
			return;

		createRectTextureShader();
		createTextureUV();

	}

// 	SPVoid SPDrawRect::setXenTexture(const SPChar *fileName)
// 	{
// 	#ifndef _WIN32
// 		m_TextureId = SPTextureManager::getInstancePtr()->loadTextureCallback(fileName);
// 
// 		if(m_nDrawMode == 1)
// 			return;
// 
// 		createRectTextureShader();
// 		createTextureUV();
// 	#endif	
// 	}

	SPVoid SPDrawRect::setTextureID(SPUInt texID)
	{
		m_TextureId = texID;

		if(m_nDrawMode == 1)
			return;

		createRectTextureShader();
		createTextureUV();
	}

	SPVoid SPDrawRect::setFontTexture( const SPChar *fileName )
	{

#if (ANDROID_PORTING_MODE)
		m_TextureId = SPTextureManager::getInstancePtr()->getTextureID(fileName);
#else
		m_TextureId = SPTextureManager::getInstancePtr()->loadTexture(fileName);
#endif

		if(m_nDrawMode == 2)
			return;

		createRectFontShader();
		createTextureUV();
	}

	SPVoid SPDrawRect::createRectVertex( SPFloat width, SPFloat height )
	{

		if(m_pMesh == SPNULL)
			m_pMesh = new SPMesh();


		m_pMesh->m_tVertex.clear();

		//     P3                  P4
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1                  P2

		SPVec3f vertex;

		SPFloat p1_x, p1_y;

		if(m_nRectAlign == RECT_ALIGN_CENTER)
		{
			p1_x = m_ObjectPosition.x - (width*0.5f);
			p1_y = m_ObjectPosition.y - (height*0.5f);
			//Default Center Align Rect Vertex

			// point 1
			vertex = SPVec3f(p1_x, p1_y, 0.0f);
			m_pMesh->m_tVertex.push_back(vertex);

			// point 2
			vertex = SPVec3f(p1_x + width, p1_y, 0.0f);
			m_pMesh->m_tVertex.push_back(vertex);

			// point 3
			vertex = SPVec3f(p1_x, p1_y + height, 0.0f);
			m_pMesh->m_tVertex.push_back(vertex);

			// point 4
			vertex = SPVec3f(p1_x + width, p1_y + height, 0.0f);
			m_pMesh->m_tVertex.push_back(vertex);

		}else
		{
			// Default LeftTop Align Rect Vertex

			p1_x = m_ObjectPosition.x;
			p1_y = m_ObjectPosition.y;


			// point 1
			vertex = SPVec3f(p1_x, p1_y, 0.0f);
			m_pMesh->m_tVertex.push_back(vertex);

			// point 2
			vertex = SPVec3f(p1_x + width, p1_y, 0.0f);
			m_pMesh->m_tVertex.push_back(vertex);

			// point 3
			vertex = SPVec3f(p1_x, p1_y + height, 0.0f);
			m_pMesh->m_tVertex.push_back(vertex);

			// point 4
			vertex = SPVec3f(p1_x + width, p1_y + height, 0.0f);
			m_pMesh->m_tVertex.push_back(vertex);

// 			// point 1
// 			vertex = SPVec3f(0.0f, 0.0f, 0.0f);
// 			m_pMesh->m_tVertex.push_back(vertex);
// 
// 			// point 2
// 			vertex = SPVec3f(width, 0.0f, 0.0f);
// 			m_pMesh->m_tVertex.push_back(vertex);
// 
// 			// point 3
// 			vertex = SPVec3f(0.0f, height, 0.0f);
// 			m_pMesh->m_tVertex.push_back(vertex);
// 
// 			// point 4
// 			vertex = SPVec3f(width, height, 0.0f);
// 			m_pMesh->m_tVertex.push_back(vertex);

// 			// point 1
// 			vertex = SPVec3f(0.0f, 0.0f, 0.0f);
// 			m_pMesh->m_tVertex.push_back(vertex);
// 
// 			// point 2
// 			vertex = SPVec3f(width, 0.0f, 0.0f);
// 			m_pMesh->m_tVertex.push_back(vertex);
// 
// 			// point 3
// 			vertex = SPVec3f(0.0f, height, 0.0f);
// 			m_pMesh->m_tVertex.push_back(vertex);
// 
// 			// point 4
// 			vertex = SPVec3f(width, height, 0.0f);
// 			m_pMesh->m_tVertex.push_back(vertex);
		}


		//create rect vertex index
		m_pMesh->m_tVertexIndex.clear();
		m_pMesh->m_tVertexIndex.push_back(0);
		m_pMesh->m_tVertexIndex.push_back(1);
		m_pMesh->m_tVertexIndex.push_back(2);
		m_pMesh->m_tVertexIndex.push_back(3);
		
		setMesh(m_pMesh);
	}

	SPVoid SPDrawRect::createTextureUV()
	{
		// Rect Vertex
		//     P3(0,0)            P4(1,0)
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1(0,1)            P2(1.1)

		m_pMesh->m_tTextureUV.clear();
		SPVec3f textureUV;

		textureUV = SPVec3f(0.0f, 1.0f, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);

		textureUV = SPVec3f(1.0f, 1.0f, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);

		textureUV = SPVec3f(0.0f, 0.0f, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);

		textureUV = SPVec3f(1.0f, 0.0f, 0.0f);
		m_pMesh->m_tTextureUV.push_back(textureUV);



		//     P3(0,0)            P4(1,0)
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1(0,1)            P2(1.1)

// 		textureUV = SPVec3f(0.0f, 1.0f);
// 		m_pMesh->m_tTextureUV.push_back(textureUV);
// 
// 		textureUV = SPVec3f(1.0f, 1.0f);
// 		m_pMesh->m_tTextureUV.push_back(textureUV);
// 
// 		textureUV = SPVec3f(0.0f, 0.0f);
// 		m_pMesh->m_tTextureUV.push_back(textureUV);
// 
// 		textureUV = SPVec3f(1.0f, 0.0f);
// 		m_pMesh->m_tTextureUV.push_back(textureUV);

		setMesh(m_pMesh);
	}

	SPVoid SPDrawRect::flipTextureV()
	{
		SPFloat temp = m_pMesh->m_tTextureUV[0].y;
		m_pMesh->m_tTextureUV[0].y = m_pMesh->m_tTextureUV[2].y;
		m_pMesh->m_tTextureUV[2].y = temp;

		temp = m_pMesh->m_tTextureUV[1].y;
		m_pMesh->m_tTextureUV[1].y = m_pMesh->m_tTextureUV[3].y;
		m_pMesh->m_tTextureUV[3].y = temp;
	}

	SPVoid SPDrawRect::createRectColorShader()
	{
		// Shader Program for DrawRect
		SPChar VertexShader[] =
			"uniform mediump mat4 uMVPMatrix;			\n"
			"attribute vec4 aPosition;					\n"
			"void main()								\n"
			"{											\n"
			"   gl_Position = uMVPMatrix * aPosition; \n"
			"}											\n";

		SPChar FragmentShader[] =
			"precision mediump float;                           \n"
			"uniform vec4 uColor;								\n"
			"void main()                                        \n"
			"{                                                  \n"
			"   gl_FragColor = uColor;							\n"
			"}                                                  \n";

		m_nDrawMode = 0;
		
		createShaderProgram(VertexShader, FragmentShader);
	}

	SPVoid SPDrawRect::createRectTextureShader()
	{
		// Shader Program for DrawRect
		SPChar VertexShader[] =
			"uniform mediump mat4 uMVPMatrix;				\n"
			"attribute vec4 aPosition;						\n"
			"attribute vec2 aTexUV;							\n"
			"varying vec2 vTexUV;							\n"
			"void main()									\n"
			"{												\n"
			"   vTexUV = aTexUV;							\n"
			"   gl_Position = uMVPMatrix * aPosition;		\n"
			"}												\n";

		SPChar FragmentShader[] =
			"precision mediump float;                           \n"
			"uniform vec4 uColor;								\n"
			"uniform sampler2D uTexMap;                         \n"
			"varying vec2 vTexUV;								\n"
			"void main()                                        \n"
			"{                                                  \n"
			"  vec4 TexColor = texture2D( uTexMap, vTexUV );    \n"
			"  gl_FragColor = TexColor * uColor;				\n"
			"}                                                  \n";

		m_nDrawMode = 1;

		createShaderProgram(VertexShader, FragmentShader);
	}

	SPVoid SPDrawRect::createRectFontShader()
	{
		// Shader Program for DrawRect
		SPChar VertexShader[] =
			"uniform mediump mat4 uMVPMatrix;				\n"
			"attribute vec4 aPosition;						\n"
			"attribute vec2 aTexUV;						    \n"
			"varying vec2 vTexUV;							\n"
			"void main()									\n"
			"{												\n"
			"   vTexUV = aTexUV;							\n"
			"   gl_Position = uMVPMatrix * aPosition;		\n"
			"}												\n";

		SPChar FragmentShader[] =
			"precision mediump float;                           \n"
			"uniform vec4 uColor;								\n"
			"uniform sampler2D uTexMap;                         \n"
			"varying vec2 vTexUV;								\n"
			"void main()                                        \n"
			"{                                                  \n"
			"  vec4 TexColor = texture2D( uTexMap, vTexUV );    \n"
			"  gl_FragColor = vec4(uColor.rgb, TexColor.a);     \n"
			"}                                                  \n";

		m_nDrawMode = 2;

		createShaderProgram(VertexShader, FragmentShader);
	}	

	SPVoid SPDrawRect::setTextureUV(const SPVec3f& idx_1, const SPVec3f& idx_2, const SPVec3f& idx_3, const SPVec3f& idx_4)
	{
		m_pMesh->m_tTextureUV.clear();		
		m_pMesh->m_tTextureUV.push_back(idx_1);
		m_pMesh->m_tTextureUV.push_back(idx_2);
		m_pMesh->m_tTextureUV.push_back(idx_3);
		m_pMesh->m_tTextureUV.push_back(idx_4);
	}

	SPVoid SPDrawRect::resizeSurface(SPFloat width, SPFloat height)
	{
		setOrthogonalCameraView(0.0f, width, 0.0f, height, -5000, 5000.0f);
		createRectVertex(width, height);
	}

}//namespace SPhysics
