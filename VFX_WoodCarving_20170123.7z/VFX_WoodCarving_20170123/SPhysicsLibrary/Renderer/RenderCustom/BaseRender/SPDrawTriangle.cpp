/**
* @file SPDrawTriangle.cpp
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/


#include "SPDrawTriangle.h"
#include "SPTextureManager.h"

namespace SPhysics
{
	SPDrawTriangle::SPDrawTriangle() : m_TextureId(-1), m_nDrawShapeMode(0), m_nDrawColorMode(0)
	{
		uniform0 = 0;
		uniform1 = 1;
		uniform2 = 2;
		uniform3 = 3;

		attribute0 = 0;	attribute1 = 1;	attribute2 = 2;	attribute3 = 3;

	}

	SPDrawTriangle::~SPDrawTriangle()
	{
	}

	SPVoid SPDrawTriangle::initRender( SPFloat width, SPFloat height )
	{

		setOrthogonalCameraView(0.0f, width, 0.0f, height, -5000, 5000.0f);
		//setOrthogonalCameraView( -width * 0.5f, width * 0.5f, -height * 0.5f, height * 0.5f, -5000.0f, 5000.0f);

		m_nDrawColorMode = DRAW_TEXTURE_COLOR;
		m_nDrawShapeMode = SHAPE_TRIANGLES;

		createTriangleTextureShader();
	}

	SPVoid SPDrawTriangle::drawRender()
	{
		// set shader
		switch(m_nDrawColorMode)
		{
		case DRAW_ATTRIBUTE_COLOR:
			drawTriangleAttributeColor();
			break;
		case DRAW_TEXTURE_COLOR:
			drawTriangleTextureColor();
			break;
		case DRAW_UNIFORM_COLOR:
			drawTriangleUniformColor();
			break;
		}

		// set draw shape
		switch(m_nDrawShapeMode)
		{
		case SHAPE_TRIANGLES:
			setDrawArraysWithOption(DRAW_TRIANGLES);
			break;
		case SHAPE_TRIANGLES_FAN:
			setDrawArraysWithOption(DRAW_TRIANGLES_FAN);
			break;
		case SHAPE_TRIANGLES_STRIP:
			setDrawArraysWithOption(DRAW_TRIANGLES_STRIP);
			break;
		}
	}

	SPVoid SPDrawTriangle::drawTriangleUniformColor()
	{
		setShaderArrayMeshVertex("aPosition");
		setShaderUniformMVPMatrix("uMVPMatrix");
		setShaderUnformColor("uColor");
	}

	SPVoid SPDrawTriangle::drawTriangleAttributeColor()
	{
		setShaderArrayMeshVertex("aPosition");
		setShaderArrayMeshColor("aColor");
		setShaderUniformMVPMatrix("uMVPMatrix");
	}

	SPVoid SPDrawTriangle::drawTriangleTextureColor()
	{
		//setShaderArrayMeshVertex("aPosition");
		//setShaderArrayMeshUV("aTexUV");
		//setShaderUniformMVPMatrix("uMVPMatrix");

		//setShaderUnformColor("uColor");
		//setShaderUnifromTexture("uTexMap", m_TextureId);

		//===========================================================================================================================//

		//glBindBuffer(GL_ARRAY_BUFFER,  SPVBOManager::getInstancePtr()->getVertexBufferID());
		//glBufferData(GL_ARRAY_BUFFER, m_pRenderMesh->getNumOfVertex() * 3 * 4, &m_pRenderMesh->m_tVertex[0], GL_STATIC_DRAW);
		//glVertexAttribPointer(attribute0, 3, GL_FLOAT, SPFALSE, 0, 0);
		//glEnableVertexAttribArray(attribute0);
		//glBindBuffer(GL_ARRAY_BUFFER, 0);

		//glBindBuffer(GL_ARRAY_BUFFER, SPVBOManager::getInstancePtr()->getUVBufferID());
		//glBufferData(GL_ARRAY_BUFFER, m_pRenderMesh->getNumOfVertex() * 3 * 4, &m_pRenderMesh->m_tTextureUV[0], GL_STATIC_DRAW);
		//glVertexAttribPointer(attribute1, 3, GL_FLOAT, SPFALSE, 0, 0);
		//glEnableVertexAttribArray(attribute1);
		//glBindBuffer(GL_ARRAY_BUFFER, 0);


		//glUniformMatrix4fv(uniform0, 1, GL_FALSE, m_pRenderMVP->getMVPMatrix());
		//
		//glUniform4fv(uniform1, 1, (SPFloat*)&m_ObjectColor[0]);
		//glActiveTexture ( GL_TEXTURE0 + 0 );
		//glBindTexture ( GL_TEXTURE_2D, m_TextureId );
		//glUniform1i(uniform2,0);

		

		//===========================================================================================================================//
		glVertexAttribPointer(attribute0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(SPFloat), &m_pRenderMesh->m_tVertex[0]);
		glEnableVertexAttribArray(attribute0);

		glVertexAttribPointer(attribute1, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(SPFloat), &m_pRenderMesh->m_tTextureUV[0]);
		glEnableVertexAttribArray(attribute1);

		glUniformMatrix4fv(uniform0, 1, GL_FALSE, m_pRenderMVP->getMVPMatrix());

		glUniform4fv(uniform1, 1, (SPFloat*)&m_ObjectColor[0]);
		glActiveTexture ( GL_TEXTURE0 + 0 );
		glBindTexture ( GL_TEXTURE_2D, m_TextureId );
		glUniform1i(uniform2,0);
		
		//

	}

	SPVoid SPDrawTriangle::setTexture(const SPChar *fileName, SPBool isMipMapMode )
	{
		createTriangleTextureShader();
#if (ANDROID_PORTING_MODE)
		m_TextureId = SPTextureManager::getInstancePtr()->getTextureID(fileName);
#else
		m_TextureId = SPTextureManager::getInstancePtr()->loadTexture(fileName, isMipMapMode);		
#endif
	}

	SPVoid SPDrawTriangle::changeTexture( const SPChar *fileName)
	{
#if (ANDROID_PORTING_MODE)
		m_TextureId = SPTextureManager::getInstancePtr()->getTextureID(fileName);
#else
		m_TextureId = SPTextureManager::getInstancePtr()->loadTexture(fileName);
#endif
	}


// 	SPVoid SPDrawTriangle::setXenTexture(const SPChar *fileName)
// 	{
// 	#ifndef _WIN32
// 		m_TextureId = SPTextureManager::getInstancePtr()->loadTextureCallback(fileName);
// 	#endif	
// 	}

	// mode ::  0 : draw lines, 1 : draw line strip, 2 : draw line loop
	SPVoid SPDrawTriangle::setDrawShapeMode( SPInt mode )
	{
		m_nDrawShapeMode = mode;
	}

	SPVoid SPDrawTriangle::setDrawColorMode( SPInt mode )
	{
		if(m_nDrawColorMode != mode)
		{
			switch(mode)
			{
			case DRAW_ATTRIBUTE_COLOR :
				createTriangleAttributeColorShader();
				break;
			case DRAW_TEXTURE_COLOR :
				createTriangleTextureShader();
				break;
			case DRAW_UNIFORM_COLOR :
				createTriangleUniformColorShader();
				break;
			}
		}
	}

	SPVoid SPDrawTriangle::createTriangleUniformColorShader()
	{
		// Shader Program for DrawTriangle
		SPChar VertexShader[] =  
			"uniform mediump mat4 uMVPMatrix;			\n"
			"attribute vec4 aPosition;					\n"
			"void main()								\n"
			"{											\n"
			"   gl_Position = uMVPMatrix * aPosition; \n"
			"}											\n";

		SPChar FragmentShader[] =  
			"precision mediump float;                           \n"
			"uniform vec4 uColor;								\n"
			"void main()                                        \n"
			"{                                                  \n"
			"   gl_FragColor = uColor;							\n"
			"}                                                  \n";

		m_nDrawColorMode = DRAW_UNIFORM_COLOR;
		createShaderProgram(VertexShader, FragmentShader);
		
	}

	SPVoid SPDrawTriangle::createTriangleAttributeColorShader()
	{
		// Shader Program for DrawTriangle
		SPChar VertexShader[] =  
			"uniform mediump mat4 uMVPMatrix;			\n"
			"attribute vec4 aPosition;					\n"
			"attribute vec4 aColor;					\n"
			"varying vec4 vColor;						\n"
			"void main()								\n"
			"{											\n"
			"	vColor = aColor;						\n"
			"   gl_Position = uMVPMatrix * aPosition; \n"
			"}											\n";

		SPChar FragmentShader[] =  
			"precision highp float;                     \n"
			"varying vec4 vColor;						\n"
			"void main()                                \n"
			"{                                          \n"
			"   gl_FragColor = vColor;					\n"
			"}											\n";

		m_nDrawColorMode = DRAW_ATTRIBUTE_COLOR;
		createShaderProgram(VertexShader, FragmentShader);

	}

	SPVoid SPDrawTriangle::createTriangleTextureShader()
	{
		// Shader Program for DrawTriangle
		SPChar VertexShader[] =  
			"uniform mediump mat4 uMVPMatrix;			\n"
			"attribute vec4 aPosition;					\n"
			"attribute vec2 aTexUV;					\n"
			"varying vec2 vTexUV;						\n"
			"void main()								\n"
			"{											\n"
			"   vTexUV = aTexUV;						\n"
			"   gl_Position = uMVPMatrix * aPosition; \n"
			"}											\n";

		SPChar FragmentShader[] =  
			"precision mediump float;                           \n"
			"uniform vec4 uColor;								\n"
			"uniform sampler2D uTexMap;                        \n"
			"varying vec2 vTexUV;								\n"
			"void main()                                        \n"
			"{                                                  \n"			
			"  vec4 TexColor = texture2D( uTexMap, vTexUV);  \n"
			"  gl_FragColor = vec4(TexColor.rgb * uColor.rgb, TexColor.w);				\n"
			//"  gl_FragColor = TexColor;							\n"
			"}                                                  \n";

		m_nDrawColorMode = DRAW_TEXTURE_COLOR;

		createShaderProgram(VertexShader, FragmentShader);

		attribute0 = glGetAttribLocation(m_pRenderShader->getProgram(),"aPosition");
		attribute1 = glGetAttribLocation(m_pRenderShader->getProgram(),"aTexUV");

		uniform0 = glGetUniformLocation(m_pRenderShader->getProgram(),"uMVPMatrix");
		uniform1 = glGetUniformLocation(m_pRenderShader->getProgram(),"uColor");
		uniform2 = glGetUniformLocation(m_pRenderShader->getProgram(),"uTexMap");
	}
}//namespace SPhysics
