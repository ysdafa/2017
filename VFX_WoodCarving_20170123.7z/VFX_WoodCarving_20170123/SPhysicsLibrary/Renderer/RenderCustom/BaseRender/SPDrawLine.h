/**
* @file SPDrawLine.h
* @brief This file includes module that draws various line
*
* @date 2013-02-13
* @author Joonseok Lee (wonipa.lee@samsung.com)
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_DRAW_LINE_H_
#define _SP_DRAW_LINE_H_

#include "SPDefines.h"
#include "SPIRenderer.h"

#include "SPShaderManager.h"
#include "SPMVPManager.h"
#include "SPMesh.h"
#include "glm.hpp"

namespace SPhysics
{
	//! @brief Mode for Drawing line
	typedef enum _DRAW_LINE_MODE
	{
		SHAPE_LINES,				/*!< drawing line */
		SHAPE_LINE_STRIP,			/*!< drawing line-stripe */
		SHAPE_LINE_LOOP			/*!< drawing line-loop */
	}DRAW_LINE_MODE;

	/**
	* @class SPDrawLine
	* @brief This class is mainly for Drawing Line and supports Mesh setting, color setting, etc,.
	* @par Features:
	*    - Support various drawing mode : line, line strip, line loop
	*/
	class SPDrawLine : public SPIRenderer
	{	  

	public:
		/**
		* @brief     Constructor
		*/
		SPDrawLine();
		/**
		* @brief     Destructor
		*/
		~SPDrawLine();

	public:

		/**
		* @brief     Initialize and Prepare rendering\n
		(set camera setting, initialize shader , create rectangle mesh)
		* @param     [IN] SPFloat width Clipping Plane's width size
		* @param     [IN] SPFloat height Clipping Plane's height size
		* @return     SPVoid
		*/
		SPVoid initRender(SPFloat width, SPFloat height); // virtual

		/**
		* @brief     Mesh setting & binding shader variables for drawing.
		* @return     SPVoid
		 */
		SPVoid drawRender(); // virtual

		/**
		* @brief Set drawing mode  \n
		           (0 : draw lines, 1 : draw line strip, 2 : draw line loop)
		* @param [IN] @b mode mode value
		*/
		SPVoid setDrawMode(SPInt mode);    // 

		/**
		* @brief Set draw array or elements
		* @param [IN] @b bEnable
		*/
		SPVoid setDrawArray(SPBool bEnable);
	private:
		/**
		* @brief create&initialize shader
		*/
		SPVoid createLineShader();

	private:
		SPInt    m_nDrawMode;			//! 0 : draw lines, 1 : draw line strip, 2 : draw line loop
		SPBool   m_bDrawArray;
	};

}//namespace SPhysics

#endif //_SP_DRAW_LINE_H_