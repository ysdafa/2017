/**
* @file SPDrawTriangle.h
* @brief This file includes module that represent triangle
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_DRAW_TRIANGLE_H_
#define _SP_DRAW_TRIANGLE_H_

#include "SPDefines.h"
#include "SPIRenderer.h"

#include <glm.hpp>

namespace SPhysics
{
	/**
	* @enum      DRAW_TRIANGLE_MODE_
	* @brief     Triangle drawing mode
	*/
	typedef enum DRAW_TRIANGLE_MODE_
	{
		SHAPE_TRIANGLES,
		SHAPE_TRIANGLES_STRIP,
		SHAPE_TRIANGLES_FAN
	}DRAW_TRIANGLE_MODE;	//!< Triangle drawing mode

	/**
	* @enum      DRAW_COLOR_MODE_
	* @brief     Color drawing mode
	*/
	typedef enum DRAW_COLOR_MODE_
	{
		DRAW_TEXTURE_COLOR,
		DRAW_UNIFORM_COLOR,
		DRAW_ATTRIBUTE_COLOR
	}DRAW_COLOR_MODE;	//!< Color drawing mode

	/**
	* @class     SPDrawTriangle
	* @brief	 Draw triangle
	*/
	class SPDrawTriangle : public SPIRenderer
	{

	public:
		SPDrawTriangle();
		~SPDrawTriangle();

	public:
		/**
		* @brief     Initialize and Prepare rendering\n
		(set camera setting, initialize shader , create rectangle mesh)
		* @param     [IN] SPFloat width Clipping Plane's width size
		* @param     [IN] SPFloat height Clipping Plane's height size
		* @return     SPVoid
		*/
		SPVoid initRender(SPFloat width, SPFloat height); // virtual

		/**
		* @brief     Mesh setting & binding shader variables for drawing.
		* @return     SPVoid
		 */
		SPVoid drawRender(); // virtual

		/**
		* @brief     Set draw mode
		* @param     [IN] @b  mode Draw mode select 0 : draw lines, 1 : draw line strip, 2 : draw line loop
		* @return     SPVoid
		*/
		SPVoid setDrawShapeMode(SPInt mode);   

		/**
		* @brief    Set color mode
		* @param     [IN] @b  mode mode select 0 : uniform color, 1 : attribute color
		* @return     SPVoid
		*/
		SPVoid setDrawColorMode(SPInt mode);

		/**
		* @brief Set texture of object
		* @param [IN] @b fileName File path of object texture 
		* @param [IN] @b isMipMapMode Mipmap mode select
		* @return    SPVoid
		*/
		SPVoid setTexture(const SPChar *fileName, SPBool isMipMapMode = SPFALSE);

		/**
		* @brief Change texture of object
		* @param [IN] @b fileName File path of object texture 
		* @return    SPVoid
		*/
		SPVoid changeTexture( const SPChar *fileName);

		/**
		* @brief   Use other platform(android)'s texture  
		* @param     [IN] @b fileName File name for texturing. 
		* @return     SPVoid
		*/
		//SPVoid setXenTexture(const SPChar *fileName);


	private:
		/**
		* @brief     Create Vertex and pixel shader( color option ) 
		* @return    SPVoid
		*/
		SPVoid createTriangleUniformColorShader();
		/**
		* @brief     Create Vertex and pixel shader( attribute color option )
		* @return    SPVoid
		*/
		SPVoid createTriangleAttributeColorShader();
		/**
		* @brief	 Create Vertex and pixel shader( texture apply option )
		* @return    SPVoid
		*/
		SPVoid createTriangleTextureShader();

		/**
		* @brief     draw triangles with uniform color
		* @return    SPVoid
		*/
		SPVoid drawTriangleUniformColor();

		/**
		* @brief     draw triangles with attribute color
		* @return    SPVoid
		*/
		SPVoid drawTriangleAttributeColor();

		/**
		* @brief     draw triangles with texture color
		* @return    SPVoid
		*/
		SPVoid drawTriangleTextureColor();

	private:
		SPUInt m_TextureId;
		SPInt    m_nDrawShapeMode;			// 0 : draw lines, 1 : draw line strip, 2 : draw line loop
		SPInt    m_nDrawColorMode;		    // 0 : texture color 1 : uniform color, 2 : attribute color


		SPUInt	uniform0, uniform1, uniform2, uniform3;
		SPUInt	attribute0, attribute1, attribute2, attribute3;
	};

}//namespace SPhysics

#endif //_SP_DRAW_TRIANGLE_H_