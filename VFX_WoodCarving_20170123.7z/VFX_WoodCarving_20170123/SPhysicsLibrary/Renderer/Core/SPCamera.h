/**
* @file SPCamera.h
* @brief Camera properties
*
* @date 2014-01-29
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/


#ifndef _SP_CAMERA_H_
#define _SP_CAMERA_H_

#include "SPDefines.h"
#include <glm.hpp>

namespace SPhysics
{

	/**
	* @class     SPCamera
	* @brief     This class manages and specifies camera properties
	*/
	class SPCamera
	{
	public:
		/**
		* @enum      SP_CAMERA_TYPE
		* @brief     Type of camera projection
		*/
		enum SP_CAMERA_TYPE
		{
			SP_CAMERA_ORTHO = 1,	//!< Orthographic
			SP_CAMERA_PERSPECTIVE	//!< Perspective
		};

		SPCamera();

		/**
		* @brief     Get camera type
		*/
		SP_CAMERA_TYPE             getCameraType() const;
		/**
		* @brief     Get field of view
		*/
		SPFloat                    getFieldOfView() const;
		/**
		* @brief     Get position
		*/
		const SPVec4f& getPosition() const;
		/**
		* @brief     Get direction
		*/
		const SPVec4f& getDirection() const;
		/**
		* @brief     Get up-vector
		*/
		const SPVec4f& getUpVector() const;

		/**
		* @brief     Set camera type
		*/
		SPVoid setCameraType  (SP_CAMERA_TYPE cameraType);
		/**
		* @brief     Set field of view
		*/
		SPVoid setFieldOfView (SPFloat fieldOfView);
		/**
		* @brief     Set position
		*/
		SPVoid setPosition    (const SPVec4f& position);
		/**
		* @brief     Set direction
		*/
		SPVoid setDirection   (const SPVec4f& direction);
		/**
		* @brief     Set up-vector
		*/
		SPVoid setUpVector    (const SPVec4f& upVector);

	private:
		SP_CAMERA_TYPE mCameraType;
		SPFloat mFieldOfView;
		SPVec4f mPosition;
		SPVec4f mDirection;
		SPVec4f mUpVector;

	}; // class SPCamera

} //namespace SPhysics

#endif // _SP_CAMERA_H_
