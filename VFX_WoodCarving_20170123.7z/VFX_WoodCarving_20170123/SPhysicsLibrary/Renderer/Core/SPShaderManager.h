/**
* @file SPShaderManager.h
* @brief This file includes module that manages shaders
*
* @date 
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/


#ifndef _SP_SHADER_MANAGER_H_
#define _SP_SHADER_MANAGER_H_

#include "SPDefines.h"

#include <vector>
#include <glm.hpp>

namespace SPhysics
{
	/**
	* @enum      _SHADER_ATTRIBUTE_LOC
	* @brief     Attribute Location handle ID
	*/
	typedef enum _SHADER_ATTRIBUTE_LOC
	{
		ATTRIBUTE0,
		ATTRIBUTE1,
		ATTRIBUTE2,
		ATTRIBUTE3,
		ATTRIBUTE4,
		ATTRIBUTE5,
		ATTRIBUTE6,
		ATTRIBUTE7,
		ATTRIBUTE8,
		ATTRIBUTE9,
		ATTRIBUTE10,
		ATTRIBUTE11,
		ATTRIBUTE12,
		ATTRIBUTE13,
		ATTRIBUTE14,
		ATTRIBUTE15,
		ATTRIBUTE16,
		ATTRIBUTE17,
		ATTRIBUTE18,
		ATTRIBUTE19,
		ATTRIBUTE20
	}SHADER_ATTRIBUTE_LOC;	//!< Attribute Location handle ID

	/**
	* @enum      _SHADER_UNIFORM_LOC
	* @brief     Uniform Location handle ID
	*/
	typedef enum _SHADER_UNIFORM_LOC
	{
		UNIFORM0,
		UNIFORM1,
		UNIFORM2,
		UNIFORM3,
		UNIFORM4,
		UNIFORM5,
		UNIFORM6,
		UNIFORM7,
		UNIFORM8,
		UNIFORM9,
		UNIFORM10,
		UNIFORM11,
		UNIFORM12,
		UNIFORM13,
		UNIFORM14,
		UNIFORM15,
		UNIFORM16,
		UNIFORM17,
		UNIFORM18,
		UNIFORM19,
		UNIFORM20,
		UNIFORM21,
		UNIFORM22,
		UNIFORM23,
		UNIFORM24,
		UNIFORM25
	}SHADER_UNIFORM_LOC;	//!< Uniform Location handle ID

	/**
	* @enum      _SHADER_TEXTURE_LOC
	* @brief     Texture Location handle ID
	*/
	typedef enum _SHADER_TEXTURE_LOC
	{
		TEXTURE0,
		TEXTURE1,
		TEXTURE2,
		TEXTURE3,
		TEXTURE4,
		TEXTURE5,
		TEXTURE6,
		TEXTURE7,
		TEXTURE8,
		TEXTURE9
	}SHADER_TEXTURE_LOC;	//!< Texture Location handle ID

	/**
	* @class     SPShaderManager
	* @brief     Manage all the information about shader
	*/
	class SPShaderManager
	{

	public:
		SPShaderManager();
		~SPShaderManager();
		/**
		* @brief     Reset information about shader
		* @return     SPVoid
		*/
		SPVoid reset();
		/**
		* @brief     Create shader program and shader load, program link, check the link status
		* @param     [IN] @b vertexShaderSrc		vertex shader code
		* @param     [IN] @b fragmentShaderSrc	fragment shader code
		* @return     SPVoid
		*/
		SPVoid createProgram ( const SPChar* vertexShaderCode, const SPChar* fragmentShaderCode );	
		/**
		* @brief     Add attribute type value
		* @param     [IN] @b index					index of attribute
		* @param     [IN] @b attributeName	name of attribute 
		* @return     SPVoid
		*/
		SPVoid addAttribute(SPInt index, const SPChar* attributeName);	
		/**
		* @brief     Add uniform type value
		* @param     [IN] @b index					index of uniform
		* @param     [IN] @b uniformName		name of uniform 
		* @return     SPVoid
		*/
		SPVoid addUniform(SPInt index, const SPChar* uniformName);

		/**
		* @brief     Get m_nProgramObject
		* @return     SPUInt
		*/
		SPUInt getProgram();
		/**
		* @brief     Get index value of m_vAttributeLoc
		* @param     [IN] @b index	 indexof m_vAttributeLoc
		* @return     SPUInt
		*/
		SPUInt getAttribute(SPInt index);
		/**
		* @brief     Get index value of m_vUniformLoc
		* @param     [IN] @b index	 index of m_vUniformLoc
		* @return     SPInt
		*/
		SPInt getUniform(SPInt index);
		/**
		* @brief     Get attribute handling by program
		* @param     [IN] @b name attribute name
		* @return     SPUInt
		*/
		SPUInt getAttributeLoc(const SPChar* name);
		/**
		* @brief     Get uniform handling by program
		* @param     [IN] @b name uniform name
		* @return     SPInt
		*/
		SPInt  getUniformLoc(const SPChar* name);

	private:
		/**
		* @brief     Create shader program and shader load.\n called by createProgram()
		* @param     [IN] @b type					shader type ( GL_VERTEX_SHADER, GL_FRAGMENT_SHADER )
		* @param     [IN] @b shaderSrc		shader code
		* @return    SPBool @b return the status of compile
		*/
		SPBool compileShader( SPUInt shaderID, const SPChar* shaderCode );

		/**
		* @brief     print the error message about the status of compile, link
		* @param     [IN] @b objectID		object ID : shader or program
		* @param     [IN] @b objectType		objectType : shader or program
		* @return    SPVoid
		*/
		SPVoid printGLErrorLog( SPUInt objectID, SPUInt objectType);

	private :
		SPUInt m_nProgramObject;
		std::vector<SPVec2u > m_vAttributeLoc;
		std::vector<SPVec2i > m_vUniformLoc;
	};

}//namespace SPhysics

#endif //_SP_SHADER_MANAGER_H_