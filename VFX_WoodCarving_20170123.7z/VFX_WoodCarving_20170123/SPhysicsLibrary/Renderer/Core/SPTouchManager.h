/**
* @file SPTouchManager.h
* @brief This file includes module that manage camera setting and model,view,projection transforms.
*
* @date 
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_TOUCH_MANAGER_H_
#define _SP_TOUCH_MANAGER_H_

#include "SPDefines.h"
#include <vector>
#include <glm.hpp>

namespace SPhysics
{
	#define MAX_TOUCH_NUM	10	//!< Maximum number of touches

	/**
	* @class     SPTouchManager
	* @brief     This class manages camera setting and transformation.
	*/
	class SPTouchManager
	{

	public:
		/**
		* @brief     Constructor
		*/
		SPTouchManager();

		/**
		* @brief     Destructor
		*/
		~SPTouchManager();

	public:
		/**
		* @brief	 set the touch information to manage the touch data for the single touch
		* @param     [IN] @b touch event type
		* @param     [IN] @b touch event x position
		* @param     [IN] @b touch event y position
		* @return     SPVoid
		*/
		SPVoid setTouchEvent(SPInt eventType, SPInt xPos, SPInt yPos);

		/**
		* @brief	 set the touch information to manage the touch data for the multi-touch
		* @param     [IN] @b touch event id
		* @param     [IN] @b touch event number
		* @param     [IN] @b touch event type
		* @param     [IN] @b touch event x position array
		* @param     [IN] @b touch event y position array
		* @return     SPVoid
		*/
		SPVoid setMultiTouchEvent(SPInt touchID, SPInt touchNum, SPInt eventType, SPInt *xPos, SPInt *yPos);

		/**
		* @brief	 return the previouse touch position value
		* @param     [IN] @b touch index (in case single touch, always touch idx = 0)
		* @return     SPVec2i
		*/
		SPVec2i getPrevTouchPosition(SPInt touchIdx = 0);

		/**
		* @brief	 return the current touch position value
		* @param     [IN] @b touch index (in case single touch, always touch idx = 0)
		* @return     SPVec2i
		*/
		SPVec2i getTouchPosition(SPInt touchIdx = 0);

		/**
		* @brief	 return the touch event type
		* @param     [IN] @b touch index (in case single touch, always touch idx = 0)
		* @return     SPVec2i
		*/
		SPInt getTouchEventType(SPInt touchIdx = 0);

		/**
		* @brief	 return the running touch number
		* @return     SPInt
		*/
		SPInt  getTouchNum();

		/**
		* @brief	 return the running touch id (ex : for(int idx; idx < touchnum: ~) getRunningTouchID[idx])
		* @return     SPInt
		*/
		SPInt  getRunningTouchID(SPInt index);

	public:
		std::vector<SPInt > m_stRunningTouchID;	//!< Running touch Id
		std::vector<SPInt > m_stTouchEventType;	//!< Touch event type

 		std::vector<SPVec2i > m_stCurrTouchPos;	//!< Current touch position
 		std::vector<SPVec2i > m_stPrevTouchPos;	//!< Previous touch position

		SPInt m_nTouchNum;	//!< Touch number

	};

}//namespace SPhysics

#endif //_SP_MULTI_TOUCH_MANAGER_H_