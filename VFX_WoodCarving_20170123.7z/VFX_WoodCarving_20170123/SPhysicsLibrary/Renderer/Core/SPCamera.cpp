#include "SPCamera.h"

namespace SPhysics
{


SPCamera::SPCamera():
	mCameraType(SP_CAMERA_ORTHO),
	mFieldOfView(0.f),
	mPosition(0.f,0.f,0.f,0.f),
	mDirection(0.f,0.f,0.f,0.f),
	mUpVector(0.f,0.f,0.f,0.f)
{

}

//==================================================================================================
// getters
//==================================================================================================
SPCamera::SP_CAMERA_TYPE SPCamera::getCameraType() const
{
	return mCameraType;
}
//--------------------------------------------------------------------------------------------------
SPFloat SPCamera::getFieldOfView() const
{
	return mFieldOfView;
}
//--------------------------------------------------------------------------------------------------
const SPVec4f& SPCamera::getPosition() const
{
	return mPosition;
}
//--------------------------------------------------------------------------------------------------
const SPVec4f& SPCamera::getDirection() const
{
	return mDirection;
}
//--------------------------------------------------------------------------------------------------
const SPVec4f& SPCamera::getUpVector() const
{
	return mUpVector;
}
//==================================================================================================
// setters
//==================================================================================================
SPVoid SPCamera::setCameraType(SP_CAMERA_TYPE cameraType)
{
	mCameraType = cameraType;
}
//--------------------------------------------------------------------------------------------------
SPVoid SPCamera::setFieldOfView(float fieldOfView)
{
	mFieldOfView = fieldOfView;
}
//--------------------------------------------------------------------------------------------------
SPVoid SPCamera::setPosition(const SPVec4f& position)
{
	mPosition = position;
}
//--------------------------------------------------------------------------------------------------
SPVoid SPCamera::setDirection(const SPVec4f& direction)
{
	mDirection = direction;
}
//--------------------------------------------------------------------------------------------------
SPVoid SPCamera::setUpVector(const SPVec4f& upVector)
{
	mUpVector = upVector;
}
//--------------------------------------------------------------------------------------------------

} //namespace SPhysics
