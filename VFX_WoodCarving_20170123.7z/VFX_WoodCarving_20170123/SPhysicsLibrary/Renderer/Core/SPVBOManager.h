/**
* @file SPVBOManager.h
* @brief This file includes module that manages gl-buffer(vbo).
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_VBO_MANAGER_H_
#define _SP_VBO_MANAGER_H_

#include "SPDefines.h"
#include <vector>

namespace SPhysics
{
	/**
	* @struct     _VERTEX_BUFFER_OBJ
	* @brief     Specifies the Buffer's properties after generater the VBO
	*/
	typedef struct _VERTEX_BUFFER_OBJ
	{
		SPChar vBufferName[50];	//!< name of the buffer
		SPUInt vBufferID;	//!< Image width
	}VERTEX_BUFFER_OBJ;

	/**
	* @struct     _INDEX_BUFFER_OBJ
	* @brief     Specifies the Buffer's properties after generater the VBO
	*/
	typedef struct _INDEX_BUFFER_OBJ
	{
		SPChar iBufferName[50];	//!< name of the buffer
		SPUInt iBufferID;	//!< Image width
	}INDEX_BUFFER_OBJ;
	
	/**
	* @class     SPVBOManager
	* @brief    This class manages VBO buffer
	*/
	class SPVBOManager
	{
	  
	public:
		/**
		* @brief     Constructor
		*/
		SPVBOManager();
		
		/**
		* @brief     Destructor
		*/
		~SPVBOManager();

	public:

		/**
		* @brief     return vertex buffer object id.
		* @return     SPUInt
		*/
		SPUInt getVertexBufferObject( const SPChar* name);

		/**
		* @brief     return index buffer id.
		* @return     SPUInt
		*/
		SPUInt getIndexBufferObject( const SPChar* name);

	private:

		std::vector <VERTEX_BUFFER_OBJ> m_vVertexBufferItems;
		std::vector <INDEX_BUFFER_OBJ> m_vIndexBufferItems;
	};

}//namespace SPhysics

#endif //_SP_VBO_MANAGER_H_