/**
* @file SPFBOManager.cpp
* @brief 
*
* @date 2013-12-31
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPFBOManager.h"
// 
// namespace SPhysics
// {
// 	SPFBOManager *SPFBOManager::m_pInstance = SPNULL;
// 
// 	SPFBOManager::SPFBOManager()
// 	{
// 	}
// 
// 	SPFBOManager::~SPFBOManager()
// 	{		
// 	}
// 
// 	SPFBOManager * SPFBOManager::getInstancePtr()
// 	{
// 		if(!m_pInstance)
// 		{
// 			m_pInstance = new SPFBOManager();
// 		}
// 
// 		return m_pInstance;
// 	}
// 
// 	SPhysics::SPVoid SPFBOManager::ReleaseInstance()
// 	{
// 		if(m_pInstance != SPNULL)
// 		{
// 			delete m_pInstance; 
// 			m_pInstance = SPNULL;
// 		}
// 	}
// }//namespace SPhysics