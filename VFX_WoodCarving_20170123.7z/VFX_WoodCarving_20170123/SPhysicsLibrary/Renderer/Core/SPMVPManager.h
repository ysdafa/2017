/**
* @file SPMVPManager.h
* @brief This file includes module that manage camera setting and model,view,projection transforms.
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_MVP_MANAGER_H_
#define _SP_MVP_MANAGER_H_

#include "SPDefines.h"
#include <glm.hpp>

namespace SPhysics
{

	/**
	* @class     SPMVPManager
	* @brief     This class manages camera setting and transformation.
	*/
	class SPMVPManager
	{

	public:
		/**
		* @brief     Constructor
		*/
		SPMVPManager();

		/**
		* @brief     Destructor
		*/
		~SPMVPManager();

	public:
		/**
		* @brief     Define a Viewing (Transform) matrix
		* @param     [IN] @b eyex The X location of the viewpoint
		* @param     [IN] @b eyey The Y location of the viewpoint
		* @param     [IN] @b eyez The Z location of the viewpoint
		* @param     [IN] @b centerx The position of the reference point X
		* @param     [IN] @b centery The position of the reference point Y
		* @param     [IN] @b centerz The position of the reference point Z
		* @param     [IN] @b upx The X-direction of the up vector
		* @param     [IN] @b upy The Y-direction of the up vector
		* @param     [IN] @b upz The Z-direction of the up vector
		*/
		SPVoid setLookAt(SPFloat eyex, SPFloat eyey, SPFloat eyez, SPFloat centerx, SPFloat centery, SPFloat centerz, SPFloat upx, SPFloat upy, SPFloat upz);
		/**
		* @brief     Define a Viewing (Transform) matrix
		* @param     [IN] @b eye The location of the viewpoint
		* @param     [IN] @b center The position of the reference point
		* @param     [IN] @b up The direction of the up vector
		*/
		SPVoid setLookAt(SPVec3f& eye, SPVec3f& at, SPVec3f& up);
		
		/**
		* @brief     Set frustum of Camera
		* @param     [IN] @b left Coordinates for the left vertical clipping planes
		* @param     [IN] @b right Coordinates for the right vertical clipping planes
		* @param     [IN] @b bottom Coordinates for the bottom horizontal clipping planes
		* @param     [IN] @b top Coordinates for the top horizontal clipping planes
		* @param     [IN] @b nearZ Distances to the near depth clipping planes.  distances must be positive.
		* @param     [IN] @b farZ Distances to the far depth clipping planes.  distances must be positive.
		* @return     SPVoid
		*/
		SPVoid setFrustum(SPFloat left, SPFloat right, SPFloat bottom, SPFloat top, SPFloat nearZ, SPFloat farZ);
		
		/**
		* @brief      Set Camera setting when using perspective view
		* @param     [IN] @b fovy Field of view y angle in degrees.
		* @param     [IN] @b aspect The ratio of the width of a shape to its height
		* @param     [IN] @b nearZ Near plane distance
		* @param     [IN] @b farZ Far plane distance
		* @return     SPVoid
		*/
		SPVoid setPerspective(SPFloat fovy, SPFloat aspect, SPFloat nearZ, SPFloat farZ);
		
		/**
		* @brief     Set Camera setting when using orthogonal view
		* @param     [IN] @b left Coordinates for the left vertical clipping planes
		* @param     [IN] @b right right Coordinates for the right vertical clipping planes
		* @param     [IN] @b bottom Coordinates for the bottom horizontal clipping planes
		* @param     [IN] @b top Coordinates for the top horizontal clipping planes
		* @param     [IN] @b nearZ Distances to the near depth clipping planes. distances must be positive.
		* @param     [IN] @b farZ Distances to the far depth clipping planes.  distances must be positive.
		* @return     SPVoid
		*/
		SPVoid setOrtho(SPFloat left, SPFloat right, SPFloat bottom, SPFloat top, SPFloat nearZ, SPFloat farZ);
		
		/**
		* @brief     Set translated position
		* @param     [IN] @b x X position 
		* @param     [IN] @b y Y position 
		* @param     [IN] @b z Z position
		* @return     SPVoid
		*/
		SPVoid setTranslate(SPFloat x, SPFloat y, SPFloat z);
		
		/**
		* @brief     Set the rotation angle and axis 
		* @param     [IN] @b angle The angle of rotation
		* @param     [IN] @b x Rotation Axis - X value
		* @param     [IN] @b y Rotation Axis - Y value
		* @param     [IN] @b z Rotation Axis - Z value
		* @return     SPVoid
		*/
		SPVoid setRotate(SPFloat angle, SPFloat x, SPFloat y, SPFloat z);
		
		/**
		* @brief     Set scale proportions. \n
						(Ref. 1.0 - current value)
		* @param     [IN] @b xScale X ratio
		* @param     [IN] @b yScale Y ratio
		* @param     [IN] @b zScale Z ratio
		* @return     SPVoid
		*/
		SPVoid setScale(SPFloat x, SPFloat y, SPFloat z);
		
		/**
		* @brief     Set model-transformation matrix
		* @param     [IN] @b matrix Specifies model-transform matrix which User want to set.
		* @return     SPVoid
		*/
		SPVoid setModelTransform(SPMat4x4f& matrix);			//added

		/**
		* @brief     Set view matrix
		* @param     [IN] @b matrix Specifies view matrix which User want to set.
		* @return     SPVoid
		*/
		SPVoid setViewMatrix(const SPMat4x4f& matrix);

		/**
		* @brief     Set view matrix
		* @param     [IN] @b matrix Specifies view matrix which User want to set.
		* @return     SPVoid
		*/
		SPVoid setViewMatrix(const SPFloat *matrix);

		/**
		* @brief     Get Model-View-Projection transform matrix
		* @return     SPFloat* SPFloat type-casted value of matrix.
		*/
		SPFloat* getMVPMatrix();
		
		/**
		* @brief     Get Model-View transform matrix
		* @return     SPFloat* SPFloat type-casted value of matrix.
		*/
		SPFloat* getMVMatrix();
		
		/**
		* @brief     Get Projection transform matrix
		* @return     SPFloat* SPFloat type-casted value of matrix.
		*/
		SPFloat* getProjMatrix();
		
		/**
		* @brief     Get Model transform matrix
		* @return     SPFloat* SPFloat type-casted value of matrix.
		*/
		SPFloat* getModelMatrix();
		
		/**
		* @brief     Get View transform matrix
		* @return     SPFloat* SPFloat type-casted value of matrix.
		*/
		SPFloat* getViewMatrix();
		
		/**
		* @brief     Get View-Projection transform matrix
		* @return     SPFloat* SPFloat type-casted value of matrix.
		*/
		SPFloat* getViewProjMatrix();
		
		/**
		* @brief     Get inverse transform model matrix
		* @return     SPFloat* SPFloat type-casted value of matrix.
		*/
		SPFloat* getITModelMatrix();

		/**
		* @brief     Get Camera position coordinates(Viewpoint position)
		* @return     SPVec3f Camera position
		*/
		SPVec3f getCameraPosition();

		/**
		* @brief     Set camera position
		* @param     [IN] @b _pos Position of camera
		* @return     SPVoid
		*/
		void setCameraPosition(SPVec3f _pos);
		
		/**
		* @brief     Convert floating array values to Matrix
		* @param     [IN] @b matrix Floating-point values list
		* @return     SPVoid
		*/
		SPVoid setModelMatrix(const SPFloat* matrix );

	private:
		/**
		* @brief     Make Viewing transform matrix using camera setting
		* @param     [OUT]result Specifies output matrix
		* @param     [IN] @b eyex The X location of the viewpoint
		* @param     [IN] @b eyey The Y location of the viewpoint
		* @param     [IN] @b eyez The Z location of the viewpoint
		* @param     [IN] @b centerx The position of the reference point X
		* @param     [IN] @b centery The position of the reference point Y
		* @param     [IN] @b centerz The position of the reference point Z
		* @param     [IN] @b upx The X-direction of the up vector
		* @param     [IN] @b upy The Y-direction of the up vector
		* @param     [IN] @b upz The Z-direction of the up vector
		* @return     SPVoid
		*/
		SPVoid getLookAtMatrix(SPMat4x4f *result, SPFloat eyex, SPFloat eyey, SPFloat eyez, SPFloat centerx, SPFloat centery, SPFloat centerz,
			SPFloat upx, SPFloat upy, SPFloat upz);
		
		/**
		* @brief     Make Frustum matrix
		* @param     [OUT]result Specifies output matrix
		* @param     [IN] @b left Coordinates for the left vertical clipping planes
		* @param     [IN] @b right Coordinates for the right vertical clipping planes
		* @param     [IN] @b bottom Coordinates for the bottom horizontal clipping planes
		* @param     [IN] @b top Coordinates for the top horizontal clipping planes
		* @param     [IN] @b nearZ Distances to the near depth clipping planes.  distances must be positive.
		* @param     [IN] @b farZ Distances to the far depth clipping planes.  distances must be positive.
		* @return     SPVoid
		*/
		SPVoid getFrustumMatrix(SPMat4x4f *result, SPFloat left, SPFloat right, SPFloat bottom, SPFloat top, SPFloat nearZ, SPFloat farZ);
		
		/**
		* @brief     Make Perspective set Matrix
		* @param     [OUT]result Specifies output matrix
		* @param     [IN] @b fovy Field of view y angle in degrees.
		* @param     [IN] @b aspect The ratio of the width of a shape to its height
		* @param     [IN] @b nearZ Near plane distance
		* @param     [IN] @b farZ Far plane distance
		* @return     SPVoid
		*/
		SPVoid getPerspectiveMatrix(SPMat4x4f *result, SPFloat fovy, SPFloat aspect, SPFloat nearZ, SPFloat farZ);
		/**
		* @brief     Make Orthogonal set Matrix
		* @param     [OUT]result Specifies output matrix
		* @param     [IN] @b left Coordinates for the left vertical clipping planes
		* @param     [IN] @b right right Coordinates for the right vertical clipping planes
		* @param     [IN] @b bottom Coordinates for the bottom horizontal clipping planes
		* @param     [IN] @b top Coordinates for the top horizontal clipping planes
		* @param     [IN] @b nearZ Distances to the near depth clipping planes. distances must be positive.
		* @param     [IN] @b farZ Distances to the far depth clipping planes.  distances must be positive.
		* @return     SPVoid
		*/
		SPVoid getOrthoMatrix(SPMat4x4f *result, SPFloat left, SPFloat right, SPFloat bottom, SPFloat top, SPFloat nearZ, SPFloat farZ);

		/**
		* @brief     Make matrix reflected scaling factor
		* @param     [OUT]result Specifies output matrix
		* @param     [IN] @b sx X scaling-ratio
		* @param     [IN] @b sy Y scaling-ratio
		* @param     [IN] @b sz Z scaling-ratio
		* @return     SPVoid
		*/
		SPVoid scaleMatrix(SPMat4x4f *result, SPFloat sx, SPFloat sy, SPFloat sz);
		/**
		* @brief     Make matrix reflected translation factor
		* @param     [OUT]result Specifies output matrix
		* @param     [IN] @b tx X position 
		* @param     [IN] @b ty X position 
		* @param     [IN] @b tz X position 
		* @return     SPVoid
		*/
		SPVoid translateMatrix(SPMat4x4f *result, SPFloat tx, SPFloat ty, SPFloat tz);
		
		/**
		* @brief     Make matrix reflected rotating factor
		* @param     [INOUT]result Specifies output matrix
		* @param     [IN] @b angle The angle of rotation
		* @param     [IN] @b x Rotation Axis - X value
		* @param     [IN] @b y Rotation Axis - Y value
		* @param     [IN] @b z Rotation Axis - Z value
		* @return     SPVoid
		*/
		SPVoid rotateMatrix(SPMat4x4f *result, SPFloat angle, SPFloat x, SPFloat y, SPFloat z);
		
		/**
		* @brief     Multiplies matrix
		* @param     [OUT]result Specifies output matrix
		* @param     [IN] @b srcA Specifies input matrix
		* @param     [IN] @b srcB Specifies input matrix
		* @return     SPVoid
		*/
		SPVoid multiplyMatrix(SPMat4x4f *result, SPMat4x4f *srcA, SPMat4x4f *srcB);
		
		/**
		* @brief     Identifies Matrix
		* @param     [OUT]result Specifies output matrix
		* @return     SPVoid
		*/
		SPVoid setIdentityMatrix(SPMat4x4f *result);
		
	private:
		SPMat4x4f m_stMVPMatrix;
		SPMat4x4f m_stMVMatrix;
		SPMat4x4f m_stVPMatrix;

		SPMat4x4f m_stViewMatrix;
		SPMat4x4f m_stProjMatrix;
		SPMat4x4f m_stModelMatrix;
		SPMat4x4f m_stITModelMatrix;		

		SPVec3f m_Translate;
		SPVec3f m_Scale;
		SPVec4f m_Rotate;

	public:
		SPVec3f m_CameraPos;	//!< Camera position
		SPVec3f m_CameraUp;		//!< Camera up-vector
		SPVec3f	m_CameraTgt;	//!< Camera target

	};

}//namespace SPhysics

#endif //_SP_MVP_MANAGER_H_