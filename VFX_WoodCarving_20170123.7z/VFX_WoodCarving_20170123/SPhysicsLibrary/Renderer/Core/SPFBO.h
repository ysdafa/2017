/**
* @file SPFBO.h
* @brief This file includes module that manage camera setting and model,view,projection transforms.
*
* @date
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_FBO_H_
#define _SP_FBO_H_

#include "SPDefines.h"
#include "SPTextureManager.h"
#include <glm.hpp>

namespace SPhysics
{
	/**
	* @class     SPFBO
	* @brief     This class manages the FBO
	*/
	class SPFBO
	{
	public:
		/**
		* @brief     Constructor
		*/
		SPFBO();

		/**
		* @brief     Destructor
		*/
		~SPFBO();

	public:
		/**
		* @brief	 create FBO surface :: fbo handler, texture, color buffer, render buffer
		* @param     [IN] @b width of the FBO
		* @param     [IN] @b height of the FBO
		* @return     SPVoid
		*/
		SPVoid createFBOSurface(const SPUInt& width, const SPUInt& height);

		/**
		* @brief	 resize FBO surface
		* @param     [IN] @b width of the FBO
		* @param     [IN] @b height of the FBO
		* @return     SPVoid
		*/
		SPVoid resizeFBOSurface(const SPUInt& width, const SPUInt& height);

		/**
		* @brief	 clear FBO surface
		* @return     SPVoid
		*/
		SPVoid bindFBOSurface();

		/**
		* @brief	 unbind FBO surface
		* @param     [IN] @b width of the viewport return to Original view
		* @param     [IN] @b height of the viewport return to Original view
		* @return     SPVoid
		*/
		SPVoid unbindFBOSurface(const SPUInt& viewWidth, const SPUInt& viewHeight);

		/**
		* @brief	 clear FBO surface
		* @return     SPVoid
		*/
		SPVoid clearFBOSurface();

		/**
		* @brief	 set the clear color
		* @param     [IN] @b r 
		* @param     [IN] @b g 
		* @param     [IN] @b b 
		* @param     [IN] @b a 
		* @return     SPVoid
		*/
		SPVoid setClearColor(const SPFloat& r, const SPFloat& g, const SPFloat& b, const SPFloat& a);

		/**
		* @brief	 delete FBO surface
		* @return     SPVoid
		*/
		SPVoid destroyFBOSurface();

		/**
		* @brief	 set clear color for FBO surface
		* @return     SPVoid
		*/
		SPVoid setFBOClearColor(const SPFloat& red, const SPFloat& green, const SPFloat& blue, const SPFloat& alpha);

		/**
		* @brief	 return texture handler
		* @return     SPUInt
		*/
		SPUInt getFBOTexture();

		/**
		* @brief	 return depth texture handler
		* @return     SPUInt
		*/
		SPUInt getFBODepthTexture();

		/**
		* @brief	 return FBO handler
		* @return     SPUInt
		*/
		SPUInt getFBOHandler();

		/**
		* @brief	 enable depth buffer (attaches depth buffer to framebuffer. creates depth buffer if it has not been yet created)
		* @return     SPUInt
		*/
		SPVoid enableFBODepthBuffer();

		/**
		* @brief	 disable depth buffer (detaches depth buffer from framebuffer but not deletes)
		* @return     SPUInt
		*/
		SPVoid disableFBODepthBuffer();

		/**
		* @brief	 set a property of the texture wrap mode
		* (options : WRAP_REPEAT = GL_REPEAT,
		*            WRAP_CRAMP = GL_CLAMP_TO_EDGE,
		*            WRAP_MIRRORED = GL_MIRRORED_REPEAT)
		* @return     SPUInt
		*/
		SPVoid setFBOTextureWrapOption(const TEX_WRAP& wrapOption);

		/**
		* @brief	 set a property of the texture magnitude filter
		* (options : MF_NEAREST = GL_NEAREST,
		*            MF_LINEAR = GL_LINEAR)
		* @return     SPUInt
		*/
		SPVoid setFBOTextureMagFilterOption(const TEX_MFILTER& filterOption);

		/**
		* @brief	 set a property of the texture data type
		* options : DT_BYTE             = GL_BYTE,
		*			DT_UNSIGNED_BYTE    = GL_UNSIGNED_BYTE,
		*			DT_SHORT            = GL_SHORT,
		*			DT_UNSIGNED_SHORT   = GL_UNSIGNED_SHORT,
		*			DT_INT              = GL_INT,
		*			DT_UNSIGNED_INT     = GL_UNSIGNED_INT,
		*			DT_FLOAT            = GL_FLOAT,
		*			DT_FIXED            = GL_FIXED  )
		* @return     SPUInt
		*/
		SPVoid setFBOTextureDataType(const TEX_DTYPE& dataType);

	private:
		/**
		* @brief	 create FBO surface :: fbo handler, texture, color buffer, render buffer
		* @param     [IN] @b width of the FBO
		* @return     SPVoid
		*/
		SPVoid bindFBOTexture(const SPUInt& texID);

		/**
		* @brief	 create FBO surface :: fbo handler, texture, color buffer, render buffer
		* @param     [IN] @b width of the FBO
		* @return     SPVoid
		*/
		SPVoid bindFBODepthTexture(const SPUInt& texID);

	private:
		SPBool m_bEnableDepthBuffer;
		SPUInt m_nTextureWrapOption;
		SPUInt m_nTextureMagFilterOption;
		SPUInt m_nTextureDataType;

		SPUInt m_nFBOWidth;
		SPUInt m_nFBOHeight;

		SPUInt m_nFBOHandler;
		SPUInt m_nFBOTexture;
		SPUInt m_nFBODepthTexture;

		SPVec4f m_tClearColor;
	};
}//namespace SPhysics

#endif //_SP_FBO_H_