/**
* @file SPUIManager.h
* @brief 
*
* @date 2013-04-16
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/


#ifndef _SP_UI_MANAGER_H_
#define _SP_UI_MANAGER_H_

#include "SPDefines.h"

#include "SPUIButton.h"
#include "SPColorPalette.h"

#define UI_BUTTON_SIZE_WIDTH		80	//!< UI button width
#define UI_BUTTON_SIZE_HEIGHT		80	//!< UI button height
#define UI_MAINBUTTON_SIZE			60	//!< UI main button size

namespace SPhysics{
	
	/**
	* @class     SPUIManager
	* @brief     UI Manager
	*/
	class SPUIManager
	{
	public:
		/**
		* @enum      _RETURN_VALUE
		* @brief     Return value
		*/
		enum _RETURN_VALUE{
			SP_FALSE,
			SP_BUTTON_HIT,
			SP_COLOR_HIT
		};

		SPUIManager();
		~SPUIManager();

	public:
		/**
		* @brief     Manager init
		*/
		SPVoid ManagerInit(SPInt width, SPInt height);
		/**
		* @brief     Manager update
		*/
		SPInt Managerupdate(SPInt m_nMouseEventType, SPInt m_nMouseX, SPInt m_nMouseY);
		/**
		* @brief     Draw manager
		*/
		SPVoid ManagerDraw();
		/**
		* @brief     Destroy manager
		*/
		SPVoid ManagerDestroy();
		/**
		* @brief     Add UI button material
		*/
		SPVoid Add_MaterialButtonUI(SPChar* _fileName, SPInt _buttonID);
		/**
		* @brief     Get state
		*/
		SPUInt getState();
		/**
		* @brief     Get color
		*/
		SPVec3f getColor();

	private:
		//SPVoid ButtonUI_setOption(){}		Unused private function
		SPVoid Add_MainButtonUI();
		

	private:
		SPInt							m_iScreenWidth;
		SPInt							m_iScreenHeight;

		SPUIButton*					m_UI_onLeftButton;		//�� ��ü�� Ŭ���ϸ�, Material UI�� ����
		SPUIButton*					m_UI_onRightButton;		//�� ��ü�� Ŭ���ϸ�, Color UI�� ����
		std::vector<SPUIButton*>	m_UI_Material_Button_List;		//Material UI ��ư List
		SPUIButton*					m_UI_Color_Button;

		SPBool						m_bMouseRightOverOn;			//���콺�� UI ��ġ�� �ִ��� Ȯ��
		SPBool						m_bMouseLeftOverOn;			//���콺�� UI ��ġ�� �ִ��� Ȯ��

		SPUInt						m_iStatus;				//���� ������, ��ü����, ��ü����..

		SPColorPalette				m_cColorPalette;
		SPVec3f			m_vColor;
	
	};
}
#endif