/**
* @file SPUIButton.h
* @brief 
*
* @date 2013-04-16
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_UIBUTTON_H_
#define _SP_UIBUTTON_H_

#include "SPDefines.h"
#include "SPShaderManager.h"
#include "SPMVPManager.h"
#include "SPMesh.h"
#include "SPDrawTriangle.h"
#include "SPTextureManager.h"

#include <glm.hpp>

namespace SPhysics{

	/**
	* @struct    _BoundingBox
	* @brief     Bounding box
	*/
	typedef struct _BoundingBox{
		SPFloat minX;	//!< Min X
		SPFloat minY;	//!< Min Y
		SPFloat maxX;	//!< Max X
		SPFloat maxY;	//!< Max Y

		_BoundingBox(){
			minX = 0.0f;
			minY = 0.0f;
			maxX = 0.0f;
			maxY = 0.0f;
		}

		/**
		* @brief     Set values
		*/
		SPVoid set(SPFloat _minX, SPFloat _minY, SPFloat _maxX , SPFloat _maxY){
			minX = _minX; minY = _minY; maxX = _maxX; maxY = _maxY; 
		}

	}SPBoundingBox;	//!< Bounding box

	/**
	* @class     SPUIButton
	* @brief     UI button
	*/
	class SPUIButton
	{
	public:
		SPUIButton();
		~SPUIButton();

		/**
		* @brief     Init
		*/
		SPVoid ButtonUI_init(SPFloat width, SPFloat height, SPInt cameraAlign);
		/**
		* @brief     Create vertex
		*/
		SPVoid ButtonUI_createVertex();
		/**
		* @brief     Create texture
		*/
		SPVoid ButtonUI_createTexture();

		/**
		* @brief     Update
		*/
		SPVoid ButtonUI_update();
		/**
		* @brief     Draw
		*/
		SPVoid ButtonUI_draw();
		/**
		* @brief     Destroy
		*/
		SPVoid ButtonUI_destory();

		/**
		* @brief     Set size
		*/
		SPVoid ButtonUI_setSize(SPUInt _XSize, SPUInt _YSize);
		/**
		* @brief     Set scale
		*/
		SPVoid ButtonUI_setScale(){}
		/**
		* @brief     Set position
		*/
		SPVoid ButtonUI_setPos(SPInt _XPos, SPInt _YPos){m_XPosition = _XPos; m_YPosition = _YPos;}
		/**
		* @brief     Set color
		*/
		SPVoid ButtonUI_setColor(){}
		/**
		* @brief     Set texture
		*/
		SPVoid ButtonUI_setTexture(const SPChar* _fileName);
		/**
		* @brief     Set Id
		*/
		SPVoid ButtonUI_setID(const SPUInt _buttonID){m_ButtonID = _buttonID;}

		/**
		* @brief     Set bounding box
		*/
		SPVoid ButtonUI_setBoundingBox(SPInt _minX, SPInt _minY, SPInt _maxX, SPInt _maxY){ m_BoudingBox.minX = _minX; m_BoudingBox.minY = _minY; m_BoudingBox.maxX = _maxX; m_BoudingBox.maxY = _maxY;}
		/**
		* @brief     Get bounding box
		*/
		const SPBoundingBox&	ButtonUI_getBoundingBox(){return m_BoudingBox;}
		/**
		* @brief     Get Id
		*/
		SPUInt			ButtonUI_getID(){ return m_ButtonID; }

	private:
		SPMesh*						m_pMesh;
		SPDrawTriangle				m_cDrawTriangle;
		SPUInt						m_TextureId;
		SPUInt						m_XPosition;
		SPUInt						m_YPosition;
		SPUInt						m_XSize;
		SPUInt						m_YSize;
		SPUInt						m_ButtonID;


		SPBoundingBox				m_BoudingBox;
	};
}

#endif

