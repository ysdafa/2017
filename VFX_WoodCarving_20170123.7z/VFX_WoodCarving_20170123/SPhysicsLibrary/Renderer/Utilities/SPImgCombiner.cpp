#include <stdarg.h>
#include <assert.h>

#include <string.h>

#include "SPMesh.h"
#include "SPImgCombiner.h"
#include "SPLog.h"

#ifdef _WIN32
#	pragma warning(disable:4996)
#endif

namespace SPhysics
{
	SPImgCombiner::SPImgCombiner() : m_layout(true), m_samplingOption(NEAREST_SAMPLING)
	{
	}


	SPImgCombiner::~SPImgCombiner()
	{
	}

	/*
	SPBool SPImgCombiner::mergeTexturing(int paramCnt, TEXTURE_COLOR_BUFFER* outputImg, ... )
	{
		//SP_LOGE("[SPImgCombiner::%s] ----1----", __FUNCTION__);
		const int MAX=5;
		if(paramCnt > MAX) 
		{
			SP_LOGE("[%s] Totoal varying-parameter number is limited %d. ", __FUNCTION__, MAX);
			return false;
		}
		
		TEXTURE_COLOR_BUFFER* srcList[MAX] = {0,};

		va_list arg;
		va_start(arg, paramCnt );

#ifdef _WIN32		// the order of stack is not same.(depends on platform)
#	ifdef _DEBUG
		for(int i=0; i< paramCnt ; i++ )
#	else
		for(int i=1; i< paramCnt ; i++ )
#	endif
		{
			srcList[i] = va_arg( arg, TEXTURE_COLOR_BUFFER* );
			//SP_LOGE("[%s] --address -- [%d] %p", __FUNCTION__, i, srcList[i]);
		}

#else // Android note2
		for(int i=1; i< paramCnt ; i++ )
		{
			srcList[i] = va_arg( arg, TEXTURE_COLOR_BUFFER* );
			//SP_LOGE("[%s] --address -- [%d] %p", __FUNCTION__, i, srcList[i]);
		}
#endif
		va_end(arg);

		//SP_LOGE("[SPImgCombiner::%s] ----2 ----", __FUNCTION__);

		SPVec2i resolution = SPVec2i(outputImg->ImgWidth, outputImg->ImgHeight);
		if (outputImg->ImgSize  != (resolution.x * resolution.y * 4) )
		{
			delete [] outputImg->ImgData ;
			outputImg->ImgData  = NULL;
			outputImg->ImgSize = resolution.x * resolution.y * 4;
			outputImg->ImgData = new SPUChar[outputImg->ImgSize];
		}
				
		outputImg->PixelSize = srcList[1]->PixelSize;
		memset(outputImg->ImgData, 0, outputImg->ImgSize);
			
		
		int dR1[45] ={0,};
		int dR2[45] ={0,};

		//Test hard-coding , index1, 2
		for(int j=0; j< resolution.y; j++ )
		{
			int startPoint =0, passPoint = 0;

			for(int lpCnt = 1; lpCnt < paramCnt ; lpCnt++)
			{
				passPoint += srcList[lpCnt]->ImgWidth;
				
				for (int i=startPoint; i< passPoint; i++ )
				{
					//int dstArrayIdx = ((resolution.y-j)* tex1->ImgWidth + i )* tex1->PixelSize;
					int dstArrayIdx = (j* srcList[lpCnt]->ImgWidth + (i-startPoint) )* srcList[lpCnt]->PixelSize;
					int dR = srcList[lpCnt]->ImgData[ dstArrayIdx];
					int dG = srcList[lpCnt]->ImgData[ dstArrayIdx+1];
					int dB = srcList[lpCnt]->ImgData[ dstArrayIdx+2];
					int dA = srcList[lpCnt]->ImgData[ dstArrayIdx+3];

					int outIdx = (j* resolution.x + i) * srcList[lpCnt]->PixelSize;
					if(outIdx>=outputImg->ImgSize )
						continue;;
					outputImg->ImgData[outIdx] = dR;
					outputImg->ImgData[outIdx+1] = dG;
					outputImg->ImgData[outIdx+2] = dB;
					outputImg->ImgData[outIdx+3] = dA;
				}
				startPoint = passPoint;
			}
		}

		//SP_LOGE("[SPImgCombiner::%s] ---- end ----", __FUNCTION__);
		return true;
	}


	SPBool SPImgCombiner::mergeTexturing2(int paramCnt, bool check[4], TEXTURE_COLOR_BUFFER* outputImg, ... )
	{
		const int MAX=6;
		if(paramCnt > MAX) 
		{
			SP_LOGE("[%s] Totoal varying-parameter number is limited %d. ", __FUNCTION__, MAX);
			return false;
		}
		
		TEXTURE_COLOR_BUFFER* srcList[MAX] = {0,};

		va_list arg;
		va_start(arg, paramCnt );

#ifdef _WIN32		// the order of stack is not same.(depends on platform)
#	ifdef _DEBUG
		for(int i=0; i< paramCnt ; i++ )
#	else
		for(int i=1; i< paramCnt ; i++ )
#	endif
		{
			srcList[i] = va_arg( arg, TEXTURE_COLOR_BUFFER* );
			//SP_LOGE("[%s] --address -- [%d] %p", __FUNCTION__, i, srcList[i]);
		}

#else // Android note2
		for(int i=1; i< paramCnt ; i++ )
		{
			srcList[i] = va_arg( arg, TEXTURE_COLOR_BUFFER* );
		}
#endif
		va_end(arg);

		SPVec2i resolution = SPVec2i(outputImg->ImgWidth, outputImg->ImgHeight);
		if (outputImg->ImgSize  != (resolution.x * resolution.y * 4) )
		{
			delete [] outputImg->ImgData ;
			outputImg->ImgData  = NULL;
			outputImg->ImgSize = resolution.x * resolution.y * 4;
			outputImg->ImgData = new SPUChar[outputImg->ImgSize];
			memset(outputImg->ImgData, 0, outputImg->ImgSize);
		}

		if( m_layout )	//vertical mode
		{
			for(int j=0; j< resolution.y; j++ )
			{
				int startPoint =0, passPoint = 0;

				for(int lpCnt = 2; lpCnt < paramCnt ; lpCnt++)
				{
					passPoint += srcList[lpCnt]->ImgWidth;
				
					if (check [lpCnt-2] == true )
					{
						for (int i=startPoint; i< passPoint; i++ )
						{
							//int dstArrayIdx = ((resolution.y-j)* tex1->ImgWidth + i )* tex1->PixelSize;
							int dstArrayIdx = (j* srcList[lpCnt]->ImgWidth + (i-startPoint) )* srcList[lpCnt]->PixelSize;
							int dR = srcList[lpCnt]->ImgData[ dstArrayIdx];
							int dG = srcList[lpCnt]->ImgData[ dstArrayIdx+1];
							int dB = srcList[lpCnt]->ImgData[ dstArrayIdx+2];
							int dA = srcList[lpCnt]->ImgData[ dstArrayIdx+3];

							int outIdx = (j* resolution.x + i) * srcList[lpCnt]->PixelSize;
							if(outIdx>=outputImg->ImgSize )
								continue;;
							outputImg->ImgData[outIdx] = dR;
							outputImg->ImgData[outIdx+1] = dG;
							outputImg->ImgData[outIdx+2] = dB;
							outputImg->ImgData[outIdx+3] = dA;
						
						}
					}
					startPoint = passPoint;
				}
			} 
		}
		// horizontal mode
		else {
						
			//original
			for(int j=0; j< resolution.y; j++ )
			{
				int startPoint =0, passPoint = 0;

				for(int lpCnt = 2; lpCnt < paramCnt ; lpCnt++)
				{
					passPoint += srcList[lpCnt]->ImgWidth;

					if (check [lpCnt-2] == true )
					{
						for (int i=startPoint; i< passPoint; i++ )
						{
							//int dstArrayIdx = ((resolution.y-j)* tex1->ImgWidth + i )* tex1->PixelSize;
							int dstArrayIdx = (j* srcList[lpCnt]->ImgWidth + (i-startPoint) )* srcList[lpCnt]->PixelSize;
							int dR = srcList[lpCnt]->ImgData[ dstArrayIdx];
							int dG = srcList[lpCnt]->ImgData[ dstArrayIdx+1];
							int dB = srcList[lpCnt]->ImgData[ dstArrayIdx+2];
							int dA = srcList[lpCnt]->ImgData[ dstArrayIdx+3];

							int outIdx = ( (resolution.y -i-1)* resolution.x + j) * srcList[lpCnt]->PixelSize;

							if(outIdx>=outputImg->ImgSize )
								continue;;
							outputImg->ImgData[outIdx] = dR;
							outputImg->ImgData[outIdx+1] = dG;
							outputImg->ImgData[outIdx+2] = dB;
							outputImg->ImgData[outIdx+3] = dA;
						}
					}
					startPoint = passPoint;
				}
			}
		}
		return true;
	}
	*/
	
	// the memory is allocate in the Image info
	TEXTURE_COLOR_BUFFER* SPImgCombiner::overlayImage2WhiteBoard(stImgInfo* srcImgInfo, stImgInfo* outImgInfo, TEXTURE_COLOR_BUFFER* srcImg)
	{
		assert( NULL != srcImg );
		// initialization
		TEXTURE_COLOR_BUFFER*  outputImg = new TEXTURE_COLOR_BUFFER;
		outputImg->ImgWidth = outImgInfo->width;
		outputImg->ImgHeight = outImgInfo->height;
		outputImg->ImgSize = outImgInfo->imgSize;
		outputImg->PixelSize = outImgInfo->pixelSize;
		outputImg->ImgData = new SPUChar[outImgInfo->imgSize];		
		
		memcpy(outputImg->FileName, srcImg->FileName, strlen(srcImg->FileName)+1);

		memset(outputImg->ImgData, 0x00, outputImg->ImgSize);

		SPVec2i resolution = SPVec2i(outputImg->ImgWidth, outputImg->ImgHeight);

		int dstHeightIdx = srcImgInfo->posY;
		int dstWidthIdx = srcImgInfo->posX;

		//duplicate branches for 'if' and 'else'.
		//if( m_layout )	//vertical mode
		{
			for(int j= 0; j< srcImg->ImgHeight; j++ )
			{
				for(int i = 0;  i< srcImg->ImgWidth; i++)
				{
					int dstArrayIdx = (j* srcImg->ImgWidth + i )* srcImg->PixelSize;
					int dR = srcImg->ImgData[ dstArrayIdx];
					int dG = srcImg->ImgData[ dstArrayIdx+1];
					int dB = srcImg->ImgData[ dstArrayIdx+2];
					int dA = srcImg->ImgData[ dstArrayIdx+3];

					int outIdx = ( (dstHeightIdx+ j)* resolution.x + (i+dstWidthIdx) ) * srcImgInfo->pixelSize;
					if(outIdx>=outputImg->ImgSize )
						continue;;
					outputImg->ImgData[outIdx] = dR;
					outputImg->ImgData[outIdx+1] = dG;
					outputImg->ImgData[outIdx+2] = dB;
					outputImg->ImgData[outIdx+3] = dA;

					//printf("[%d][%d] R(%d) G(%d) B(%d) A(%d)\n", j, i, dR, dG, dB, dA);
				}
			} 
		}
		// horizontal mode
		//else {

		//	for(int j= 0; j< srcImg->ImgHeight; j++ )
		//	{
		//		for(int i = 0;  i< srcImg->ImgWidth; i++)
		//		{
		//			int dstArrayIdx = (j* srcImg->ImgWidth + i )* srcImg->PixelSize;
		//			int dR = srcImg->ImgData[ dstArrayIdx];
		//			int dG = srcImg->ImgData[ dstArrayIdx+1];
		//			int dB = srcImg->ImgData[ dstArrayIdx+2];
		//			int dA = srcImg->ImgData[ dstArrayIdx+3];

		//			int outIdx = ( (dstHeightIdx+ j)* resolution.x + (i+dstWidthIdx) ) * srcImgInfo->pixelSize;
		//			if(outIdx>=outputImg->ImgSize )
		//				continue;;
		//			outputImg->ImgData[outIdx] = dR;
		//			outputImg->ImgData[outIdx+1] = dG;
		//			outputImg->ImgData[outIdx+2] = dB;
		//			outputImg->ImgData[outIdx+3] = dA;

		//			//printf("[%d][%d] R(%d) G(%d) B(%d) A(%d)\n", j, i, dR, dG, dB, dA);
		//		}
		//	} 
		//}
		return outputImg;
	}

	SPVoid SPImgCombiner::setResizingMethods(_IMG_SAMPLING_OPTION_ option)
	{
		m_samplingOption = option;
	}


	SPVoid SPImgCombiner::setArrangeLayout(bool layout)
	{
		m_layout = layout;
	}


	TEXTURE_COLOR_BUFFER* SPImgCombiner::resizeImage(TEXTURE_COLOR_BUFFER* srcImg, stImgInfo* sizeInfo)
	{
		return resizeImage(m_samplingOption, srcImg, sizeInfo);
	}


	TEXTURE_COLOR_BUFFER* SPImgCombiner::resizeImage(_IMG_SAMPLING_OPTION_ option, TEXTURE_COLOR_BUFFER* srcImg, stImgInfo* imgInfo)
	{
		//SP_LOGE("[%s] --1 -- ", __FUNCTION__);
		//assert(NULL != srcImg && NULL != outputImg);
		assert(NULL != srcImg ); 
		switch ( option )
		{
		case NEAREST_SAMPLING :
			{
				return resizeNNSampling(srcImg, imgInfo/*, outputImg*/);
			}
			break;
		case BILINEAR_SAMPLING :
			{
				return resizeBilinearSampling(srcImg, imgInfo/*, outputImg*/);
			}
			break;
		default:
			{
				assert(0);
				SP_LOGE("[SPImgCombiner::resizeImage] option is invalid");
			}
			break;
		}

		return NULL;
	}
	

	TEXTURE_COLOR_BUFFER*  SPImgCombiner::resizeNNSampling(TEXTURE_COLOR_BUFFER* srcImg, stImgInfo* imgInfo)
	{
		TEXTURE_COLOR_BUFFER*  outputImg = new TEXTURE_COLOR_BUFFER;

		//SP_LOGE("[%s] --1--", __FUNCTION__);
		SPVec2i resolution = SPVec2i(imgInfo->width, imgInfo->height);
		outputImg->ImgWidth = imgInfo->width;
		outputImg->ImgHeight = imgInfo->height;
		outputImg->ImgSize = imgInfo->imgSize;
		outputImg->PixelSize = imgInfo->pixelSize;
		outputImg->ImgData = new SPUChar[outputImg->ImgSize];		
		memset(outputImg->ImgData, 0, outputImg->ImgSize);
		memcpy(outputImg->FileName, srcImg->FileName, strlen(srcImg->FileName)+1);
				
		float xRatio = (float)srcImg->ImgWidth / resolution.x;
		float yRatio = (float)srcImg->ImgHeight / resolution.y;

		//SP_LOGE("[%s] xRatio : %f, yRatio : %f", __FUNCTION__, xRatio, yRatio);

		
		if( 3 == outputImg->PixelSize )
		{
			for(int j=0; j< resolution.y; j++ )
			{
				for (int i=0; i< resolution.x; i++ )
				{
					int yPos = (int) j*yRatio;
					int xPos = (int) i* xRatio;

					int dstArrayIdx = (yPos* srcImg->ImgWidth + xPos )* srcImg->PixelSize;
					int dR = srcImg->ImgData[ dstArrayIdx];
					int dG = srcImg->ImgData[ dstArrayIdx+1];
					int dB = srcImg->ImgData[ dstArrayIdx+2];

					int outIdx = (j* resolution.x + i) * srcImg->PixelSize;
					outputImg->ImgData[outIdx] = dR;
					outputImg->ImgData[outIdx+1] = dG;
					outputImg->ImgData[outIdx+2] = dB;
				}
			}
		}
		
		else if (4 == outputImg->PixelSize )
		{
			for(int j=0; j< resolution.y; j++ )
			{
				for (int i=0; i< resolution.x; i++ )
				{
					int yPos = (int) j*yRatio;
					int xPos = (int) i* xRatio;

					int dstArrayIdx = (yPos* srcImg->ImgWidth + xPos )* srcImg->PixelSize;
					int dR = srcImg->ImgData[ dstArrayIdx];
					int dG = srcImg->ImgData[ dstArrayIdx+1];
					int dB = srcImg->ImgData[ dstArrayIdx+2];
					int dA = srcImg->ImgData[ dstArrayIdx+3];

					int outIdx = (j* resolution.x + i) * srcImg->PixelSize;
					outputImg->ImgData[outIdx] = dR;
					outputImg->ImgData[outIdx+1] = dG;
					outputImg->ImgData[outIdx+2] = dB;
					outputImg->ImgData[outIdx+3] = dA;
				}
			}
		}

		for(int j=0; j< resolution.y * resolution.x ; j++)
		{
			if (srcImg->ImgData[j] != outputImg->ImgData[j])
			{
				//int a= 0;
			}
		}
		//SP_LOGE("[%s] --2--", __FUNCTION__);

		return outputImg;
	}

	TEXTURE_COLOR_BUFFER* SPImgCombiner::resizeBilinearSampling(TEXTURE_COLOR_BUFFER* srcImg, stImgInfo* imgInfo)
	{
		TEXTURE_COLOR_BUFFER* outputImg = new TEXTURE_COLOR_BUFFER;

		SPVec2i resolution = SPVec2i(imgInfo->width, imgInfo->height);
		outputImg->ImgWidth = imgInfo->width;
		outputImg->ImgHeight = imgInfo->height;
		outputImg->ImgSize = imgInfo->imgSize;
		outputImg->PixelSize = imgInfo->pixelSize;
		outputImg->ImgData = new SPUChar[outputImg->ImgSize];		
		memset(outputImg->ImgData, 0, outputImg->ImgSize);
		memcpy(outputImg->FileName, srcImg->FileName, strlen(srcImg->FileName)+1);

		float xRatio = (float)srcImg->ImgWidth / resolution.x;
		float yRatio = (float)srcImg->ImgHeight / resolution.y;

		//SP_LOGE("[%s] xRatio : %f, yRatio : %f", __FUNCTION__, xRatio, yRatio);
		
		for(int j=0; j< resolution.y; j++ )
		{
			for (int i=0; i< resolution.x; i++ )
			{
				float yPrecisePos =  j*yRatio;
				float xPrecisePos =  i* xRatio;

				int y1Pos = (int) yPrecisePos;
				int x1Pos = (int) xPrecisePos;

				int x2Pos = x1Pos +1;
				int y2Pos = y1Pos + 1;

				if( x2Pos == srcImg->ImgWidth  )
				{
					x2Pos = srcImg->ImgWidth - 1; 
				}
				if ( y2Pos == srcImg->ImgHeight )
					y2Pos = srcImg->ImgHeight -1;

				float p = xPrecisePos - x1Pos;
				float q = yPrecisePos - y1Pos;


				int dstOutIdx = (j* resolution.x + i) * srcImg->PixelSize;

				//for(int k =0; k< outputImg->PixelSize ; k++)
				for(int k =0; k< 4 ; k++)
				{
					int y1x1 = (srcImg->ImgWidth* y1Pos + x1Pos) * srcImg->PixelSize + k;
					int y1x2 = (srcImg->ImgWidth* y1Pos + x2Pos) * srcImg->PixelSize + k;
					int y2x1 = (srcImg->ImgWidth* y2Pos + x1Pos) * srcImg->PixelSize + k;
					int y2x2 = (srcImg->ImgWidth* y2Pos + x2Pos) * srcImg->PixelSize + k;

					float outputColor = (  (1.0f - p) * (1.f - q) * srcImg->ImgData[y1x1] +p*(1.0f -q) * srcImg->ImgData[y1x2] +
						(1.0f - p ) * q * srcImg->ImgData[y2x1] + p* q* srcImg->ImgData[y2x2] 
					);
					outputImg->ImgData[dstOutIdx + k] = (int) outputColor;
				}
			}
		}
		
		return outputImg;
	}


}
