/**
* @file SPColorPalette.h
* @brief This files is the implementation of Color Palette Modules.
*
* @date 2013-04-16
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/


#ifndef _SP_COLOR_PALETTE_H_
#define _SP_COLOR_PALETTE_H_

#include "SPDefines.h"

#include "SPDrawRect.h"
#include "SPOperations.h"
#include "SPMesh.h"

namespace SPhysics
{

	/**
	* @class     SPColorPalette
	* @brief     This class implements function about Color Palette, i.e, Color setting/getting, Changing Color button Size. etc.
	*/
	class SPColorPalette
	{		
		/* Methods */
	public:		
		/**
		* @brief     Constructor
		*/
		SPColorPalette();
		/**
		* @brief     Destructor
		*/
		~SPColorPalette();

		/**
		* @brief     Initialize 
		* @param     [IN] @b width Resolution Width size
		* @param     [IN] @b height Resolution Height size
		* @return    SPVoid
		*/
		SPVoid initialize(const SPFloat& width, const SPFloat& height);

		/**
		* @brief     Draw Control Button & Color Palette
		* @return    SPVoid
		*/
		SPVoid draw();

		/**
		* @brief     Do event-processing
		* @param     [IN] @b mouse_x
		* @param     [IN] @b mouse_y
		* @param     [IN] @b mouse_event
		* @return    SPBool
		*/
		SPBool onEventMouse( const SPFloat& mouse_x, const SPFloat& mouse_y, const SPFloat& mouse_event );

		/**
		* @brief     Calculate Color value based on Input-position in Palette-Control.
		* @param     [IN] @b width
		* @param     [IN] @b height
		* @param     SPBool isUpEvent
		* @return    SPBool
		*/
		SPBool pickColor(const SPFloat& width, const SPFloat& height, SPBool isUpEvent = SPFALSE);

		/**
		* @brief     Change Control-Button size
		* @param     [IN] @b size Value which User want to change
		*/
		SPVoid setControlButtonSize(const SPFloat& size);

		/**
		* @brief     Change Control-Button size
		* @param     [IN] @b width Value(width) which User want to change
		* @param     [IN] @b height Value(height) which User want to change
		*/
		SPVoid setControlButtonSize(const SPFloat& width, const SPFloat& height);

		/**
		* @brief     Change Control-Button position
		* @param     [IN] @b x X-Coordinate
		* @param     [IN] @b y Y-Coordinate
		* @return    SPVoid
		*/
		SPVoid setControlButtonPosition(const SPFloat& x, const SPFloat& y);

		/**
		* @brief     Change Color-Palette-Control Size.
		* @param     [IN] @b size The value that user want to set.
		*/
		SPVoid setColorPaletteSize(const SPFloat& size);

		/**
		* @brief     Change Color-Palette-Control Size 
		* @param     [IM] @width Value(width) which User want to change
		* @param     [IN] @b height Value(height) which User want to change
		*/
		SPVoid setColorPaletteSize(const SPFloat& width, const SPFloat& height);

		/**
		* @brief     Change Color-Palette-Control Position
		* @param     [IN] @b x X-Coordinate
		* @param     [IN] @b y Y-Coordinate
		*/
		SPVoid setColorPalettePosition(const SPFloat& x, const SPFloat& y);

		/**
		* @brief     Set Color-Control-Button's Color
		* @param     [IN] @b r Color's R value
		* @param     [IN] @b g Color's G value
		* @param     [IN] @b b Color's B value
		*/
		SPVoid setColor(const SPFloat& r, const SPFloat& g, const SPFloat& b);

		/**
		* @brief     Set Color-Control-Button's Color
		* @param     [IN] @b const SPVec3f& color Color which User want to set.
		*/
		SPVoid setColor(const SPVec3f& color);

		/**
		* @brief     Get Picked Color Value.
		* @return    const SPVec3f& Return Color using SPVector3D type.
		*/
		const SPVec3f& getColor() const;

		/**
		* @brief     Get Picked Color's R value.
		* @return    const SPFloat & Return Color's R value.
		*/
		const SPFloat& getRed() const;

		/**
		* @brief     Get Picked Color's G value.
		* @return    const SPFloat & Return Color's G value.
		*/
		const SPFloat& getGreen() const;

		/**
		* @brief     Get Picked Color's B value.
		* @return    const SPFloat & Return Color's B value.
		*/
		const SPFloat& getBlue() const;		

		/**
		* @brief     Set Color-Control-Button Visible
		* @param     [IN] @b SPBool bVisible visible flag
		*/
		SPVoid setControlButtonVisible(const SPBool& bVisible);

	protected:
	private:

		/**
		* @brief     Check that User's touch(mouse) Color-Control-Button
		* @param     [IN] @b mousePos Input Position
		* @return    SPBool true : if touched   false : if not.
		*/
		SPBool hitControlButton(const SPVec2f& mousePos);

		/**
		* @brief     Convert Screen Coordinate to Simulation Resolution Coordinates.
		* @param     [IN] @b arg Screen Coordinates
		* @return    const SPVec2f Return Converted Coordinates, using SPVector2D Types.
		*/
		inline const SPVec2f screenToSimulationRes(const SPVec2f& arg)
		{
			return SPVec2f(arg.x / (SPFloat)m_vScreenResolution.x * m_vSimulationResolution.x, arg.y / (SPFloat)m_vScreenResolution.y * m_vSimulationResolution.y);
		};

		/**
		* @brief     Convert Screen Coordinate to Simulation Resolution Coordinates.
		* @param     [IN] @b x X-coordinate
		* @param     [IN] @b y Y-coordinate
		* @return    const SPVec2f Return Converted Coordinates, using SPVector2D Types.
		*/
		inline const SPVec2f screenToSimulationRes(const SPFloat& x, const SPFloat& y)
		{
			return SPVec2f(x / (SPFloat)m_vScreenResolution.x * m_vSimulationResolution.x, y / (SPFloat)m_vScreenResolution.y * m_vSimulationResolution.y);
		};

		/* Member Variables */
	public:
	protected:
	private:

		SPVec2f m_vScreenResolution;
		SPVec2f m_vSimulationResolution;		

		// 		SPInt       m_nColorArrWidth;
		// 		SPInt       m_nColorArrHeight;

		SPVec2f m_vColorArraySize;

		SPVec2f m_vControlButtonPosition;

		SPVec2f m_fControlButtonSize;

		SPDrawRect*         m_pDrawControlButton;

		SPVec3f m_vColor;
		SPVec2f m_vColorPalettePosition;
		SPVec2f m_fColorPaletteSize;

		SPDrawRect*         m_pDrawColorPalette;

		SPBool              m_bColorPaletteVisible;	
		SPBool              m_bControlButtonVisible;
	};

}  //namespace SPhysics

#endif // _SP_COLOR_PALETTE_H_