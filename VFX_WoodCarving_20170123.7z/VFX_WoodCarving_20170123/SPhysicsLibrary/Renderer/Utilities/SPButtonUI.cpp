/**
* @file SPButtonUI.cpp
* @brief 
*
* @date 2013-04-16
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include <stdlib.h>


#include "SPButtonUI.h"
#include "SPTextureManager.h"

namespace SPhysics{

	SPButtonUI::SPButtonUI() : m_ButtonDraw(SPNULL), 
		m_ButtonStretchType(0), m_buttonWidth(0.0),m_buttonHeight(0.0),m_halfButtonWidth(0.0),m_halfButtonHeight(0.0),m_ScreenWidth(0.0),m_ScreenHeight(0.0),
		m_LeftPosition(0.0),m_BottomPosition(0.0),m_MagnifyRatio(0.0),m_ButtonDisplayState(0),m_CurrentButtonID(0),m_MagnifyButtonID(0),m_MagnifierMoveUpPos(0.0)
	{
	}

	SPButtonUI::~SPButtonUI(){
		SP_SAFE_DELETE(m_ButtonDraw);
		m_vButtonItems.clear();
	}
	SPVoid SPButtonUI::reset()
	{
		SP_SAFE_DELETE(m_ButtonDraw);
		m_vButtonItems.clear();
	}
	SPVoid SPButtonUI::init( SPFloat width, SPFloat height )
	{
		m_ButtonDisplayState = IDLE_STATE;
		m_MagnifyButtonID = -1;
		m_CurrentButtonID = 0;
		m_buttonWidth = 50.0f;
		m_buttonHeight = 50.0f;
		m_MagnifyRatio = 1.5f;

		m_ButtonStretchType = LEFT_RIGHT;
		//m_MagnifierMoveUpPos = 50.0f;
		m_ScreenWidth = width;
		m_ScreenHeight = height;
		m_halfButtonWidth = m_buttonWidth * 0.5f;
		m_halfButtonHeight = m_buttonHeight * 0.5f;
		m_MagnifierMoveUpPos = height * m_MagnifyRatio;
		if(m_ButtonDraw == SPNULL)
			m_ButtonDraw = new SPDrawRect();
		m_ButtonDraw->initialize(width, height);
		m_ButtonDraw->setRectAlign(RECT_ALIGN_CENTER);
		m_ButtonDraw->setSize(m_buttonWidth, m_buttonHeight);
	}
	SPVoid SPButtonUI::setPosition( SPFloat x, SPFloat y )
	{
		SPFloat diffX = x - m_LeftPosition;
		SPFloat diffY = y - m_BottomPosition;
		m_LeftPosition += diffX;
		m_BottomPosition += diffY;

		for(SPInt idx = 0; idx < (SPInt)m_vButtonItems.size(); idx++)
		{
			m_vButtonItems[idx].left += diffX;
			m_vButtonItems[idx].bottom += diffY;
		}
	}

	SPVoid SPButtonUI::addButton(const SPChar *imgName )
	{
		//SPInt insertButtonNum = m_vButtonItems.size();
		SP_BUTTON button;
		button.left = m_LeftPosition;
		button.bottom = m_BottomPosition;

#if (ANDROID_PORTING_MODE)
		button.TextureID = SPTextureManager::getInstancePtr()->getTextureID(imgName);
#else
		button.TextureID = SPTextureManager::getInstancePtr()->loadTexture(imgName, SPTRUE);
#endif
		m_vButtonItems.push_back(button);
	}



	SPVoid SPButtonUI::setStretchType( SPInt type )
	{
		m_ButtonStretchType = type;
	}


	SPVoid SPButtonUI::draw()
	{
		switch(m_ButtonStretchType)
		{
		case LEFT_RIGHT:
			draw_left_to_right();
			break;
		case BOTTOM_TOP_LEFT:
			draw_bottom_to_top_left();
			break;
		case BOTTOM_TOP_RIGHT:
			draw_bottom_to_top_right();
			break;
		case TOP_BOTTOM_LEFT:
			draw_top_to_bottom_left();
			break;
		case TOP_BOTTOM_RIGHT:
			draw_top_to_bottom_right();
			break;
		}
	}


	SPInt SPButtonUI::onTouchEvent( SPInt eventType, SPFloat x, SPFloat y )
	{
		//m_vButtonItems[0].scale = 1.5f;
		SPFloat mouseY = y;

		switch(eventType)
		{
		case 0: // TOUCH_DOWN
			{
				actionMouseDownEvent(x, mouseY);
				break;
			}
		case 1: // TOUCH_UP
			{
// 				m_ButtonDisplayState = IDLE_STATE;
// 				m_vButtonItems[m_CurrentButtonID].scale = 1.0f; 
				actionMouseUpEvent(x, mouseY);
				break;

			}
		case 2: // TOUCH_MOVE
			{
				actionMouseMoveEvent(x, mouseY);
				break;
			}
		}
		if(m_ButtonDisplayState == STRETCH_MAGNIFIER_STATE)
		{
			return 1;
		}else
		{
			return 0;
		}
	}


	SPVoid SPButtonUI::setButtonSize( SPFloat width, SPFloat height )
	{
		m_buttonWidth = width;
		m_buttonHeight = height;

		m_ButtonDraw->setSize(m_buttonWidth, m_buttonHeight);

		m_halfButtonWidth = m_buttonWidth * 0.5f;
		m_halfButtonHeight = m_buttonHeight * 0.5f;

		m_MagnifierMoveUpPos = height * m_MagnifyRatio;
	}


	SPVoid SPButtonUI::setMagnifyRatio( SPFloat ratio )
	{
        m_MagnifyRatio = ratio;
	}

	SPInt SPButtonUI::getCurrentButton()
	{
		return m_CurrentButtonID;
	}

	SPVoid SPButtonUI::actionMouseDownEvent( SPFloat x, SPFloat y )
	{
// 		m_ButtonDisplayState = STRETCH_STATE;
// 		m_CurrentButtonID = 5;
// 		m_vButtonItems[m_CurrentButtonID].scale = 1.4f; 

		switch(m_ButtonDisplayState)
		{
		case IDLE_STATE:
			{
				if(hitTestButton(m_vButtonItems[m_CurrentButtonID], x, y))
				{
					m_ButtonDisplayState = STRETCH_MAGNIFIER_STATE;
					m_MagnifyButtonID = 0;
				}
				break;
			}
		case STRETCH_STATE:
			{
				for(SPInt idx = 0; idx < (SPInt)m_vButtonItems.size(); idx++)
				{
					if(hitTestButton(m_vButtonItems[idx], x, y))
					{
						m_ButtonDisplayState = STRETCH_MAGNIFIER_STATE;
						m_MagnifyButtonID = idx;
						break;
					}
				}
				break;
			}
		case STRETCH_MAGNIFIER_STATE:
			{
				break;
			}
		case FOLD_ANIMATE_STATE:
			{
				break;
			}
		case UNFOLD_ANIMATE_STATE:
			{
				break;
			}
		}
	}

	SPVoid SPButtonUI::actionMouseUpEvent( SPFloat x, SPFloat y )
	{
		switch(m_ButtonDisplayState)
		{
		case IDLE_STATE:
			{

				break;
			}
		case STRETCH_STATE:
			{

				break;
			}
		case STRETCH_MAGNIFIER_STATE:
			{
				if(m_MagnifyButtonID != -1)
				{
					//m_ButtonDisplayState = STRETCH_STATE;
					m_ButtonDisplayState = IDLE_STATE;
					m_CurrentButtonID = m_MagnifyButtonID;
					m_MagnifyButtonID = -1;

					resetButtonCoordinate();
				}else
				{
					m_ButtonDisplayState = IDLE_STATE;
				}
				break;
			}
		case FOLD_ANIMATE_STATE:
			{

				break;
			}
		case UNFOLD_ANIMATE_STATE:
			{

				break;
			}
		}
	}

	SPVoid SPButtonUI::actionMouseMoveEvent( SPFloat x, SPFloat y )
	{
		switch(m_ButtonDisplayState)
		{
		case IDLE_STATE:
			{

				break;
			}
		case STRETCH_STATE:
			{

				break;
			}
		case STRETCH_MAGNIFIER_STATE:
			{
				for(SPInt idx = 0; idx < (SPInt)m_vButtonItems.size(); idx++)
				{
					if(hitTestButton(m_vButtonItems[idx], x, y))
					{
//						m_ButtonDisplayState = STRETCH_MAGNIFIER_STATE;
						m_MagnifyButtonID = idx;
						break;
					}
				}
				break;
			}
		case FOLD_ANIMATE_STATE:
			{

				break;
			}
		case UNFOLD_ANIMATE_STATE:
			{

				break;
			}
		}
	}

	SPVoid SPButtonUI::resetButtonCoordinate()
	{
		for(SPInt idx = 0; idx < (SPInt)m_vButtonItems.size(); idx++)
		{
			m_vButtonItems[idx].left = m_LeftPosition;
			m_vButtonItems[idx].bottom = m_BottomPosition;
		}
	}

	SPInt SPButtonUI::hitTestButton( SP_BUTTON button, SPFloat touchX, SPFloat touchY )
	{
		SPInt hitTest = 0;
		if(button.left <= touchX && touchX <= button.left + m_buttonWidth)
		{
			if( button.bottom <= touchY && touchY <= button.bottom + m_buttonHeight)
			{
				hitTest = 1;
			}
		}

		return hitTest;
	}


	SPVoid SPButtonUI::draw_left_to_right()
	{
		switch(m_ButtonDisplayState)
		{
		case IDLE_STATE:
			{
				m_ButtonDraw->setTranslate(m_halfButtonWidth + m_LeftPosition, m_halfButtonHeight + m_BottomPosition, 0.0);
				m_ButtonDraw->setScale(1.0f, 1.0f, 0.0f);
				m_ButtonDraw->setTextureID(m_vButtonItems[m_CurrentButtonID].TextureID);
				m_ButtonDraw->setColor(1.0f, 1.0f, 1.0f, 0.2f);
				m_ButtonDraw->draw();
				break;
			}
		case STRETCH_STATE:
			{
				for(SPInt idx = 0; idx < (SPInt)m_vButtonItems.size(); idx++)
				{
					m_vButtonItems[idx].left = m_LeftPosition + idx * m_buttonWidth;

					m_ButtonDraw->setTranslate(m_halfButtonWidth + m_LeftPosition + idx * m_buttonWidth, m_halfButtonHeight + m_BottomPosition, 0.0);
					m_ButtonDraw->setScale(1.0f, 1.0f, 0.0f);
					m_ButtonDraw->setTextureID(m_vButtonItems[idx].TextureID);
					m_ButtonDraw->draw();
				}
				break;
			}
		case STRETCH_MAGNIFIER_STATE:
			{
				m_ButtonDraw->setColor(1.0f, 1.0f, 1.0f, 1.0f);
				if(m_MagnifyButtonID == -1)  // there is no seclected button
				{				
					for(SPInt idx = 0; idx < (SPInt)m_vButtonItems.size(); idx++)
					{
						m_vButtonItems[idx].left = m_LeftPosition + idx * m_buttonWidth;

						m_ButtonDraw->setTranslate(m_halfButtonWidth + m_LeftPosition + idx * m_buttonWidth, m_halfButtonHeight + m_BottomPosition, 0.0);
						m_ButtonDraw->setScale(1.0f, 1.0f, 0.0f);
						m_ButtonDraw->setTextureID(m_vButtonItems[idx].TextureID);
						m_ButtonDraw->draw();
					}
				}else
				{
					for(SPInt idx = 0; idx < (SPInt)m_vButtonItems.size(); idx++)
					{
						//if(m_MagnifyButtonID != idx)
						{
							m_vButtonItems[idx].left = m_LeftPosition + idx * m_buttonWidth;

							m_ButtonDraw->setTranslate(m_halfButtonWidth + m_LeftPosition + idx * m_buttonWidth, m_halfButtonHeight + m_BottomPosition, 0.0);
							m_ButtonDraw->setScale(1.0f, 1.0f, 0.0f);
							m_ButtonDraw->setTextureID(m_vButtonItems[idx].TextureID);
							m_ButtonDraw->draw();
						}
					}

					m_vButtonItems[m_MagnifyButtonID].left = m_LeftPosition + m_CurrentButtonID * m_buttonWidth;

					//m_ButtonDraw->setTranslate(m_halfButtonWidth + m_LeftPosition + m_MagnifyButtonID * m_buttonWidth, m_halfButtonHeight + m_BottomPosition, 0.0);
					m_ButtonDraw->setTranslate(m_halfButtonWidth + m_LeftPosition + m_MagnifyButtonID * m_buttonWidth, m_halfButtonHeight + m_BottomPosition + m_MagnifierMoveUpPos, 0.0);
					//m_ButtonDraw->setTranslate(m_halfButtonWidth + m_LeftPosition + m_MagnifyButtonID * m_buttonWidth, m_halfButtonHeight + m_BottomPosition + m_buttonHeight, 0.0);
					m_ButtonDraw->setScale(m_MagnifyRatio, m_MagnifyRatio, 0.0f);
					m_ButtonDraw->setTextureID(m_vButtonItems[m_MagnifyButtonID].TextureID);
					m_ButtonDraw->draw();
				}
				break;
			}
		case FOLD_ANIMATE_STATE:
			{
				break;
			}
		case UNFOLD_ANIMATE_STATE:
			{
				break;
			}
		}
	}

	SPVoid SPButtonUI::draw_bottom_to_top_left()
	{

	}

	SPVoid SPButtonUI::draw_bottom_to_top_right()
	{

	}

	SPVoid SPButtonUI::draw_top_to_bottom_left()
	{

	}

	SPVoid SPButtonUI::draw_top_to_bottom_right()
	{
		switch(m_ButtonDisplayState)
		{
		case IDLE_STATE:
			{
				m_ButtonDraw->setTranslate(m_halfButtonWidth + m_LeftPosition, m_halfButtonHeight + m_BottomPosition, 0.0);
				m_ButtonDraw->setScale(1.0f, 1.0f, 0.0f);
				m_ButtonDraw->setTextureID(m_vButtonItems[m_CurrentButtonID].TextureID);
				m_ButtonDraw->setColor(1.0f, 1.0f, 1.0f, 0.2f);
				m_ButtonDraw->draw();
				break;
			}
		case STRETCH_STATE:
			{
				for(SPInt idx = 0; idx < (SPInt)m_vButtonItems.size(); idx++)
				{
					m_vButtonItems[idx].left = m_LeftPosition + idx * m_buttonWidth;

					m_ButtonDraw->setTranslate(m_halfButtonWidth + m_LeftPosition + idx * m_buttonWidth, m_halfButtonHeight + m_BottomPosition, 0.0);
					m_ButtonDraw->setScale(1.0f, 1.0f, 0.0f);
					m_ButtonDraw->setTextureID(m_vButtonItems[idx].TextureID);
					m_ButtonDraw->draw();
				}
				break;
			}
		case STRETCH_MAGNIFIER_STATE:
			{
				m_ButtonDraw->setColor(1.0f, 1.0f, 1.0f, 1.0f);
				if(m_MagnifyButtonID == -1)  // there is no seclected button
				{				
					for(SPInt idx = 0; idx < (SPInt)m_vButtonItems.size(); idx++)
					{
						//m_vButtonItems[idx].left = m_LeftPosition + idx * m_buttonWidth;
						m_vButtonItems[idx].left = m_LeftPosition;
						m_vButtonItems[idx].bottom = m_BottomPosition - idx * m_buttonHeight;

						//m_ButtonDraw->setTranslate(m_halfButtonWidth + m_LeftPosition + idx * m_buttonWidth, m_halfButtonHeight + m_BottomPosition, 0.0);
						m_ButtonDraw->setTranslate(m_halfButtonWidth + m_LeftPosition, m_halfButtonHeight + m_vButtonItems[idx].bottom, 0.0);
						m_ButtonDraw->setScale(1.0f, 1.0f, 0.0f);
						m_ButtonDraw->setTextureID(m_vButtonItems[idx].TextureID);
						m_ButtonDraw->draw();
					}
				}else
				{
// 					for(SPInt idx = 0; idx < m_vButtonItems.size(); idx++)
// 					{
// 						//if(m_MagnifyButtonID != idx)
// 						{
// 							m_vButtonItems[idx].left = m_LeftPosition + idx * m_buttonWidth;
// 
// 							m_ButtonDraw->setTranslate(m_halfButtonWidth + m_LeftPosition + idx * m_buttonWidth, m_halfButtonHeight + m_BottomPosition, 0.0);
// 							m_ButtonDraw->setScale(1.0f, 1.0f, 0.0f);
// 							m_ButtonDraw->setTextureID(m_vButtonItems[idx].TextureID);
// 							m_ButtonDraw->draw();
// 						}
// 					}

					for(SPInt idx = 0; idx < (SPInt)m_vButtonItems.size(); idx++)
					{
						//m_vButtonItems[idx].left = m_LeftPosition + idx * m_buttonWidth;
						m_vButtonItems[idx].left = m_LeftPosition;
						m_vButtonItems[idx].bottom = m_BottomPosition - idx * m_buttonHeight;

						//m_ButtonDraw->setTranslate(m_halfButtonWidth + m_LeftPosition + idx * m_buttonWidth, m_halfButtonHeight + m_BottomPosition, 0.0);
						m_ButtonDraw->setTranslate(m_halfButtonWidth + m_LeftPosition, m_halfButtonHeight + m_vButtonItems[idx].bottom, 0.0);
						m_ButtonDraw->setScale(1.0f, 1.0f, 0.0f);
						m_ButtonDraw->setTextureID(m_vButtonItems[idx].TextureID);
						m_ButtonDraw->draw();
					}

//					m_vButtonItems[m_MagnifyButtonID].left = m_LeftPosition + m_CurrentButtonID * m_buttonWidth;

					//m_ButtonDraw->setTranslate(m_halfButtonWidth + m_LeftPosition + m_MagnifyButtonID * m_buttonWidth, m_halfButtonHeight + m_BottomPosition, 0.0);
					//m_ButtonDraw->setTranslate(m_halfButtonWidth + m_LeftPosition + m_MagnifyButtonID * m_buttonWidth, m_halfButtonHeight + m_BottomPosition + m_MagnifierMoveUpPos, 0.0);
					m_ButtonDraw->setTranslate(m_halfButtonWidth + m_LeftPosition - m_MagnifierMoveUpPos - 50.0, m_halfButtonHeight + m_BottomPosition - m_MagnifyButtonID * m_buttonHeight, 0.0);
					//m_ButtonDraw->setTranslate(m_halfButtonWidth + m_LeftPosition + m_MagnifyButtonID * m_buttonWidth, m_halfButtonHeight + m_BottomPosition + m_buttonHeight, 0.0);
					m_ButtonDraw->setScale(m_MagnifyRatio, m_MagnifyRatio, 0.0f);
					m_ButtonDraw->setTextureID(m_vButtonItems[m_MagnifyButtonID].TextureID);
					m_ButtonDraw->draw();
				}
				break;
			}
		case FOLD_ANIMATE_STATE:
			{
				break;
			}
		case UNFOLD_ANIMATE_STATE:
			{
				break;
			}
		}
	}

}