#ifndef _SPHYSICS_SPIMGCOMBINER_H_
#define _SPHYSICS_SPIMGCOMBINER_H_

#include "SPDefines.h"
#include "SPTextureManager.h"

namespace SPhysics
{
	// Forward class declaration
	class SPMesh;
	struct IMG_COLOR_BUFFER;


	/**
	* @class     SPImgCombiner
	* @brief     Image combiner
	*/
	class SPImgCombiner
	{
	public:
		/**
		* @enum      _IMG_SAMPLING_OPTION_
		* @brief     Image sampling option
		*/
		enum _IMG_SAMPLING_OPTION_
		{
			NEAREST_SAMPLING,
			BILINEAR_SAMPLING,
		};
		
		/**
		* @struct    stImgInfo
		* @brief     Image info
		*/
		struct stImgInfo
		{
			int width;		//!< Width
			int height;		//!< Height
			int pixelSize;	//!< Pixel size
			int imgSize;	//!< Image size
			int posX;		//!< Position X
			int posY;		//!< Position Y
			stImgInfo(): width(0), height(0), pixelSize(0), imgSize(0), posX(0), posY(0)
			{}
		};

		/*explicit */SPImgCombiner();
		virtual ~SPImgCombiner();
		
		/**
		* @brief     Merging Texture
		* @param     [IN] @b N �������� ������ 
		* @param     [INOUT] @b output output image buffer
		* @param     [IN] @b TEXTURE_COLOR_BUFFER* type�� parameter �� �ִ� 4������ �� �� �ִ�.
		* @return     SPBool
		*/
		//SPBool mergeTexturing(int N, TEXTURE_COLOR_BUFFER* output, ... );

		/**
		* @brief     layout �� ���缭 ȸ���ϵ��� ��.
		* @param     [IN] @b N �������� ������ 
		* @param     [INOUT] @b output output image buffer
		* @param     [IN] @b TEXTURE_COLOR_BUFFER* type�� parameter �� �ִ� 4������ �� �� �ִ�.
		* @return     SPBool
		*/
		//SPBool mergeTexturing2(int N, bool check[4], TEXTURE_COLOR_BUFFER* output, ... );
		

		/**
		* @brief     Overlay image to whiteboard
		* @param     [IN] @b srcImgInfo source image info
		* @param     [IN] @b outImgInfo destination image info
		* @param     [IN] @b input source image
		* @return     IMAGE_RGB_BUFFER* instance
		*/
		TEXTURE_COLOR_BUFFER* overlayImage2WhiteBoard(stImgInfo* srcImgInfo, stImgInfo* outImgInfo, TEXTURE_COLOR_BUFFER* input);

		/**
		* @brief     Select Resizing algorithm 
		* @param     [IN] @b option _IMG_SAMPLING_OPTION_ 
		* @return     SPVoid
		*/
		SPVoid setResizingMethods(_IMG_SAMPLING_OPTION_ option);

		/**
		* @brief     Set layout(vertical or horizontal), <�������, �̿ϼ�>
		* @param     [IN] @b layout true - vertical, false - horizontal
		* @return     SPVoid
		*/
		SPVoid setArrangeLayout(bool layout);


		/**
		* @brief     Resizing image
		* @param     [IN] @b srcImg source image
		* @param     [IN] @b sizeInfo information for sampling
		* @return     IMAGE_RGB_BUFFER* output image
		*/
		TEXTURE_COLOR_BUFFER* resizeImage(TEXTURE_COLOR_BUFFER* srcImg, stImgInfo* sizeInfo);

		/**
		* @brief     Resizing image
		* @param     [IN] @b option sampling option
		* @param     [IN] @b srcImg source image
		* @param     [IN] @b sizeInfo information for sampling
		* @return     IMAGE_RGB_BUFFER* output image
		*/
		TEXTURE_COLOR_BUFFER* resizeImage(_IMG_SAMPLING_OPTION_ option, TEXTURE_COLOR_BUFFER* srcImg, stImgInfo* sizeInfo);

		
	private:
		/**
		* @brief     nearest-neighboring interpolation
		* @param     [IN] @b src1 source Image 
		* @param     [INOUT] @b output output Image
		* @return     IMAGE_RGB_BUFFER*
		*/
		TEXTURE_COLOR_BUFFER* resizeNNSampling(TEXTURE_COLOR_BUFFER* src, stImgInfo* sizeInfo);

		/**
		* @brief     bilinear sampling method
		* @param     [IN] @b src src input source image data
		* @param     [INOUT] @b output output source image data
		* @return     IMAGE_RGB_BUFFER*
		*/
		TEXTURE_COLOR_BUFFER* resizeBilinearSampling(TEXTURE_COLOR_BUFFER* src, stImgInfo* sizeInfo);

	private:
		bool m_layout;
		_IMG_SAMPLING_OPTION_ m_samplingOption;
	};
}

#endif // _SPHYSICS_SPIMGCOMBINER_H_
