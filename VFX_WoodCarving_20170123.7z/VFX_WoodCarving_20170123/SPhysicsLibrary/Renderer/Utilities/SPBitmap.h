/**
* @file SPBitmap.h
* @brief This files is the implementation of Button UI Modules.
*
* @date 2014-09-25
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/
#ifndef _SP_BITMAP_H_
#define _SP_BITMAP_H_

#define SP_MAX_BITMAP_SIZE	(1024 * 1024 * 1024)

#include "SPDefines.h"
namespace SPhysics
{
	/**
	* @class     SPBitmap
	* @brief     This class is Button unit class
	*/
	class SPBitmap
	{
	public:
		/**
		* @enum      NPixelFormat
		* @brief     Pixel format
		*/
		typedef enum NPixelFormat
		{
			PIXEL_FORMAT_NONE,
			PIXEL_FORMAT_GRAY8,
			PIXEL_FORMAT_BGR16,
			PIXEL_FORMAT_BGR24,
			PIXEL_FORMAT_BGRA32,			
		} NPixelFormat;	//!< Pixel format

		/**
		* @struct    _SPBitmapData
		* @brief     Bitmap data
		*/
		typedef struct _SPBitmapData
		{
			SPInt			width;	//!< Width
			SPInt			height;	//!< Height
			NPixelFormat	format;	//!< Format
			SPVoid*			pixels;	//!< Pixels
		}SPBitmapData;	//!< Bitmap data

	public:
		SPBitmap(void);
		virtual ~SPBitmap(void);

		/**
		* @brief     Get bitmap
		*/
		static SPBool		GetBitmap(const SPChar* path, SPBitmapData& bitmapData, SPBool fromBottom = SPFALSE);

		/**
		* @brief     Release bitmap data
		*/
		static SPVoid		ReleaseBitmapData(SPBitmapData& bitmapData);
		
		/**
		* @brief     Save bitmap
		*/
		static SPBool		SaveBitmap(const SPChar* path, SPInt width, SPInt height, NPixelFormat format, SPVoid* pixels, SPBool fromBottom = SPFALSE);

	private:

#pragma pack(push,1)
		typedef struct _SPBitmapFileHeader
		{
			SPUShort type;
			SPULong  size;
			SPUShort reserved1;
			SPUShort reserved2;
			SPULong  dataOffset;
		} SPBitmapFileHeader;

		typedef struct _SPBitmapInfoHeader
		{
			unsigned long  size;
			long           width;
			long           height;
			unsigned short planes;
			unsigned short bitCount;
			unsigned long  compression;
			unsigned long  sizeImage;
			long           xPelsPerMeter;
			long           yPelsPerMeter;
			unsigned long  clrUsed;
			unsigned long  clrImportant;
		} SPBitmapInfoHeader;
#pragma pack(pop)

	};
}

#endif