/**
* @file SPButton.h
* @brief This files is the implementation of Button UI Modules.
*
* @date 2013-04-23
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/
#ifndef _SP_BUTTON_H_
#define _SP_BUTTON_H_

#include "SPDefines.h"
#include "SPDrawRect.h"

#include <vector>
#include <glm.hpp>

namespace SPhysics
{

	/**
	* @class     SPButton
	* @brief     This class is Button unit class
	 */
	class SPButton
	{
	public:
		SPButton();
		~SPButton();

		/**
		* @brief     Set screen size
		*/
		SPVoid setScreenSize(SPFloat width, SPFloat height);
		/**
		* @brief     Create button
		*/
		SPVoid createButton(SPInt buttonID, SPFloat width, SPFloat height);
		/**
		* @brief     Get size
		*/
		SPVec2f getSize();
		/**
		* @brief     Draw
		*/
		SPVoid draw();

		/**
		* @brief     Set position
		*/
		SPVoid setPosition(SPFloat x, SPFloat y, SPFloat z);
		/**
		* @brief     Get position
		*/
		SPVec3f getPosition();

		/**
		* @brief     Set image
		*/
		SPVoid setImage(const SPChar* name);		
		/**
		* @brief     Set pressed image
		*/
		SPVoid setPressedImage(const SPChar* name);
		/**
		* @brief     Set focused image
		*/
		SPVoid setFocusedImage(const SPChar* name);

		/**
		* @brief     Set button texture Id
		*/
		SPVoid setButtonTextureID(SPUInt texID);

		/**
		* @brief     Get button texture Id
		*/
		SPUInt getButtonTextureID();
		/**
		* @brief     Get pressed texture Id
		*/
		SPUInt getPressedTextureID();
		/**
		* @brief     Get focused texture Id
		*/
		SPUInt getFocusedTextureID();

		/**
		* @brief     Set color
		*/
		SPVoid setColor(SPFloat red, SPFloat green, SPFloat blue, SPFloat alpha);
		/**
		* @brief     Set focused color
		*/
		SPVoid setFocusedColor(SPFloat red, SPFloat green, SPFloat blue, SPFloat alpha);

		/**
		* @brief     Release
		*/
		SPVoid release();
		/**
		* @brief     Set focus status
		*/
		SPVoid setFocusStatus(SPBool flag);
		/**
		* @brief     Get focus status
		*/
		SPBool getFocusStatus();
		/**
		* @brief     Set visibility
		*/
		SPVoid setVisibility(SPBool flag);
		/**
		* @brief     Get visibility
		*/
		SPBool getVisibility() const;
		/**
		* @brief     Set Negotiability
		*/
		SPVoid setNegotiability(SPBool flag);
		/**
		* @brief     Get negotiability
		*/
		SPBool getNegotiability() const;

		/**
		* @brief     Get button Id
		*/
		SPInt getButtonID();

		/**
		* @brief     Hit test
		*/
		SPInt hitTest(SPFloat x, SPFloat y);

		/**
		* @brief     Set hit test margin
		*/
		SPVoid setHitTestMargin(SPFloat width, SPFloat height);
		/**
		* @brief     Set button shader enable flag
		*/
		SPVoid setEnableButtonShader(SPBool bEnable);

	private:
		SPVoid createDrawUnit();
		SPVoid createFocusedDrawUnit();
		SPVoid drawbutton();
		SPVoid drawFocusedButton();

	private:

		SPInt      m_nButtonID;

		// draw unit
		SPDrawRect* m_ButtonDraw;
		SPDrawRect* m_FocusedButtonDraw;

		SPFloat     m_fScreenWidth;
		SPFloat     m_fScreenHeight;
		SPFloat     m_fWidth;
		SPFloat     m_fHeight;
		SPFloat     m_fHalfWidth;
		SPFloat     m_fHalfHeight;
		SPVec3f   m_vCenterPos;
		
		SPUInt		m_nButtonTexture;
		SPUInt		m_nPressedTexture;
		SPUInt		m_nFocusedTexture;

		SPBool		m_bIsFocused;
		SPBool		m_bIsPressed;
		SPBool      m_bIsVisible;
		SPVec4f  m_vColor;
		SPVec4f  m_vFocusedColor;

		SPFloat     m_fHitTestHalfWidth;
		SPFloat     m_fHitTestHalfHeight;

		SPBool	    m_bButtonShader;

		SPBool	m_bNegotiability;
	};
}
#endif