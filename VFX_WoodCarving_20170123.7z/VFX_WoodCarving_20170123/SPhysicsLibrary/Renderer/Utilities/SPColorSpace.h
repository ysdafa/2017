/**
* @file      SPColorSpace.h
* @brief     This file includes module that has information about mesh

* @date      2013-05-22 
* @author    Graphics Lab. Animation Physics 
* @see 
* * Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
 */



#ifndef _SP_COLOR_SPACE_H_
#define _SP_COLOR_SPACE_H_

#include "SPDefines.h"

#include "glm.hpp"

namespace SPhysics
{

	/**
	* @class     SPColorSpace
	* @brief     Color space
	*/
	class SPColorSpace
	{

	public:
		SPColorSpace();
		~SPColorSpace();

		/**
		* @brief     RGB to HSB
		*/
		SPVec3f rgb2hsb(const SPInt r, const SPInt g, const SPInt b);
		/**
		* @brief     RGB to HSB
		*/
		SPVec3f rgb2hsb(const SPVec3i& rgb);

		/**
		* @brief     HSB to RGB
		*/
		SPVec3i hsb2rgb(const SPFloat& h, const SPFloat& s, const SPFloat& v);
		/**
		* @brief     HSB to RGB
		*/
		SPVec3i hsb2rgb(const SPVec3f& hsb);

	};

}  //namespace SPhysics

#endif // SPColorSpace

