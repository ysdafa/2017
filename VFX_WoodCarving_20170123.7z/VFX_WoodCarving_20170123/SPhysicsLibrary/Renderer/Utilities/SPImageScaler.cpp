#include "SPDefines.h"
#include "SPLog.h"
#include "SPComparison.h"
#include "SPImageScaler.h"

#include <string.h>
#include <assert.h>
#include <glm.hpp>

namespace SPhysics
{
	SPVoid SPImagerScaler::resizeTextureColor(TEXTURE_COLOR_BUFFER* src, TEXTURE_COLOR_BUFFER* dst, SPInt dstWidth, SPInt dstHeight, SP_IMAGE_SCALE_OPTION option /* = SP_IMAGE_SCALE_NEAREST */, SP_IMAGE_PIXEL_TYPE pixelType /* = SP_IMAGE_DATA_RGBA32 */)
	{
		SPRawImageInfo srcInfo;
		srcInfo.width		= src->ImgWidth;
		srcInfo.height		= src->ImgHeight;
		srcInfo.pixels		= src->ImgData;
		srcInfo.pixelType	= pixelType;

		strcpy(dst->FileName, src->FileName);
		dst->ImgWidth	= dstWidth;
		dst->ImgHeight	= dstHeight;
		dst->PixelSize	= src->PixelSize;
		dst->ImgSize	= dstWidth * dstHeight * pixelSize(pixelType);
		dst->ImgData	= new SPUChar[dst->ImgSize];
		assert(dst->ImgData != NULL);

		resizeRawImage(&srcInfo, dst->ImgData, dst->ImgWidth, dst->ImgHeight, option);
	}

	SPVoid SPImagerScaler::resizeTextureColor(TEXTURE_COLOR_BUFFER* src, TEXTURE_COLOR_BUFFER* dst, SPFloat scaleRatio, SP_IMAGE_SCALE_OPTION option /* = SP_IMAGE_SCALE_NEAREST */, SP_IMAGE_PIXEL_TYPE pixelType /* = SP_IMAGE_DATA_RGBA32 */)
	{
		SPRawImageInfo srcInfo;
		srcInfo.width		= src->ImgWidth;
		srcInfo.height		= src->ImgHeight;
		srcInfo.pixels		= src->ImgData;
		srcInfo.pixelType	= pixelType;

		strcpy(dst->FileName, src->FileName);
		dst->ImgWidth	= (SPInt)(scaleRatio * src->ImgWidth);
		dst->ImgHeight	= (SPInt)(scaleRatio * src->ImgHeight);
		dst->PixelSize	= src->PixelSize;
		dst->ImgSize	= dst->ImgWidth * dst->ImgHeight * pixelSize(pixelType);
		dst->ImgData	= new SPUChar[dst->ImgSize];
		assert(dst->ImgData != NULL);

		resizeRawImage(&srcInfo, dst->ImgData, dst->ImgWidth, dst->ImgHeight, option);
	}

	SPVoid SPImagerScaler::replaceTextureColor(TEXTURE_COLOR_BUFFER* src, SPInt dstWidth, SPInt dstHeight, SP_IMAGE_SCALE_OPTION option /* = SP_IMAGE_SCALE_NEAREST */, SP_IMAGE_PIXEL_TYPE pixelType /* = SP_IMAGE_DATA_RGBA32 */)
	{
		SPRawImageInfo srcInfo;
		srcInfo.width		= src->ImgWidth;
		srcInfo.height		= src->ImgHeight;
		srcInfo.pixels		= src->ImgData;
		srcInfo.pixelType	= pixelType;
		
		SPUChar* ImgData = new SPUChar[dstWidth * dstHeight * pixelSize(pixelType)];
		assert(ImgData != NULL);

		resizeRawImage(&srcInfo, ImgData, dstWidth, dstHeight, option);
				
		SP_SAFE_DELETE_ARRAY(src->ImgData);
		src->ImgData	= ImgData;
		src->ImgHeight	= dstHeight;
		src->ImgWidth	= dstWidth;
	}

	SPVoid SPImagerScaler::replaceTextureColor(TEXTURE_COLOR_BUFFER* src, SPFloat scaleRatio, SP_IMAGE_SCALE_OPTION option /* = SP_IMAGE_SCALE_NEAREST */, SP_IMAGE_PIXEL_TYPE pixelType /* = SP_IMAGE_DATA_RGBA32 */)
	{
		SPRawImageInfo srcInfo;
		srcInfo.width		= src->ImgWidth;
		srcInfo.height		= src->ImgHeight;
		srcInfo.pixels		= src->ImgData;
		srcInfo.pixelType	= pixelType;

		SPInt dstWidth	= SPInt(scaleRatio * src->ImgWidth);
		SPInt dstHeight = SPInt(scaleRatio * src->ImgHeight);
		
		SPUChar* ImgData = new SPUChar[dstWidth * dstHeight * pixelSize(pixelType)];
		assert(ImgData != NULL);

		resizeRawImage(&srcInfo, ImgData, dstWidth, dstHeight, option);

		SP_SAFE_DELETE_ARRAY(src->ImgData);
		src->ImgData	= ImgData;
		src->ImgHeight	= dstHeight;
		src->ImgWidth	= dstWidth;
	}

	SPVoid SPImagerScaler::resizeRawImage(SPRawImageInfo* srcRawImage, SPRawImageInfo* dstRawImage, SPFloat scaleRatio, SP_IMAGE_SCALE_OPTION option /* = SP_IMAGE_SCALE_NEAREST */)
	{
		dstRawImage->width		= SPInt(scaleRatio * srcRawImage->width);
		dstRawImage->height		= SPInt(scaleRatio * srcRawImage->height);
		dstRawImage->pixelType	= srcRawImage->pixelType;
		dstRawImage->pixels		= (SPVoid*)new SPUChar[dstRawImage->width * dstRawImage->height * pixelSize(srcRawImage->pixelType)];
		assert(dstRawImage->pixels != NULL);

		resizeRawImage(srcRawImage, dstRawImage->pixels, dstRawImage->width, dstRawImage->height, option);
	}


	SPVoid* SPImagerScaler::resizeRawImage(SPRawImageInfo* srcRawImage, SPInt dstWidth, SPInt dstHeight, SP_IMAGE_SCALE_OPTION option /* = SP_IMAGE_SCALE_NEAREST */)
	{
		SPVoid* dstData = (SPVoid*)new SPUChar[dstWidth * dstHeight * pixelSize(srcRawImage->pixelType)];
		assert(dstData != NULL);

		resizeRawImage(srcRawImage, dstData, dstWidth, dstHeight, option);		

		return dstData;
	}

	SPVoid SPImagerScaler::resizeRawImage(SPRawImageInfo* srcRawImage, SPVoid* dstData, SPInt dstWidth, SPInt dstHeight, SP_IMAGE_SCALE_OPTION option /* = SP_IMAGE_SCALE_NEAREST */)
	{
		if (srcRawImage->width != dstWidth || srcRawImage->height != dstHeight)
		{
			switch (option)
			{
			case SP_IMAGE_SCALE_NEAREST:
				switch (srcRawImage->pixelType)
				{
				case SP_IMAGE_DATA_RGBA32:		resizeRawImageNearestRGBA32(srcRawImage, dstData, dstWidth, dstHeight); break;
				case SP_IMAGE_DATA_RGB24:		resizeRawImageNearestRGB24(srcRawImage, dstData, dstWidth, dstHeight); break;
				case SP_IMAGE_DATA_RGB16:		resizeRawImageNearestRGB16(srcRawImage, dstData, dstWidth, dstHeight); break;
				case SP_IMAGE_DATA_LUMINANCE8:	resizeRawImageNearestLUMINANCE8(srcRawImage, dstData, dstWidth, dstHeight); break;
				case SP_IMAGE_DATA_FLOAT32:
				default:
					SP_LOGW("Invalid pixel type");
					return;
				}
				break;

			case SP_IMAGE_SCALE_LINEAR:
				switch (srcRawImage->pixelType)
				{
				case SP_IMAGE_DATA_RGBA32:		resizeRawImageLinearRGBA32(srcRawImage, dstData, dstWidth, dstHeight); break;
				case SP_IMAGE_DATA_RGB24:		resizeRawImageLinearRGB24(srcRawImage, dstData, dstWidth, dstHeight); break;
				case SP_IMAGE_DATA_RGB16:		resizeRawImageLinearRGB16(srcRawImage, dstData, dstWidth, dstHeight); break;
				case SP_IMAGE_DATA_LUMINANCE8:	resizeRawImageLinearLUMINANCE8(srcRawImage, dstData, dstWidth, dstHeight); break;
				case SP_IMAGE_DATA_FLOAT32:
				default:
					SP_LOGW("Invalid pixel type");
					return;
				}
				break;

			case SP_IMAGE_SCALE_BLUR:
				switch (srcRawImage->pixelType)
				{
				case SP_IMAGE_DATA_RGBA32:		resizeRawImageBlurRGBA32(srcRawImage, dstData, dstWidth, dstHeight); break;
				case SP_IMAGE_DATA_RGB24:		resizeRawImageBlurRGB24(srcRawImage, dstData, dstWidth, dstHeight); break;
				case SP_IMAGE_DATA_RGB16:		resizeRawImageBlurRGB16(srcRawImage, dstData, dstWidth, dstHeight); break;
				case SP_IMAGE_DATA_LUMINANCE8:	resizeRawImageBlurLUMINANCE8(srcRawImage, dstData, dstWidth, dstHeight); break;
				case SP_IMAGE_DATA_FLOAT32:
				default:
					SP_LOGW("Invalid pixel type");
					return;
				}
				break;
			}
		}
		else
		{
			memcpy(dstData, srcRawImage->pixels, dstWidth * dstHeight * pixelSize(srcRawImage->pixelType));
		}
	}
	

	SPVoid SPImagerScaler::resizeRawImageNearestRGBA32(SPRawImageInfo* srcRawImage, SPVoid* dstData, SPInt dstWidth, SPInt dstHeight)
	{
		SPInt pixelSize = 4 * sizeof(SPUChar);
		SPUChar* srcImage = (SPUChar*)srcRawImage->pixels;
		SPUChar* dstImage = (SPUChar*)dstData;

		SPFloat xRatio = (SPFloat)srcRawImage->width / dstWidth;
		SPFloat yRatio = (SPFloat)srcRawImage->height / dstHeight;

		for (SPInt j = 0; j < dstHeight; j++)
		{
			int yPos = (int)(j*	yRatio);
			for (int i = 0; i < dstWidth; i++)
			{
				int xPos = (int)(i*	xRatio);

				int dstArrayIdx = (yPos* srcRawImage->width + xPos)* pixelSize;
				int dR = srcImage[dstArrayIdx + 0];
				int dG = srcImage[dstArrayIdx + 1];
				int dB = srcImage[dstArrayIdx + 2];
				int dA = srcImage[dstArrayIdx + 3];

				int outIdx = (j* dstWidth + i) * pixelSize;
				dstImage[outIdx + 0] = dR;
				dstImage[outIdx + 1] = dG;
				dstImage[outIdx + 2] = dB;
				dstImage[outIdx + 3] = dA;
			}
		}
	}

	SPVoid SPImagerScaler::resizeRawImageLinearRGBA32(SPRawImageInfo* srcRawImage, SPVoid* dstData, SPInt dstWidth, SPInt dstHeight)
	{
		SPInt pixelSize = 4 * sizeof(SPUChar);
		SPUChar* srcImage = (SPUChar*)srcRawImage->pixels;
		SPUChar* dstImage = (SPUChar*)dstData;
		
		SPFloat xRatio = (float)srcRawImage->width / dstWidth;
		SPFloat yRatio = (float)srcRawImage->height / dstHeight;

		//SP_LOGE("[%s] xRatio : %f, yRatio : %f", __FUNCTION__, xRatio, yRatio);

		for (int j = 0; j < dstHeight; j++)
		{
			for (int i = 0; i < dstWidth; i++)
			{
				float yPrecisePos = j*yRatio;
				float xPrecisePos = i* xRatio;

				int y1Pos = (int)yPrecisePos;
				int x1Pos = (int)xPrecisePos;

				int x2Pos = x1Pos + 1;
				int y2Pos = y1Pos + 1;

				if (x2Pos == srcRawImage->width)
				{
					x2Pos = srcRawImage->width - 1;
				}
				if (y2Pos == srcRawImage->height)
					y2Pos = srcRawImage->height - 1;

				float p = xPrecisePos - x1Pos;
				float q = yPrecisePos - y1Pos;


				int dstOutIdx = (j* dstWidth + i) * pixelSize;

				//for(int k =0; k< outputImg->PixelSize ; k++)
				for (int k = 0; k < 4; k++)
				{
					int y1x1 = (srcRawImage->width* y1Pos + x1Pos) * pixelSize + k;
					int y1x2 = (srcRawImage->width* y1Pos + x2Pos) * pixelSize + k;
					int y2x1 = (srcRawImage->width* y2Pos + x1Pos) * pixelSize + k;
					int y2x2 = (srcRawImage->width* y2Pos + x2Pos) * pixelSize + k;

					float outputColor = ((1.0f - p) * (1.0f - q) * srcImage[y1x1] + p*(1.0f - q) * srcImage[y1x2] +
						(1.0f - p) * q * srcImage[y2x1] + p* q* srcImage[y2x2]);
					dstImage[dstOutIdx + k] = (int)outputColor;
				}
			}
		}
	}

	SPVoid SPImagerScaler::resizeRawImageBlurRGBA32(SPRawImageInfo* srcRawImage, SPVoid* dstData, SPInt dstWidth, SPInt dstHeight)
	{
		SPInt pixelSize = 4 * sizeof(SPUChar);
		SPUChar* srcImage = (SPUChar*)srcRawImage->pixels;
		SPUChar* dstImage = (SPUChar*)dstData;

		SPFloat xRatio = (float)srcRawImage->width / dstWidth;
		SPFloat yRatio = (float)srcRawImage->height / dstHeight;
		
		for (SPInt j = 0; j < dstHeight; ++j)
		{
			for (SPInt i = 0; i < dstWidth; ++i)
			{
				const int dst_index = (j * dstWidth + i) * pixelSize;
				const int src_index = ((SPInt)(j * yRatio) * srcRawImage->width + (SPInt)(i * xRatio)) * pixelSize;

				dstImage[dst_index + 0] = srcImage[src_index + 0];
				dstImage[dst_index + 1] = srcImage[src_index + 1];
				dstImage[dst_index + 2] = srcImage[src_index + 2];
				dstImage[dst_index + 3] = srcImage[src_index + 3];
			}
		}

		// blur /////////////////////////////////////////////////////////////////////////////////////////////

		// nombre d'octets par pixel
		const SPInt bp = pixelSize;//mBpp/8;
		std::vector<SPUChar> temp(dstWidth*dstHeight*bp);

		const SPFloat radius = 2.0f;
		const SPFloat sigma2 = radius*radius;
		const SPInt size = 2;//good approximation of filter

		SPVec4f pixel;

		//blurs x components
		for (SPInt y = 0; y < dstHeight; y++)
		{
			for (SPInt x = 0; x < dstWidth; x++)
			{
				//process a pixel
				SPFloat sum = 0;
				pixel = SPVec4f();

				//accumulate colors
				for (SPInt i = maximum(0, x - size); i <= minimum(dstWidth - 1, x + size); ++i)
				{
					const SPFloat factor = exp(-(i - x)*(i - x) / (2 * sigma2));
					sum += factor;
					for (SPInt c = 0; c < bp; c++)
					{
						pixel[c] += factor * dstImage[(i + y*dstWidth)*bp + c];
					}
				}
				//copy a pixel
				for (SPInt c = 0; c < bp; c++)
				{
					temp[(x + y*dstWidth)*bp + c] = (SPUChar)(pixel[c] / sum);
				}
			}
		}

		//blurs x components
		for (SPInt y = 0; y < dstHeight; y++)
		{
			for (SPInt x = 0; x < dstWidth; x++)
			{
				//process a pixel
				SPFloat sum = 0;
				pixel = SPVec4f();

				//accumulate colors
				for (SPInt i = maximum(0, y - size); i <= minimum(dstHeight - 1, y + size); ++i)
				{
					const SPFloat factor = exp(-(i - y)*(i - y) / (2 * sigma2));
					sum += factor;
					for (SPInt c = 0; c < bp; c++)
					{
						pixel[c] += factor * temp[(x + i*dstWidth)*bp + c];
					}
				}

				//copy a pixel
				for (SPInt c = 0; c < bp; c++)
				{
					dstImage[(x + y*dstWidth)*bp + c] = (SPUChar)(pixel[c] / sum);
				}
			}
		}
	}

	SPVoid SPImagerScaler::resizeRawImageNearestRGB24(SPRawImageInfo* srcRawImage, SPVoid* dstData, SPInt dstWidth, SPInt dstHeight)
	{
		SPInt pixelSize = 3 * sizeof(SPUChar);
		SPUChar* srcImage = (SPUChar*)srcRawImage->pixels;
		SPUChar* dstImage = (SPUChar*)dstData;

		SPFloat xRatio = (SPFloat)srcRawImage->width / dstWidth;
		SPFloat yRatio = (SPFloat)srcRawImage->height / dstHeight;

		for (SPInt j = 0; j < dstHeight; j++)
		{
			int yPos = (int)(j*	yRatio);

			for (int i = 0; i < dstWidth; i++)
			{
				int xPos = (int)(i*	xRatio);

				int dstArrayIdx = (yPos* srcRawImage->width + xPos)* pixelSize;
				int dR = srcImage[dstArrayIdx + 0];
				int dG = srcImage[dstArrayIdx + 1];
				int dB = srcImage[dstArrayIdx + 2];

				int outIdx = (j* dstWidth + i) * pixelSize;
				dstImage[outIdx + 0] = dR;
				dstImage[outIdx + 1] = dG;
				dstImage[outIdx + 2] = dB;
			}
		}
	}

	SPVoid SPImagerScaler::resizeRawImageLinearRGB24(SPRawImageInfo* srcRawImage, SPVoid* dstData, SPInt dstWidth, SPInt dstHeight)
	{
		SPInt pixelSize = 3 * sizeof(SPUChar);
		SPUChar* srcImage = (SPUChar*)srcRawImage->pixels;
		SPUChar* dstImage = (SPUChar*)dstData;

		SPFloat xRatio = (float)srcRawImage->width / dstWidth;
		SPFloat yRatio = (float)srcRawImage->height / dstHeight;

		//SP_LOGE("[%s] xRatio : %f, yRatio : %f", __FUNCTION__, xRatio, yRatio);

		for (int j = 0; j < dstHeight; j++)
		{
			for (int i = 0; i < dstWidth; i++)
			{
				float yPrecisePos = j*yRatio;
				float xPrecisePos = i* xRatio;

				int y1Pos = (int)yPrecisePos;
				int x1Pos = (int)xPrecisePos;

				int x2Pos = x1Pos + 1;
				int y2Pos = y1Pos + 1;

				if (x2Pos == srcRawImage->width)
				{
					x2Pos = srcRawImage->width - 1;
				}
				if (y2Pos == srcRawImage->height)
					y2Pos = srcRawImage->height - 1;

				float p = xPrecisePos - x1Pos;
				float q = yPrecisePos - y1Pos;


				int dstOutIdx = (j* dstWidth + i) * pixelSize;

				//for(int k =0; k< outputImg->PixelSize ; k++)
				for (int k = 0; k < 3; k++)
				{
					int y1x1 = (srcRawImage->width* y1Pos + x1Pos) * pixelSize + k;
					int y1x2 = (srcRawImage->width* y1Pos + x2Pos) * pixelSize + k;
					int y2x1 = (srcRawImage->width* y2Pos + x1Pos) * pixelSize + k;
					int y2x2 = (srcRawImage->width* y2Pos + x2Pos) * pixelSize + k;

					float outputColor = ((1.0f - p) * (1.0f - q) * srcImage[y1x1] + p*(1.0f - q) * srcImage[y1x2] +
						(1.0f - p) * q * srcImage[y2x1] + p* q* srcImage[y2x2]);
					dstImage[dstOutIdx + k] = (int)outputColor;
				}
			}
		}
	}

	SPVoid SPImagerScaler::resizeRawImageBlurRGB24(SPRawImageInfo* srcRawImage, SPVoid* dstData, SPInt dstWidth, SPInt dstHeight)
	{
		SPInt pixelSize = 3 * sizeof(SPUChar);
		SPUChar* srcImage = (SPUChar*)srcRawImage->pixels;
		SPUChar* dstImage = (SPUChar*)dstData;

		SPFloat xRatio = (float)srcRawImage->width / dstWidth;
		SPFloat yRatio = (float)srcRawImage->height / dstHeight;

		for (SPInt j = 0; j < dstHeight; ++j)
		{
			for (SPInt i = 0; i < dstWidth; ++i)
			{
				const int dst_index = (j * dstWidth + i) * pixelSize;
				const int src_index = ((SPInt)(j * yRatio) * srcRawImage->width + (SPInt)(i * xRatio)) * pixelSize;

				dstImage[dst_index + 0] = srcImage[src_index + 0];
				dstImage[dst_index + 1] = srcImage[src_index + 1];
				dstImage[dst_index + 2] = srcImage[src_index + 2];
			}
		}

		// blur /////////////////////////////////////////////////////////////////////////////////////////////

		// nombre d'octets par pixel
		const SPInt bp = pixelSize;//mBpp/8;
		std::vector<SPUChar> temp(dstWidth*dstHeight*bp);

		const SPFloat radius = 2.0f;
		const SPFloat sigma2 = radius*radius;
		const SPInt size = 2;//good approximation of filter

		SPVec4f pixel;

		//blurs x components
		for (SPInt y = 0; y < dstHeight; y++)
		{
			for (SPInt x = 0; x < dstWidth; x++)
			{
				//process a pixel
				SPFloat sum = 0;
				pixel = SPVec4f();

				//accumulate colors
				for (SPInt i = maximum(0, x - size); i <= minimum(dstWidth - 1, x + size); ++i)
				{
					const SPFloat factor = exp(-(i - x)*(i - x) / (2 * sigma2));
					sum += factor;
					for (SPInt c = 0; c < bp; c++)
					{
						pixel[c] += factor * dstImage[(i + y*dstWidth)*bp + c];
					}
				}
				//copy a pixel
				for (SPInt c = 0; c < bp; c++)
				{
					temp[(x + y*dstWidth)*bp + c] = (SPUChar)(pixel[c] / sum);
				}
			}
		}

		//blurs x components
		for (SPInt y = 0; y < dstHeight; y++)
		{
			for (SPInt x = 0; x < dstWidth; x++)
			{
				//process a pixel
				SPFloat sum = 0;
				pixel = SPVec4f();

				//accumulate colors
				for (SPInt i = maximum(0, y - size); i <= minimum(dstHeight - 1, y + size); ++i)
				{
					const SPFloat factor = exp(-(i - y)*(i - y) / (2 * sigma2));
					sum += factor;
					for (SPInt c = 0; c < bp; c++)
					{
						pixel[c] += factor * temp[(x + i*dstWidth)*bp + c];
					}
				}

				//copy a pixel
				for (SPInt c = 0; c < bp; c++)
				{
					dstImage[(x + y*dstWidth)*bp + c] = (SPUChar)(pixel[c] / sum);
				}
			}
		}
	}

	SPVoid SPImagerScaler::resizeRawImageNearestRGB16(SPRawImageInfo* srcRawImage, SPVoid* dstData, SPInt dstWidth, SPInt dstHeight)
	{
		SPUShort* srcImage = (SPUShort*)srcRawImage->pixels;
		SPUShort* dstImage = (SPUShort*)dstData;

		SPFloat xRatio = (SPFloat)srcRawImage->width / dstWidth;
		SPFloat yRatio = (SPFloat)srcRawImage->height / dstHeight;

		for (SPInt j = 0; j < dstHeight; j++)
		{
			int yPos = (int)(j*	yRatio);
			for (int i = 0; i < dstWidth; i++)
			{
				int xPos = (int)(i*	xRatio);

				int dstArrayIdx = (yPos* srcRawImage->width + xPos);
				int outIdx = (j* dstWidth + i);
				dstImage[outIdx] = srcImage[dstArrayIdx];
			}
		}
	}

	SPVoid SPImagerScaler::resizeRawImageLinearRGB16(SPRawImageInfo* srcRawImage, SPVoid* dstData, SPInt dstWidth, SPInt dstHeight)
	{
		SPUShort* srcImage = (SPUShort*)srcRawImage->pixels;
		SPUShort* dstImage = (SPUShort*)dstData;

		SPFloat xRatio = (float)srcRawImage->width / dstWidth;
		SPFloat yRatio = (float)srcRawImage->height / dstHeight;

		//SP_LOGE("[%s] xRatio : %f, yRatio : %f", __FUNCTION__, xRatio, yRatio);

		for (int j = 0; j < dstHeight; j++)
		{
			for (int i = 0; i < dstWidth; i++)
			{
				float yPrecisePos = j*yRatio;
				float xPrecisePos = i* xRatio;

				int y1Pos = (int)yPrecisePos;
				int x1Pos = (int)xPrecisePos;

				int x2Pos = x1Pos + 1;
				int y2Pos = y1Pos + 1;

				if (x2Pos == srcRawImage->width)
					x2Pos = srcRawImage->width - 1;
				if (y2Pos == srcRawImage->height)
					y2Pos = srcRawImage->height - 1;

				float p = xPrecisePos - x1Pos;
				float q = yPrecisePos - y1Pos;


				int dstOutIdx = (j* dstWidth + i);

				SPUShort r,g,b;
				int y1x1, y1x2, y2x1, y2x2;
				// for Red channel
				y1x1 = GET_RED_CHANNEL_OF_RGB16(srcRawImage->width* y1Pos + x1Pos);
				y1x2 = GET_RED_CHANNEL_OF_RGB16(srcRawImage->width* y1Pos + x2Pos);
				y2x1 = GET_RED_CHANNEL_OF_RGB16(srcRawImage->width* y2Pos + x1Pos);
				y2x2 = GET_RED_CHANNEL_OF_RGB16(srcRawImage->width* y2Pos + x2Pos);

				r = (SPUShort)((1.0f - p) * (1.0f - q) * srcImage[y1x1] + p*(1.0f - q) * srcImage[y1x2] + (1.0f - p) * q * srcImage[y2x1] + p* q* srcImage[y2x2]);


				y1x1 = GET_GREEN_CHANNEL_OF_RGB16(srcRawImage->width* y1Pos + x1Pos);
				y1x2 = GET_GREEN_CHANNEL_OF_RGB16(srcRawImage->width* y1Pos + x2Pos);
				y2x1 = GET_GREEN_CHANNEL_OF_RGB16(srcRawImage->width* y2Pos + x1Pos);
				y2x2 = GET_GREEN_CHANNEL_OF_RGB16(srcRawImage->width* y2Pos + x2Pos);

				g = (SPUShort)((1.0f - p) * (1.0f - q) * srcImage[y1x1] + p*(1.0f - q) * srcImage[y1x2] + (1.0f - p) * q * srcImage[y2x1] + p* q* srcImage[y2x2]);

				y1x1 = GET_BLUE_CHANNEL_OF_RGB16(srcRawImage->width* y1Pos + x1Pos);
				y1x2 = GET_BLUE_CHANNEL_OF_RGB16(srcRawImage->width* y1Pos + x2Pos);
				y2x1 = GET_BLUE_CHANNEL_OF_RGB16(srcRawImage->width* y2Pos + x1Pos);
				y2x2 = GET_BLUE_CHANNEL_OF_RGB16(srcRawImage->width* y2Pos + x2Pos);

				b = (SPUShort)((1.0f - p) * (1.0f - q) * srcImage[y1x1] + p*(1.0f - q) * srcImage[y1x2] + (1.0f - p) * q * srcImage[y2x1] + p* q* srcImage[y2x2]);

				dstImage[dstOutIdx] = COMBINE_TO_RGB16(r, g, b);
			}
		}
	}

	SPVoid SPImagerScaler::resizeRawImageBlurRGB16(SPRawImageInfo* srcRawImage, SPVoid* dstData, SPInt dstWidth, SPInt dstHeight)
	{
		SPUShort* srcImage = (SPUShort*)srcRawImage->pixels;
		SPUShort* dstImage = (SPUShort*)dstData;

		SPFloat xRatio = (float)srcRawImage->width / dstWidth;
		SPFloat yRatio = (float)srcRawImage->height / dstHeight;

		for (SPInt j = 0; j < dstHeight; ++j)
		{
			for (SPInt i = 0; i < dstWidth; ++i)
			{
				const int dst_index = (j * dstWidth + i);
				const int src_index = ((SPInt)(j * yRatio) * srcRawImage->width + (SPInt)(i * xRatio));

				dstImage[dst_index] = srcImage[src_index];
			}
		}

		// blur /////////////////////////////////////////////////////////////////////////////////////////////

		// nombre d'octets par pixel
		std::vector<SPUShort> temp(dstWidth*dstHeight);

		const SPFloat radius = 2.0f;
		const SPFloat sigma2 = radius*radius;
		const SPInt size = 2;//good approximation of filter

		//blurs x components
		for (SPInt y = 0; y < dstHeight; y++)
		{
			for (SPInt x = 0; x < dstWidth; x++)
			{
				//process a pixel
				SPFloat sum = 0.0f;
				SPFloat r = 0.0f, g = 0.0f, b = 0.0f;

				//accumulate colors
				for (SPInt i = maximum(0, x - size); i <= minimum(dstWidth - 1, x + size); ++i)
				{
					const SPFloat factor = exp(-(i - x)*(i - x) / (2 * sigma2));
					sum += factor;

					SPUShort color = dstImage[(i + y*dstWidth)];
					r += factor * GET_RED_CHANNEL_OF_RGB16(color);
					g += factor * GET_GREEN_CHANNEL_OF_RGB16(color);
					b += factor * GET_BLUE_CHANNEL_OF_RGB16(color);
				}
				//copy a pixel
				temp[(x + y*dstWidth)] = COMBINE_TO_RGB16(r / sum, g / sum, b / sum);
			}
		}

		//blurs x components
		for (SPInt y = 0; y < dstHeight; y++)
		{
			for (SPInt x = 0; x < dstWidth; x++)
			{
				//process a pixel
				SPFloat sum = 0;
				SPFloat r = 0.0f, g = 0.0f, b = 0.0f;

				//accumulate colors
				for (SPInt i = maximum(0, y - size); i <= minimum(dstHeight - 1, y + size); ++i)
				{
					const SPFloat factor = exp(-(i - y)*(i - y) / (2 * sigma2));
					sum += factor;

					SPUShort color = temp[(x + i*dstWidth)];
					r += factor * GET_RED_CHANNEL_OF_RGB16(color);
					g += factor * GET_GREEN_CHANNEL_OF_RGB16(color);
					b += factor * GET_BLUE_CHANNEL_OF_RGB16(color);
				}

				//copy a pixel
				dstImage[(x + y*dstWidth)] = COMBINE_TO_RGB16(r / sum, g / sum, b / sum);
			}
		}
	}

	SPVoid SPImagerScaler::resizeRawImageNearestLUMINANCE8(SPRawImageInfo* srcRawImage, SPVoid* dstData, SPInt dstWidth, SPInt dstHeight)
	{
		SPUChar* srcImage = (SPUChar*)srcRawImage->pixels;
		SPUChar* dstImage = (SPUChar*)dstData;

		SPFloat xRatio = (SPFloat)srcRawImage->width / dstWidth;
		SPFloat yRatio = (SPFloat)srcRawImage->height / dstHeight;

		for (SPInt j = 0; j < dstHeight; j++)
		{
			int yPos = (int)(j*	yRatio);
			for (int i = 0; i < dstWidth; i++)
			{
				int xPos = (int)(i*	xRatio);

				int dstArrayIdx = (yPos* srcRawImage->width + xPos);
				int outIdx = (j* dstWidth + i);
				dstImage[outIdx] = srcImage[dstArrayIdx];
			}
		}
	}

	SPVoid SPImagerScaler::resizeRawImageLinearLUMINANCE8(SPRawImageInfo* srcRawImage, SPVoid* dstData, SPInt dstWidth, SPInt dstHeight)
	{
		SPUChar* srcImage = (SPUChar*)srcRawImage->pixels;
		SPUChar* dstImage = (SPUChar*)dstData;

		SPFloat xRatio = (float)srcRawImage->width / dstWidth;
		SPFloat yRatio = (float)srcRawImage->height / dstHeight;

		//SP_LOGE("[%s] xRatio : %f, yRatio : %f", __FUNCTION__, xRatio, yRatio);

		for (int j = 0; j < dstHeight; j++)
		{
			for (int i = 0; i < dstWidth; i++)
			{
				float yPrecisePos = j*yRatio;
				float xPrecisePos = i* xRatio;

				int y1Pos = (int)yPrecisePos;
				int x1Pos = (int)xPrecisePos;

				int x2Pos = x1Pos + 1;
				int y2Pos = y1Pos + 1;

				if (x2Pos == srcRawImage->width)
					x2Pos = srcRawImage->width - 1;
				if (y2Pos == srcRawImage->height)
					y2Pos = srcRawImage->height - 1;

				float p = xPrecisePos - x1Pos;
				float q = yPrecisePos - y1Pos;


				int dstOutIdx = (j* dstWidth + i);

				int y1x1 = (srcRawImage->width* y1Pos + x1Pos);
				int y1x2 = (srcRawImage->width* y1Pos + x2Pos);
				int y2x1 = (srcRawImage->width* y2Pos + x1Pos);
				int y2x2 = (srcRawImage->width* y2Pos + x2Pos);

				dstImage[dstOutIdx] = (SPUChar)((1.0f - p) * (1.0f - q) * srcImage[y1x1] + p*(1.0f - q) * srcImage[y1x2] + (1.0f - p) * q * srcImage[y2x1] + p* q* srcImage[y2x2]);
			}
		}
	}

	SPVoid SPImagerScaler::resizeRawImageBlurLUMINANCE8(SPRawImageInfo* srcRawImage, SPVoid* dstData, SPInt dstWidth, SPInt dstHeight)
	{
		SPUChar* srcImage = (SPUChar*)srcRawImage->pixels;
		SPUChar* dstImage = (SPUChar*)dstData;

		SPFloat xRatio = (float)srcRawImage->width / dstWidth;
		SPFloat yRatio = (float)srcRawImage->height / dstHeight;

		for (SPInt j = 0; j < dstHeight; ++j)
		{
			for (SPInt i = 0; i < dstWidth; ++i)
			{
				const int dst_index = (j * dstWidth + i);
				const int src_index = ((SPInt)(j * yRatio) * srcRawImage->width + (SPInt)(i * xRatio));

				dstImage[dst_index] = srcImage[src_index];
			}
		}

		// blur /////////////////////////////////////////////////////////////////////////////////////////////

		// nombre d'octets par pixel
		std::vector<SPUChar> temp(dstWidth*dstHeight);

		const SPFloat radius = 2.0f;
		const SPFloat sigma2 = radius*radius;
		const SPInt size = 2;//good approximation of filter

		//blurs x components
		for (SPInt y = 0; y < dstHeight; y++)
		{
			for (SPInt x = 0; x < dstWidth; x++)
			{
				//process a pixel
				SPFloat sum = 0.0f;
				SPFloat color = 0.0f;

				//accumulate colors
				for (SPInt i = maximum(0, x - size); i <= minimum(dstWidth - 1, x + size); ++i)
				{
					const SPFloat factor = exp(-(i - x)*(i - x) / (2 * sigma2));
					sum += factor;

					color += factor * dstImage[(i + y*dstWidth)];
				}
				//copy a pixel
				temp[(x + y*dstWidth)] = (SPUChar)(color / sum);
			}
		}

		//blurs x components
		for (SPInt y = 0; y < dstHeight; y++)
		{
			for (SPInt x = 0; x < dstWidth; x++)
			{
				//process a pixel
				SPFloat sum = 0.0f;
				SPFloat color = 0.0f;

				//accumulate colors
				for (SPInt i = maximum(0, y - size); i <= minimum(dstHeight - 1, y + size); ++i)
				{
					const SPFloat factor = exp(-(i - y)*(i - y) / (2 * sigma2));
					sum += factor;

					color += factor * temp[(x + i*dstWidth)];
				}

				//copy a pixel
				dstImage[(x + y*dstWidth)] = (SPUChar)(color / sum);
			}
		}
	}

	SPInt  SPImagerScaler::pixelSize(SP_IMAGE_PIXEL_TYPE pixelType)
	{
		SPInt pixelSize;
		switch (pixelType)
		{
		case SP_IMAGE_DATA_RGBA32:		pixelSize = 4 * sizeof(SPUChar);	break;
		case SP_IMAGE_DATA_RGB24:		pixelSize = 3 * sizeof(SPUChar);	break;
		case SP_IMAGE_DATA_RGB16:		pixelSize = sizeof(SPUShort);		break;
		case SP_IMAGE_DATA_LUMINANCE8:	pixelSize = sizeof(SPUChar);		break;
		case SP_IMAGE_DATA_FLOAT32:		pixelSize = sizeof(SPFloat);		break;
		default:
			pixelSize = 0;
			SP_LOGW("Invalid pixel type");
		}

		return pixelSize;
	}
}
