/**
* @file SPImageScaler.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/


#ifndef _SP_IMAGE_SCALER_H_
#define _SP_IMAGE_SCALER_H_

#include "SPTextureManager.h"

#define GET_RED_CHANNEL_OF_RGB16(color)			(((color) >> 11) & 0x1f)	//!< Get Red channel of RGB16
#define GET_GREEN_CHANNEL_OF_RGB16(color)		(((color) >> 5) & 0x3f)		//!< Get Green channel of RGB16
#define GET_BLUE_CHANNEL_OF_RGB16(color)		(((color) >> 0) & 0x1f)		//!< Get Blue channel of RGB16
#define COMBINE_TO_RGB16(r, g, b)				(((SPUShort)(r) << 11) | ((SPUShort)(g) << 5) | ((SPUShort)(b) << 0))	//!< Combine to RGB


namespace SPhysics
{
	/**
	* @class     SPImagerScaler
	* @brief     Imager scaler
	*/
	class SPImagerScaler
	{
	public:
		/**
		* @enum      SP_IMAGE_SCALE_OPTION
		* @brief     Image scale option
		*/
		typedef enum
		{
			SP_IMAGE_SCALE_NEAREST,
			SP_IMAGE_SCALE_LINEAR,
			SP_IMAGE_SCALE_BLUR,
		} SP_IMAGE_SCALE_OPTION;

		/**
		* @enum      SP_IMAGE_PIXEL_TYPE
		* @brief     Image pixel size
		*/
		typedef enum
		{
			SP_IMAGE_DATA_RGBA32,
			SP_IMAGE_DATA_RGB24,
			SP_IMAGE_DATA_RGB16,			// not supported yet
			SP_IMAGE_DATA_LUMINANCE8,		// not supported yet
			SP_IMAGE_DATA_FLOAT32,			// not supported yet
		} SP_IMAGE_PIXEL_TYPE;


		/**
		* @struct    _SPRawImageInfo
		* @brief     Raw image info
		*/
		typedef struct _SPRawImageInfo
		{
			SPInt				width;		//!< Width
			SPInt				height;		//!< Height
			SP_IMAGE_PIXEL_TYPE	pixelType;	//!< Pixel type
			SPVoid*				pixels;		//!< Pixels

			_SPRawImageInfo() :
				width(0),
				height(0),
				pixelType(SP_IMAGE_DATA_RGBA32),
				pixels(SPNULL) {}
		} SPRawImageInfo;	//!< Raw image info

	public:
		/**
		* @brief     Constructor
		*/
		SPImagerScaler() {}

		/**
		* @brief     Destructor
		*/
		~SPImagerScaler() {}


		/**
		* @brief	Resize texture color buffer (you have to delete texture color & imgData when you don't want to use)
		* @param     [IN]  @b TEXTURE_COLOR_BUFFER*		Source of Texture color buffer
		* @param	 [OUT] @b TEXTURE_COLOR_BUFFER*		destination of Texture color buffer;
		* @param     [IN]  @b SPInt						Destined image's width
		* @param     [IN]  @b SPInt						Destined image's height
		* @param     [IN]  @b SP_IMAGE_SCALE_OPTION		Scaling option
		*				(option		SP_IMAGE_SCALE_NEAREST,
		*							SP_IMAGE_SCALE_LINEAR,
		*							SP_IMAGE_SCALE_BLUR			)
		* @param     [IN] @b SP_IMAGE_PIXEL_TYPE		Data type of image data
		*				(option		SP_IMAGE_DATA_RGBA32,
		*							SP_IMAGE_DATA_RGB24,
		*							SP_IMAGE_DATA_RGB16,
		*							SP_IMAGE_DATA_LUMINANCE8,
		*							SP_IMAGE_DATA_FLOAT32		)
		* @return	SPVoid
		*/
		static SPVoid resizeTextureColor(TEXTURE_COLOR_BUFFER* src, TEXTURE_COLOR_BUFFER* dst, SPInt dstWidth, SPInt dstHeight, SP_IMAGE_SCALE_OPTION option = SP_IMAGE_SCALE_NEAREST, SP_IMAGE_PIXEL_TYPE pixelType = SP_IMAGE_DATA_RGBA32);

		/**
		* @brief	Resize texture color buffer (you have to delete texture color & imgData when you don't want to use)
		* @param     [IN]  @b TEXTURE_COLOR_BUFFER*		Source of Texture color buffer
		* @param	 [OUT] @b TEXTURE_COLOR_BUFFER*		destination of Texture color buffer;
		* @param     [IN]  @b SPFloat					Destined image's scale ratio
		* @param     [IN]  @b SP_IMAGE_SCALE_OPTION		Scaling option
		*				(option		SP_IMAGE_SCALE_NEAREST,
		*							SP_IMAGE_SCALE_LINEAR,
		*							SP_IMAGE_SCALE_BLUR			)
		* @param     [IN] @b SP_IMAGE_PIXEL_TYPE		Data type of image data
		*				(option		SP_IMAGE_DATA_RGBA32,
		*							SP_IMAGE_DATA_RGB24,
		*							SP_IMAGE_DATA_RGB16,
		*							SP_IMAGE_DATA_LUMINANCE8,
		*							SP_IMAGE_DATA_FLOAT32		)
		* @return	SPVoid
		*/
		static SPVoid resizeTextureColor(TEXTURE_COLOR_BUFFER* src, TEXTURE_COLOR_BUFFER* dst, SPFloat scaleRatio, SP_IMAGE_SCALE_OPTION option = SP_IMAGE_SCALE_NEAREST, SP_IMAGE_PIXEL_TYPE pixelType = SP_IMAGE_DATA_RGBA32);

		/**
		* @brief	Replace with resized texture color buffer (you have to delete texture color & imgData when you don't want to use)
		* @param     [INOUT] @b TEXTURE_COLOR_BUFFER*	Source of Texture color buffer
		* @param     [IN] @b SPInt						Destined image's width
		* @param     [IN] @b SPInt						Destined image's height
		* @param     [IN] @b SP_IMAGE_SCALE_OPTION		Scaling option
		*				(option		SP_IMAGE_SCALE_NEAREST,
		*							SP_IMAGE_SCALE_LINEAR,
		*							SP_IMAGE_SCALE_BLUR			)
		* @param     [IN] @b SP_IMAGE_PIXEL_TYPE		Data type of image data
		*				(option		SP_IMAGE_DATA_RGBA32,
		*							SP_IMAGE_DATA_RGB24,
		*							SP_IMAGE_DATA_RGB16,
		*							SP_IMAGE_DATA_LUMINANCE8,
		*							SP_IMAGE_DATA_FLOAT32		)
		* @return	SPVoid*
		*/
		static SPVoid replaceTextureColor(TEXTURE_COLOR_BUFFER* src, SPInt dstWidth, SPInt dstHeight, SP_IMAGE_SCALE_OPTION option = SP_IMAGE_SCALE_NEAREST, SP_IMAGE_PIXEL_TYPE pixelType = SP_IMAGE_DATA_RGBA32);


		/**
		* @brief	Replace with resized texture color buffer (you have to delete texture color & imgData when you don't want to use)
		* @param     [INOUT]	@b TEXTURE_COLOR_BUFFER*	Source of Texture color buffer
		* @param     [IN]		@b SPFloat					scale ratio for resize (resizeRatio > 0.0f)
		* @param     [IN]		@b SP_IMAGE_SCALE_OPTION	Scaling option
		*				(option		SP_IMAGE_SCALE_NEAREST,
		*							SP_IMAGE_SCALE_LINEAR,
		*							SP_IMAGE_SCALE_BLUR			)
		* @param     [IN]		@b SP_IMAGE_PIXEL_TYPE		Data type of image data
		*				(option		SP_IMAGE_DATA_RGBA32,
		*							SP_IMAGE_DATA_RGB24,
		*							SP_IMAGE_DATA_RGB16,
		*							SP_IMAGE_DATA_LUMINANCE8,
		*							SP_IMAGE_DATA_FLOAT32		)
		* @return	SPVoid*
		*/
		static SPVoid replaceTextureColor(TEXTURE_COLOR_BUFFER* src, SPFloat scaleRatio, SP_IMAGE_SCALE_OPTION option = SP_IMAGE_SCALE_NEAREST, SP_IMAGE_PIXEL_TYPE pixelType = SP_IMAGE_DATA_RGBA32);


		/**
		* @brief	Get resized raw image buffer (you have to delete texture color & imgData when you don't want to use)
		* @param     [IN]  @b SPRawImageInfo*		Source of Raw Image & it's information
		* @param     [OUT] @b SPRawImageInfo*		Destination of Raw Image & it's information
		* @param     [IN]  @b SPFloat				scale ratio for resize (resizeRatio > 0.0f)
		* @param     [IN]  @b SP_IMAGE_SCALE_OPTION	Scaling option
		*				(option		SP_IMAGE_SCALE_NEAREST,
		*							SP_IMAGE_SCALE_LINEAR,
		*							SP_IMAGE_SCALE_BLUR     )
		* @return	SPVoid
		*/
		static SPVoid resizeRawImage(SPRawImageInfo* srcRawImage, SPRawImageInfo* dstRawImage, SPFloat scaleRatio, SP_IMAGE_SCALE_OPTION option = SP_IMAGE_SCALE_NEAREST);


		/**
		* @brief	Get resized raw image buffer (you have to delete texture color & imgData when you don't want to use)
		* @param     [IN] @b SPRawImageInfo*			Source of Raw Image & it's information
		* @param     [IN] @b SPInt						Destined image's width
		* @param     [IN] @b SPInt						Destined image's height
		* @param     [IN] @b SP_IMAGE_SCALE_OPTION		Scaling option
		*				(option		SP_IMAGE_SCALE_NEAREST,
		*							SP_IMAGE_SCALE_LINEAR,
		*							SP_IMAGE_SCALE_BLUR     )
		* @return	SPVoid*									resized raw image
		*/
		static SPVoid* resizeRawImage(SPRawImageInfo* srcRawImage, SPInt dstWidth, SPInt dstHeight, SP_IMAGE_SCALE_OPTION option = SP_IMAGE_SCALE_NEAREST);

		/**
		* @brief	Get resized raw image
		* @param     [IN]  @b SPRawImageInfo*				Source of Raw Image & it's information
		* @param     [OUT] @b SPVoid*						Destination of Raw Image that will be resized
		* @param     [IN]  @b SPInt							Destined image's width
		* @param     [IN]  @b SPInt							Destined image's height
		* @param     [IN]  @b SP_IMAGE_SCALE_OPTION			Scaling option
		*				(option		SP_IMAGE_SCALE_NEAREST,
		*							SP_IMAGE_SCALE_LINEAR,
		*							SP_IMAGE_SCALE_BLUR     )
		* @return	SPVoid
		*/
		static SPVoid resizeRawImage(SPRawImageInfo* srcRawImage, SPVoid* dstData, SPInt dstWidth, SPInt dstHeight, SP_IMAGE_SCALE_OPTION option = SP_IMAGE_SCALE_NEAREST);

		

	private:
		static SPVoid resizeRawImageNearestRGBA32(SPRawImageInfo* srcRawImage, SPVoid* dstData, SPInt dstWidth, SPInt dstHeight);
		static SPVoid resizeRawImageLinearRGBA32(SPRawImageInfo* srcRawImage, SPVoid* dstData, SPInt dstWidth, SPInt dstHeight);
		static SPVoid resizeRawImageBlurRGBA32(SPRawImageInfo* srcRawImage, SPVoid* dstData, SPInt dstWidth, SPInt dstHeight);

		static SPVoid resizeRawImageNearestRGB24(SPRawImageInfo* srcRawImage, SPVoid* dstData, SPInt dstWidth, SPInt dstHeight);
		static SPVoid resizeRawImageLinearRGB24(SPRawImageInfo* srcRawImage, SPVoid* dstData, SPInt dstWidth, SPInt dstHeight);
		static SPVoid resizeRawImageBlurRGB24(SPRawImageInfo* srcRawImage, SPVoid* dstData, SPInt dstWidth, SPInt dstHeight);

		static SPVoid resizeRawImageNearestRGB16(SPRawImageInfo* srcRawImage, SPVoid* dstData, SPInt dstWidth, SPInt dstHeight);
		static SPVoid resizeRawImageLinearRGB16(SPRawImageInfo* srcRawImage, SPVoid* dstData, SPInt dstWidth, SPInt dstHeight);
		static SPVoid resizeRawImageBlurRGB16(SPRawImageInfo* srcRawImage, SPVoid* dstData, SPInt dstWidth, SPInt dstHeight);

		static SPVoid resizeRawImageNearestLUMINANCE8(SPRawImageInfo* srcRawImage, SPVoid* dstData, SPInt dstWidth, SPInt dstHeight);
		static SPVoid resizeRawImageLinearLUMINANCE8(SPRawImageInfo* srcRawImage, SPVoid* dstData, SPInt dstWidth, SPInt dstHeight);
		static SPVoid resizeRawImageBlurLUMINANCE8(SPRawImageInfo* srcRawImage, SPVoid* dstData, SPInt dstWidth, SPInt dstHeight);

		static SPInt  pixelSize(SP_IMAGE_PIXEL_TYPE pixelType);
	};

} // namespace SPhysics


#endif	// _SP_IMAGE_SCALER_H_
