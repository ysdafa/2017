/**
* @file SPUIManager.cpp
* @brief 
*
* @date 2013-04-16
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPUIManager.h"
#include "SPMesh.h"

#include <stdlib.h>
#include <glm.hpp>

namespace SPhysics{
	SPUIManager::SPUIManager() : m_iScreenWidth(0), m_iScreenHeight(0), m_UI_onLeftButton(SPNULL), m_UI_onRightButton(SPNULL), m_UI_Color_Button(SPNULL),
		m_bMouseRightOverOn(SPFALSE), m_bMouseLeftOverOn(SPFALSE), m_iStatus(0) {
			m_UI_Material_Button_List.clear();
	}
	SPUIManager::~SPUIManager(){


	}

	SPVoid SPUIManager::ManagerInit(SPInt width, SPInt height){
		m_iScreenWidth = width;
		m_iScreenHeight = height;
		m_iStatus = 0;

		//ADD ButtonUI
		Add_MainButtonUI();				

		m_cColorPalette.initialize(width, height);
	}

	SPInt SPUIManager::Managerupdate(SPInt m_nMouseEventType, SPInt m_nMouseX, SPInt m_nMouseY){
		//BoundingBox ON Check		
		if(m_bMouseRightOverOn == SPTRUE){			
			if(m_cColorPalette.pickColor(m_nMouseX, m_nMouseY))
			{
				m_bMouseRightOverOn = SPFALSE;
				m_vColor = m_cColorPalette.getColor();
				return SP_COLOR_HIT;
			}			
		}

		if(m_nMouseEventType == 0){
			if(m_nMouseX > m_UI_onLeftButton->ButtonUI_getBoundingBox().minX && m_nMouseX < m_UI_onLeftButton->ButtonUI_getBoundingBox().maxX 
				&&m_nMouseY > m_UI_onLeftButton->ButtonUI_getBoundingBox().minY && m_nMouseY < m_UI_onLeftButton->ButtonUI_getBoundingBox().maxY ){
					m_bMouseRightOverOn = SPFALSE;
					m_bMouseLeftOverOn = SPTRUE;
					return SP_BUTTON_HIT;
			}
			else if(m_nMouseX > m_UI_onRightButton->ButtonUI_getBoundingBox().minX && m_nMouseX < m_UI_onRightButton->ButtonUI_getBoundingBox().maxX 
				&&m_nMouseY > m_UI_onRightButton->ButtonUI_getBoundingBox().minY && m_nMouseY < m_UI_onRightButton->ButtonUI_getBoundingBox().maxY ){
					m_bMouseRightOverOn = SPTRUE;
					m_bMouseLeftOverOn = SPFALSE;
					return SP_BUTTON_HIT;
			}
		}


		if(m_nMouseEventType == 0 && m_bMouseLeftOverOn == SPTRUE ){
			for(SPUInt i = 0 ; i < m_UI_Material_Button_List.size() ; ++i){
				if(m_nMouseX > m_UI_Material_Button_List[i]->ButtonUI_getBoundingBox().minX && m_nMouseX < m_UI_Material_Button_List[i]->ButtonUI_getBoundingBox().maxX 
					&&m_nMouseY > m_UI_Material_Button_List[i]->ButtonUI_getBoundingBox().minY && m_nMouseY < m_UI_Material_Button_List[i]->ButtonUI_getBoundingBox().maxY ){
						m_iStatus = i;
						m_bMouseLeftOverOn = SPFALSE;
						return SP_BUTTON_HIT;
				}
			}
		}
		return SP_FALSE;
	}

	SPVoid SPUIManager::ManagerDraw(){
		//Button Render
		m_UI_onLeftButton->ButtonUI_draw();
		m_UI_onRightButton->ButtonUI_draw();

		if(m_bMouseLeftOverOn == SPTRUE){
			for(SPUInt i = 0 ; i < m_UI_Material_Button_List.size(); ++i){
				m_UI_Material_Button_List[i]->ButtonUI_draw();
			}
		}

		if(m_bMouseRightOverOn == SPTRUE){			
			m_cColorPalette.draw();
		}
	}

	SPVoid SPUIManager::ManagerDestroy(){
		SP_SAFE_DELETE(m_UI_onLeftButton);
		SP_SAFE_DELETE(m_UI_onRightButton);

		for(SPUInt i = 0 ; i < m_UI_Material_Button_List.size(); ++i){
			SP_SAFE_DELETE(m_UI_Material_Button_List[i]);
		}
		m_UI_Material_Button_List.clear();
		m_bMouseRightOverOn = SPFALSE;
		m_bMouseLeftOverOn = SPFALSE;
	}

	SPVoid SPUIManager::Add_MaterialButtonUI(SPChar* _fileName, SPInt _buttonID){
		SPUIButton* newUI_Button = new SPUIButton;
		//3x3 Textureing.. Pos setting -> check the order 
		SPUInt tempXPos = (( m_UI_Material_Button_List.size() % 6 ) * UI_BUTTON_SIZE_WIDTH ) + UI_MAINBUTTON_SIZE;
		SPUInt tempYPos = (m_UI_Material_Button_List.size() / 6 * UI_BUTTON_SIZE_HEIGHT) + UI_MAINBUTTON_SIZE;
		tempYPos = m_iScreenHeight - tempYPos - UI_BUTTON_SIZE_HEIGHT;

		newUI_Button->ButtonUI_setPos( tempXPos ,tempYPos );// start position of the button
		newUI_Button->ButtonUI_setSize( UI_BUTTON_SIZE_WIDTH, UI_BUTTON_SIZE_HEIGHT );//Size of the button

		newUI_Button->ButtonUI_init(m_iScreenWidth,m_iScreenHeight,0);
		newUI_Button->ButtonUI_setTexture(_fileName);
		newUI_Button->ButtonUI_setID(_buttonID);
		m_UI_Material_Button_List.push_back(newUI_Button);
	}

	/* Set the Button UI
	*/
	SPVoid SPUIManager::Add_MainButtonUI(){

		if(m_UI_onLeftButton == SPNULL) {  m_UI_onLeftButton = new SPUIButton; }
		m_UI_onLeftButton->ButtonUI_setPos(1, m_iScreenHeight - UI_MAINBUTTON_SIZE * 1.5);
		m_UI_onLeftButton->ButtonUI_setSize( UI_MAINBUTTON_SIZE, UI_MAINBUTTON_SIZE );
		m_UI_onLeftButton->ButtonUI_init(m_iScreenWidth,m_iScreenHeight,0);
		m_UI_onLeftButton->ButtonUI_setTexture("UIButtonImage/mainbutton_small.png");
		m_UI_onLeftButton->ButtonUI_setID(-1);

		if(m_UI_onRightButton == SPNULL) {  m_UI_onRightButton = new SPUIButton; }
		m_UI_onRightButton->ButtonUI_setPos(m_iScreenWidth - UI_MAINBUTTON_SIZE, m_iScreenHeight - UI_MAINBUTTON_SIZE  * 1.5);
		m_UI_onRightButton->ButtonUI_setSize( UI_MAINBUTTON_SIZE, UI_MAINBUTTON_SIZE );
		m_UI_onRightButton->ButtonUI_init(m_iScreenWidth,m_iScreenHeight,0);
		m_UI_onRightButton->ButtonUI_setTexture("UIButtonImage/colorpalette_small.png");
		m_UI_onRightButton->ButtonUI_setID(-1);
	}

	SPUInt SPUIManager::getState()
	{
		if(m_UI_Material_Button_List[m_iStatus] != SPNULL){
			return m_UI_Material_Button_List[m_iStatus]->ButtonUI_getID();
		}

		return -1;
	}

	SPVec3f SPUIManager::getColor()
	{
		return m_vColor;
	}

}