/**
* @file SPButton.cpp
* @brief 
*
* @date 2014-0308-
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include <stdlib.h>


#include "SPButton.h"
#include "SPTextureManager.h"

namespace SPhysics{

	SPButton::SPButton() : m_nButtonID(-1), m_ButtonDraw(SPNULL), m_FocusedButtonDraw(SPNULL), m_fWidth(0), m_fHeight(0) \
		                   , m_nButtonTexture(0), m_nPressedTexture(0), m_nFocusedTexture(0) \
						   , m_bIsFocused(SPFALSE), m_bIsPressed(SPFALSE), m_bIsVisible(SPTRUE) \
						   , m_fHitTestHalfWidth(0), m_fHitTestHalfHeight(0), m_bButtonShader(SPTRUE), m_bNegotiability(SPTRUE)

	{
		 m_vColor = SPVec4f(1.0, 1.0, 1.0, 1.0);
		 m_vFocusedColor = SPVec4f(1.0, 1.0, 1.0, 1.0);
		 m_vCenterPos = SPVec3f();
	}

	SPButton::~SPButton(){
		SP_SAFE_DELETE(m_ButtonDraw);
		SP_SAFE_DELETE(m_FocusedButtonDraw);
	}

	SPVoid SPButton::setScreenSize( SPFloat width, SPFloat height )
	{
		m_fScreenWidth = width;
		m_fScreenHeight = height;
	}

	SPVoid SPButton::createButton( SPInt buttonID, SPFloat width, SPFloat height )
	{
		m_nButtonID = buttonID;

		m_fWidth = width;
		m_fHeight = height;

		m_fHalfWidth = width * 0.5f;
		m_fHalfHeight = height * 0.5f;

		m_fHitTestHalfWidth = m_fHalfWidth;
		m_fHitTestHalfHeight = m_fHalfHeight;
	}

	SPVoid SPButton::draw()
	{
		drawbutton();
		drawFocusedButton();
	}

	SPVoid SPButton::setPosition( SPFloat x, SPFloat y, SPFloat z )
	{
		m_vCenterPos = SPVec3f(x, y, z);
	}

	SPVoid SPButton::setImage( const SPChar* name )
	{
#if (ANDROID_PORTING_MODE)
		m_nButtonTexture = SPTextureManager::getInstancePtr()->getTextureID(name);
#else
		m_nButtonTexture = SPTextureManager::getInstancePtr()->loadTexture(name);
#endif
		createDrawUnit();
	}

	SPVoid SPButton::setFocusedImage( const SPChar* name )
	{
#if (ANDROID_PORTING_MODE)
		m_nFocusedTexture = SPTextureManager::getInstancePtr()->getTextureID(name);
#else
		m_nFocusedTexture = SPTextureManager::getInstancePtr()->loadTexture(name);
#endif
		createFocusedDrawUnit();
	}

	SPVoid SPButton::setPressedImage( const SPChar* name )
	{
#if (ANDROID_PORTING_MODE)
		m_nFocusedTexture = SPTextureManager::getInstancePtr()->getTextureID(name);
#else
		m_nPressedTexture = SPTextureManager::getInstancePtr()->loadTexture(name);
#endif
		createDrawUnit();
	}

	SPVoid SPButton::setButtonTextureID(SPUInt texID)
	{
		m_nButtonTexture = texID;
		createDrawUnit();
	}

	SPVoid SPButton::setColor( SPFloat red, SPFloat green, SPFloat blue, SPFloat alpha )
	{
		m_vColor = SPVec4f(red, green, blue, alpha);
		createDrawUnit();
	}

	SPVoid SPButton::setFocusedColor( SPFloat red, SPFloat green, SPFloat blue, SPFloat alpha )
	{
		m_vFocusedColor = SPVec4f(red, green, blue, alpha);
		createFocusedDrawUnit();
	}

	SPVoid SPButton::release()
	{
		m_bIsPressed = SPFALSE;
	}

	SPVoid SPButton::setFocusStatus( SPBool flag )
	{
		m_bIsFocused = flag;
	}

	SPBool SPButton::getFocusStatus()
	{
		return m_bIsFocused;
	}

	SPVoid SPButton::setVisibility( SPBool flag )
	{
		m_bIsVisible = flag;
	}

	SPBool SPButton::getVisibility() const
	{
		return m_bIsVisible;
	}

	SPVoid SPButton::setNegotiability(SPBool flag)
	{
		m_bNegotiability = flag;
	}
	
	SPBool SPButton::getNegotiability() const
	{
		return m_bNegotiability;
	}

	SPInt SPButton::getButtonID()
	{
		return m_nButtonID;
	}

	SPInt SPButton::hitTest( SPFloat x, SPFloat y )
	{
		SPInt nResult = -1;

		if(m_bIsPressed == SPTRUE)
			m_bIsPressed = SPFALSE;

		if(x >= m_vCenterPos.x - m_fHitTestHalfWidth && x <= m_vCenterPos.x + m_fHitTestHalfWidth)
		{
			if(y >= m_vCenterPos.y - m_fHitTestHalfHeight && y <= m_vCenterPos.y + m_fHitTestHalfHeight)
			{
				nResult = m_nButtonID;
				m_bIsPressed = SPTRUE;
			}
		}

		return nResult;
	}

	SPVoid SPButton::setHitTestMargin( SPFloat width, SPFloat height )
	{
		m_fHitTestHalfWidth += width;
		m_fHitTestHalfHeight += height;
	}


	SPVoid SPButton::createDrawUnit()
	{
		if (m_bButtonShader == SPTRUE && m_ButtonDraw == SPNULL)
		{
			m_ButtonDraw = new SPDrawRect();
			m_ButtonDraw->setRectAlign(RECT_ALIGN_CENTER);
			m_ButtonDraw->initialize(m_fScreenWidth, m_fScreenHeight);
			m_ButtonDraw->setSize(m_fWidth, m_fHeight);
			m_ButtonDraw->setTranslate(m_vCenterPos.x, m_vCenterPos.y, m_vCenterPos.z);
		}
	}

	SPVoid SPButton::createFocusedDrawUnit()
	{
		if (m_bButtonShader == SPTRUE && m_FocusedButtonDraw == SPNULL)
		{
			m_FocusedButtonDraw = new SPDrawRect();
			m_FocusedButtonDraw->setRectAlign(RECT_ALIGN_CENTER);
			m_FocusedButtonDraw->initialize(m_fScreenWidth, m_fScreenHeight);
			m_FocusedButtonDraw->setSize(m_fWidth, m_fHeight);
			m_FocusedButtonDraw->setTranslate(m_vCenterPos.x, m_vCenterPos.y, m_vCenterPos.z);
		}
	}

	SPVoid SPButton::drawbutton()
	{
		if(m_ButtonDraw == SPNULL)
			return;

		if(m_bIsVisible == SPFALSE)
			return;

		m_ButtonDraw->setColor(m_vColor.r, m_vColor.g, m_vColor.b, m_vColor.a);
		m_ButtonDraw->setTranslate(m_vCenterPos.x, m_vCenterPos.y, m_vCenterPos.z);

		if(m_nButtonTexture != 0)
		{
			m_ButtonDraw->setTextureID(m_nButtonTexture);
		}

		if(m_bIsPressed == SPTRUE && m_nPressedTexture != 0)
		{
			m_ButtonDraw->setTextureID(m_nPressedTexture);
		}

		m_ButtonDraw->draw();
	}

	SPVoid SPButton::drawFocusedButton()
	{
		if(m_FocusedButtonDraw == SPNULL)
			return;

		if(m_bIsVisible == SPFALSE || m_bIsFocused == SPFALSE)
			return;

		m_FocusedButtonDraw->setColor(m_vFocusedColor.r, m_vFocusedColor.g, m_vFocusedColor.b, m_vFocusedColor.a);
		m_FocusedButtonDraw->setTranslate(m_vCenterPos.x, m_vCenterPos.y, m_vCenterPos.z);

		if(m_bIsFocused == SPTRUE && m_nFocusedTexture != 0)
		{
			m_FocusedButtonDraw->setTextureID(m_nFocusedTexture);
		}

		m_FocusedButtonDraw->draw();
	}

	SPVec3f SPButton::getPosition()
	{
		return m_vCenterPos;
	}
		
	SPVoid SPButton::setEnableButtonShader(SPBool bEnable)
	{
		m_bButtonShader = bEnable;
	}
	
	SPUInt SPButton::getButtonTextureID()
	{
		return m_nButtonTexture;
	}
	
	SPUInt SPButton::getPressedTextureID()
	{
		return m_nPressedTexture;
	}

	SPUInt SPButton::getFocusedTextureID()
	{
		return m_nFocusedTexture;
	}

	SPVec2f SPButton::getSize()
	{
		return SPVec2f(m_fWidth, m_fHeight);
	}

}