/**
* @file SPBitmap.cpp
* @brief 
*
* @date 2014-09-25
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include "SPLog.h"
#include "SPBitmap.h"

namespace SPhysics
{
	/** "BM" (little endian)*/
#define SP_BITMAP_ID 0x4d42

	SPBitmap::SPBitmap(void)
	{

	}

	SPBitmap::~SPBitmap(void)
	{

	}

	SPBool SPBitmap::GetBitmap(const SPChar* path, SPBitmapData& bitmapData, SPBool fromBottom)
	{
		assert(path != NULL);
		assert(path[0] != 0);

		FILE* bmpFile;
		memset(&bitmapData, 0, sizeof(SPBitmapData));

		if ((bmpFile = fopen(path, "rb")) != SPNULL)
		{
			SPBitmapFileHeader fileHeader;
			if (fread(&fileHeader, sizeof(SPBitmapFileHeader), 1, bmpFile) == 1)
			{
				if (fileHeader.type == SP_BITMAP_ID)
				{
					SPBitmapInfoHeader infoHeader;
					if (fread(&infoHeader, sizeof(SPBitmapInfoHeader), 1, bmpFile) == 1)
					{
						if (fseek(bmpFile, fileHeader.dataOffset, SEEK_SET) == 0)
						{
							unsigned long imageSize = infoHeader.sizeImage;
							if (imageSize == 0)
								imageSize = fileHeader.size - fileHeader.dataOffset;

							switch(infoHeader.bitCount)
							{
							case 8:
								bitmapData.format = PIXEL_FORMAT_GRAY8;
								break;

							case 16:
								bitmapData.format = PIXEL_FORMAT_BGR16;
								break;

							case 24:
								bitmapData.format = PIXEL_FORMAT_BGR24;
								break;

							case 32:
								bitmapData.format = PIXEL_FORMAT_BGRA32;
								break;

							default:
								bitmapData.format = PIXEL_FORMAT_NONE;
								imageSize = 0;
							}

							if (0 < imageSize && imageSize < SP_MAX_BITMAP_SIZE)
							{
								bitmapData.pixels = new SPUChar[imageSize];
								if (bitmapData.pixels != SPNULL)
								{
									bool ret = SPFALSE;
									if (fromBottom == SPFALSE)
									{
										if (fread(bitmapData.pixels, sizeof(SPUChar), imageSize, bmpFile) == imageSize)
										{
											ret = SPTRUE;
										}
										else
											SP_LOGE("reading bitmap data is failed");
									}
									else
									{
										ret = SPTRUE;
										SPULong stride = infoHeader.width * infoHeader.bitCount / 8;
										for (SPUChar* buffer = (SPUChar*)bitmapData.pixels + imageSize - stride; buffer >= (SPUChar*)bitmapData.pixels; buffer -= stride)
										{
											if (fread(buffer, sizeof(SPUChar), stride, bmpFile) != stride)
											{
												ret = SPFALSE;
												break;
											}
										}
									}

									if (ret == SPTRUE)
									{
										bitmapData.width = infoHeader.width;
										bitmapData.height = infoHeader.height;

										fclose(bmpFile);
										return SPTRUE;
									}

									delete[] (SPUChar*)(bitmapData.pixels);
									bitmapData.pixels = SPNULL;
								}
								else
									SP_LOGE("there is no memory bitmap's pixel");
							}
							else
								SP_LOGE("bitmap's pixel count is zero");
						}
						else
							SP_LOGE("seek to bitmap's pixel data is failed");
					}
					else
						SP_LOGE("reading bitmap info header is failed");
				}
				else
					SP_LOGE("reading bitmap file header is failed");
			}
			else
				SP_LOGE("file open failed (%s)", path);

			fclose(bmpFile);
		}

		return SPFALSE;
	}

	SPVoid SPBitmap::ReleaseBitmapData(SPBitmapData& bitmapData)
	{
		delete[] (SPUChar*)(bitmapData.pixels);
		bitmapData.pixels	= SPNULL;
		bitmapData.width	= 0;
		bitmapData.height	= 0;
	}

	SPBool SPBitmap::SaveBitmap(const SPChar* path, SPInt width, SPInt height, NPixelFormat format, SPVoid* pixels, SPBool fromBottom)
	{
		assert(path != SPNULL);
		assert(path[0] != 0);
		assert(pixels != SPNULL);
		
		FILE* bmpFile;
		if ((bmpFile = fopen(path, "wb")) != SPNULL)
		{
			SPBitmapInfoHeader infoHeader;
			infoHeader.size = sizeof(SPBitmapInfoHeader);
			infoHeader.width = width;
			infoHeader.height = height;
			infoHeader.planes = 1;
			switch(format)
			{
			case PIXEL_FORMAT_GRAY8:
				infoHeader.bitCount = 8;
				break;

			case PIXEL_FORMAT_BGR16:
				infoHeader.bitCount = 16;
				break;

			case PIXEL_FORMAT_BGR24:
				infoHeader.bitCount = 24;
				break;

			case PIXEL_FORMAT_BGRA32:
				infoHeader.bitCount = 32;
				break;

			default:
				fclose(bmpFile);
				return SPFALSE;
			}

			infoHeader.compression = 0;
			infoHeader.sizeImage = (unsigned long)(width * height) * infoHeader.bitCount / 8;
			infoHeader.xPelsPerMeter = 0;
			infoHeader.yPelsPerMeter = 0;
			infoHeader.clrUsed = 0;
			infoHeader.clrImportant = 0;

			SPBitmapFileHeader fileHeader;
			fileHeader.type = 0x4d42;
			fileHeader.dataOffset = sizeof(SPBitmapFileHeader) + sizeof(SPBitmapInfoHeader);
			fileHeader.size = infoHeader.sizeImage + fileHeader.dataOffset;
			fileHeader.reserved1 = 0;
			fileHeader.reserved2 = 0;

			if (fwrite(&fileHeader, sizeof(SPBitmapFileHeader), 1, bmpFile) == 1)
			{
				if (fwrite(&infoHeader, sizeof(SPBitmapInfoHeader), 1, bmpFile) == 1)
				{
					if (fromBottom == SPFALSE)
					{
						if (fwrite(pixels, sizeof(SPUChar), infoHeader.sizeImage, bmpFile) == infoHeader.sizeImage)
						{
							fclose(bmpFile);
							return SPTRUE;
						}
						else
							SP_LOGE("pixel writing is failed (size = %lu)", infoHeader.sizeImage);
					}
					else
					{
						SPBool ret = SPTRUE;
						SPULong stride = infoHeader.width * infoHeader.bitCount / 8;
						for (SPUChar* buffer = (SPUChar*)pixels + infoHeader.sizeImage - stride; buffer >= (SPUChar*)pixels; buffer -= stride)
						{
							if (fwrite(buffer, sizeof(SPUChar), stride, bmpFile) != stride)
							{
								ret = SPFALSE;
								break;
							}
						}

						if (ret == SPTRUE)
						{
							fclose(bmpFile);
							return SPTRUE;
						}
					}
				}
				else
					SP_LOGE("info header writing is failed");
			}
			else
				SP_LOGE("file header writing is failed");
			
			fclose(bmpFile);
		}
		else
			SP_LOGE("file open failed (%s)", path);

		return SPFALSE;
	}

}
