/**
* @file SPLineWidthUtil.cpp
* @brief 
*
* @date 2013-04-20
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/
#include "SPLineWidthUtil.h"
#include "SPBresenHamLine.h"
#include "SPVectorUtilities.h"
#include <list>
namespace SPhysics
{
	template <typename T>
	SPLineWidthUtil<T>::SPLineWidthUtil()
		:m_LineWidth(0.0f)
	{
	}

	template <typename T>
	SPLineWidthUtil<T>::~SPLineWidthUtil()
	{
	}	

	template <typename T>
	SPMesh SPLineWidthUtil<T>::get_line_modified_mesh( SPMesh& line_mesh, T line_width, SPVec2t screen_resolution, SPVec2t sim_resolution )
	{
		const SPUInt circle_segments = 8;
		SPMesh ret_mesh;
		for(SPInt i =0; i < (SPInt)line_mesh.m_tVertex.size() - 1; i++)
		{

			SPVec2t pos1 = SPVec2t(line_mesh.m_tVertex[i]);
			SPVec2t pos2 = SPVec2t(line_mesh.m_tVertex[i + 1]);

			SPVec2t normal_vec = SPVectorUtilities<T>::perpendicularVector(pos2 - pos1, 1.0);
			normal_vec = glm::normalize(normal_vec);
			normal_vec *= sim_resolution.x / screen_resolution.x * line_width;

			SPVec2t v1 = pos1 - normal_vec;
			SPVec2t v2 = pos1 + normal_vec;

			SPVec2t v3 = pos2 - normal_vec;
			SPVec2t v4 = pos2 + normal_vec;

			ret_mesh.m_tVertex.push_back(SPVec3t(v1.x, v1.y, 0.0));
			ret_mesh.m_tVertex.push_back(SPVec3t(v2.x, v2.y, 0.0));				
			ret_mesh.m_tVertex.push_back(SPVec3t(v3.x, v3.y, 0.0));
			
			ret_mesh.m_tVertex.push_back(SPVec3t(v2.x, v2.y, 0.0));
			ret_mesh.m_tVertex.push_back(SPVec3t(v3.x, v3.y, 0.0));
			ret_mesh.m_tVertex.push_back(SPVec3t(v4.x, v4.y, 0.0));

			if(m_LineWidth != line_width)
			{
				m_CircleMesh.clear();
				m_CircleMesh = makeCircleMesh(line_width,circle_segments);
				m_LineWidth = line_width;
			}

			SPUInt offset = ret_mesh.m_tVertex.size();
			const SPUInt circle_size = m_CircleMesh.size();
			
// 			static SPBresenHamLine bresenHamLine;
// 
// 			SPVec2i src = pos1;
// 			SPVec2i dst = pos2;
// 
// 			auto trace = bresenHamLine.generate(src, dst);			
// 			for(auto itr = trace.begin(); itr != trace.end(); ++itr)
// 			{
// 				ret_mesh.m_tVertex.resize(offset + circle_size);
// 				for(SPUInt c = 0; c<circle_size; ++c) ret_mesh.m_tVertex[offset + c] = SPVec3t(m_CircleMesh[c].x + itr->x, m_CircleMesh[c].y + itr->y, 0.0); 
// 			}
// 
// 			offset = ret_mesh.m_tVertex.size();

 			ret_mesh.m_tVertex.resize(offset + circle_size * 2);
 			for(SPUInt c = 0; c<circle_size; ++c) ret_mesh.m_tVertex[offset + c] = SPVec3t(m_CircleMesh[c].x + pos1.x, m_CircleMesh[c].y + pos1.y, 0.0);
 			for(SPUInt c = 0; c<circle_size; ++c) ret_mesh.m_tVertex[offset + circle_size + c] = SPVec3t(m_CircleMesh[c].x + pos2.x, m_CircleMesh[c].y + pos2.y, 0.0);

		}
		return ret_mesh;
	}

	template <typename T>
	SPMesh SPLineWidthUtil<T>::get_line_modified_mesh_inktest(SPMesh& line_mesh, T line_width, SPVec2t screen_resolution, SPVec2t sim_resolution)
	{
		const SPUInt circle_segments = 8;
		SPMesh ret_mesh;
		for (SPInt i = 0; i < (SPInt)line_mesh.m_tVertex.size() - 1; i++)
		{

			SPVec2t pos1 = SPVec2t(line_mesh.m_tVertex[i]);
			SPVec2t pos2 = SPVec2t(line_mesh.m_tVertex[i + 1]);

			if (m_LineWidth != line_width)
			{
				m_CircleMesh.clear();
				m_CircleMesh = makeCircleMesh(line_width, circle_segments);
				m_LineWidth = line_width;
			}

			SPUInt offset = ret_mesh.m_tVertex.size();
			const SPUInt circle_size = m_CircleMesh.size();

			ret_mesh.m_tVertex.resize(offset + circle_size * 2);
			for (SPUInt c = 0; c < circle_size; ++c) ret_mesh.m_tVertex[offset + c] = SPVec3t(m_CircleMesh[c].x + pos1.x, m_CircleMesh[c].y + pos1.y, 0.0);
			for (SPUInt c = 0; c < circle_size; ++c) ret_mesh.m_tVertex[offset + circle_size + c] = SPVec3t(m_CircleMesh[c].x + pos2.x, m_CircleMesh[c].y + pos2.y, 0.0);

		}
		return ret_mesh;
	}

	template <typename T>
	SPMesh SPLineWidthUtil<T>::get_line_modified_circle_mesh( SPMesh& line_mesh, T line_width, SPVec2t screen_resolution, SPVec2t sim_resolution )
	{
		const SPUInt circle_segments = 8;
		SPMesh ret_mesh;

		if(m_LineWidth != line_width)
		{
			m_CircleMesh.clear();
			m_CircleMesh = makeCircleMesh(line_width,circle_segments);
			m_LineWidth = line_width;
		}

		for(SPInt i =0; i < (SPInt)line_mesh.m_tVertex.size() - 1; i++)
		{

			SPVec2t pos1 = SPVec2t(line_mesh.m_tVertex[i]);
			SPVec2t pos2 = SPVec2t(line_mesh.m_tVertex[i + 1]);
						
			static SPBresenHamLine bresenHamLine;

			SPVec2i src = pos1;
			SPVec2i dst = pos2;

			auto trace = bresenHamLine.generate(src, dst);
			for(auto itr = trace.begin(); itr != trace.end(); ++itr)
			{
				const SPUInt offset = ret_mesh.m_tVertex.size();
				const SPUInt circle_size = m_CircleMesh.size();

				ret_mesh.m_tVertex.resize(offset + circle_size);

				for(SPUInt c = 0; c<circle_size; ++c) 
					ret_mesh.m_tVertex[offset + c] = SPVec3t(m_CircleMesh[c].x + itr->x, m_CircleMesh[c].y + itr->y, 0.0); 
			}
		}
		return ret_mesh;
	}

	template <typename T>
	std::vector<SPVec3t > SPLineWidthUtil<T>::makeCircleMesh( const T& r, const int& nSegs )
	{
		std::vector<SPVec3t > circle;
		for( int i = 0; i < nSegs; ++i ) {
			T x = r * cosine( (T)PI2 * ( i/(T)nSegs ) );
			T y = r * sine( (T)PI2 * ( i/(T)nSegs ) );

			T x1, y1;
			if(i + 1 < nSegs){
				x1 = r * cosine( (T)PI2 * ( (i+1)/(T)nSegs ) );
				y1 = r * sine( (T)PI2 * ( (i+1)/(T)nSegs ) );
			}
			else
			{
				x1 = r * cosine( (T)PI2 * ( (0)/(T)nSegs ) );
				y1 = r * sine( (T)PI2 * ( (0)/(T)nSegs ) );
			}

			circle.push_back( SPVec3t(x, y,0) );
			circle.push_back( SPVec3t(0.0, 0.0,0) );
			circle.push_back( SPVec3t(x1, y1,0) );
		}
		return circle;
	}

	template class SPLineWidthUtil<SPFloat>;
	template class SPLineWidthUtil<SPDouble>;

} // namespace SPhysics 

