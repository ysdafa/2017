#include "SPMotionCurve.h"
#include "math.h"

namespace SPhysics
{
	SPFloat QuintOut50::getInterpolation(SPFloat input)
	{
		SPFloat segments[2][3] = {{0.0f, 0.502f, 0.742f}, {0.742f, 1.082f, 1.0f}};

		SPFloat _loc_5 = input / 1;
		SPInt segmentsLength = sizeof(segments) / (sizeof(SPFloat) * 3);
		SPInt _loc_6 = segmentsLength;
		SPInt _loc_9 = floor(_loc_6 * _loc_5);
		if (_loc_9 >= segmentsLength) _loc_9 = segmentsLength - 1;

		SPFloat _loc_7 = (_loc_5 - _loc_9 * (1.0f / _loc_6)) * _loc_6;
		SPFloat* _loc_8 = segments[_loc_9];
		SPFloat ret = 0 + 1 * (_loc_8[0] + _loc_7 * (2 * (1 - _loc_7) * (_loc_8[1] - _loc_8[0]) + _loc_7 * (_loc_8[2] - _loc_8[0])));

		return ret;
	}
	SPFloat QuintOut80::getInterpolation(SPFloat input)
	{
		SPFloat segments[2][3] = {{0.04f, 0.718f, 0.84f}, {0.845f, 0.998f, 1.0f}};

		SPFloat _loc_5 = input / 1;
		SPInt segmentsLength = sizeof(segments) / (sizeof(SPFloat) * 3);
		SPInt _loc_6 = segmentsLength;
		SPInt _loc_9 = floor(_loc_6 * _loc_5);
		if (_loc_9 >= segmentsLength) _loc_9 = segmentsLength - 1;

		SPFloat _loc_7 = (_loc_5 - _loc_9 * (1.0f / _loc_6)) * _loc_6;
		SPFloat* _loc_8 = segments[_loc_9];
		SPFloat ret = 0 + 1 * (_loc_8[0] + _loc_7 * (2 * (1 - _loc_7) * (_loc_8[1] - _loc_8[0]) + _loc_7 * (_loc_8[2] - _loc_8[0])));

		return ret;
	}
	SPFloat SineIn33::getInterpolation(SPFloat input)
	{
		SPFloat segments[2][3] = {{0.0f, 0.001f, 0.32f}, {0.32f, 0.59f, 1.0f}};

		SPFloat _loc_5 = input / 1;
		SPInt segmentsLength = sizeof(segments) / (sizeof(SPFloat) * 3);
		SPInt _loc_6 = segmentsLength;
		SPInt _loc_9 = floor(_loc_6 * _loc_5);
		if (_loc_9 >= segmentsLength) _loc_9 = segmentsLength - 1;

		SPFloat _loc_7 = (_loc_5 - _loc_9 * (1.0f / _loc_6)) * _loc_6;
		SPFloat* _loc_8 = segments[_loc_9];
		SPFloat ret = 0 + 1 * (_loc_8[0] + _loc_7 * (2 * (1 - _loc_7) * (_loc_8[1] - _loc_8[0]) + _loc_7 * (_loc_8[2] - _loc_8[0])));

		return ret;
	}

	SPFloat SineInOut33::getInterpolation(SPFloat input)
	{
		SPFloat segments[2][3] = {{0.0f, 0.050f, 0.495f}, {0.495f, 0.940f, 1.0f}};

		SPFloat _loc_5 = input / 1;
		SPInt segmentsLength = sizeof(segments) / (sizeof(SPFloat) * 3) ;
		SPInt _loc_6 = segmentsLength;
		SPInt _loc_9 = floor(_loc_6 * _loc_5);
		if (_loc_9 >= segmentsLength) _loc_9 = segmentsLength - 1;

		SPFloat _loc_7 = (_loc_5 - _loc_9 * (1.0f / _loc_6)) * _loc_6;
		SPFloat* _loc_8 = segments[_loc_9];
		SPFloat ret = 0 + 1 * (_loc_8[0] + _loc_7 * (2 * (1 - _loc_7) * (_loc_8[1] - _loc_8[0]) + _loc_7 * (_loc_8[2] - _loc_8[0])));

		return ret;
	}
	SPFloat SineInOut50::getInterpolation(SPFloat input)
	{
		SPFloat segments[2][3] = {{0.0f, 0.050f, 0.628f}, {0.610f, 0.999f, 1.0f}};

		SPFloat _loc_5 = input / 1;
		SPInt segmentsLength = sizeof(segments) / (sizeof(SPFloat) * 3) ;
		SPInt _loc_6 = segmentsLength;
		SPInt _loc_9 = floor(_loc_6 * _loc_5);
		if (_loc_9 >= segmentsLength) _loc_9 = segmentsLength - 1;

		SPFloat _loc_7 = (_loc_5 - _loc_9 * (1.0f / _loc_6)) * _loc_6;
		SPFloat* _loc_8 = segments[_loc_9];
		SPFloat ret = 0 + 1 * (_loc_8[0] + _loc_7 * (2 * (1 - _loc_7) * (_loc_8[1] - _loc_8[0]) + _loc_7 * (_loc_8[2] - _loc_8[0])));

		return ret;
	}
	SPFloat SineInOut60::getInterpolation(SPFloat input)
	{
		SPFloat segments[3][3] = {{0.0f, 0.01f, 0.37f}, {0.37f, 0.72f, 0.888f}, {0.888f, 0.9999f, 1.0f }};

		SPFloat _loc_5 = input / 1;
		SPInt segmentsLength = sizeof(segments) /(sizeof(SPFloat) * 3) ;
		SPInt _loc_6 = segmentsLength;
		SPInt _loc_9 = floor(_loc_6 * _loc_5);
		if (_loc_9 >= segmentsLength) _loc_9 = segmentsLength - 1;

		SPFloat _loc_7 = (_loc_5 - _loc_9 * (1.0f / _loc_6)) * _loc_6;
		SPFloat* _loc_8 = segments[_loc_9];
		SPFloat ret = 0 + 1 * (_loc_8[0] + _loc_7 * (2 * (1 - _loc_7) * (_loc_8[1] - _loc_8[0]) + _loc_7 * (_loc_8[2] - _loc_8[0])));

		return ret;
	}
	SPFloat SineInOut70::getInterpolation(SPFloat input)
	{
		SPFloat segments[3][3] = {{0.0f, 0.01f, 0.45f}, {0.45f, 0.80f, 0.908f}, {0.908f, 0.9999f, 1.0f}};

		SPFloat _loc_5 = input / 1;
		SPInt segmentsLength = sizeof(segments) / (sizeof(SPFloat) * 3) ;
		SPInt _loc_6 = segmentsLength;
		SPInt _loc_9 = floor(_loc_6 * _loc_5);
		if (_loc_9 >= segmentsLength) _loc_9 = segmentsLength - 1;

		SPFloat _loc_7 = (_loc_5 - _loc_9 * (1.0f / _loc_6)) * _loc_6;
		SPFloat* _loc_8 = segments[_loc_9];
		SPFloat ret = 0 + 1 * (_loc_8[0] + _loc_7 * (2 * (1 - _loc_7) * (_loc_8[1] - _loc_8[0]) + _loc_7 * (_loc_8[2] - _loc_8[0])));

		return ret;
	}
	SPFloat SineInOut80::getInterpolation(SPFloat input)
	{
		SPFloat segments[5][3] = {{0.0f, 0.000f, 0.195f},{0.195f, 0.48f, 0.645f},{0.645f, 0.835f, 0.885f}, {0.885f, 0.955f, 0.978f}, {0.978f, 0.9999f, 1.0f}};
		

		SPFloat _loc_5 = input / 1;
		SPInt segmentsLength = sizeof(segments) / (sizeof(SPFloat) * 3) ;
		SPInt _loc_6 = segmentsLength;
		SPInt _loc_9 = floor(_loc_6 * _loc_5);
		if (_loc_9 >= segmentsLength) _loc_9 = segmentsLength - 1;

		SPFloat _loc_7 = (_loc_5 - _loc_9 * (1.0f / _loc_6)) * _loc_6;
		SPFloat* _loc_8 = segments[_loc_9];
		SPFloat ret = 0 + 1 * (_loc_8[0] + _loc_7 * (2 * (1 - _loc_7) * (_loc_8[1] - _loc_8[0]) + _loc_7 * (_loc_8[2] - _loc_8[0])));

		return ret;
	}
	SPFloat SineInOut90::getInterpolation(SPFloat input)
	{
		SPFloat segments[5][3] = {{0.0f, 0.000f, 0.247f},{0.247f, 0.48f, 0.720f},{0.700f, 0.835f, 0.905f}, {0.910f, 0.955f, 0.978f}, {0.978f, 0.9999f, 1.0f}};
								

		SPFloat _loc_5 = input / 1;
		SPInt segmentsLength = sizeof(segments) / (sizeof(SPFloat) * 3) ;
		SPInt _loc_6 = segmentsLength;
		SPInt _loc_9 = floor(_loc_6 * _loc_5);
		if (_loc_9 >= segmentsLength) _loc_9 = segmentsLength - 1;

		SPFloat _loc_7 = (_loc_5 - _loc_9 * (1.0f / _loc_6)) * _loc_6;
		SPFloat* _loc_8 = segments[_loc_9];
		SPFloat ret = 0 + 1 * (_loc_8[0] + _loc_7 * (2 * (1 - _loc_7) * (_loc_8[1] - _loc_8[0]) + _loc_7 * (_loc_8[2] - _loc_8[0])));

		return ret;
	}

	SPFloat SinOut33::getInterpolation(SPFloat input)
	{
		SPFloat segments[2][3] = {{0.0f, 0.386f, 0.645f}, {0.645f, 0.962f, 1.0f}};

		SPFloat _loc_5 = input / 1;
		SPInt segmentsLength = sizeof(segments) / (sizeof(SPFloat) * 3) ;
		SPInt _loc_6 = segmentsLength;
		SPInt _loc_9 = floor(_loc_6 * _loc_5);
		if (_loc_9 >= segmentsLength) _loc_9 = segmentsLength - 1;

		SPFloat _loc_7 = (_loc_5 - _loc_9 * (1.0f / _loc_6)) * _loc_6;
		SPFloat* _loc_8 = segments[_loc_9];
		SPFloat ret = 0 + 1 * (_loc_8[0] + _loc_7 * (2 * (1 - _loc_7) * (_loc_8[1] - _loc_8[0]) + _loc_7 * (_loc_8[2] - _loc_8[0])));

		return ret;
	}

}