/**
* @file SPButtonUI.h
* @brief This files is the implementation of Button UI Modules.
*
* @date 2013-04-23
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/
#ifndef _SP_BUTTON_UI_H_
#define _SP_BUTTON_UI_H_

#include "SPDefines.h"

#include <vector>
#include "SPDrawRect.h"

namespace SPhysics
{
	/**
	* @struct    _SP_BUTTON
	* @brief     Button
	*/
	typedef struct _SP_BUTTON
	{
		SPFloat left;		//!< left
		SPFloat bottom;		//!< bottom
		SPUInt TextureID;	//!< Texture Id
	}SP_BUTTON;	//!< Button

	/**
	* @enum      _BUTTON_DISPLAY_STATE
	* @brief     Button display state
	*/
	typedef enum _BUTTON_DISPLAY_STATE
	{
		IDLE_STATE,
		FOLD_ANIMATE_STATE,
		UNFOLD_ANIMATE_STATE,
		STRETCH_STATE,
		STRETCH_MAGNIFIER_STATE
	}BUTTON_DISPLAY_STATE;	//!< Button display state

	/**
	* @enum   _BUTTON_STRETCH_TYPE
	* @brief   This enum defines Layout of Button lists.
	*/
	typedef enum _BUTTON_STRETCH_TYPE
	{
		LEFT_RIGHT,
		BOTTOM_TOP_LEFT,
		BOTTOM_TOP_RIGHT,
		TOP_BOTTOM_LEFT,
		TOP_BOTTOM_RIGHT
	}BUTTON_STRETCH_TYPE;	//!< This enum defines Layout of Button lists.

	/**
	* @class     SPButtonUI
	* @brief     Create Button UI
	 */
	class SPButtonUI
	{
	public:
		SPButtonUI();
		~SPButtonUI();

		/**
		* @brief	Class Initialization
		* @param [IN] @b width  width size of view port
		* @param [IN] @b height height size of view port
		* @return    SPVoid
		 */
		SPVoid init(SPFloat width, SPFloat height);
		/**
		* @brief  Reset of object data( re initialize ) 
		* @return    SPVoid
		*/
		SPVoid reset();
		/**
		* @brief	 Set position of UI
		* @param [IN] @b x X position
		* @param [IN] @b y Y position
		* @return    SPVoid
		*/
		SPVoid setPosition(SPFloat x, SPFloat y);

		/**
		* @brief	Add UI Button
		* @param [IN] @b imgName Filepath of UI image 
		* @return    SPVoid
		 */
		SPVoid addButton(const SPChar *imgName);
		/**
		* @brief	Set StretchType
		* @param [IN] @b type  one of enum _BUTTON_STRETCH_TYPE 
		* @return    SPVoid
		*/
		SPVoid setStretchType(SPInt type);
		/**
		* @brief	Draw UI
		* @return    SPVoid
		*/
		SPVoid draw();
		/**
		* @brief	Touch event handling
		* @param [IN] @b eventType touch event type( move, down, up )
		* @param [IN] @b x Position X of touch 
		* @param [IN] @b y Position Y of touch 
		* @return    SPInt
		*/
		SPInt onTouchEvent(SPInt eventType, SPFloat x, SPFloat y);
		/**
		* @brief	Set Size of UI Button
		* @param [IN] @b width  Width size of UI Button
		* @param [IN] @b height Height size of UI Button
		* @return    SPVoid
		 */
		SPVoid setButtonSize(SPFloat width, SPFloat height);
		/**
		* @brief    Set magnify ratio of UI Button
		* @param [IN] @b ratio Magnify ratio 
		* @return    SPVoid
		 */
		SPVoid setMagnifyRatio(SPFloat ratio);
		/**
		* @brief	Get current button state
		* @return    SPInt
		 */
		SPInt getCurrentButton();
		
	private:
		/**
		* @brief	Action when mouse down event 
		* @param     [IN] @b x position X of mouse
		* @param     [IN] @b y position Y of mouse
		* @return    SPVoid
		 */
		SPVoid actionMouseDownEvent(SPFloat x, SPFloat y);
		/**
		* @brief	Action when mouse up event 
		* @param     [IN] @b x position X of mouse
		* @param     [IN] @b y position Y of mouse
		* @return    SPVoid
		 */
		SPVoid actionMouseUpEvent(SPFloat x, SPFloat y);
		/**
		* @brief	 Action when mouse move event 
		* @param     [IN] @b x position X of mouse
		* @param     [IN] @b y position Y of mouse
		* @return    SPVoid
		*/
		SPVoid actionMouseMoveEvent(SPFloat x, SPFloat y);

		/**
		* @brief	Reset coordinate of button texture
		* @return    SPVoid
		 */
		SPVoid resetButtonCoordinate();
		/**
		* @brief	Touch event check 
		* @param     [IN] @b button Button to check 
		* @param     [IN] @b touchX Position X of touch
		* @param     [IN] @b touchY Position Y of touch
		* @return    SPInt
		 */
		SPInt hitTestButton(SP_BUTTON button, SPFloat touchX, SPFloat touchY);
		/**
		* @brief	 Draw button UI left to right
		* @return    SPVoid
		 */
		SPVoid draw_left_to_right();
		/**
		* @brief	 Draw button UI top to left
		* @return    SPVoid
		 */
		SPVoid draw_bottom_to_top_left();
		/**
		* @brief	Draw button UI top to right
		* @return    SPVoid
		 */
		SPVoid draw_bottom_to_top_right();
		/**
		* @brief	Draw button UI bottom to left
		* @return    SPVoid
		 */
		SPVoid draw_top_to_bottom_left();
		/**
		* @brief	Draw button UI top to bottom
		* @return    SPVoid
		 */
		SPVoid draw_top_to_bottom_right();


		std::vector <SP_BUTTON> m_vButtonItems;

		SPDrawRect* m_ButtonDraw;

		SPInt   m_ButtonStretchType;

		SPFloat m_buttonWidth;
		SPFloat m_buttonHeight;
		SPFloat m_halfButtonWidth;
		SPFloat m_halfButtonHeight;

		SPFloat m_ScreenWidth;
		SPFloat m_ScreenHeight;

		SPFloat m_LeftPosition;
		SPFloat m_BottomPosition;	

		SPFloat m_MagnifyRatio;

		SPInt   m_ButtonDisplayState;
		SPInt   m_CurrentButtonID;
		SPInt   m_MagnifyButtonID;
		SPFloat m_MagnifierMoveUpPos;
	};
}
#endif