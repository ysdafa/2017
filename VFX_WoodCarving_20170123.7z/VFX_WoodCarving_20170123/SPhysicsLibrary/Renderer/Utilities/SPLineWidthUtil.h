/**
* @file SPLineWidthUtil.h
* @brief This file includes module that manages Line's width 
*
* @date 2013-04-20
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/
#ifndef _SP_LINE_WIDTH_UTIL_H_
#define _SP_LINE_WIDTH_UTIL_H_

#include "SPDefines.h"
#include "SPMesh.h"
#include "SPConstant.h"
#include "SPTrigonometric.h"

#include <vector>
#include <glm.hpp>

namespace SPhysics
{
	/**
	* @class     SPLineWidthUtil
	* @brief     This module support function that modifies mesh's line width.
	*/
	template <typename T>
	class SPLineWidthUtil
	{
		/* Methods */
	public:
		/**
		* @brief     Constructor
		*/
		SPLineWidthUtil();
		
		/**
		* @brief     Destructor
		*/
		~SPLineWidthUtil();

		/**
		* @brief     Modifies lines width of mesh
		* @param     [IN] @b line_mesh Original mesh data which User wanted to change
		* @param     [IN] @b line_width Specifies line width which want to be changed
		* @param     [IN] @b screen_resolution Screen resolution value
		* @param     [IN] @b resolution Simulation resolution value		
		* @return     SPMesh Modifies Mesh data
		*/
		SPMesh get_line_modified_mesh(SPMesh& line_mesh, T line_width, SPVec2t screen_resolution, SPVec2t simulation_resolution );
		/**
		* @brief     Modifies line width with circle mesh
		*/
		SPMesh get_line_modified_circle_mesh( SPMesh& line_mesh, T line_width, SPVec2t screen_resolution, SPVec2t sim_resolution );
		/**
		* @brief     Make circle mesh
		*/
		std::vector<SPVec3t > makeCircleMesh( const T& r, const int& nSegs );
		/**
		* @brief     Modifies line width with mesh gradation
		*/
		SPMesh get_line_modified_mesh_gradation(SPMesh& line_mesh, T line_width_min, T line_width_max, SPVec2t screen_resolution, SPVec2t sim_resolution);
		/**
		* @brief     Modifies line width with ink test
		*/
		SPMesh get_line_modified_mesh_inktest(SPMesh& line_mesh, T line_width, SPVec2t screen_resolution, SPVec2t sim_resolution);
	protected:
	private:

		/* Member Variables */
	public:
	protected:
	private:
		SPFloat m_LineWidth;
		std::vector<SPVec3t > m_CircleMesh;
	};

}  //namespace SPhysics

#endif // _SP_LINE_WIDTH_UTIL_H_

