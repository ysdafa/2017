/**
* @file SPColorSpace.cpp
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/
#include "SPColorSpace.h"
#include "SPLog.h"
#include "SPComparison.h"

namespace SPhysics
{
	SPColorSpace::SPColorSpace()
	{
	}

	SPColorSpace::~SPColorSpace()
	{
	}

	SPVec3f SPColorSpace::rgb2hsb(const SPInt r, const SPInt g, const SPInt b)
	{  
		//assert 0 <= r && r <= 255;  
		//assert 0 <= g && g <= 255;  
		//assert 0 <= b && b <= 255;  

		SPInt min_of_rgb, max_of_rgb;
		minimumMaximum<SPInt>(r,g,b, min_of_rgb, max_of_rgb);

		SPFloat hsbB = max_of_rgb / 255.f;  
		SPFloat hsbS = max_of_rgb == 0 ? 0.f : (max_of_rgb-min_of_rgb)/(SPFloat)max_of_rgb;  
		SPFloat hsbH = 0.f;  

 		if(max_of_rgb == r && g >= b) 
		{  
 			hsbH = (g-b)*60.f / (max_of_rgb-min_of_rgb) + 0;  
 		} 
		else if(max_of_rgb == r && g < b) 
		{  
 			hsbH = (g-b)*60.f / (max_of_rgb-min_of_rgb) + 360;  
 		} 
		else if(max_of_rgb == g) 
		{  
 			hsbH = (b-r)*60.f / (max_of_rgb-min_of_rgb) + 120;  
 		} 
		else if(max_of_rgb == b) 
		{  
 			hsbH = (r-g)*60.f / (max_of_rgb-min_of_rgb) + 240;  
 		}  

		return SPVec3f( hsbH, hsbS, hsbB );  
	} 

	SPVec3f SPColorSpace::rgb2hsb(const SPVec3i& rgb) 
	{
		return rgb2hsb(rgb.r, rgb.g, rgb.b);
	}

	/**
	* @brief     HSB to RGB
	*/
	SPVec3i hsb2rgb(const SPFloat& h, const SPFloat& s, const SPFloat& v)
	{
// 		assert Float.compare(h, 0.0f) >= 0 && Float.compare(h, 360.0f) <= 0;  
// 		assert Float.compare(s, 0.0f) >= 0 && Float.compare(s, 1.0f) <= 0;  
// 		assert Float.compare(v, 0.0f) >= 0 && Float.compare(v, 1.0f) <= 0;  
		
		const SPInt i = SPInt( ((SPInt)h/60) % 6 );  
		SPFloat f = (h/60.f) - i;  
		SPFloat p = v * (1.f - s);  
		SPFloat q = v * (1.f - f*s);  
		SPFloat t = v * (1.f - (1.f-f)*s);  

		SPVec3i rgb;  

		switch(i) {  
			case 0:  
				rgb = SPVec3i( SPInt(v*255.f), SPInt(t*255.f), SPInt(p*255.f) );  
				break;  
			case 1:  
				rgb = SPVec3i( SPInt(q*255.f), SPInt(v*255.f), SPInt(p*255.f) );  
				break;  
			case 2:  
				rgb = SPVec3i( SPInt(p*255.f), SPInt(v*255.f), SPInt(t*255.f) );  
				break;  
			case 3:  
				rgb = SPVec3i( SPInt(p*255.f), SPInt(q*255.f), SPInt(v*255.f) );  
				break;  
			case 4:  
				rgb = SPVec3i( SPInt(t*255.f), SPInt(p*255.f), SPInt(v*255.f) );  
				break;  
			case 5:  
				rgb = SPVec3i( SPInt(v*255.f), SPInt(p*255.f), SPInt(q*255.f) );  
				break;  

			default:  
				break;  
		}  

		return rgb;  
	}  

	/**
	* @brief     HSB to RGB
	*/
	SPVec3i hsb2rgb(const SPVec3f& hsb)
	{
		return hsb2rgb(hsb.x, hsb.y, hsb.z);
	}

} // namespace SPhysics 

