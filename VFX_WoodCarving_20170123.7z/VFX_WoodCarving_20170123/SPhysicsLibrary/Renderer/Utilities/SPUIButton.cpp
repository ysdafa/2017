/**
* @file SPUIButton.cpp
* @brief 
*
* @date 2013-04-16
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPUIButton.h"

namespace SPhysics{
	SPUIButton::SPUIButton() 
	:m_pMesh(SPNULL), m_TextureId(-1), m_XPosition(0), m_YPosition(0), m_XSize(0), m_YSize(0), m_ButtonID(-1)
	{
	}


	SPUIButton::~SPUIButton()
	{
	}

	SPVoid SPUIButton::ButtonUI_init(SPFloat width, SPFloat height, SPInt cameraAlign){

		if(m_pMesh == SPNULL){ m_pMesh = new SPMesh; }
		ButtonUI_createVertex();
		ButtonUI_createTexture();
		ButtonUI_setBoundingBox(m_XPosition, m_YPosition, m_XPosition + m_XSize, m_YPosition + m_YSize);
		m_cDrawTriangle.initialize(width, height);
		m_cDrawTriangle.setMesh(m_pMesh);		
	}

	SPVoid SPUIButton::ButtonUI_createVertex(){
		//vertex
		SPVec3f tempVertex;
		tempVertex = SPVec3f(m_XPosition,				 m_YPosition,				 0.0f); m_pMesh->m_tVertex.push_back(tempVertex);
		tempVertex = SPVec3f(m_XPosition + m_XSize,	 m_YPosition,				 0.0f); m_pMesh->m_tVertex.push_back(tempVertex);
		tempVertex = SPVec3f(m_XPosition,				 m_YPosition + m_YSize,		 0.0f); m_pMesh->m_tVertex.push_back(tempVertex);
		
		tempVertex = SPVec3f(m_XPosition,				 m_YPosition + m_YSize,		 0.0f); m_pMesh->m_tVertex.push_back(tempVertex);
		tempVertex = SPVec3f(m_XPosition + m_XSize,	 m_YPosition,				 0.0f); m_pMesh->m_tVertex.push_back(tempVertex);
		tempVertex = SPVec3f(m_XPosition + m_XSize,	 m_YPosition + m_YSize,		 0.0f); m_pMesh->m_tVertex.push_back(tempVertex);
		
	}

	SPVoid SPUIButton::ButtonUI_createTexture(){
		SPVec3f textureUV;

		textureUV = SPVec3f(0.0f, 1.0f, 0.0f); m_pMesh->m_tTextureUV.push_back(textureUV);
		textureUV = SPVec3f(1.0f, 1.0f, 0.0f); m_pMesh->m_tTextureUV.push_back(textureUV);
		textureUV = SPVec3f(0.0f, 0.0f, 0.0f); m_pMesh->m_tTextureUV.push_back(textureUV);
		
		textureUV = SPVec3f(0.0f, 0.0f, 0.0f); m_pMesh->m_tTextureUV.push_back(textureUV);
		textureUV = SPVec3f(1.0f, 1.0f, 0.0f); m_pMesh->m_tTextureUV.push_back(textureUV);
		textureUV = SPVec3f(1.0f, 0.0f, 0.0f); m_pMesh->m_tTextureUV.push_back(textureUV);

	}

	SPVoid SPUIButton::ButtonUI_setTexture(const SPChar* _fileName){
		m_cDrawTriangle.setTexture(_fileName);
	}

	SPVoid SPUIButton::ButtonUI_setSize(SPUInt _XSize, SPUInt _YSize){
		m_YSize = _YSize;
		m_XSize = _XSize;
	}

	SPVoid SPUIButton::ButtonUI_update(){
	
	}
	SPVoid SPUIButton:: ButtonUI_draw(){
		m_cDrawTriangle.draw();
	}
	SPVoid SPUIButton::ButtonUI_destory(){
		SP_SAFE_DELETE(m_pMesh);
	}
}
