/**
* @file SPSceneManagerDrawing.cpp
* @brief 
*
* @date
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include <stdio.h> 
#include "SPLog.h"
#include "SPSceneManagerDrawing.h"
#include "SPFPS.h"
#include "SPRecodeVideoApp.h"
#include "SPWoodCarvingApp.h"


namespace SPhysics
{

	SPSceneManagerDrawing::SPSceneManagerDrawing() : m_pApp(SPNULL), m_pFPS(SPNULL), m_pRecordVideo(SPNULL)
	{

	}

	SPSceneManagerDrawing::~SPSceneManagerDrawing()
	{
		SP_SAFE_DELETE(m_pApp);
		SP_SAFE_DELETE(m_pFPS);
		SP_SAFE_DELETE(m_pRecordVideo);
		
		releaseSingletonInstance();
	}

	void SPSceneManagerDrawing::makeSceneLayer()
	{
#ifndef _WIN32
		SP_LOGI("SPSceneManagerDrawing %s", __func__);
#endif	
		
		
		m_pApp = new SPWoodCarvingApp();
		
		

		addSceneLayer(m_pApp);


		//enableFPSViewer();
		//enableRecordVideo();
	}

	void SPSceneManagerDrawing::makeSceneLayer(SPInt sceneType)
	{
/*
#ifndef _WIN32
		SP_LOGI("SPSceneManagerDrawing %s, %d", __func__, sceneType);
#endif	
		switch(sceneType)
		{
		case SP_DRAWING_SCENE_WOOD_CARVING:
			m_pApp = new SPWoodCarvingApp();
			break;

		case SP_DRAWING_SCENE_INK_PAINT:
			m_pApp = new SPInkPaintApp();
			break;

		case SP_DRAWING_SCENE_SAND_ART:
			//m_pApp = new SPSandArtApp();
			m_pApp = new SPSandArtApp();
			break;
		
		case SP_DRAWING_SCENE_CRAYON_SCRATCH:
			m_pApp = new SPScratchApp();
			break;

		default:
			SP_LOGE("Wrong scene type for Drawing (%d)", sceneType);
			return;
		}
		
		addSceneLayer(m_pApp);
*/

		//enableFPSViewer();
		//enableRecordVideo();
	}
// 
// 	SPVoid SPSceneManagerDrawing::setCurrentScene(int currentScene)
// 	{
// 		
// 	}

	SPVoid SPSceneManagerDrawing::enableFPSViewer()
	{
		if(m_pFPS == SPNULL)
			m_pFPS = new SPFPS();

		addSceneLayer(m_pFPS);
	}

	SPVoid SPSceneManagerDrawing::enableRecordVideo()
	{
		if(m_pRecordVideo == SPNULL)
			m_pRecordVideo = new SPRecodeVideoApp();

		addSceneLayer(m_pRecordVideo);
	}

} // namespace SPhysics 




