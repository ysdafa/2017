/**
* @file SPSceneManagerDrawing.h
* @brief This file includes the implementations that manage scene component
*
* @date
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/


#ifndef _SP_SCENEMANAGER_DRAWING_H_
#define _SP_SCENEMANAGER_DRAWING_H_


#include "SPISceneComponent.h"
#include "SPTextureManager.h"

namespace SPhysics
{
	/**
	* @class     SPSceneManagerDrawing
	* @brief     Scene manager
	*/
	class SPSceneManagerDrawing : public SPISceneComponent
	{
	public:
		typedef enum
		{
			SP_DRAWING_SCENE_WOOD_CARVING = 1,
			SP_DRAWING_SCENE_INK_PAINT,
			SP_DRAWING_SCENE_SAND_ART,
			SP_DRAWING_SCENE_CRAYON_SCRATCH,
		} SPDrawingSceneType;
	public:
		SPSceneManagerDrawing();
		~SPSceneManagerDrawing();

		/**
		* @brief     Run Application in child class of SPISceneComponent class
		* @return    SPVoid
		*/
		SPVoid makeSceneLayer();
		SPVoid makeSceneLayer(SPInt sceneType);

		//SPVoid setCurrentScene(int currentScene);

		// not support in CSeneManager class
		SPVoid initApp(SPInt width, SPInt height){};

		SPVoid updateApp(){};
		SPVoid drawApp(){};
		SPVoid onEventTouch(TOUCH_TYPE eventType, SPInt xPos, SPInt yPos){};
		SPVoid onEventMultiTouch(TOUCH_TYPE eventType, SPInt touchID, SPInt touchNum, SPInt *xPos, SPInt *yPos){};
		SPVoid onEventSensor(SENSOR_TYPE sensorType, SPFloat xValue, SPFloat yValue, SPFloat zValue){};

		SPVoid resetApp(){};
		SPVoid setForceApp(){};		


		/**
		* @brief     Release all of the singleton patter instance
		* @return    SPVoid
		*/
		SPVoid releaseSingletonInstance()
		{
			SPTextureManager::getInstancePtr()->ReleaseInstance();
		}

	private:
		SPVoid enableFPSViewer();
		SPVoid enableRecordVideo();

	private:
		SPISceneComponent *m_pApp;
		SPISceneComponent *m_pFPS;
		SPISceneComponent *m_pRecordVideo;

	};

}  //namespace SPhysics

#endif // _SP_SCENEMANAGER_DRAWING_H_
