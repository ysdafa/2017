/**
* @file SPDrawWood.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_DRAW_WOOD_H_
#define _SP_DRAW_WOOD_H_



#include "SPMesh.h"
#include "SPMVPManager.h"
#include "SPShaderManager.h"
#include "SPDefines.h"
#include "SPOBJLoader.h"
#include "SPLightProperty.h"


namespace SPhysics
{

	class SPDrawWood 
	{
	public:
		SPDrawWood(void);
		~SPDrawWood(void);

		SPVoid init(int width, int height);
		SPVoid draw();
		SPVoid setTexture(const SPChar* aFileName);
		SPVoid setTexture2(const SPChar* aFileName);
		SPVoid setNormalHeightMap(SPVoid* textureBuffer, SPUInt width, SPUInt height);
		SPVoid setMesh(SPMesh* aMesh);
		SPVoid setRenderMode(SPUInt aRenderMode);
		static SPLightProperty* getLight();
		SPVoid setModelMatrix(float* aMatrix);
		SPVoid setLookAt(float aEx, float aEy, float aEz, float aCx, float aCy, float aCz, float aUx, float aUy,float aUz);

		SPVoid setSketchTexture(SPUInt texture);

	private:
		SPVoid createSpherePhongShading();

		//light
    	static SPLightProperty* m_pLight;

		// pointer of Manager
		SPMVPManager*			m_pMVP;
		static SPShaderManager*		m_pShader;

		SPMesh* mMesh;

		GLuint m_TextureId;
		GLuint m_TextureId2;
		GLuint m_TextureId3;

		GLuint m_SketchTextureId;

		SPVoid* m_NormalHeightMapBuffer;
		SPUInt m_Width;
		SPUInt m_Height;

		SPUInt m_RenderMode;
	};

}//namespace SPhysics

#endif //_SP_DRAW_WOOD_H_