/**
* @file SPWoodCarvingGUI.h
* @brief This files is the implementation of Button UI Modules.
*
* @date 2014-03-08
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/
#ifndef _SP_WOODCARVING_GUI_H_
#define _SP_WOODCARVING_GUI_H_

#include "SPDefines.h"
#include "SPDrawRect.h"
#include "SPButton.h"

#include <vector>
#include <glm.hpp>


namespace SPhysics
{
	//! @brief option for texture wrap mode
	typedef enum _WOODCARVING_BTN_ID
	{
		TOOL_CURVED_L = 1,
		TOOL_CURVED_M,  
		TOOL_CURVED_S,  
		TOOL_FLAT_L,
		TOOL_FLAT_M,
		TOOL_FLAT_S,
		TOOL_SHARP_L,
		TOOL_SHARP_M,
		TOOL_SHARP_S,
		SKETCHES_TYPE1,
		SKETCHES_TYPE2,
		SKETCHES_TYPE3,
		SKETCHES_TYPE4,
		BG_TYPE1,
		BG_TYPE2,
		FADE_BTN,
		HOME_BTN,
		NEW_BTN,
		UNDO_BTN
	}WOODCARVING_BTN_ID;

	typedef std::vector<SPButton*> SPButtonArray;

	/**
	* @class     SPWoodCarvingGUI
	* @brief     This class is GUI for the WoodCarving
	 */
	class SPWoodCarvingGUI
	{
		typedef enum _GROUP_BTN_ID
		{
			BTN_GROUP_CURVED,
			BTN_GROUP_FLAT,  
			BTN_GROUP_SHARP,  
			BTN_GROUP_SKETCH,
			BTN_GROUP_BG,
			BTN_GROUP_CONTROL
		}GROUP_BTN_ID;

		struct BUTTON_GROUP
		{
			SPUInt groupID;
			SPFloat left;
			SPFloat right;
			SPFloat top;
			SPFloat bottom;
			SPButtonArray vButton;
		};

		typedef enum _TOOL_BAR_STATUS
		{
			TOOL_BAR_HIDE = 1,
			TOOL_BAR_SHOW,
			TOOL_BAR_FADE_IN,
			TOOL_BAR_FADE_OUT
		}TOOL_BAR_STATUS;

	public:
		SPWoodCarvingGUI();
		~SPWoodCarvingGUI();

		SPFloat SCALE(SPFloat value);
		SPVoid create(SPFloat width, SPFloat height);
		SPVoid draw();

		SPInt hitTest(SPFloat touchX, SPFloat touchY);

		SPVoid setUndoBtnDimStatus(SPBool dimFlag);

		SPBool isDrawableStatus(SPFloat touchX, SPFloat touchY);

	private:
		SPVoid createToolBar();
		SPVoid setGroupBoundary(BUTTON_GROUP* group, SPFloat left, SPFloat right, SPFloat top, SPFloat bottom);
		SPVoid addGroupButtonL(BUTTON_GROUP* group, SPUInt btnID, SPFloat btnSize, SPFloat centerPosX, SPFloat centerPosY);
		SPVoid addGroupButtonM(BUTTON_GROUP* group, SPUInt btnID, SPFloat btnSize, SPFloat centerPosX, SPFloat centerPosY);
		SPVoid addGroupButtonCtl(BUTTON_GROUP* group, SPUInt btnID, SPFloat btnSize, SPFloat centerPosX, SPFloat centerPosY);

		SPVoid clearGroupButton(BUTTON_GROUP* group);

		SPBool hitTestGroupButton(BUTTON_GROUP* group, SPFloat touchX, SPFloat touchY);

		SPVoid animateToolBar();

		SPVoid changeBTNFocusStatus(SPInt btnID);
		SPVoid changeBGBTNFocusStatus( SPInt btnID );
		SPVoid changeToolBTNFocusStatus( SPInt btnID );
		SPVoid changeSketchBTNFocusStatus( SPInt btnID );
	private:
		SPDrawRect*     m_pDrawFullBG;

		SPButton*       m_pFadeBTN;

		SPUInt			m_ScreenWidth;
		SPUInt			m_ScreenHeight;

		SPFloat         m_fScreenRation_W;
		SPFloat         m_fScreenRation_H;

		SPFloat			m_fToolbarWidth;
		SPFloat			m_fToolbarHeight;


		SPFloat			m_fAnimateRightPos;
		SPFloat         m_fMaxFadeDist;


		SPInt           m_fAnimateFCnt;


		SPUInt			m_nToolbarState;
		SPUInt          m_nToolCurrentFocusGroup;
		SPUInt          m_nToolNextFocusGroup;

		SPBool			m_bDimedUndoBtn;

		std::vector<BUTTON_GROUP*> m_vBtnGroup;
	};
}
#endif // _SP_WOODCARVING_GUI_H_