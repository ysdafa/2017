/**
* @file SPWoodCarvingApp.cpp
* @brief
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPWoodCarvingApp.h"
#include "SPTextureManager.h"
#include "SPOBJLoader.h"

namespace SPhysics
{



SPWoodCarvingApp::SPWoodCarvingApp() :
	mWood(NULL),
	mToolDepth(1.0f),
	mNormalMapBuffer(NULL),
	mNormalMapBuffer_Pre(SPNULL),
	m_NMbuffersize(0),
	m_pDrawBasicIcon(SPNULL),
	m_bUndoFlag(SPFALSE),
	m_bResetFlag(SPFALSE),
	m_bTouchDownOK(SPFALSE),
	m_bIsMove(SPFALSE),
	m_bIsGUIEventRun(SPFALSE),
	m_nGUIBtnID(-1),
	m_nSketchTextureID(0)
{
	m_nSketchTexHeight = 1;
	m_nScreenWidth = 1;
	m_nSketchTexWidth = 1;
	m_nDesignRatio = 1.0f;
	m_nScreenHeight = 1;
	m_nWoodCarvingSurfaceWidth = 1;
	m_nFrameCnt = 1;
	m_nWoodCarvingSurfaceHeight = 1;
	m_bUndoIconEnable = false;
}

SPWoodCarvingApp::~SPWoodCarvingApp()
{
	delete mWood;
	delete mNormalMapBuffer;
	delete mNormalMapBuffer_Pre;

	m_vTouchEvent.clear();

	SP_SAFE_DELETE(m_pDrawBasicIcon);
}

SPVoid SPWoodCarvingApp::initApp(SPInt width, SPInt height)
{
	ISourceControl* sourceCtrl;
	int nRet = TVServiceAPI::CreateSourceControl(PROFILE_TYPE_MAIN, 0, &sourceCtrl);

	ESource source = SOURCE_TYPE_HDMI1;
	if(sourceCtrl->SetSource(source, "NoAppId") > 0)
	{
		printf("~~~~SetTVSource to HDMI~~~~");
	}

	m_nScreenWidth = width;
	m_nScreenHeight = height;

	
	m_nFrameCnt = 0;

	// limite the surface size of the wood carving
	m_nWoodCarvingSurfaceWidth = (SPUInt)(width * 0.7f);
	m_nWoodCarvingSurfaceHeight = (SPUInt)(height * 0.7f);
//  	m_nWoodCarvingSurfaceWidth = 1792;
//  	m_nWoodCarvingSurfaceHeight = 1120;

// 	m_nWoodCarvingSurfaceWidth = 2560;
// 	m_nWoodCarvingSurfaceHeight = 1600;


	m_nDesignRatio = (SPFloat)m_nWoodCarvingSurfaceWidth / width;

	// Normalmap Buffer
	m_NMbuffersize = m_nWoodCarvingSurfaceWidth * m_nWoodCarvingSurfaceHeight * 4;

	mNormalMapBuffer = new SPChar[m_NMbuffersize];
	mNormalMapBuffer_Pre = new SPChar[m_NMbuffersize];

	m_vTouchEvent.clear();

	mSurfaceMesh.m_tVertex.resize(4);
	mSurfaceMesh.m_tNormal.resize(4);
	mSurfaceMesh.m_tTextureUV.resize(4);

	SPFloat ratio = SPFloat(width) / SPFloat(height);
	SPFloat mult = 10.0f * 0.4142f;
	SPFloat x = -mult * ratio;
	SPFloat y = -mult;
	SPFloat z = 0.0f;
	SPFloat swidth = mult * 2.0f * ratio;
	SPFloat sheight = mult * 2.0f;
	SPFloat textureStartX = 0.0f;
	SPFloat textureStartY = 0.0f;
	SPFloat textureEndX = 1.0f;
	SPFloat textureEndY = 1.0f;

	mSurfaceMesh.m_tVertex[0] = SPVec3f(x, y, z);
	mSurfaceMesh.m_tVertex[1] = SPVec3f(x + swidth, y, z);
	mSurfaceMesh.m_tVertex[2] = SPVec3f(x, y + sheight, z);
	mSurfaceMesh.m_tVertex[3] = SPVec3f(x + swidth, y + sheight, z);

	mSurfaceMesh.m_tNormal[0] = SPVec3f(0, 0, 1);
	mSurfaceMesh.m_tNormal[1] = SPVec3f(0, 0, 1);
	mSurfaceMesh.m_tNormal[2] = SPVec3f(0, 0, 1);
	mSurfaceMesh.m_tNormal[3] = SPVec3f(0, 0, 1);

	mSurfaceMesh.m_tTextureUV[0] = SPVec3f(textureStartX, textureStartY, 0);
	mSurfaceMesh.m_tTextureUV[1] = SPVec3f(textureEndX, textureStartY, 0);
	mSurfaceMesh.m_tTextureUV[2] = SPVec3f(textureStartX, textureEndY, 0);
	mSurfaceMesh.m_tTextureUV[3] = SPVec3f(textureEndX, textureEndY, 0);

	
	mShavingDrawer.init(width, height);
	mShavingDrawer.setRenderMode(GL_TRIANGLE_STRIP);
	mShavingDrawer.setLookAt(0,0,10,0,0,0,0,1,0);
	mShavingDrawer.setMesh(&mShavingMesh);

	// create dummy texture
	m_nSketchTexWidth = 1024;
	m_nSketchTexHeight = 640;
	
	SPUChar* ImgData = new SPUChar[m_nSketchTexWidth * m_nSketchTexHeight * 3];
	memset(ImgData, 0x0, sizeof(SPUChar) * m_nSketchTexWidth * m_nSketchTexHeight * 3);
	m_nSketchTextureID = SPTextureManager::getInstancePtr()->setTexture("dummyTexture", ImgData, m_nSketchTexWidth, m_nSketchTexHeight);

	//m_nSketchTextureID = SPTextureManager::getInstancePtr()->setTexture("dummyTexture", SPNULL, m_nSketchTexWidth, m_nSketchTexHeight);

	mSurfaceDrawer.init(width, height);
	mSurfaceDrawer.setRenderMode(GL_TRIANGLE_STRIP);
	mSurfaceDrawer.setTexture("Res/woodcarving/wood_0.png");
	mSurfaceDrawer.setTexture2("Res/woodcarving/woodcarved_0.png");
	mSurfaceDrawer.setNormalHeightMap(mNormalMapBuffer, m_nWoodCarvingSurfaceWidth, m_nWoodCarvingSurfaceHeight);
	mSurfaceDrawer.setLookAt(0,0,10,0,0,0,0,1,0);
	mSurfaceDrawer.setMesh(&mSurfaceMesh);
	mSurfaceDrawer.setSketchTexture(m_nSketchTextureID);

// 	mSurfaceDrawer.getLight()->setLightAmbientColor(0.4,0.4,0.4,0.4);
// 	mSurfaceDrawer.getLight()->setLightDiffuseColor(0.7,0.7,0.7,0.7);
	//mSurfaceDrawer.getLight()->setLightPosition(-255,144,164);

	mSurfaceDrawer.getLight()->setLightAmbientColor(0.7,0.7,0.7,0.7);
	mSurfaceDrawer.getLight()->setLightDiffuseColor(1.0,1.0,1.0,1.0);
	mSurfaceDrawer.getLight()->setLightPosition(-255,144,164);
	//mSurfaceDrawer.getLight()->setLightPosition(-5,144,164);
	 
	//mWood = new Physics::WoodCarving::SPWood(width, height, (glm::cvec4*) (mNormalMapBuffer), 60, 50.0f, mult, ratio, 0.001f * mult, 3.0f * mult);
	
	mWood = new SPWood(m_nWoodCarvingSurfaceWidth, m_nWoodCarvingSurfaceHeight, (glm::cvec4*) (mNormalMapBuffer), SCALE(45), 50.0f, mult, ratio, 0.001f * mult, 3.0f * mult);
	mWood->setToolType(1);
	mToolDepth = 0.85f;
	mWood->setToolSize(SCALE(45), SPWoodTool::Elipse);
	
	m_WoodCarvingGUI.create(width, height);

	m_stWoodImgName = "Res/woodcarving/wood_0.png";
	m_stCarvingImgName = "Res/woodcarving/woodcarved_0.png";

}

SPVoid SPWoodCarvingApp::updateApp()
{
	if(m_nFrameCnt < 5)
	{
		m_nFrameCnt++;
		// on second draw frame, prepare the necessary texture
		if(m_nFrameCnt == 2)
		{
			SPTextureManager::getInstancePtr()->loadTexture("Res/woodcarving/wood_1.png");
			SPTextureManager::getInstancePtr()->loadTexture("Res/woodcarving/woodcarved_1.png");
		}
		
	}
	if(m_bIsGUIEventRun == SPTRUE)
	{
		GUIEventHandler();
		m_bIsGUIEventRun = SPFALSE;
	}

	updateTouchEvent();


	mWood->step();
}

SPVoid SPWoodCarvingApp::drawApp()
{
	glClear(GL_COLOR_BUFFER_BIT);
	mSurfaceDrawer.draw();

	for (auto shaving = mWood->getShavings().begin(), end = mWood->getShavings().end();
		shaving != end; shaving++)
	{
		SPUInt size = shaving->mShavingObjects[0].getVertexCount();
		if(size != 0)
		{
			mShavingMesh.m_tVertex.resize(size);
			mShavingMesh.m_tNormal.resize(size);
			mShavingMesh.m_tTextureUV.resize(size);

			for(SPUInt i=0;i<size;i++)
			{
				mShavingMesh.m_tVertex[i] = *((SPVec3f*)&shaving->mShavingObjects[0].getPositions3D()[i]);
				mShavingMesh.m_tNormal[i] = *((SPVec3f*)&shaving->mShavingObjects[0].getNormals()[i]);
				mShavingMesh.m_tTextureUV[i].x = shaving->mShavingObjects[0].getTextureCoords()[i].x;
				mShavingMesh.m_tTextureUV[i].y = shaving->mShavingObjects[0].getTextureCoords()[i].y;
			}

			//mShavingDrawer.setTexture("Res/woodcarving/wood_1.png");
			mShavingDrawer.setTexture(m_stWoodImgName.c_str());
			mShavingDrawer.setModelMatrix((SPFloat*)&shaving->mShavingObjects[0].mModelMatrix);
			mShavingDrawer.draw();

			for(SPUInt i=0;i<size;i++)
			{
				mShavingMesh.m_tVertex[i] = *((SPVec3f*)&shaving->mShavingObjects[1].getPositions3D()[i]);
				mShavingMesh.m_tNormal[i] = *((SPVec3f*)&shaving->mShavingObjects[1].getNormals()[i]);
				mShavingMesh.m_tTextureUV[i].x = shaving->mShavingObjects[1].getTextureCoords()[i].x;
				mShavingMesh.m_tTextureUV[i].y = shaving->mShavingObjects[1].getTextureCoords()[i].y;
			}

			//mShavingDrawer.setTexture("Res/woodcarving/woodcarved_1.png");
			mShavingDrawer.setTexture(m_stCarvingImgName.c_str());
			mShavingDrawer.setModelMatrix((SPFloat*)&shaving->mShavingObjects[1].mModelMatrix);
			mShavingDrawer.draw();
		}
	}

	// draw the GUI
	m_WoodCarvingGUI.draw();
}

SPVoid SPWoodCarvingApp::onEventTouch(TOUCH_TYPE eventType, SPInt xPos, SPInt yPos)
{

	SPFloat x = SPFloat(xPos) / SPFloat(m_nScreenWidth);
	SPFloat y = SPFloat(yPos) / SPFloat(m_nScreenHeight);

	SPVec3f data;

	switch(eventType)
	{
	case TOUCH_DOWN:
		{
			SPInt btnID = m_WoodCarvingGUI.hitTest(xPos, yPos);
			if(btnID > 0)
			{
				m_bIsGUIEventRun = SPTRUE;
				m_nGUIBtnID = btnID;
			}else
			{
				if(m_WoodCarvingGUI.isDrawableStatus(xPos, yPos))
				{
					data = SPVec3f(0.0f, x, y);
					m_vTouchEvent.push_back(data);
					m_bTouchDownOK = SPTRUE;
				}
			}
		}
		
		break;
	case TOUCH_UP:
		if(m_bTouchDownOK == SPTRUE)
		{
			data = SPVec3f(2.0f, 0.0f, 0.0f);
			m_vTouchEvent.push_back(data);

			m_bTouchDownOK = SPFALSE;
		}
		break;
	case TOUCH_MOVE:
		if(m_bTouchDownOK == SPTRUE)
		{
			data = SPVec3f(1.0f, x, y);
			m_vTouchEvent.push_back(data);
		}
		break;
	default:
		break;
	}

#if 0
	static SPBool isMove = false;

	SPFloat x = SPFloat(xPos) / SPFloat(m_nScreenWidth);
	SPFloat y = SPFloat(yPos) / SPFloat(m_nScreenHeight);

	SPFloat aX_clamped = glm::clamp(x, 0.f, 1.0f);
	SPFloat aY_clamped = glm::clamp(y, 0.f, 1.0f);
	SPUInt _x = (SPUInt) (aX_clamped * m_nScreenWidth);
	SPUInt _y = (SPUInt) (aY_clamped * m_nScreenHeight);

	switch(eventType)
	{
	case TOUCH_DOWN:

		savePrevousStatus();

		isMove = true;
		mWood->setToolPosition(glm::uvec2(_x, _y));

		if (x >= 0.99f || x <= 0.01f || y >= 0.99f || y <= 0.01f)
		{
			mWood->upTool();
			mWood->setToolPosition(glm::uvec2(x, y));
		}
		break;
	case TOUCH_UP:
		isMove = false;
		mWood->upTool();
		break;
	case TOUCH_MOVE:
		if(isMove)
		{
			mWood->moveToolPosition(glm::uvec2(_x, _y), mToolDepth);

			if (x >= 0.99f || x <= 0.01f || y >= 0.99f || y <= 0.01f)
			{
				mWood->upTool();
				mWood->setToolPosition(glm::uvec2(x, y));
			}
			break;
		}
	}
#endif
}

SPVoid SPWoodCarvingApp::onEventSensor(SENSOR_TYPE sensorType, SPFloat xValue, SPFloat yValue, SPFloat zValue)
{
}


SPVoid SPWoodCarvingApp::onEventCustom(SPInt customID, SPFloat customValue)
{
	enum CustomEventType{
		ToolSize,
		ClearButton
	};

//	SP_LOGE("JOOOON onEventCustom %d", customID);

	switch(customID)
	{
	case ToolSize: 
		mWood->setToolSize((SPUInt)customValue);
		//SP_LOGE("JOOOON ToolSize = %f", customValue);
		break;
	}
}

SPInt xPos_Demo_wood = 200;
SPInt yPos_Demo_wood = 800;
int   cnt_Demo_wood = 0;

SPVoid SPWoodCarvingApp::onEventKey(KEY_TYPE keyID)
{
	switch((int)keyID)
	{
	/*case (int)'c':
		m_bResetFlag = SPTRUE;
		break;
	case (int)'u':
		m_bUndoFlag = SPTRUE;
		break;
	case (int)KEY_TYPE_VOLUME_UP:
		m_bUndoFlag = SPTRUE;
		break;*/

	case 10:
		{ 
			onEventTouch(TOUCH_DOWN, xPos_Demo_wood, yPos_Demo_wood - cnt_Demo_wood*200);

			for(int i=0;i<1000;i=i+100)
			{
				int j = i%200;
				//printf("j= %d ", j);
				if(j==0) j=100;
				else if(j==100)j=-100;
				onEventTouch(TOUCH_MOVE, xPos_Demo_wood+i, yPos_Demo_wood+j - cnt_Demo_wood*200);
			}

			onEventTouch(TOUCH_UP, xPos_Demo_wood, yPos_Demo_wood - cnt_Demo_wood*200);

			cnt_Demo_wood++;
			if(cnt_Demo_wood>=4) 
			{	
				cnt_Demo_wood=0;
				xPos_Demo_wood = 1200;
			}
		}break;
	}

}

SPVoid SPWoodCarvingApp::resetApp()
{
}

SPVoid SPWoodCarvingApp::setForceApp()
{
}

// SPVoid SPWoodCarvingApp::setToolSize(const SPUInt toolSize)
// {
// 	mWood->setToolSize(toolSize);
// }

SPVoid SPWoodCarvingApp::setToolDepth(const SPFloat depth)
{
	mToolDepth = depth;
}

SPVoid SPWoodCarvingApp::reset()
{
	mWood->reset();
	resetSketchPattern();
	memset(mNormalMapBuffer_Pre, 0x0, sizeof(SPChar) * m_NMbuffersize);
	m_bUndoIconEnable = SPFALSE;
	m_WoodCarvingGUI.setUndoBtnDimStatus(SPTRUE);
}

SPVoid SPWoodCarvingApp::savePreviousStatus()
{
	memcpy(mNormalMapBuffer_Pre, mNormalMapBuffer, sizeof(SPChar) * m_NMbuffersize);

	m_bUndoIconEnable = SPTRUE;
	m_WoodCarvingGUI.setUndoBtnDimStatus(SPFALSE);
}

SPVoid SPWoodCarvingApp::resetPreviousStatus()
{
	mWood->reset();
	memset(mNormalMapBuffer_Pre, 0x0, sizeof(SPChar) * m_NMbuffersize);
	m_bUndoIconEnable = SPFALSE;
	m_WoodCarvingGUI.setUndoBtnDimStatus(SPTRUE);
}

SPVoid SPWoodCarvingApp::runUndo()
{
	if(m_bUndoIconEnable == SPTRUE)
	{
		memcpy(mNormalMapBuffer, mNormalMapBuffer_Pre, sizeof(SPChar) * m_NMbuffersize);
		m_bUndoIconEnable = SPFALSE;
		m_WoodCarvingGUI.setUndoBtnDimStatus(SPTRUE);
	}
}

SPVoid SPWoodCarvingApp::updateTouchEvent()
{
	if(m_vTouchEvent.size() == 0)
		return;

	for (SPInt i = 0; i < (SPInt)m_vTouchEvent.size(); i++)
	{
		if(m_vTouchEvent[i].x == 0.0f)  // Mouse Down event
		{
			runTouchDownEvent(m_vTouchEvent[i].y, m_vTouchEvent[i].z);
		}
		else if(m_vTouchEvent[i].x == 1.0f)  // Mouse Move event
		{
			runTouchMoveEvent(m_vTouchEvent[i].y, m_vTouchEvent[i].z);
		}
		else if(m_vTouchEvent[i].x == 2.0f)  // // Mouse Up event
		{
			runTouchUpEvent();
		}
	}

	m_vTouchEvent.clear();
}

SPVoid SPWoodCarvingApp::runTouchDownEvent(SPFloat x, SPFloat y)
{
	SPFloat aX_clamped = glm::clamp(x, 0.f, 1.0f);
	SPFloat aY_clamped = glm::clamp(y, 0.f, 1.0f);
	SPUInt _x = (SPUInt) (aX_clamped * m_nScreenWidth);
	SPUInt _y = (SPUInt) (aY_clamped * m_nScreenHeight);


	savePreviousStatus();

	m_bIsMove = SPTRUE;

	SPFloat scaleX = SCALE(_x);
	SPFloat scaleY = SCALE(_y);

	//mWood->setToolPosition(glm::uvec2(_x, _y));
	mWood->setToolPosition(glm::uvec2(scaleX, scaleY));

	if (x >= 0.99f || x <= 0.01f || y >= 0.99f || y <= 0.01f)
	{
		mWood->upTool();
		mWood->setToolPosition(glm::uvec2(x, y));
	}
}

SPVoid SPWoodCarvingApp::runTouchMoveEvent(SPFloat x, SPFloat y)
{
	SPFloat aX_clamped = glm::clamp(x, 0.f, 1.0f);
	SPFloat aY_clamped = glm::clamp(y, 0.f, 1.0f);
	SPUInt _x = (SPUInt) (aX_clamped * m_nScreenWidth);
	SPUInt _y = (SPUInt) (aY_clamped * m_nScreenHeight);

	SPFloat scaleX = SCALE(_x);
	SPFloat scaleY = SCALE(_y);

	if(m_bIsMove)
	{
		//mWood->moveToolPosition(glm::uvec2(_x, _y), mToolDepth);
		mWood->moveToolPosition(glm::uvec2(scaleX, scaleY), mToolDepth);

		if (x >= 0.99f || x <= 0.01f || y >= 0.99f || y <= 0.01f)
		{
			mWood->upTool();
			mWood->setToolPosition(glm::uvec2(x, y));
		}
	}
}

SPVoid SPWoodCarvingApp::runTouchUpEvent()
{
	m_bIsMove = SPFALSE;
	mWood->upTool();
}

SPVoid SPWoodCarvingApp::setSketchPattern()
{
	TEXTURE_COLOR_BUFFER* colorBuff = SPNULL;
	switch(m_nGUIBtnID)
	{
	case SKETCHES_TYPE1:
		{
			colorBuff = SPTextureManager::getInstancePtr()->loadTextureColor("Res/woodcarving/sketches_a.png");
		}
		break;
	case SKETCHES_TYPE2:
		{
			colorBuff = SPTextureManager::getInstancePtr()->loadTextureColor("Res/woodcarving/sketches_b.png");
		}
		break;
	case SKETCHES_TYPE3:
		{
			colorBuff = SPTextureManager::getInstancePtr()->loadTextureColor("Res/woodcarving/sketches_c.png");
		}
		break;
	case SKETCHES_TYPE4:
		{
			colorBuff = SPTextureManager::getInstancePtr()->loadTextureColor("Res/woodcarving/sketches_d.png");
		}
		break;
	}

	if(colorBuff == SPNULL)
	{
		SP_LOGE("can't load the sketch pattern image");
		return;
	}

	SPTextureManager::getInstancePtr()->replaceTextureData(m_nSketchTextureID, &colorBuff->ImgData[0], m_nSketchTexWidth, m_nSketchTexHeight);

// 	delete[] colorBuff->ImgData;
// 	delete colorBuff;
// 	colorBuff = SPNUL
	resetPreviousStatus();
}

SPhysics::SPVoid SPWoodCarvingApp::resetSketchPattern()
{
	SPUChar* tempBuff = new SPUChar[m_nSketchTexWidth * m_nSketchTexHeight * 4];
	memset(tempBuff, 0x0, sizeof(SPUChar) * m_nSketchTexWidth * m_nSketchTexHeight * 4);

	SPTextureManager::getInstancePtr()->replaceTextureData(m_nSketchTextureID, &tempBuff[0], m_nSketchTexWidth, m_nSketchTexHeight);

	delete [] tempBuff;
}

SPVoid SPWoodCarvingApp::changeTooltoCurved()
 {
// 		case TOOL_CURVED_L:
// 		case TOOL_CURVED_M:
// 		case TOOL_CURVED_S: 

	 mWood->setToolType(1);
	 switch(m_nGUIBtnID)
	 {
	 case TOOL_CURVED_L:
		 {
			 mWood->setToolSize((SPUInt)SCALE(60), SPWoodTool::Elipse);
			 mToolDepth = 1.0f;
		 }
		 break;
	 case TOOL_CURVED_M:
		 {
			 mWood->setToolSize((SPUInt)SCALE(45), SPWoodTool::Elipse);
			 mToolDepth = 0.85f;
		 }
		 break;
	 case TOOL_CURVED_S:
		 {
			 mWood->setToolSize((SPUInt)SCALE(30), SPWoodTool::Elipse);
			 mToolDepth = 0.7f;
		 }
		 break;
	 }
}

SPVoid SPWoodCarvingApp::changeTooltoFlat()
{
// 		case TOOL_FLAT_L:
// 		case TOOL_FLAT_M:
// 		case TOOL_FLAT_

	mWood->setToolType(2);
	switch(m_nGUIBtnID)
	{
	case TOOL_FLAT_L:
		{
			//mWood->setToolSize((SPUInt)SCALE(140), SPWoodTool::Elipse);
			mWood->setToolSize((SPUInt)SCALE(140), SPWoodTool::Cone, 0.55f);
			mToolDepth = 0.7f;
		}
		break;
	case TOOL_FLAT_M:
		{
			//mWood->setToolSize((SPUInt)SCALE(110), SPWoodTool::Elipse);
			mWood->setToolSize((SPUInt)SCALE(110), SPWoodTool::Cone, 0.55f);
			mToolDepth = 0.55f;
		}
		break;
	case TOOL_FLAT_S:
		{
			//mWood->setToolSize((SPUInt)SCALE(80), SPWoodTool::Elipse);
			mWood->setToolSize((SPUInt)SCALE(80), SPWoodTool::Cone, 0.55f);
			mToolDepth = 0.4f;
		}
		break;
	}
}

SPVoid SPWoodCarvingApp::changeTooltoSharp()
{
// 	case TOOL_SHARP_L:
// 	case TOOL_SHARP_M:
// 	case TOOL_SHARP_	switch(m_nGUIBtnID)
	mWood->setToolType(3);
	switch(m_nGUIBtnID)
	{
	case TOOL_SHARP_L:
		{
			mWood->setToolSize((SPUInt)SCALE(80), SPWoodTool::Cone);
			mToolDepth = 0.9f;
		}
		break;
	case TOOL_SHARP_M:
		{
			mWood->setToolSize((SPUInt)SCALE(60), SPWoodTool::Cone);
			mToolDepth = 0.75f;
		}
		break;
	case TOOL_SHARP_S:
		{
			mWood->setToolSize((SPUInt)SCALE(30), SPWoodTool::Cone);
			mToolDepth = 0.6f;
		}
		break;
	}
}


SPVoid SPWoodCarvingApp::changeBG()
{

	switch(m_nGUIBtnID)
	{
		case BG_TYPE1:
			{
				mSurfaceDrawer.setTexture("Res/woodcarving/wood_0.png");
				mSurfaceDrawer.setTexture2("Res/woodcarving/woodcarved_0.png");

				m_stWoodImgName = "Res/woodcarving/wood_0.png";
				m_stCarvingImgName = "Res/woodcarving/woodcarved_0.png";
			}
			break;
		case BG_TYPE2:
			{
				mSurfaceDrawer.setTexture("Res/woodcarving/wood_1.png");
				mSurfaceDrawer.setTexture2("Res/woodcarving/woodcarved_1.png");

				m_stWoodImgName = "Res/woodcarving/wood_1.png";
				m_stCarvingImgName = "Res/woodcarving/woodcarved_1.png";
			}
			break;
	}

	resetPreviousStatus();
}

SPVoid SPWoodCarvingApp::GUIEventHandler()
{
	switch(m_nGUIBtnID)
	{
	case TOOL_CURVED_L:
	case TOOL_CURVED_M:
	case TOOL_CURVED_S: 
		{
			changeTooltoCurved();
		}
		break;
	case TOOL_FLAT_L:
	case TOOL_FLAT_M:
	case TOOL_FLAT_S:
		{
			changeTooltoFlat();
		}
		break;
	case TOOL_SHARP_L:
	case TOOL_SHARP_M:
	case TOOL_SHARP_S:
		{
			changeTooltoSharp();
		}
		break;
	case SKETCHES_TYPE1:
	case SKETCHES_TYPE2:
	case SKETCHES_TYPE3:
	case SKETCHES_TYPE4:
		{
			setSketchPattern();
		}
		break;
	case BG_TYPE1:
	case BG_TYPE2:
		{
			changeBG();
		}
		break;
	case NEW_BTN:
		{
			reset();
		}
		break;
	case UNDO_BTN:
		{
			runUndo();
		}
		break;
	case HOME_BTN:
		{
			//print3DMesh();
		}
		break;
	}


	m_nGUIBtnID = -1;
	m_bIsGUIEventRun = SPFALSE;
}

SPFloat SPWoodCarvingApp::SCALE( SPFloat value )
{
	return value * m_nDesignRatio;
}

SPVoid SPWoodCarvingApp::print3DMesh()
{
	SPFloat yPos = 0.0f;
	SPFloat xPos = 0.0f;
	SPFloat zPos = 0.0f;
	SPFloat yStep = (SPFloat)10.0f / m_nWoodCarvingSurfaceHeight;
	SPFloat xStep = (SPFloat)16.0f / m_nWoodCarvingSurfaceWidth;

	SPUInt p1_idx = 1;
	SPUInt p2_idx = 2;
	SPUInt p3_idx = 3;
	SPUInt p4_idx = 4;

	for(int yIdx = 0; yIdx < (int)m_nWoodCarvingSurfaceHeight; yIdx++)
	{
		for(int xIdx = 0; xIdx < (int)m_nWoodCarvingSurfaceWidth; xIdx++)
		{
			SPInt mapIdx = (yIdx * m_nWoodCarvingSurfaceWidth + xIdx) * 4;
			SPVec3f point;

			xPos = (SPFloat)xIdx * xStep;
			yPos = (SPFloat)yIdx * yStep;
			zPos = 0.0f;
			if(mNormalMapBuffer[mapIdx + 3] != 0)
			{
				zPos = (SPFloat)(mNormalMapBuffer[mapIdx + 3] - 255) / 255.0f;

				zPos *= 0.1f;
			}

			point = SPVec3f(xPos, yPos, zPos);
			//point = SPVec3f(xPos, yPos, 0.0f);

			m3DPrintMesh.m_tVertex.push_back(point);

// 			SPVec3f normal;
// 			if(mNormalMapBuffer[mapIdx + 3] == 0)
// 			{
// 				normal.setZero();
// 			}else
// 			{
// 				normal.x = (SPFloat)mNormalMapBuffer[mapIdx + 0] / 127.5;
// 				normal.y = (SPFloat)mNormalMapBuffer[mapIdx + 1] / 127.5;
// 				normal.z = (SPFloat)mNormalMapBuffer[mapIdx + 2] / 127.5;
// // 
// 				normal.x -= 1.0f;
// 				normal.y -= 1.0f;
// 				normal.z -= 1.0f;
// 			}
// 			
// 			m3DPrintMesh.m_tNormal.push_back(normal);

			/*             
			*              p2              p3
			*              * -------------- *
			*              |                |
			*			   |                |
			*              *----------------*
			*              p1              p4
			*/

			if(yIdx >= 1 && xIdx < (int)m_nWoodCarvingSurfaceWidth - 1)
			{
				p1_idx = yIdx * m_nWoodCarvingSurfaceWidth + xIdx + 1;
				p2_idx = (yIdx - 1) * m_nWoodCarvingSurfaceWidth + xIdx + 1;
				p3_idx = (yIdx - 1) * m_nWoodCarvingSurfaceWidth + xIdx + 2;
				p4_idx = yIdx * m_nWoodCarvingSurfaceWidth + xIdx + 2;

				// generate the face index
				m3DPrintMesh.m_tVertexIndex16.push_back(p1_idx);
				m3DPrintMesh.m_tVertexIndex16.push_back(p4_idx);
				m3DPrintMesh.m_tVertexIndex16.push_back(p2_idx);
				m3DPrintMesh.m_tVertexIndex16.push_back(p4_idx);
				m3DPrintMesh.m_tVertexIndex16.push_back(p3_idx);
				m3DPrintMesh.m_tVertexIndex16.push_back(p2_idx);
			}
		}
	}


	SPOBJLoader objExporter;

	objExporter.setExportMesh(&m3DPrintMesh);
	objExporter.exportObjMesh("woodcarving3d.obj");

	//SPInt pointerNum = m3DPrintMesh.m_tVertex.size();
	//SPInt IndexNum = m3DPrintMesh.m_tVertexIndex.size();


	//SPInt joon = 100;

	m3DPrintMesh.reset();

}

}    //namespace SPhysics
