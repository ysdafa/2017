/**
* @file SPWoodCarvingApp.h
* @brief
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_WOOD_CARVING_APP_H_
#define _SP_WOOD_CARVING_APP_H_

#include "SPISceneComponent.h"
#include "SPDrawWoodCarving.h"
#include "SPDrawWood.h"
#include "SPWood.h"
#include "SPDrawRect.h"
#include "SPWoodCarvingGUI.h"

#include "ISourceControl.h"
#include "TVServiceAPI.h"


namespace SPhysics
{
	class SPWoodCarvingApp: public SPISceneComponent
	{
	public:
		SPWoodCarvingApp();
		~SPWoodCarvingApp();

	public:
		SPVoid initApp(SPInt width, SPInt height);
		SPVoid updateApp();
		SPVoid drawApp();
		SPVoid onEventKey(KEY_TYPE keyID);
		SPVoid onEventTouch(TOUCH_TYPE eventType, SPInt xPos, SPInt yPos);
		SPVoid onEventMultiTouch(TOUCH_TYPE eventType, SPInt touchID, SPInt touchNum, SPInt *xPos, SPInt *yPos){};
		SPVoid onEventSensor(SENSOR_TYPE sensorType, SPFloat xValue, SPFloat yValue, SPFloat zValue);
		SPVoid onEventCustom(SPInt customID, SPFloat customValue);
		SPVoid resetApp();
		SPVoid setForceApp();

		//SPVoid setToolSize(const SPUInt toolSize);
		SPVoid setToolDepth(const SPFloat depth);
		SPVoid reset();
		

	private:
		SPVoid savePreviousStatus();
		SPVoid resetPreviousStatus();
		SPVoid runUndo();
		SPVoid updateTouchEvent();
		SPVoid runTouchDownEvent(SPFloat x, SPFloat y);
		SPVoid runTouchMoveEvent(SPFloat x, SPFloat y);
		SPVoid runTouchUpEvent();

		SPVoid setSketchPattern();
		SPVoid resetSketchPattern();
		SPVoid changeTooltoCurved();
		SPVoid changeTooltoFlat();
		SPVoid changeTooltoSharp();
		SPVoid changeBG();

		SPVoid GUIEventHandler();

		SPFloat SCALE(SPFloat value);

		SPVoid print3DMesh();

	private:
		SPWoodCarvingGUI  m_WoodCarvingGUI;
		SPDrawWoodCarving mShavingDrawer;
		SPDrawWood mSurfaceDrawer;
		SPWood* mWood;
		SPFloat mToolDepth;

		SPChar* mNormalMapBuffer;
		SPChar* mNormalMapBuffer_Pre;
		SPInt   m_NMbuffersize;

		SPMesh mShavingMesh;
		SPMesh mSurfaceMesh;
		SPMesh m3DPrintMesh;

		SPDrawRect *m_pDrawBasicIcon;


		SPBool m_bUndoIconEnable;
		SPBool m_bUndoFlag;
		SPBool m_bResetFlag;

		SPBool m_bTouchDownOK;

		std::vector<SPVec3f > m_vTouchEvent;
		SPBool m_bIsMove;

		SPInt m_nScreenWidth;
		SPInt m_nScreenHeight;

		SPBool m_bIsGUIEventRun;
		SPInt m_nGUIBtnID;

		SPInt m_nFrameCnt;

		SPUInt m_nSketchTextureID;
		SPUInt m_nSketchTexWidth;
		SPUInt m_nSketchTexHeight;

		SPUInt m_nWoodCarvingSurfaceWidth;
		SPUInt m_nWoodCarvingSurfaceHeight;

		SPFloat m_nDesignRatio;

		std::string m_stWoodImgName;
		std::string m_stCarvingImgName;
	};

}    //namespace SPhysics

#endif //_SP_WOOD_CARVING_APP_H_
