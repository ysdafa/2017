/**
* @file SPWoodCarvingGUI.cpp
* @brief 
*
* @date 2014-0308-
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include <stdlib.h>

#include "SPWoodCarvingGUI.h"
#include "SPTextureManager.h"
#include "SPMotionCurve.h"

#define GUI_DESIGN_TOOLBAR_WIDTH  776
#define GUI_DESIGN_TOOLBAR_HEIGHT  1600
#define MIN_ANIMATE_WIDTH		110
#define MAX_ANIMATE_WIDTH		GUI_DESIGN_TOOLBAR_WIDTH - MIN_ANIMATE_WIDTH
#define MAX_ANIMATE_FRAME		60

#define GUI_DESIGN_SCREEN_WIDTH 2560
#define GUI_DESIGN_SCREEN_HEIGHT 1600

#define BIG_BUTTON_SIZE   172
#define HALF_BIG_BUTTON_SIZE   86
#define SKETCH_BUTTON_SIZE   142
#define HALF_SKETCH_BUTTON_SIZE   72

#define LEFT_BASE_POS    38
#define RIGHT_MAX_POS    630
#define RIGHT_BG_MAX_POS    420

#define CURVED_TOOL_BTN_TOP  1370
#define FLAT_TOOL_BTN_TOP  1110
#define SHARP_TOOL_BTN_TOP  850
#define SKETCHES_BTN_TOP  588
#define BG_BTN_TOP  360

#define FADE_BTN_WIDTH    74
#define FADE_BTN_HEIGHT    74


namespace SPhysics{

SPWoodCarvingGUI::SPWoodCarvingGUI() :
	m_pDrawFullBG(SPNULL),
	m_pFadeBTN(SPNULL)
	{
		m_fScreenRation_W = 1.0;
		m_fScreenRation_H = 1.0;
		m_fMaxFadeDist = 0.0f;
		m_nToolNextFocusGroup = 1;

		m_ScreenWidth = 1;
		m_ScreenHeight= 1;

		m_fToolbarWidth = GUI_DESIGN_TOOLBAR_WIDTH;
		m_fToolbarHeight = GUI_DESIGN_TOOLBAR_HEIGHT;

		m_fAnimateRightPos = GUI_DESIGN_TOOLBAR_WIDTH;


		m_fAnimateFCnt = 0;
		m_nToolbarState = TOOL_BAR_HIDE;
		m_nToolCurrentFocusGroup = 0;
		m_bDimedUndoBtn = SPTRUE;
	}

	SPWoodCarvingGUI::~SPWoodCarvingGUI()
	{
		SP_SAFE_DELETE(m_pDrawFullBG);
		SP_SAFE_DELETE(m_pFadeBTN);

		// destroy the group button
		SPUInt groupSize = m_vBtnGroup.size();
		for(SPInt idx=0; idx< (SPInt)groupSize; idx++)
		{
			clearGroupButton(m_vBtnGroup[idx]);
			SP_SAFE_DELETE(m_vBtnGroup[idx]);
		}
		m_vBtnGroup.clear();
	}

	SPFloat SPWoodCarvingGUI::SCALE(SPFloat value)
	{
		return value * m_fScreenRation_W ;
	}

	SPVoid SPWoodCarvingGUI::create( SPFloat width, SPFloat height )
	{
		m_ScreenWidth = width;
		m_ScreenHeight = height;

		m_fScreenRation_W = (SPFloat)m_ScreenWidth / GUI_DESIGN_SCREEN_WIDTH;
		m_fScreenRation_H = (SPFloat)m_ScreenHeight / GUI_DESIGN_SCREEN_HEIGHT;

		// current tool bar size
		m_fToolbarWidth = SCALE(GUI_DESIGN_TOOLBAR_WIDTH);
		m_fToolbarHeight =  SCALE(GUI_DESIGN_TOOLBAR_HEIGHT);

		// current tool bar right position
		m_fAnimateRightPos = MAX_ANIMATE_WIDTH;
		m_fMaxFadeDist = m_fAnimateRightPos;

		if(m_pDrawFullBG == SPNULL)
			m_pDrawFullBG = new SPDrawRect();

		m_pDrawFullBG->initialize(width, height);
		m_pDrawFullBG->setSize(SCALE(GUI_DESIGN_TOOLBAR_WIDTH), SCALE(GUI_DESIGN_TOOLBAR_HEIGHT));
		m_pDrawFullBG->setTexture("Res/woodcarving/toolbar.png");


		if(m_pFadeBTN == SPNULL)
			m_pFadeBTN = new SPButton();
		// create a control button for the fade in/out animation
		m_pFadeBTN->setScreenSize(m_ScreenWidth, m_ScreenHeight);
		m_pFadeBTN->createButton(FADE_BTN, SCALE(FADE_BTN_WIDTH), SCALE(FADE_BTN_HEIGHT));
		m_pFadeBTN->setHitTestMargin(18, 113);
		m_pFadeBTN->setPosition(SCALE(MIN_ANIMATE_WIDTH*0.5), SCALE(GUI_DESIGN_TOOLBAR_HEIGHT*0.5), 0.0f);
		m_pFadeBTN->setImage("Res/woodcarving/fade_out.png");
		m_pFadeBTN->setImage("Res/woodcarving/fade_in.png");

		//110 * 300

		// create button group and child buttons
		createToolBar();
	}

	SPVoid SPWoodCarvingGUI::draw()
	{
		animateToolBar();
		
		m_pDrawFullBG->draw();

		if(m_nToolbarState == TOOL_BAR_SHOW)
		{
			SPUInt groupSize = m_vBtnGroup.size();
			for(SPInt idx=0; idx< (SPInt)groupSize; idx++)
			{
				SPButtonArray btnArray = m_vBtnGroup[idx]->vButton;
				SPUInt buttonSize = btnArray.size();
				for(SPUInt sIdx = 0; sIdx < buttonSize; sIdx++)
				{
					btnArray[sIdx]->draw();
				}
			}
		}

		m_pFadeBTN->draw();
		//m_pDrawFullBG->draw();
	}

	SPInt SPWoodCarvingGUI::hitTest( SPFloat touchX, SPFloat touchY )
	{
		SPInt nResult = -1;

		SPVec3f position = m_pDrawFullBG->getPosition();
		if(touchX >= position.x + m_fToolbarWidth)
		{
			return nResult;
		}

		SPInt fadeID = m_pFadeBTN->hitTest(touchX, touchY);
		if(fadeID > 0)
		{
			if(m_nToolbarState == TOOL_BAR_HIDE)
			{
				m_nToolbarState = TOOL_BAR_FADE_IN;
				m_fAnimateFCnt = 0;
			}
			else if(m_nToolbarState == TOOL_BAR_SHOW)
			{
				m_nToolbarState = TOOL_BAR_FADE_OUT;
				m_fAnimateFCnt = 0;
			}
		}


		// GUI work after finisth fade in animation
		if(m_nToolbarState != TOOL_BAR_SHOW)
			return nResult;

		SPUInt groupSize = m_vBtnGroup.size();
		for(SPInt idx=0; idx< (SPInt)groupSize; idx++)
		{
			if(hitTestGroupButton(m_vBtnGroup[idx], touchX, touchY))
			{
				SPButtonArray btnArray = m_vBtnGroup[idx]->vButton;
				SPUInt buttonSize = btnArray.size();
				for(SPUInt sIdx = 0; sIdx < buttonSize; sIdx++)
				{
					SPInt btnID = btnArray[sIdx]->hitTest(touchX, touchY);

					if(btnID > 0)
					{
						nResult = btnID;
						changeBTNFocusStatus(btnID);
						break;
					}
				}
			}
		}

		return nResult;
	}

	SPVoid SPWoodCarvingGUI::setUndoBtnDimStatus( SPBool dimFlag )
	{
		m_bDimedUndoBtn = dimFlag;

		SPUInt groupSize = m_vBtnGroup.size();
		for(SPInt idx=0; idx< (SPInt)groupSize; idx++)
		{
			if(m_vBtnGroup[idx]->groupID == BTN_GROUP_CONTROL)
			{
				SPButtonArray btnArray = m_vBtnGroup[idx]->vButton;
				SPUInt buttonSize = btnArray.size();
				for(SPUInt sIdx = 0; sIdx < buttonSize; sIdx++)
				{
					if(btnArray[sIdx]->getButtonID() == UNDO_BTN)
					{
						if(m_bDimedUndoBtn == SPTRUE)
						{
							btnArray[sIdx]->setImage("Res/woodcarving/undo_dim.png");
						}else
						{
							btnArray[sIdx]->setImage("Res/woodcarving/undo.png");
						}
					}
				}
			}
		}
	}

	SPVoid SPWoodCarvingGUI::createToolBar()
	{
		SPFloat centerLineXpos = 334;

		BUTTON_GROUP* pCurvedGroup = new BUTTON_GROUP();
		// set boundary
		setGroupBoundary(pCurvedGroup, SCALE(LEFT_BASE_POS), SCALE(RIGHT_MAX_POS), SCALE(CURVED_TOOL_BTN_TOP), SCALE(CURVED_TOOL_BTN_TOP - BIG_BUTTON_SIZE));
		// add button
		addGroupButtonL(pCurvedGroup, TOOL_CURVED_L, SCALE(BIG_BUTTON_SIZE), SCALE(LEFT_BASE_POS + HALF_BIG_BUTTON_SIZE), SCALE(CURVED_TOOL_BTN_TOP - HALF_BIG_BUTTON_SIZE));
		addGroupButtonL(pCurvedGroup, TOOL_CURVED_M, SCALE(BIG_BUTTON_SIZE), SCALE(centerLineXpos), SCALE(CURVED_TOOL_BTN_TOP - HALF_BIG_BUTTON_SIZE));
		addGroupButtonL(pCurvedGroup, TOOL_CURVED_S, SCALE(BIG_BUTTON_SIZE), SCALE(RIGHT_MAX_POS - HALF_BIG_BUTTON_SIZE), SCALE(CURVED_TOOL_BTN_TOP - HALF_BIG_BUTTON_SIZE));

		pCurvedGroup->groupID = BTN_GROUP_CURVED;
		m_nToolCurrentFocusGroup = BTN_GROUP_CURVED;
		m_vBtnGroup.push_back(pCurvedGroup);



		BUTTON_GROUP* pFlatGroup = new BUTTON_GROUP();
		setGroupBoundary(pFlatGroup, SCALE(LEFT_BASE_POS), SCALE(RIGHT_MAX_POS), SCALE(FLAT_TOOL_BTN_TOP), SCALE(FLAT_TOOL_BTN_TOP - BIG_BUTTON_SIZE));

		addGroupButtonL(pFlatGroup, TOOL_FLAT_L, SCALE(BIG_BUTTON_SIZE), SCALE(LEFT_BASE_POS + HALF_BIG_BUTTON_SIZE), SCALE(FLAT_TOOL_BTN_TOP - HALF_BIG_BUTTON_SIZE));
		addGroupButtonL(pFlatGroup, TOOL_FLAT_M, SCALE(BIG_BUTTON_SIZE), SCALE(centerLineXpos), SCALE(FLAT_TOOL_BTN_TOP - HALF_BIG_BUTTON_SIZE));
		addGroupButtonL(pFlatGroup, TOOL_FLAT_S, SCALE(BIG_BUTTON_SIZE), SCALE(RIGHT_MAX_POS - HALF_BIG_BUTTON_SIZE), SCALE(FLAT_TOOL_BTN_TOP - HALF_BIG_BUTTON_SIZE));

		pFlatGroup->groupID = BTN_GROUP_FLAT;
		m_vBtnGroup.push_back(pFlatGroup);


		BUTTON_GROUP* pSharpGroup = new BUTTON_GROUP();
		setGroupBoundary(pSharpGroup, SCALE(LEFT_BASE_POS), SCALE(RIGHT_MAX_POS), SCALE(SHARP_TOOL_BTN_TOP), SCALE(SHARP_TOOL_BTN_TOP - BIG_BUTTON_SIZE));

		addGroupButtonL(pSharpGroup, TOOL_SHARP_L, SCALE(BIG_BUTTON_SIZE), SCALE(LEFT_BASE_POS + HALF_BIG_BUTTON_SIZE), SCALE(SHARP_TOOL_BTN_TOP - HALF_BIG_BUTTON_SIZE));
		addGroupButtonL(pSharpGroup, TOOL_SHARP_M, SCALE(BIG_BUTTON_SIZE), SCALE(centerLineXpos), SCALE(SHARP_TOOL_BTN_TOP - HALF_BIG_BUTTON_SIZE));
		addGroupButtonL(pSharpGroup, TOOL_SHARP_S, SCALE(BIG_BUTTON_SIZE), SCALE(RIGHT_MAX_POS - HALF_BIG_BUTTON_SIZE), SCALE(SHARP_TOOL_BTN_TOP - HALF_BIG_BUTTON_SIZE));

		pSharpGroup->groupID = BTN_GROUP_SHARP;
		m_vBtnGroup.push_back(pSharpGroup);


		BUTTON_GROUP* pSketchGroup = new BUTTON_GROUP();
		setGroupBoundary(pSketchGroup, SCALE(LEFT_BASE_POS), SCALE(RIGHT_MAX_POS), SCALE(SKETCHES_BTN_TOP), SCALE(SKETCHES_BTN_TOP - SKETCH_BUTTON_SIZE));

		addGroupButtonM(pSketchGroup, SKETCHES_TYPE1, SCALE(SKETCH_BUTTON_SIZE), SCALE(LEFT_BASE_POS + HALF_SKETCH_BUTTON_SIZE), SCALE(SKETCHES_BTN_TOP - HALF_SKETCH_BUTTON_SIZE));
		addGroupButtonM(pSketchGroup, SKETCHES_TYPE2, SCALE(SKETCH_BUTTON_SIZE), SCALE(centerLineXpos - HALF_SKETCH_BUTTON_SIZE - 2), SCALE(SKETCHES_BTN_TOP - HALF_SKETCH_BUTTON_SIZE));
		addGroupButtonM(pSketchGroup, SKETCHES_TYPE3, SCALE(SKETCH_BUTTON_SIZE), SCALE(centerLineXpos + HALF_SKETCH_BUTTON_SIZE + 3), SCALE(SKETCHES_BTN_TOP - HALF_SKETCH_BUTTON_SIZE));
		addGroupButtonM(pSketchGroup, SKETCHES_TYPE4, SCALE(SKETCH_BUTTON_SIZE), SCALE(RIGHT_MAX_POS - HALF_SKETCH_BUTTON_SIZE + 1), SCALE(SKETCHES_BTN_TOP - HALF_SKETCH_BUTTON_SIZE));

		pSketchGroup->groupID = BTN_GROUP_SKETCH;
		m_vBtnGroup.push_back(pSketchGroup);


		BUTTON_GROUP* pBgGroup = new BUTTON_GROUP();
		setGroupBoundary(pBgGroup, SCALE(LEFT_BASE_POS), SCALE(RIGHT_BG_MAX_POS), SCALE(BG_BTN_TOP), SCALE(BG_BTN_TOP - BIG_BUTTON_SIZE));

		addGroupButtonL(pBgGroup, BG_TYPE1, SCALE(BIG_BUTTON_SIZE), SCALE(124), SCALE(BG_BTN_TOP - HALF_BIG_BUTTON_SIZE));
		addGroupButtonL(pBgGroup, BG_TYPE2, SCALE(BIG_BUTTON_SIZE), SCALE(334), SCALE(BG_BTN_TOP - HALF_BIG_BUTTON_SIZE));
// 		addGroupButtonL(pBgGroup, BG_TYPE1, SCALE(BIG_BUTTON_SIZE), SCALE(LEFT_BASE_POS + HALF_BIG_BUTTON_SIZE), SCALE(BG_BTN_TOP - HALF_BIG_BUTTON_SIZE));
// 		addGroupButtonL(pBgGroup, BG_TYPE2, SCALE(BIG_BUTTON_SIZE), SCALE(RIGHT_BG_MAX_POS - HALF_BIG_BUTTON_SIZE), SCALE(BG_BTN_TOP - HALF_BIG_BUTTON_SIZE));

		pBgGroup->groupID = BTN_GROUP_BG;
		m_vBtnGroup.push_back(pBgGroup);

		// top 1427
		// 74 / 2 = 37

		BUTTON_GROUP* pCtlGroup = new BUTTON_GROUP();
		setGroupBoundary(pCtlGroup, SCALE(32.0), SCALE(316.0), SCALE(1570.0), SCALE(1480.0));

		addGroupButtonCtl(pCtlGroup, HOME_BTN, SCALE(74.0), SCALE(74.0), SCALE(1524.0));
		addGroupButtonCtl(pCtlGroup, NEW_BTN, SCALE(74.0), SCALE(176.0), SCALE(1524.0));
		addGroupButtonCtl(pCtlGroup, UNDO_BTN, SCALE(74.0), SCALE(272.0), SCALE(1524.0));

		pCtlGroup->groupID = BTN_GROUP_CONTROL;
		m_vBtnGroup.push_back(pCtlGroup);
	}

	SPVoid SPWoodCarvingGUI::setGroupBoundary( BUTTON_GROUP* group, SPFloat left, SPFloat right, SPFloat top, SPFloat bottom )
	{
		group->left = left;
		group->right = right;
		group->top = top;
		group->bottom = bottom;
	}

	SPVoid SPWoodCarvingGUI::addGroupButtonL( BUTTON_GROUP* group, SPUInt btnID, SPFloat btnSize, SPFloat centerPosX, SPFloat centerPosY )
	{
		SPButton *pButton = new SPButton();
		pButton->setScreenSize(m_ScreenWidth, m_ScreenHeight);
		pButton->createButton(btnID, btnSize, btnSize);
		pButton->setPosition(centerPosX, centerPosY, 0.0f);
		pButton->setFocusedImage("Res/woodcarving/selected_l.png");
		pButton->setFocusStatus(SPFALSE);

		if(btnID == TOOL_CURVED_M || btnID == BG_TYPE1)
			pButton->setFocusStatus(SPTRUE);

		group->vButton.push_back(pButton);
	}

	SPVoid SPWoodCarvingGUI::addGroupButtonM( BUTTON_GROUP* group, SPUInt btnID, SPFloat btnSize, SPFloat centerPosX, SPFloat centerPosY )
	{
		SPButton *pButton = new SPButton();
		pButton->setScreenSize(m_ScreenWidth, m_ScreenHeight);
		pButton->createButton(btnID, btnSize, btnSize);
		pButton->setPosition(centerPosX, centerPosY, 0.0f);
		pButton->setFocusedImage("Res/woodcarving/selected_m.png");
		pButton->setFocusStatus(SPFALSE);

		group->vButton.push_back(pButton);
	}


	SPVoid SPWoodCarvingGUI::addGroupButtonCtl( BUTTON_GROUP* group, SPUInt btnID, SPFloat btnSize, SPFloat centerPosX, SPFloat centerPosY )
	{
		SPButton *pButton = new SPButton();
		pButton->setScreenSize(m_ScreenWidth, m_ScreenHeight);
		pButton->createButton(btnID, btnSize, btnSize);
		pButton->setPosition(centerPosX, centerPosY, 0.0f);

		if(btnID == UNDO_BTN)
		{
			pButton->setImage("Res/woodcarving/undo.png");
			pButton->setImage("Res/woodcarving/undo_dim.png");
		}

		group->vButton.push_back(pButton);
	}

	SPVoid SPWoodCarvingGUI::clearGroupButton(BUTTON_GROUP* group)
	{
		if (group != NULL)
		{
			SPInt buttonCount = (SPInt)group->vButton.size();
			for (SPInt idx = 0; idx < buttonCount; idx++)
			{
				SP_SAFE_DELETE(group->vButton[idx]);
			}
			group->vButton.clear();
		}
	}

	SPBool SPWoodCarvingGUI::hitTestGroupButton( BUTTON_GROUP* group, SPFloat touchX, SPFloat touchY )
	{
		SPBool bResult = SPFALSE;
		if(touchX >= group->left && touchX <= group->right)
		{
			if(touchY >= group->bottom && touchY <= group->top)
			{
				bResult = SPTRUE;
			}
		}

		return bResult;
	}

	SPVoid SPWoodCarvingGUI::animateToolBar()
	{
		switch(m_nToolbarState)
		{
		case TOOL_BAR_FADE_IN:
			{
				m_fAnimateFCnt++;

				if(m_fAnimateFCnt <= MAX_ANIMATE_FRAME)
				{
					SPFloat curveValue = SineInOut33::getInterpolation((SPFloat)m_fAnimateFCnt / MAX_ANIMATE_FRAME);
					m_fAnimateRightPos = m_fMaxFadeDist - m_fMaxFadeDist*curveValue;

					SPFloat fadeBtnCenterX =  m_fMaxFadeDist - m_fAnimateRightPos + (MIN_ANIMATE_WIDTH*0.5);
					m_pFadeBTN->setPosition(SCALE(fadeBtnCenterX), SCALE(GUI_DESIGN_TOOLBAR_HEIGHT*0.5), 0.0f);
				}else
				{
					m_nToolbarState = TOOL_BAR_SHOW;
					m_pFadeBTN->setImage("Res/woodcarving/fade_out.png");
				}

			}
			break;
		case TOOL_BAR_FADE_OUT:
			{
				m_fAnimateFCnt++;

				if(m_fAnimateFCnt <= MAX_ANIMATE_FRAME)
				{
					SPFloat curveValue = SineInOut33::getInterpolation((SPFloat)m_fAnimateFCnt / MAX_ANIMATE_FRAME);
					m_fAnimateRightPos = m_fMaxFadeDist*curveValue;

					SPFloat fadeBtnCenterX =  m_fMaxFadeDist - m_fAnimateRightPos + (MIN_ANIMATE_WIDTH*0.5);
					m_pFadeBTN->setPosition(SCALE(fadeBtnCenterX), SCALE(GUI_DESIGN_TOOLBAR_HEIGHT*0.5), 0.0f);
				}else
				{
					m_nToolbarState = TOOL_BAR_HIDE;
					m_pFadeBTN->setImage("Res/woodcarving/fade_in.png");
				}

			}
			break;
		}

		m_pDrawFullBG->setTranslate(SCALE(-m_fAnimateRightPos), 0.0f, 0.0f);

	}

	SPVoid SPWoodCarvingGUI::changeBTNFocusStatus( SPInt btnID )
	{
		if(btnID == BG_TYPE1 || btnID == BG_TYPE2)
		{
			changeBGBTNFocusStatus(btnID);
		}
		else if(btnID >= TOOL_CURVED_L && btnID <= TOOL_CURVED_S)
		{
			m_nToolNextFocusGroup = BTN_GROUP_CURVED;
			changeToolBTNFocusStatus(btnID);
		}
		else if(btnID >= TOOL_FLAT_L && btnID <= TOOL_FLAT_S)
		{
			m_nToolNextFocusGroup = BTN_GROUP_FLAT;
			changeToolBTNFocusStatus(btnID);
		}
		else if(btnID >= TOOL_SHARP_L && btnID <= TOOL_SHARP_S)
		{
			m_nToolNextFocusGroup = BTN_GROUP_SHARP;
			changeToolBTNFocusStatus(btnID);
		}
		else if(btnID >= SKETCHES_TYPE1 && btnID <= SKETCHES_TYPE4)
		{
			changeSketchBTNFocusStatus(btnID);
		}
		else if(btnID == NEW_BTN)
		{
			changeSketchBTNFocusStatus(-1);
		}
	}

	SPVoid SPWoodCarvingGUI::changeBGBTNFocusStatus( SPInt btnID )
	{
		SPUInt groupSize = m_vBtnGroup.size();
		for(SPInt idx=0; idx< (SPInt)groupSize; idx++)
		{
			if(m_vBtnGroup[idx]->groupID == BTN_GROUP_BG)
			{
				SPButtonArray btnArray = m_vBtnGroup[idx]->vButton;
				SPUInt buttonSize = btnArray.size();
				for(SPUInt sIdx = 0; sIdx < buttonSize; sIdx++)
				{
					if(btnArray[sIdx]->getButtonID() == btnID)
					{
						btnArray[sIdx]->setFocusStatus(SPTRUE);
					}
					else
					{
						btnArray[sIdx]->setFocusStatus(SPFALSE);
					}
				}
			}
		}
	}

	SPVoid SPWoodCarvingGUI::changeToolBTNFocusStatus( SPInt btnID )
	{
		SPUInt groupSize = m_vBtnGroup.size();
		for(SPInt idx=0; idx< (SPInt)groupSize; idx++)
		{
			SPButtonArray btnArray = m_vBtnGroup[idx]->vButton;
			SPUInt buttonSize = btnArray.size();

			if(m_vBtnGroup[idx]->groupID == m_nToolNextFocusGroup)
			{
				if(m_nToolNextFocusGroup == m_nToolCurrentFocusGroup)
				{
					for(SPUInt sIdx = 0; sIdx < buttonSize; sIdx++)
					{
						if(btnArray[sIdx]->getButtonID() == btnID)
						{
							btnArray[sIdx]->setFocusStatus(SPTRUE);
						}
						else
						{
							btnArray[sIdx]->setFocusStatus(SPFALSE);
						}
					}
					break;
				}else
				{
					for(SPUInt sIdx = 0; sIdx < buttonSize; sIdx++)
					{
						if(btnArray[sIdx]->getButtonID() == btnID)
						{
							btnArray[sIdx]->setFocusStatus(SPTRUE);

							continue;
						}
					}
				}
			}
			else if(m_vBtnGroup[idx]->groupID == m_nToolCurrentFocusGroup && m_nToolCurrentFocusGroup != m_nToolNextFocusGroup)
			{
				for(SPUInt sIdx = 0; sIdx < buttonSize; sIdx++)
				{
					btnArray[sIdx]->setFocusStatus(SPFALSE);
				}
			}
		}

		m_nToolCurrentFocusGroup = m_nToolNextFocusGroup;
	}

	SPVoid SPWoodCarvingGUI::changeSketchBTNFocusStatus( SPInt btnID )
	{
		SPUInt groupSize = m_vBtnGroup.size();
		for(SPInt idx=0; idx< (SPInt)groupSize; idx++)
		{
			if(m_vBtnGroup[idx]->groupID == BTN_GROUP_SKETCH)
			{
				SPButtonArray btnArray = m_vBtnGroup[idx]->vButton;
				SPUInt buttonSize = btnArray.size();
				for(SPUInt sIdx = 0; sIdx < buttonSize; sIdx++)
				{
					if(btnArray[sIdx]->getButtonID() == btnID)
					{
						btnArray[sIdx]->setFocusStatus(SPTRUE);
					}
					else
					{
						btnArray[sIdx]->setFocusStatus(SPFALSE);
					}
				}
			}
		}
	}

	SPBool SPWoodCarvingGUI::isDrawableStatus(SPFloat touchX, SPFloat touchY)
	{
		SPVec3f position = m_pDrawFullBG->getPosition();
		if(m_nToolbarState == TOOL_BAR_SHOW || m_nToolbarState == TOOL_BAR_HIDE)
		{
			if(touchX > position.x + m_fToolbarWidth)
			{
				return SPTRUE;
			}
		}
		

		return SPFALSE;
	}

}
