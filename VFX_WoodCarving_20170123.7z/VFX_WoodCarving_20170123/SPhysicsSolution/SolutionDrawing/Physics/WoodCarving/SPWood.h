/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPWood.h
 * @brief  Class SPWood
 * @author Arthur Yusupov (a.yusupov@samsung.com)
 * @author Andrii Krenevych (a.krenevych@samsung.com)
 */

#ifndef _WOOD_H_
#define _WOOD_H_

#include "SPWoodTool.h"
#include "SPShaving.h"

#include <glm.hpp>

#include <list>

namespace SPhysics
{

/**
 *  Class SPWood
 */
class SPWood
{
public:

	/**
	 * Structure for interaction with shaving.
	 */
	struct ShavingObject
	{
		/**
		 * Default constructor
		 */
		inline ShavingObject() :
				mShaving(NULL),
				mShavingObjects(NULL)
		{
		}

		/**
		 * Copy constructor.
		 *
		 * @param aShaving SPShaving to copy.
		 */
		inline ShavingObject(SPShaving* aShaving) :
				mShaving(aShaving),
				mShavingObjects(aShaving->getObjects())
		{
		}

		SPShaving* mShaving; /**< Pointer to shaving.*/
		SPWObject* mShavingObjects; /**< Pointer to shaving object.*/
	};

	/**
	 * Constructor
	 *
	 * @param aWidth Width of heightmap in X-direction.
	 * @param aHeight Height of heightmap in X-direction.
	 * @param aNormalHeightMap Pointer to map of normals and heights
	 * @param aToolSize Diameter of tool.
	 * @param aMinLength Minimal distance of movement of tool before the carving begins.
	 * @param aMult Width multiplier.
	 * @param aRatio Value of ratio X to Y in model.
	 * @param aVelocityDamp Damp coeficient of velocity of the tool.
	 * @param aMaxShavingLength Maximal length of the each shaving in model.
	 */
	SPWood(const SPUInt aWidth,
		 const SPUInt aHeight,
		 glm::cvec4* const aNormalHeightMap,
		 const SPUInt aToolSize,
		 const SPFloat aMinLength,
		 const SPFloat aMult,
		 const SPFloat aRatio,
		 const SPFloat aVelocityDamp,
		 const SPFloat aMaxShavingLength);

	/**
	 * Destructor.
	 */
	~SPWood();

	/**
	 * Reset to original state.
	 */
	SPVoid reset();

	/**
	 * Simulates the behavior of wood and all visible shavings per frame.
	 */
	SPVoid step();

	/**
	 * Defines behaviour of model on "touch down" event and prepearing model for carving.
	 * Sets current tool position.
	 *
	 * @param aPosition Position of the tool.
	 */
	SPVoid setToolPosition(const glm::uvec2 aPosition);

	/**
	 * Defines behaviour of model on "move" event. Provides linear wood carving from previous position to current.
	 * Sets current tool position and tool depth.
	 *
	 * @param aPosition Position of the tool.
	 * @param aDepth Depth of tool.
	 */
	SPVoid moveToolPosition(const glm::uvec2 aPosition, SPFloat aDepth);

	/**
	 * Defines behaviour of model on "touch up" event.
	 */
	SPVoid upTool();

	/**
	 * Sets the diameter of tool.
	 *
	 * @param aToolSize Diameter of tool.
	 * @param aToolType Tool type.
	 * @param aInnerToolRadius Defines internal relative radius (value from 0.0f to 1.0f) of tool domain where razor is parallel to wood domain.
	 */
	SPVoid setToolSize(const SPUInt aToolSize, SPWoodTool::ToolType aToolType = SPWoodTool::Elipse, const float aInnerToolRadius = 0.0f);

	/**
	 * Sets the type of tool.
	 * tool types : 1 = Curved, 2 = flat, 3 = sharp
	 * @param aTool Type
	 */
	SPVoid setToolType(const SPUInt aToolType);

	/**
	 * Sets current value of gravity force.
	 *
	 * @param aValue Value of gravity.
	 */
	inline SPVoid setGravity(const glm::vec2& aValue);

	/**
	 * Returns list of shavings in model.
	 *
	 * @return List of shavings.
	 */
	inline std::list<ShavingObject>& getShavings();

	std::vector<ShavingObject> mShavingsToAdd; /**< List of shavings which has been created before next render frame */
	std::vector<ShavingObject> mShavingsToRemove; /**< List of shavings which has been removed before next render frame */

private:

	/**
	 * Complex method of carving.
	 * Includes the carving and creation (or increasing) shaving.
	 *
	 * @param aPosition Current position of tool.
	 * @param aDepth Current depth of tool.
	 * @param aAddAsNewPoint Indicates whether to create a new segment of shaving or to increase previous.
	 */
	SPVoid carve(const glm::vec2 aPosition, const SPFloat aDepth, const SPBool aAddAsNewPoint);

	/**
	 * The main method of carving (without shaving).
	 * Carves canal in wood from previous to current position of tool.
	 *
	 * @param aPosition Current position of tool.
	 * @param aDepth Current depth of tool.
	 */
	inline SPVoid cut(const glm::vec2 aPosition, const SPFloat aDepth);

	/**
	 * Method of finalization of current broken shaving and creation of new empty shaving.
	 */
	SPVoid finalizeShaving();

	/**
	 * Converts physical coordinates of model into graphic coordinates for visualisation.
	 *
	 * @param aPosition Physical coordinates.
	 * @return Graphic coordinates.
	 */
	inline glm::vec2 positionToVertexPosition(const glm::vec2 aPosition);

	const SPUInt mWidth; /**< Number of columns in physical grid of model. */
	const SPUInt mHeight; /**< Number of lines in physical grid of model. */
	const SPFloat mInvertWidth; /**< Coefficient which is defined as one divided to mWidth. */
	const SPFloat mInvertHeight; /**< Coefficient which is defined as one divided to mHeight. */

	glm::cvec4* mNormalHeightMap; /**< Pointer to map of normals and heights which is defined on the grid of model. */

	glm::uvec2 mPrevPosition; /**< Coordinates of the previous position of the tool. */
	glm::vec2 mVelocity; /**< Current velocity of the tool. */
	SPFloat mVelocityDamp; /**< Damp coeficient of velocity of the tool. */
	SPFloat mPrevDepth; /**< Value of the previous depth of the tool. */

	const SPFloat mMinLength; /**< Minimal distance of movement of tool before the carving begins. */
	const SPFloat mMult; /**< Width multiplier. */

	const SPFloat mRatio; /**< Value of ratio of X to Y in model. */

	glm::vec2 mMinToolPosition; /**< Edgze coordinate of the left and bottom position of tool. */
	glm::vec2 mMaxToolPosition; /**< Edgze coordinate of the right and top position of tool. */
	glm::vec4 mVisibleWoodArea; /**< The visible area of the wood. */

	SPWoodTool mTool; /**<Instance of the tool.*/
	std::list<ShavingObject> mShavings; /**<List of the visible shavings.*/
	SPShaving* mCurrentShaving; /**< Pointer to the current shaving which is created at the moment.*/
	SPFloat mMaxShavingLength; /**< Maximal length of the each shaving.*/
	SPUInt mMaxShavingsPoint; /**< Maximal number of points which defines the boundary of the each shaving.*/
	SPFloat mAngle; /**< Current value of rotation angle of the tool during carving.*/
	SPFloat mPreviousAngle; /**< Previous value of rotation angle of the tool during carving.*/
	SPBool mIsIncreaseShaving; /**< Indicate is shaving is need to increase.*/
	SPBool mIsDeltaXNegative; /**< Holds value true if X-component of diference between current and previous positions less than zero.*/
	SPBool mIsDeltaYNegative; /**< Holds value true if Y-component of diference between current and previous positions less than zero.*/
	SPBool mIsZeroAngle; /**< Holds true if angle of direction is about zero.*/
	SPBool mIsFirstTouch; /**< Takes the value true when carving begins. Takes value false during carving (moving the tool). */
	SPBool mIsCut; /**< Takes the value true during carving. */
	SPBool mIsMove; /**< Takes the value true during carving and moving of tool. */

	SPUInt mToolType;

	glm::vec2 mGravity; /**< Current value of gravity which is defined according to value of accelerometer. */
};

} /* namespace SPhysics */

#include "SPWood.inl"

#endif /* _WOOD_H_ */
