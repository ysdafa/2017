/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPShaving.h
 * @brief  Class SPShaving
 * @author Author (a.krenevych@samsung.com)
 */

#ifndef _SHAVING_H_
#define _SHAVING_H_

#include "SPWObject.h"

#include <glm.hpp>

#include <vector>

namespace SPhysics
{

/**
 *  Class SPShaving
 */
class SPShaving
{
public:

	/**
	 * Constructor.
	 *
	 * @param aCapacity Numbers of boundary points of shaving.
	 * @param aRatio Ratio of X to Y in model.
	 * @param aMult Width multiplier.
	 * @param aMaxShavingLength Maximal length of shaving.
	 */
	SPShaving(const SPUInt aCapacity,
			const SPFloat aRatio,
			const SPFloat aMult,
			const SPFloat aMaxShavingLength);

	/**
	 * Destructor.
	 */
	~SPShaving();

	/**
	 * Adds new or updates last segment of shaving.
	 *
	 * @param aLeftPoint
	 * @param aRightPoint
	 * @param aAddAsNewSegment
	 * @param aToSpin
	 */
	SPVoid addSegment(const glm::vec2 aLeftPoint,
					const glm::vec2 aRightPoint,
					const SPBool aAddAsNewSegment,
					const SPBool aToSpin = true);

	/**
	 * Method of finalizing of shaving.
	 *
	 * @param aAngle Angle of direction of tool moving.
	 * @param aVelocity Velocity of tool before finalizing.
	 * @param aIsBreak
	 */
	SPVoid finalize(const SPFloat aAngle, glm::vec2 aVelocity, SPBool aIsBreak = false);

	/**
	 * Simulates the behavior of shaving per frame.
	 */
	SPVoid step();

	/**
	 * Indicates whether the shaving is visible.
	 *
	 * @param aVisibleArea Coordinates of bottom left and top right coners of the visible area.
	 * @return "true" if shaving is visible and "false" otherwise.
	 */
	SPBool isVisible(glm::vec4 aVisibleArea);

	/**
	 * Indicates whether the shaving is too long.
	 *
	 * @return "true" if shaving has or exceeds the maximum length.
	 */
	inline SPBool isTooLong();

	/**
	 * Sets current value of gravity force.
	 *
	 * @param aGravity Value of gravity.
	 */
	inline SPVoid setGravity(const glm::vec2 aGravity);

	/**
	 * @return Number of boundary points of shaving.
	 */
	inline SPUInt getShavingPointCount();

	/**
	 * @return Pointer to object which holds geometry of shaving.
	 */
	inline SPWObject* getObjects();

private:

	/**
	 * Method of spining shaving during carving.
	 */
	SPVoid spin();

	/**
	 * Creates final segments of shaving in moment of breaking shaving off.
	 *
	 * @param aAngle Angle of tool moving direction before breaking off shaving.
	 */
	SPVoid finalizeSegments(SPFloat aAngle);

	/**
	 * Indicates whether the last segment of shaving is too long.
	 *
	 * @return "true" if the last segment of shaving has or exceeds the maximum length.
	 */
	inline SPBool isCurrentSegmentTooLong();

	/**
	 * Updates positions of bottom shaving by positions of top shaving.
	 *
	 * @param aId Number of segment of shaving.
	 */
	inline SPVoid updateSecondObjectPositions(const SPUInt aId);

	/**
	 * Updates normals of bottom shaving by positions of top shaving.
	 *
	 * @param aId Number of segment of shaving.
	 */
	inline SPVoid updateSecondObjectNormals(const SPUInt aId);

	/**
	 * Initialize positions of bottom shaving by plain positions shaving.
	 *
	 * @param aId Number of segment of shaving.
	 */
	inline SPVoid initObjectPositionByPlain(const SPUInt aId);

	/**
	 * Updates texture coordinates of bottom and top shavings for modified or added segment.
	 */
	SPVoid updateTextureCoords();

	/**
	 * Provides translations and rotations of shaving.
	 */
	inline SPVoid applyTransformations();

	std::vector<glm::vec2> mPlanePositions; /**< Vector of 2D-points which defines boundary of shaving. */
	glm::vec3 mShavingPosition; /**< Absolute position of shaving. */
	glm::vec3 mVelocity; /**< Velosity of shaving. */

	SPUInt mSize; /**< Numbers of boundary points of shaving. */

	SPWObject mObject[2]; /**<
	 Geometry of the shaving. Used for simulation of the top and bottom surfaces of shaving. */

	const SPUInt mMinPointCount; /**< Minimal number of points for visible shaving. */
	SPFloat mLeftLength; /**< Length of left edge of shaving boundary. */
	SPFloat mRightLength; /**< Length of right edge of shaving boundary. */
	SPFloat mMaxShavingLength; /**< Maximal length of shaving. */
	SPFloat mMaxSegmentLength; /**< Maximal length of segment of shaving. */

	SPBool mIsBrokenFromWood; /**<
	 Holds value "false" in process of creation of shaving.
	 When shaving is broken off from wood, this parameter is set to "true",
	 the shaving is able to fall from wood. */

	SPFloat mOneDivRatio; /**< Value of ratio of Y to X in model.*/
	SPFloat mMult; /**< Width multiplier. */
	SPFloat mHalfDivMult; /**< Half of the ratio one to width multiplier. */

	glm::vec2 mGravity; /**< Current value of gravity which is defined according to value of accelerometer. */
	glm::vec3 mMassCenter; /**< Position of the center of mass of the shaving. */
	SPFloat mVertShift; /**< Vertical shift of carved shaving. */
};

} /* namespace SPhysics */

#include "SPShaving.inl"

#endif /* _SHAVING_H_ */
