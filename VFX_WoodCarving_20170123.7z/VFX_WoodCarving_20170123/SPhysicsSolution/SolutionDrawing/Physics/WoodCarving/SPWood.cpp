/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPWood.cpp
 * @brief  Class SPWood
 * @author Arthur Yusupov (a.yusupov@samsung.com)
 * @author Andrii Krenevych (a.krenevych@samsung.com)
 */

#include "SPWood.h"
#include "SPException.h"

#include <glm.hpp>
#include <gtx/compatibility.hpp>
#include <gtx/norm.hpp>
#include <gtc/matrix_transform.hpp>

#include "SPLog.h"

#include <string.h>

#define SHARP_ANGLE glm::quarter_pi<SPFloat>()
#define ALMOST_ZERO_ANGLE 0.1f

namespace SPhysics
{

SPWood::SPWood(const SPUInt aWidth,
		   const SPUInt aHeight,
		   glm::cvec4* const aNormalHeightMap,
		   const SPUInt aToolSize,
		   const SPFloat aMinLength,
		   const SPFloat aMult,
		   const SPFloat aRatio,
		   const SPFloat aVelocityDamp,
		   const SPFloat aMaxShavingLength) :
		mWidth(aWidth),
		mHeight(aHeight),
		mInvertWidth(1.0f / SPFloat(mWidth - 1)),
		mInvertHeight(1.0f / SPFloat(mHeight - 1)),
		mNormalHeightMap(aNormalHeightMap),
		mVelocityDamp(aVelocityDamp),
		mPrevDepth(0.f),
		mMinLength(aMinLength),
		mMult(aMult),
		mRatio(aRatio),
		mVisibleWoodArea(
				positionToVertexPosition(glm::vec2(-0.5f * SPFloat(mWidth), -0.5f * SPFloat(mHeight))),
				positionToVertexPosition(glm::vec2(1.50f * SPFloat(mWidth), 1.50f * SPFloat(mHeight)))),
		mCurrentShaving(NULL),
		mMaxShavingLength(aMaxShavingLength),
		mMaxShavingsPoint(2048),
		mAngle(0.f),
		mPreviousAngle(0.f),
	    mIsIncreaseShaving(true),
		mIsDeltaXNegative(false),
		mIsDeltaYNegative(false),
		mIsZeroAngle(false),
		mIsFirstTouch(false),
	    mToolType(1)
{
	ARGUMENT_VALUE_CHECK(aWidth == 0);
	ARGUMENT_VALUE_CHECK(aHeight == 0);
	ARGUMENT_VALUE_CHECK(aNormalHeightMap == NULL);
	ARGUMENT_VALUE_CHECK(aMinLength <= 0.f);
	ARGUMENT_VALUE_CHECK(aMaxShavingLength <= 0.f);

	reset();
	setToolSize(aToolSize,SPWoodTool::Cone, 0.5f);
}

SPWood::~SPWood()
{
	for (auto shaving = mShavings.begin(); shaving != mShavings.end(); shaving++)
	{
		delete (*shaving).mShaving;
	}
}

SPVoid SPWood::reset()
{
	for (auto shaving = mShavings.begin(); shaving != mShavings.end(); shaving++)
	{
		delete (*shaving).mShaving;
	}

	mCurrentShaving = NULL;

	mShavings.clear();
	mShavingsToAdd.clear();
	mShavingsToRemove.clear();

	finalizeShaving();

	glm::cvec4 empty(127, 127, 255, 0);
	for (SPUInt i = 0, size = mWidth * mHeight; i < size; i++)
	{
		mNormalHeightMap[i] = empty;
	}

	mIsCut = false;
	mIsMove = false;
}

SPVoid SPWood::step()
{
	for (auto shaving = mShavings.begin(); shaving != mShavings.end();)
	{
		if (shaving->mShaving->isVisible(mVisibleWoodArea))
		{
			shaving->mShaving->setGravity(mGravity);
			shaving->mShaving->step();
			shaving++;
		}
		else
		{
			mShavingsToRemove.push_back(*shaving);
			delete shaving->mShaving;
			shaving = mShavings.erase(shaving);
		}
	}
}

SPVoid SPWood::setToolPosition(const glm::uvec2 aPosition)
{
	glm::bvec2 outOfBounds = glm::lessThanEqual(aPosition, glm::uvec2(mMinToolPosition));
	outOfBounds |= glm::greaterThanEqual(aPosition, glm::uvec2(mMaxToolPosition));

	if (outOfBounds.x || outOfBounds.y)
	{
		return;
	}

//	unsigned int index = aPosition.y * mWidth + aPosition.x;
//
//	if (mNormalHeightMap[index].w > 0 || mCurrentShaving->isTooLong())
//	{
//		return;
//	}
	mPrevPosition = aPosition;
	mPrevDepth = 0.05f;
	mIsIncreaseShaving = true;
	mIsFirstTouch = true;
	mIsCut = true;
}

SPVoid SPWood::moveToolPosition(const glm::uvec2 aPosition, SPFloat aDepth)
{
	if (!mIsCut)
	{
		return;
	}

	glm::vec2 delta(glm::vec2(aPosition) - glm::vec2(mPrevPosition));

	if (glm::length2(delta) < mMinLength)
	{
		return;
	}

	glm::bvec2 outOfBounds = glm::lessThanEqual(aPosition, glm::uvec2(mMinToolPosition));
	outOfBounds |= glm::greaterThanEqual(aPosition, glm::uvec2(mMaxToolPosition));

	if (outOfBounds.x || outOfBounds.y)
	{
		finalizeShaving();
//		upTool();
		return;
	}

	aDepth = glm::pow(glm::clamp(aDepth, 0.05f, 1.0f), 4.0f);

	mVelocity = delta * mVelocityDamp;

	mAngle = -glm::atan(delta.x, delta.y);
	mIsDeltaXNegative = delta.x < 0.0f;
	mIsDeltaYNegative = delta.y < 0.0f;
	mIsZeroAngle = glm::abs(delta.x) < 0.01f;

	if (mIsFirstTouch)
	{
		mIsFirstTouch = false;
		mPreviousAngle = mAngle;
	}

	SPFloat deltaAngle = glm::abs(mAngle - mPreviousAngle);
	if (deltaAngle > glm::pi<SPFloat>())
	{
		deltaAngle = 2 * glm::pi<SPFloat>() - deltaAngle;
	}

	if (deltaAngle > SHARP_ANGLE)
	{
		finalizeShaving();
	}

	glm::vec2 adelta(glm::abs(delta));
	SPUInt iterations;

	SPFloat dz = aDepth - mPrevDepth;
	SPFloat currentDepth = mPrevDepth;

	if (adelta.x > adelta.y)
	{
		dz /= adelta.x * 5.0f;
		iterations = (SPUInt) (adelta.x - 1);
		delta.y /= adelta.x;
		delta.x = glm::sign(delta.x);
	}
	else
	{
		dz /= adelta.y * 5.0f;
		iterations = (SPUInt) (adelta.y - 1);
		delta.x /= adelta.y;
		delta.y = glm::sign(delta.y);
	}

	SPFloat limitsClamping = 1.0f / 255.0f;

	dz = glm::clamp(dz, -limitsClamping, limitsClamping);

	if(mToolType == 2)
	{
		currentDepth = aDepth;
	}

	carve(glm::vec2(mPrevPosition), currentDepth, deltaAngle > ALMOST_ZERO_ANGLE);
	mIsMove = true;
	glm::vec2 pos(mPrevPosition + glm::uvec2(delta));
	glm::vec2 nextPos;
	mIsIncreaseShaving = true;

	//for (; iterations != 0; iterations--, pos = nextPos, currentDepth += dz)
	for (; iterations != 0; iterations--, pos = nextPos)
	{
		if(mToolType != 2) // flat tool
		{
			currentDepth += dz;
		}		

		nextPos = pos + delta;
		SPUInt index = (SPInt(nextPos.y)) * mWidth + SPInt(nextPos.x);

		if (mNormalHeightMap[index].w > 0 || mCurrentShaving->isTooLong())
		{
			mIsIncreaseShaving = false;
			finalizeShaving();
			break;    // Optimization.
		}

		carve(pos, currentDepth, false);
	}

	// Optimization.
	// Continue previous loop without check for 'mNormalHeightMap[index].w > 0 || mCurrentShaving->isTooLong()'.
	//for (; iterations != 0; iterations--, pos += delta, currentDepth += dz)
	for (; iterations != 0; iterations--, pos += delta)
	{
		//currentDepth += dz;

		if(mToolType != 2) // flat tool
		{
			currentDepth += dz;
		}

		carve(pos, currentDepth, false);
	}

	mPrevPosition = aPosition;
	mPrevDepth = currentDepth;
	mPreviousAngle = mAngle;
}

SPVoid SPWood::upTool()
{
	if (mIsCut && mIsMove)
	{
		cut(glm::vec2(mPrevPosition), mPrevDepth);
		mIsDeltaXNegative = !mIsDeltaXNegative;
		mIsDeltaYNegative = !mIsDeltaYNegative;
		cut(glm::vec2(mPrevPosition), mPrevDepth);
		finalizeShaving();
	}

	mIsMove = mIsCut = false;
}

SPVoid SPWood::setToolSize(const SPUInt aToolSize, SPWoodTool::ToolType aToolType, const SPFloat aInnerToolRadius)
{
	mMinToolPosition = glm::uvec2(aToolSize / 2, aToolSize / 2);
	mMaxToolPosition = glm::uvec2(mWidth - 1 - aToolSize / 2, mHeight - 1 - aToolSize / 2);
	mTool.init(aToolSize + 1 - aToolSize % 2, aToolType, aInnerToolRadius);
}

SPVoid SPWood::setToolType( const SPUInt aToolType )
{
	// aToolType : 1(Curved), 2(Flat), 3(Sharp)
	mToolType = aToolType;
}

SPVoid SPWood::carve(const glm::vec2 aPosition, const SPFloat aDepth, const SPBool aAddAsNewPoint)
{
	if (mIsIncreaseShaving)
	{
		SPInt toolCenter = SPInt((mTool.getSize() / 2) * glm::pow(aDepth, glm::third<SPFloat>()));

		glm::vec2 left(-toolCenter, 0);
		glm::vec2 right(toolCenter, 0);

		glm::mat2 transformationMatrix = glm::mat2(
				glm::rotate(glm::mat4(), mAngle, glm::vec3(0, 0, 1)));

		left = transformationMatrix * left + aPosition;
		right = transformationMatrix * right + aPosition;

		left = positionToVertexPosition(left);
		right = positionToVertexPosition(right);

		mCurrentShaving->addSegment(left, right, aAddAsNewPoint);
	}

	cut(aPosition, aDepth);
}

SPVoid SPWood::finalizeShaving()
{
	if (mCurrentShaving != NULL)
	{
		if (mCurrentShaving->getShavingPointCount() <= 2)
		{
			mShavingsToRemove.push_back(mCurrentShaving);
			delete mCurrentShaving;
			mShavings.pop_back();

			for (auto toAdd = mShavingsToAdd.begin(), toAddEnd = mShavingsToAdd.end(); toAdd != toAddEnd; ++toAdd)
			{
				if (toAdd->mShaving == mCurrentShaving)
				{
					mShavingsToAdd.erase(toAdd);
					break;
				}
			}
		}
		else
		{
			mCurrentShaving->finalize(mAngle, mVelocity, false);
		}
	}

	mCurrentShaving = new SPShaving(mMaxShavingsPoint, mRatio, mMult, mMaxShavingLength);
	mShavings.push_back(mCurrentShaving);
	mShavingsToAdd.push_back(mCurrentShaving);
}

} /* namespace SPhysics */
