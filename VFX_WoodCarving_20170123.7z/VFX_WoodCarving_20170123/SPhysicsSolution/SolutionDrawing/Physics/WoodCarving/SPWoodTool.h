/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPWoodTool.h
 * @brief  Class of tool.
 * @author Arthur Yusupov (a.yusupov@samsung.com)
 * @author Andrii Krenevych (a.krenevych@samsung.com)
 */

#ifndef _WOOD_TOOL_H_
#define _WOOD_TOOL_H_

#include <glm.hpp>
#include <vector>
#include "SPDefines.h"

namespace glm
{

typedef glm::tvec4<SPhysics::SPUChar> cvec4;

} /* namespace glm*/

namespace SPhysics
{

class SPWoodTool
{

public:

	enum ToolType
	{
		Elipse = 0,
		Cone = 1,
		Undefined = 2
	};

	/**
	 * Define constructor.
	 */
	inline SPWoodTool();

	/**
	 * Initialization of tool.
	 *
	 * @param aSize Diameter of tool.
	 */
	inline SPVoid init(const SPUInt aSize, ToolType aToolType, const float aInnerToolRadius = 0.0f);

	/**
	 * Returns value of map of normals and heights at selected cell.
	 *
	 * @param aIndex Index (number) of cell of map.
	 * @param aK four-dimensional array of coefficients which provides antialiasing carving.
	 *
	 * @return 4D-dimensional vector where the first three componets are coordinates of normal and the last one - value of depth.
	 */
	inline glm::cvec4 getNormalAndHeight(const unsigned aIndex, const SPFloat* const aK) const;

	/**
	 * @return Size (diameter) of tool.
	 */
	inline SPUInt getSize() const;

private:

	std::vector<glm::cvec4> mNormalHeightMap; /**< Map of normals and heights of tool. */
	SPUInt mSize; /**< Diameter of tool. */
};

} /* namespace SPhysics */

#include "SPWoodTool.inl"

#endif /* _WOOD_TOOL_H_ */
