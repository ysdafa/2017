/*
 * Copyright (c) 2000~2014 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPWObject.h
 * @brief  File Object
 */

#ifndef _SP_WOOD_OBJECT_H_
#define _SP_WOOD_OBJECT_H_

#include "SPMesh.h"
#include "SPObjectData.h"

#include <string>
#include <glm.hpp>

namespace SPhysics
{

/**
 * @brief Contains vertices, indexes & UV data.
 */
class SPWObject
{
public:

	/**
	 * Initialize empty mesh object
	 */
	inline SPWObject();

	/**
	 * Destructor.
	 */
	inline virtual ~SPWObject();

	/**
	 * Translate object.
	 *
	 * @param aValue Vector that describe translation on X, Y, Z coordinates.
	 */
	inline void translateModel(const glm::vec3& aValue);

	/**
	 * Rotate object.
	 *
	 * @param aAngle Angle to rotate.
	 * @param aValue Vector that describe rotation on X, Y, Z coordinates.
	 */
	inline void rotateModel(const float aAngle, const glm::vec3& aValue);

	/**
	 * Set model matrix
	 *
	 * @param aMatrix Model matrix.
	 */
	inline void setModelMatrix(const glm::mat4& aMatrix);

	/**
	 * Update model matrix
	 *
	 * @param aTranform Transformation matrix
	 * @param aTranslate Translation vector
	 */
	inline void updateModelMatrix(const glm::mat3& aTranform, const glm::vec3& aTranslate);

	inline unsigned int getVertexCount() const;
	inline unsigned int getIndexCount() const;
	inline glm::vec3* getPositions3D();
	inline glm::vec3* getNormals();
	inline glm::vec2* getTextureCoords();
	inline unsigned short* getIndexes();

	inline void setVertexCount(unsigned int aVertexCount);
	inline void setIndexCount(unsigned int aIndexCount);
	inline void setPositions3D(glm::vec3* aPositions3D);
	inline void setNormals(glm::vec3* aNormals);
	inline void setTextureCoords(glm::vec2* aTextureCords);
	inline void setIndexes(unsigned short* aIndexes);

	glm::mat4 mModelMatrix; /**<Model matrix*/
private:

	unsigned int mIndexCount;/**<Size of the index array.*/
	unsigned int mVertexCount;/**<Number of vertices in the model.*/

	glm::vec3* mPositions;
	glm::vec3* mNormals;/**< Pointer to the array which stores the normals*/
	glm::vec2* mTextureCoords;/**< Pointer to the array which stores textures coordinates*/
	unsigned short* mIndexes;/**<Index array for vertices (Only for index model).*/
};

} /* namespace SPhysics */

#include "SPWObject.inl"

#endif /* _SP_WOOD_OBJECT_H_ */

