/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPShaving.cpp
 * @brief  Class SPShaving
 * @author Author (a.krenevych@samsung.com)
 */

#include "SPShaving.h"

#include <gtx/compatibility.hpp>
#include <gtc/epsilon.hpp>
#include <gtx/norm.hpp>

#include <string.h>
#include <stdlib.h>

namespace SPhysics
{

SPShaving::SPShaving(const SPUInt aCapacity,
				 const SPFloat aRatio,
				 const SPFloat aMult,
				 const SPFloat aMaxShavingLength) :
		mPlanePositions(aCapacity),
		mSize(0),
		mMinPointCount(4),
		mLeftLength(0.f),
		mRightLength(0.f),
		mMaxShavingLength(aMaxShavingLength),
		mMaxSegmentLength(0.01f * aMult),
		mIsBrokenFromWood(false),
		mOneDivRatio(1.0f / aRatio),
		mMult(aMult),
		mHalfDivMult(0.5f / aMult),
		mVertShift(0.005f)
{
	mPlanePositions.resize(0);

	mObject[0].setIndexes(NULL);
	mObject[0].setVertexCount(2);
	mObject[0].setIndexCount(2);
	mObject[0].setNormals(new glm::vec3[aCapacity]);
	mObject[0].setTextureCoords(new glm::vec2[aCapacity]);
	mObject[0].setPositions3D(new glm::vec3[aCapacity]);

	mObject[1].setIndexes(NULL);
	mObject[1].setVertexCount(2);
	mObject[1].setIndexCount(2);
	mObject[1].setNormals(new glm::vec3[aCapacity]);
	mObject[1].setTextureCoords(new glm::vec2[aCapacity]);
	mObject[1].setPositions3D(new glm::vec3[aCapacity]);

	for (SPUInt i = 0; i < aCapacity; i++)
	{
		mObject[0].getNormals()[i] = glm::vec3(0, 0, 1);
		mObject[0].getTextureCoords()[i] = mObject[1].getTextureCoords()[i] = glm::vec2(0, 0);
		mObject[1].getNormals()[i] = -mObject[0].getNormals()[i];
	}
}

SPShaving::~SPShaving()
{
	delete[] mObject[0].getNormals();
//	delete[] mObject[0].getTextureCoords();
	delete[] mObject[0].getPositions3D();

	delete[] mObject[1].getNormals();
//	delete[] mObject[1].getTextureCoords();
	delete[] mObject[1].getPositions3D();
}

SPVoid SPShaving::addSegment(const glm::vec2 aLeftPoint,
						 const glm::vec2 aRightPoint,
						 const SPBool aAddAsNewSegment,
						 const SPBool aToSpin)
{
	if (mSize == 0)
	{
		mPlanePositions.push_back(aLeftPoint);
		mPlanePositions.push_back(aRightPoint);
		mSize += 2;

		initObjectPositionByPlain(0);
		updateSecondObjectPositions(0);
	}
	else if (mSize < mMinPointCount || isCurrentSegmentTooLong() || aAddAsNewSegment)
	{
		mLeftLength += glm::distance(aLeftPoint, mPlanePositions[mSize - 2]);
		mRightLength += glm::distance(aRightPoint, mPlanePositions[mSize - 1]);

		mPlanePositions.push_back(aLeftPoint);
		mPlanePositions.push_back(aRightPoint);
		mSize += 2;

		if (aToSpin)
		{
			spin();
		}
		else
		{
			initObjectPositionByPlain(mSize - 2);
			updateSecondObjectPositions(mSize - 2);
		}
	}
	else
	{
		mLeftLength -= glm::distance(mPlanePositions[mSize - 2], mPlanePositions[mSize - 4]);
		mRightLength -= glm::distance(mPlanePositions[mSize - 1], mPlanePositions[mSize - 3]);

		mLeftLength += glm::distance(aLeftPoint, mPlanePositions[mSize - 4]);
		mRightLength += glm::distance(aRightPoint, mPlanePositions[mSize - 3]);

		mPlanePositions[mSize - 2] = aLeftPoint;
		mPlanePositions[mSize - 1] = aRightPoint;

		initObjectPositionByPlain(mSize - 2);
		updateSecondObjectPositions(mSize - 2);
	}
	updateTextureCoords();
}

SPVoid SPShaving::spin()
{
	glm::vec3 ortOfRotationAxis(
			glm::normalize(mPlanePositions[mSize - 2] - mPlanePositions[mSize - 1]), 0.f);

	SPFloat angleRotation(glm::half_pi<SPFloat>() / (mMult * (1.0f + mLeftLength)));

	glm::mat3 transformationMatrix = glm::mat3(
			glm::rotate(angleRotation, ortOfRotationAxis));

	initObjectPositionByPlain(mSize - 2);
	updateSecondObjectPositions(mSize - 2);

	glm::vec3 nextLeft = mObject[0].getPositions3D()[mSize - 4] - mObject[0].getPositions3D()[mSize - 2];
	glm::vec3 nextRight = mObject[0].getPositions3D()[mSize - 3] - mObject[0].getPositions3D()[mSize - 1];

	for (SPUInt i = mSize - 4; i >= 2; i -= 2)
	{
		glm::vec3 rotatedLeft = transformationMatrix * nextLeft;
		nextLeft = mObject[0].getPositions3D()[i - 2] - mObject[0].getPositions3D()[i];
		mObject[0].getPositions3D()[i] = mObject[0].getPositions3D()[i + 2] + rotatedLeft;
		mObject[0].getNormals()[i] = transformationMatrix * mObject[0].getNormals()[i];

		glm::vec3 rotatedRight = transformationMatrix * nextRight;
		nextRight = mObject[0].getPositions3D()[i - 1] - mObject[0].getPositions3D()[i + 1];
		mObject[0].getPositions3D()[i + 1] = mObject[0].getPositions3D()[i + 3] + rotatedRight;
		mObject[0].getNormals()[i + 1] = transformationMatrix * mObject[0].getNormals()[i + 1];

		updateSecondObjectPositions(i);
		updateSecondObjectNormals(i);
	}
	glm::vec3 rotatedLeft = transformationMatrix * nextLeft;
	mObject[0].getPositions3D()[0] = mObject[0].getPositions3D()[2] + rotatedLeft;
	mObject[0].getNormals()[0] = transformationMatrix * mObject[0].getNormals()[0];

	glm::vec3 rotatedRight = transformationMatrix * nextRight;
	mObject[0].getPositions3D()[1] = mObject[0].getPositions3D()[3] + rotatedRight;
	mObject[0].getNormals()[1] = transformationMatrix * mObject[0].getNormals()[1];

	updateSecondObjectPositions(0);
	updateSecondObjectNormals(0);

}

SPVoid SPShaving::finalize(const SPFloat aAngle, glm::vec2 aVelocity, SPBool aIsBreak)
{
	mIsBrokenFromWood = true;
	mVelocity += glm::vec3(aVelocity, 0.f);

	if (mSize <= 2 || aIsBreak)
	{
		return;
	}
	finalizeSegments(aAngle);

	glm::vec3 center;

	for (SPUInt i = 0; i < mSize; i++)
	{
		center += mObject[0].getPositions3D()[i];
	}

	center /= mSize;

	mMassCenter = center;

	center = -center;

	for (SPUInt i = 0; i < mSize; i++)
	{
		mObject[0].getPositions3D()[i] += center;
		mObject[1].getPositions3D()[i] += center;
	}
}

SPVoid SPShaving::step()
{
	if (mSize <= 2)
	{
		return;
	}

	mObject[0].setVertexCount(mSize);
	mObject[0].setIndexCount(mSize);
	mObject[1].setVertexCount(mSize);
	mObject[1].setIndexCount(mSize);

	if (mIsBrokenFromWood)
	{
		applyTransformations();
		applyTransformations();    //Second apply needs to prevent penetration.

		mObject[1].mModelMatrix = mObject[0].mModelMatrix;

		mShavingPosition += mVelocity;
		mVelocity += glm::vec3(mGravity, 0.0f);
	}
}

SPBool SPShaving::isVisible(glm::vec4 aVisibleArea)
{
	if (!mIsBrokenFromWood || mSize <= 2)
	{
		return true;
	}

	glm::vec2 startPosition(mMassCenter + mShavingPosition + mObject[0].getPositions3D()[mSize - 2]);
	glm::vec2 endPosition(mMassCenter + mShavingPosition + mObject[0].getPositions3D()[0]);

	SPBool start = startPosition.x >= aVisibleArea.x && startPosition.x <= aVisibleArea.z
				 && startPosition.y >= aVisibleArea.y && startPosition.y <= aVisibleArea.w;

	SPBool end = endPosition.x >= aVisibleArea.x && endPosition.x <= aVisibleArea.z
			   && endPosition.y >= aVisibleArea.y && endPosition.y <= aVisibleArea.w;

	return start || end;
}

SPVoid SPShaving::finalizeSegments(SPFloat aAngle)
{
	aAngle += glm::half_pi<SPFloat>();

	glm::vec2 middle = 0.5f * (mPlanePositions[mSize - 2] + mPlanePositions[mSize - 1]);
	SPFloat r = 0.5f * glm::distance(mPlanePositions[mSize - 2], mPlanePositions[mSize - 1]);

	SPFloat start = glm::half_pi<SPFloat>() * 0.4166666666666667f;    //  * 5/12.f;
	SPFloat decrement = glm::half_pi<SPFloat>() * 0.1f;
	for (SPFloat shift = start; shift >= 0; shift -= decrement)
	{
		glm::vec2 left = middle + r * glm::vec2(glm::cos(aAngle + shift), glm::sin(aAngle + shift));
		glm::vec2 right = middle
						  + r * glm::vec2(glm::cos(aAngle - shift), glm::sin(aAngle - shift));
		addSegment(left, right, true, false);
		updateTextureCoords();
	}
}

SPVoid SPShaving::updateTextureCoords()
{
	mObject[0].getTextureCoords()[mSize - 2].x = mPlanePositions[mSize - 2].x * mHalfDivMult
											 * mOneDivRatio
											 + 0.5f;
	mObject[0].getTextureCoords()[mSize - 2].y = mPlanePositions[mSize - 2].y * mHalfDivMult + 0.5f;
	mObject[0].getTextureCoords()[mSize - 1].x = mPlanePositions[mSize - 1].x * mHalfDivMult
											 * mOneDivRatio
											 + 0.5f;
	mObject[0].getTextureCoords()[mSize - 1].y = mPlanePositions[mSize - 1].y * mHalfDivMult + 0.5f;

	mObject[1].getTextureCoords()[mSize - 1].x = mObject[0].getTextureCoords()[mSize - 2].x;
	mObject[1].getTextureCoords()[mSize - 1].y = mObject[0].getTextureCoords()[mSize - 2].y;
	mObject[1].getTextureCoords()[mSize - 2].x = mObject[0].getTextureCoords()[mSize - 1].x;
	mObject[1].getTextureCoords()[mSize - 2].y = mObject[0].getTextureCoords()[mSize - 1].y;
}

} /* namespace SPhysics */

