#include "SPDefines.h"
#include "SPLog.h"
#include "SPSyncParallelFunc.h"

namespace SPhysics
{
#define SET_AVAILABLE_THREAD(bits, pos)			(bits |= (0x1 << pos))
#define CLEAR_AVAILABLE_THREAD(bits, pos)		(bits &= ~(0x1 << pos))
#define IS_AVAILABLE_THREAD(bits, pos)			((bits >> pos) & 0x1)

	/**
	 * @class SPAsyncLocalThread
	 * @brief Asynchronous local thread
	 */
	class SPAsyncLocalThread
	{
	public:
		SPVoid*				m_arg;		//!< Argument
		SPInt				m_threadID;	//!< Thread ID
		SPBool				m_bRun;		//!< Run flag
		SPBool				m_bBusy;	//!< Busy flas
		SPVoid				(*m_function)(void* arg);	//!< Function pointer

		SPInt*				m_pManagerAvailableThread;	//!< Available thread
		pthread_cond_t*		m_manager_condWait;			//!< Condition
		pthread_mutex_t*	m_manager_mutex;			//!< Mutex

	private:
		SPBool				m_isCreated;
		pthread_t			m_thread;
		pthread_mutex_t		m_mutex;
		pthread_cond_t		m_condWait;
			

	public:

		/**
		 * @brief Contructor
		 */
		SPAsyncLocalThread(SPInt threadID, pthread_mutex_t* manager_mutex, pthread_cond_t* manager_condWait, SPInt* managerAvailableThread):
			m_arg(NULL),
			m_bRun(false),
			m_bBusy(false),
			m_function(NULL),
			m_thread(0)
		{
			m_isCreated = SPFALSE;
			
			m_threadID				= threadID;
			m_manager_mutex			= manager_mutex;
			m_manager_condWait		= manager_condWait;
			m_pManagerAvailableThread = managerAvailableThread;

			pthread_mutex_init(&m_mutex, SPNULL);
			pthread_cond_init(&m_condWait, SPNULL);
		}
		virtual ~SPAsyncLocalThread()
		{
			if (m_isCreated)
			{
				m_bRun = SPFALSE;
				pthread_mutex_lock(&m_mutex);
				pthread_cond_signal(&m_condWait);
				pthread_mutex_unlock(&m_mutex);

				SPVoid* ret;
				pthread_join(m_thread, &ret);
			}

			pthread_mutex_destroy(&m_mutex);
			pthread_cond_destroy(&m_condWait);
		}

		/**
		 * @brief Local thread func
		 */
		static SPVoid* localThreadFunc(SPVoid* arg)
		{
			SPAsyncLocalThread* thread = (SPAsyncLocalThread*)arg;

			while (thread->m_bRun)
			{
				pthread_mutex_lock(&thread->m_mutex);
				thread->m_bBusy = SPTRUE;
				pthread_mutex_unlock(&thread->m_mutex);
				//SP_LOGE("thread is run (threadID = %d, func = %p, arg = %p)", thread->m_threadID, thread->m_function, thread->m_arg);
				if (thread->m_function)
				{
					thread->m_function(thread->m_arg);
					thread->m_function = SPNULL;
				}

				//SP_LOGE("thread function is done (threadID = %d, condWait = %p, availableThread = %p)", thread->m_threadID, thread->m_manager_condWait, thread->m_pManagerAvailableThread);

				pthread_mutex_lock(&thread->m_mutex);
				if (thread->m_manager_condWait)
				{
					pthread_mutex_lock(thread->m_manager_mutex);
					SET_AVAILABLE_THREAD(*(thread->m_pManagerAvailableThread), thread->m_threadID);
					pthread_cond_signal(thread->m_manager_condWait);
					pthread_mutex_unlock(thread->m_manager_mutex);
				}

				pthread_cond_wait(&thread->m_condWait, &thread->m_mutex);
				pthread_mutex_unlock(&thread->m_mutex);
			}

			return SPNULL;
		}


		/**
		 * @brief execute
		 */
		SPVoid execute(SPVoid (*function)(SPVoid*), SPVoid* argment)
		{
			if (m_isCreated == SPFALSE)
			{
				m_function	= function;
				m_arg		= argment;
				m_bRun		= SPTRUE;
				
				//SP_LOGE("creating thread for threadID = %d", m_threadID);
				int err = pthread_create(&m_thread, SPNULL, SPAsyncLocalThread::localThreadFunc, this);
				if (err == 0) // if (m_thread != SPNULL) changed because in MinGW m_thread is structure and have not "!=" operator.
					m_isCreated = SPTRUE;
				else
					SP_LOGE("Error : creating thread is failed: %i", err);
			}
			else
			{
				m_function	= function;
				m_arg		= argment;

				pthread_mutex_lock(&m_mutex);
				pthread_cond_signal(&m_condWait);
				pthread_mutex_unlock(&m_mutex);
			}
		}
	};


	SPSyncParallelFunc::SPSyncParallelFunc():
		m_threadCount(0)
	{
		m_bWaiting			= SPFALSE;
		m_nInitedThread		= 0;
		m_nAvailableThread	= 0;
		pthread_mutex_init(&m_nThreadMutex, NULL);
		pthread_cond_init(&m_nThreadCondWait, NULL);

		for (SPInt pos = 0; pos < MAX_RUNNING_ASYNC_TASK_COUNT; pos++)
		{
			m_pThread[pos] = new SPAsyncLocalThread(pos, &m_nThreadMutex, &m_nThreadCondWait, &m_nAvailableThread);
			if (m_pThread[pos])
			{
				SET_AVAILABLE_THREAD(m_nInitedThread, pos);
				SET_AVAILABLE_THREAD(m_nAvailableThread, pos);
			}
			else
				SP_LOGE("Error : creating thread is failed");
		}
	}

	SPSyncParallelFunc::~SPSyncParallelFunc()
	{
		for (SPInt pos = 0; pos < MAX_RUNNING_ASYNC_TASK_COUNT; pos++)
		{
			SP_SAFE_DELETE(m_pThread[pos]);
		}
		pthread_mutex_destroy(&m_nThreadMutex);
		pthread_cond_destroy(&m_nThreadCondWait);
	}

	SPVoid SPSyncParallelFunc::execute(SPVoid (*function)(SPVoid*), SPVoid* argument)
	{
		SPInt pos = -1;

		while (pos < 0)
		{
			pthread_mutex_lock(&m_nThreadMutex);
			{
				pos = ffs_32(m_nAvailableThread);
				if (pos >= 0)
				{
					//SP_LOGE("thread is available %d", pos);
					CLEAR_AVAILABLE_THREAD(m_nAvailableThread, pos);
				}
				else
				{
					//SP_LOGE("waiting available thread (%d)", pos);
					pthread_cond_wait(&m_nThreadCondWait, &m_nThreadMutex);
				}
			}
			pthread_mutex_unlock(&m_nThreadMutex);
		}

		//SP_LOGE("%d thread is excuting", pos);
		m_pThread[pos]->execute(function, argument);
		//SP_LOGE("%d thread is excuted", pos);
	}

	SPVoid SPSyncParallelFunc::wait()
	{
		SPBool flagRun = isRun();
		while (flagRun)
		{
			pthread_mutex_lock(&m_nThreadMutex);
			{
				pthread_cond_wait(&m_nThreadCondWait, &m_nThreadMutex);
				flagRun = (SPBool)(m_nInitedThread != m_nAvailableThread);
				//SP_LOGE("wait %x %x", m_nInitedThread, m_nAvailableThread);
			}
			pthread_mutex_unlock(&m_nThreadMutex);
		}
	}

	SPBool SPSyncParallelFunc::isRun()
	{
		SPBool ret;

		pthread_mutex_lock(&m_nThreadMutex);
		{
			ret = (SPBool)(m_nInitedThread != m_nAvailableThread);
		}
		pthread_mutex_unlock(&m_nThreadMutex);

		return ret;
	}
}