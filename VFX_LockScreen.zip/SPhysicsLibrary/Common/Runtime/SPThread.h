/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPThread.h
 * @brief  File SPThread
 * @author Author Arthur Yusupov (a.yusupov@samsung.com)
 */

#ifndef _SP_THREAD_H_
#define _SP_THREAD_H_

#include "SPNonCopyable.h"
#include "SPPthread.h"

namespace SPhysics
{

/**
 * SPThread.
 */
class SPThread: NonCopyable
{
public:

	typedef void* (*PThreadFunction)(void*);	//!< Pointer to function

	/**
	 * Constructor.
	 */
	inline SPThread();

	/**
	 * @brief Constructor.
	 *
	 * @tparam aFunction Function that will be started in new SPThread..
	 * @param aArgument Argument that will passed to function in new SPThread.
	 */
	template<typename FunctionArgumentType>
	inline SPThread(void * (aFunction)(FunctionArgumentType), const FunctionArgumentType aArgument);

	/**
	 * @brief Destructor.
	 * SPThread will be joined before destruction.
	 */
	inline ~SPThread();

	/**
	 * Set current SPThread name.
	 * @param aName SPThread name.
	 */
	inline static void setCurrentThreadName(const char* const aName);

	/**
	 * @brief Create new SPThread.
	 *
	 * @tparam aFunction Function that will be started in new SPThread..
	 * @param aArgument Argument that will passed to function in new SPThread.
	 */
	template<typename FunctionArgumentType>
	inline void create(void * (aFunction)(FunctionArgumentType), const FunctionArgumentType aArgument);

	/**
	 * Start 'user function' in new SPThread with given argument.
	 */
	inline void start();

	/**
	 * Wait until SPThread is terminated.
	 * @return Address, which returned by SPThread.
	 */
	inline void* join();

	/**
	 * Get count of processors.
	 *
	 * @return Count of processors.
	 */
	inline static unsigned int getProcessorsCount();

	/**
	 * Get Tick count. 1 tick = 1msec. 1000 ticks = 1sec.
	 *
	 * @return Current tick count. 1 tick = 1msec. 1000 ticks = 1sec.
	 */
	inline static unsigned long getTickCount();

	/**
	 * @brief Get Tick count. 1 tick = 1usec. 1000000 ticks = 1sec.
	 *
	 * @return Current tick count. 1 tick = 1usec. 1000000 ticks = 1sec.
	 */
	inline static unsigned long long getUTickCount();

	/**
	 * Sleep current SPThread for the given time. 1000 = 1sec.
	 * On Android minimum interval is 4 ticks.
	 *
	 * @param aTime Sleep time. 1000 = 1sec.
	 */
	inline static void sleep(const unsigned long aTime);

	/**
	 * Sleep current SPThread for the given time. 1000000 = 1sec.
	 * On Android minimum interval is 4 ticks.
	 *
	 * @param aTime Sleep time. 10000000 = 1sec.
	 */
	inline static void uSleep(const unsigned long long aTime);

private:

	/**
	 * Determine count of physical processors.
	 *
	 * @return Count of physical processors.
	 */
	inline static unsigned int determineProcessorsCount();

	pthread_t mThread; /**<SPThread*/
	PThreadFunction mFunction;/**<User function*/
	void* mArgument; /**<Argument that will be passed to 'user function'.*/
	bool mIsTerminated; /**<Is SPThread terminated.*/
};

} /* namespace SPhysics */

#include "SPThread.inl"

#endif /* _SP_THREAD_H_ */
