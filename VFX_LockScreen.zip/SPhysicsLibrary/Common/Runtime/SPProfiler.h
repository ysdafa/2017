/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPProfiler.h
 * @brief  File SPProfiler
 * @author Author Arthur Yusupov (a.yusupov@samsung.com)
 */

#ifndef _SP_PROFILER_H_
#define _SP_PROFILER_H_

#include "SPLog.h"
#include "SPThread.h"

#include <vector>
#include <string>

//#define PROFILING_ENABLED

#ifdef PROFILING_ENABLED

/**
 * Start profiling section with given name.
 * @param NAME Section name.
 */
#define PROF_START(NAME)													\
	static unsigned int __profId##NAME = SPhysics::SPProfiler::create(#NAME);	\
	unsigned long long __startTime##NAME = SPhysics::SPThread::getUTickCount();	\
	 

/**
 * End profiling section.
 */
#define PROF_END(NAME) SPhysics::SPProfiler::addTime(__profId##NAME, SPhysics::SPThread::getUTickCount() - __startTime##NAME);

/**
 * Print all collected information.
 */
#define PROF_PRINT SPhysics::SPProfiler::print();

/**
 * Clear all collected information.
 */
#define PROF_CLEAR SPhysics::SPProfiler::clear();

#else

#define PROF_START(NAME)	//!< Prof start

#define PROF_END(NAME)		//!< Prof end

#define PROF_PRINT			//!< Prof print

#define PROF_CLEAR			//!< Prof clear

#endif

namespace SPhysics
{

/**
 * @class SPProfiler
 * @brief Profiler
 */
class SPProfiler
{
public:

	/**
	 * @brief Create
	 */
	inline static unsigned int create(const std::string& aName);

	/**
	 * @brief Add time
	 */
	inline static void addTime(const unsigned int aId, const unsigned long long aTime);

	/**
	 * @brief Print
	 */
	inline static void print();

	/**
	 * @brief Clear
	 */
	inline static void clear();

	/**
	 * @brief Get all profilers
	 */
	inline static std::vector<SPProfiler>& getAllProfilers();

	std::string mName;					//!< Name
	volatile unsigned long long mTime;	//!< Time
	volatile unsigned long mCount;		//!< Count

private:

	inline SPProfiler();

	inline SPProfiler(const std::string& aName);
};

} /* namespace SPhysics */

#include "SPProfiler.inl"

#endif /* _SP_PROFILER_H_ */
