/**
* @file SPDefines.h
* @brief The header file for Defines.
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/


#ifndef _SP_DEFINES_H_
#define _SP_DEFINES_H_

#ifdef TIZEN
#include <Elementary.h>
#include <Elementary_GL_Helpers.h>
EVAS_GL_GLOBAL_GLES2_DECLARE()
#else
#include "GLES2/gl2.h"
#endif
#include "SPDataTypeDef.h"
#include "SPPlatformEventDef.h"
#include "SPVectorTypeDef.h"
#include "SPMatrixTypeDef.h"

namespace SPhysics
{



#define SP_SAFE_FREE(x) if (x != NULL) {free(x); x = NULL;}				//!< Safe free
#define SP_SAFE_DELETE(x) if (x != NULL) {delete x; x = NULL;}			//!< Safe delete
#define SP_SAFE_DELETE_ARRAY(x) if (x != NULL) {delete [] x; x = NULL;}	//!< Safe delete array
#define SP_SAFE_RELEASE(x) if (x != NULL) {(x)->release(); x = NULL;}	//!< Safe release
#define SP_SAFE_ADDREF(x) if(x != NULL) { (x)->addRef(); }				//!< Safe addRef()

#define POSTIVE_CAMERA_ALIGN  0	//!< Positive camera align
#define CENTER_CAMERA_ALIGN  1	//!< Center camera align


#define ANDROID_PORTING_MODE			0	//!< Android porting mode
}  //namespace SPhysics

#endif // _SP_DEFINES_H_

