#include "SPTimeLog.h"

#include <string.h>



namespace SPhysics
{
#if defined(__ANDROID__) || defined (__LINUX__)

#include <time.h>
#include <sys/types.h>
#include <unistd.h>

#elif defined(_WIN32) || defined(_WIN64)
#define NOMINMAX
#include <windows.h>
__int64	gUsPerFreq;

#endif

#define TIME_LOG_NAME_LENGTH	256


/**
 * @struct _SPTimeLogData
 * @brief Time log data
 */
typedef struct _SPTimeLogData
{
	SPULong		totalTime;		//!< Total time
	SPUInt		prevTime;		//!< Precious time
	SPFloat		avgInterval;	//!< Average interval
	SPUInt		count;			//!< Count
	SPChar		name[TIME_LOG_NAME_LENGTH];	//!< Name
} SPTimeLogData;

SPTimeLogData				gTimeLog[MAX_TIME_LOG_CHANNEL_COUNT];
SPTimeLog::SP_TIME_LOG_MODE	gTimeMode = SPTimeLog::SP_TIME_LOG_NORMAL_MODE;
SPBool						gTimeLogEnable = SPFALSE;
SPBool						gChannelEnable[MAX_TIME_LOG_CHANNEL_COUNT]	= {SPFALSE};

SPUInt						g_nFrameCount = 0;
bool						g_bSettedStartTime = SPFALSE;
SPULong						g_nStartTime, g_nEndTime;


SPVoid SPTimeLog::setupTimeLog(SP_TIME_LOG_MODE mode)
{
	if (!gTimeLogEnable)
	{
#if defined(_WIN32) || defined(_WIN64)
		LARGE_INTEGER frequency;
		QueryPerformanceFrequency(&frequency);
		gUsPerFreq = frequency.QuadPart / 1000000;
#endif
		gTimeMode = mode;
	}
	else
		SP_LOGE("Error : you setuped during running.");
}


SPVoid SPTimeLog::enableTimeLog(SPInt channel /* = -1 */)
{
	if (!gTimeLogEnable)
	{
		if (channel == -1)
		{
			SPInt pos;
			for (pos = 0; pos < MAX_TIME_LOG_CHANNEL_COUNT; pos++)
			{
				SPTimeLogData* timeLog = &gTimeLog[pos];
				timeLog->prevTime		= 0;
				timeLog->avgInterval	= 0.0f;
				timeLog->count			= 0;
				timeLog->totalTime		= 0;
			}
			gTimeLogEnable = SPTRUE;
			g_bSettedStartTime = SPFALSE;
			g_nFrameCount = 0;
		}
		else if (channel < MAX_TIME_LOG_CHANNEL_COUNT)
		{
			SPTimeLogData* timeLog = &gTimeLog[channel];
			timeLog->prevTime		= 0;
			timeLog->avgInterval	= 0.0f;
			timeLog->count			= 0;
			timeLog->totalTime		= 0;
			
			gChannelEnable[channel]			= SPTRUE;
		}
		else
			SP_LOGE("Error : Invalied Channel (channel = %d)", channel);
	}
// 	else
// 		SP_LOGE("Error : it is already enabled (channel = %d)", channel);
}
	
SPVoid SPTimeLog::disableTimeLog(SPInt channel /* = -1 */)
{
	if (gTimeLogEnable)
	{
		if (channel == -1)
		{
			SPInt pos;
			for (pos = 0; pos < MAX_TIME_LOG_CHANNEL_COUNT; pos++)
			{
				gChannelEnable[pos] = SPFALSE;
			}
			gTimeLogEnable = SPFALSE;
		}
		else if (channel < MAX_TIME_LOG_CHANNEL_COUNT)
			gChannelEnable[channel] = SPFALSE;
		else
			SP_LOGE("Error : Invalied Channel (channel = %d)", channel);
	}
}

#if (!SP_TIME_LOG)

SPInt  SPTimeLog::setStartTimeLog(SPInt channel) { return 0; }
SPVoid SPTimeLog::setStartTimeLog(SPInt channel, SPInt time) {}
SPInt SPTimeLog::setEndTimeLog(SPInt channel, const  SPChar* tag, const SPChar* functionName, SPUInt IntervalLowBound) { return 0; }
#else


SPInt SPTimeLog::setStartTimeLog(SPInt channel /* = 0 */)
{
	if (!gTimeLogEnable && !gChannelEnable[channel])
		return 0;

	SPTimeLogData* log = &gTimeLog[channel];	
	
#if defined(__ANDROID__) || defined (__LINUX__)

	timeval time;
	gettimeofday(&time, SPNULL);
	log->prevTime = time.tv_sec * 1000000 + time.tv_usec;

#elif defined(_WIN32) || defined(_WIN64)
	LARGE_INTEGER	time;
	QueryPerformanceCounter(&time);
	log->prevTime = (SPUInt)((SPDouble)time.QuadPart / (SPDouble)gUsPerFreq);
#endif
	log->count++;

	return log->prevTime;
}

SPVoid SPTimeLog::setStartTimeLog(SPInt channel, SPInt time)
{
	if (!gTimeLogEnable && !gChannelEnable[channel])
		return;

	SPTimeLogData* log = &gTimeLog[channel];
	log->prevTime = time;
	log->count++;
}

SPInt SPTimeLog::setEndTimeLog(SPInt channel /* = 0 */, const SPChar* tag /* SPNULL */, const SPChar* functionName /* = SPNULL */, SPUInt usIntervalLowBound /* = 1000000 us */)
{
	if (!gTimeLogEnable && !gChannelEnable[channel])
		return 0;

	SPUInt  endTime(0);

#if defined(__ANDROID__) || defined (__LINUX__)
	timeval time;
	gettimeofday(&time, SPNULL);
	endTime = SPUInt(time.tv_sec * 1000000 + time.tv_usec);
#elif defined(_WIN32) || defined(_WIN64)
	LARGE_INTEGER	time;
	QueryPerformanceCounter(&time);
	endTime = SPUInt(time.QuadPart / gUsPerFreq);
#endif

	if (gTimeLog[channel].count > 0)
	{
		SPTimeLogData* log = &gTimeLog[channel];

		SPUInt		startTime = log->prevTime;

		SPUInt duration;
		if (endTime < startTime || endTime == 0)
		{
			duration = ((unsigned int)(-1) - startTime) + (endTime + 1);
			SP_LOGW("duration = %u, startTime = %u, endTime = %u", duration, startTime, endTime);
		}
		else 
			duration = endTime - startTime;
		if (tag)
		{
			SPChar* tempString;
			SPInt length = strlen(tag);
			if (functionName != SPNULL)
				length += strlen(functionName) + 3;
			else
				length += 3;

			if (length > TIME_LOG_NAME_LENGTH - 1)
			{
				tempString = new SPChar[length];
				sprintf(tempString, "%s(%s)", tag, functionName);
				memcpy(log->name, tempString, TIME_LOG_NAME_LENGTH - 1);
				log->name[TIME_LOG_NAME_LENGTH - 1] = 0;
				delete[] tempString;
			}
			else
			{
				sprintf(log->name, "%s(%s)", tag, functionName);
			}
			

			if (duration > usIntervalLowBound)
			{
				if (functionName)
				{
					SP_LOGW("%s ( %s ) duration = %.3f ms", tag, functionName, duration / 1000.0f);
				}
				else
				{
					SP_LOGW("%s duration = %.3f ms", tag, duration / 1000.0f);
				}
			}
		}
		else
		{
			if (duration > usIntervalLowBound)
			{
				if (functionName)
				{
					SP_LOGW("%s duration = %.3f ms", functionName, duration / 1000.0f);
				}
				else
				{
					SP_LOGW("duration = %.3f ms", duration / 1000.0f);
				}
			}
		}

		switch (gTimeMode)
		{
		case SP_TIME_LOG_NORMAL_MODE:
			log->avgInterval = SPFloat(duration);
			log->totalTime += duration;
			break;

		case SP_TIME_LOG_AVG_MODE:
			log->avgInterval += (SPFloat(duration) - log->avgInterval) / SPFloat(log->count);
			log->totalTime += duration;
			break;

		default:
			SP_LOGE("Invalid mode of Time Log");
		}		
	}
	return endTime;
}
#endif  // (!SP_TIME_LOG)

SPUInt SPTimeLog::getCurrTime()
{
	SPUInt retTime = 0;

#if defined(__ANDROID__) || defined (__LINUX__)
	timeval time;
	gettimeofday(&time, SPNULL);
	retTime = SPUInt(time.tv_sec * 1000000 + time.tv_usec);
#elif defined(_WIN32) || defined(_WIN64)
	LARGE_INTEGER	time;
	QueryPerformanceCounter(&time);
	retTime = SPUInt(time.QuadPart / gUsPerFreq);
#endif

	return retTime;
}

SPVoid SPTimeLog::printAllTimeLog()
{
	SPInt pos;
	for (pos = 0; pos < MAX_TIME_LOG_CHANNEL_COUNT; pos++)
	{
		if (gChannelEnable[pos])
			gChannelEnable[pos] = SPFALSE;

		SPTimeLogData* log = &gTimeLog[pos];
		if (log->count > 0)
		{
			if (log->avgInterval > 0)
			{
				switch (gTimeMode)
				{
				case SP_TIME_LOG_NORMAL_MODE:
					SP_LOGI("SP_TIMELOG : %s (channel = %d), Peak duration = %.3f ms, count = %u, totalDuration = %.3lf ms\n", log->name, pos, (SPFloat)log->avgInterval / 1000.0f, log->count, (SPDouble)log->totalTime / 1000.0);
					break;

				case SP_TIME_LOG_AVG_MODE:
					SP_LOGI("SP_TIMELOG : %s (channel = %d), Average duration = %.3f ms, count = %u, totalDuration = %.3lf ms\n", log->name, pos, (SPFloat)log->avgInterval / 1000.0f, log->count, (SPDouble)log->totalTime / 1000.0);
					break;
				}
			}
		}
	}

	if (g_bSettedStartTime)
	{
		SPULong	 timeDiff;
		timeDiff = g_nEndTime - g_nStartTime;

		SP_LOGI("fps = %.3lf (total time = %lu, count = %u)\n", (SPDouble)g_nFrameCount / (timeDiff / 1000000.0), timeDiff, g_nFrameCount);

		// clear fps for non cumulative value
		g_bSettedStartTime = SPFALSE;
		g_nFrameCount = 0;
	}
}

#if (!SP_TIME_LOG_FPS)
SPVoid SPTimeLog::printAllTimeLog() {}

#else

SPVoid SPTimeLog::setFPSPoint(void)
{
	if (gTimeLogEnable)
	{
		g_nFrameCount++;
		SPULong currTime(0);

#if defined(__ANDROID__) || defined (__LINUX__)
		struct timeval time;
		gettimeofday(&time, SPNULL);
		currTime = time.tv_sec * 1000000 + time.tv_usec;	
#elif defined(_WIN32) || defined(_WIN64)
		LARGE_INTEGER time;
		QueryPerformanceCounter(&time);
		currTime = (SPULong)(time.QuadPart / gUsPerFreq);
#endif
		if (g_bSettedStartTime == SPFALSE)
		{
			g_bSettedStartTime = SPTRUE;
			g_nStartTime = currTime;
			g_nEndTime = currTime;
		}
		else
			g_nEndTime = currTime;
	}
}
#endif // (!SP_TIME_LOG_FPS)
}
