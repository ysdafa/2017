/**
* @file SPList.h
* @brief This files is the implementation of Button UI Modules.
*
* @date 2014-09-03
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/
#ifndef _SP_LIST_H_
#define _SP_LIST_H_

#include "SPDefines.h"
#include <assert.h>

namespace SPhysics
{
	/**
	* @class     SPList
	* @brief     List data structure class
	*/
	template <typename T>
	class SPList
	{
	public:
		/**
		 * @struct _SP_LIST_NODE
		 * @brief Node list
		 */
		typedef struct _SP_LIST_NODE
		{
			_SP_LIST_NODE*	prev;	//!< Previous
			_SP_LIST_NODE*	next;	//!< Next
			T				data;	//!< Data
		} SP_LIST_NODE;	//!< Node list

	public:
		/**
		* @brief	 Constructor  
		*/
		SPList()
		{
			m_pHead	= SPNULL;
			m_pTail	= SPNULL;
			m_nCount = 0;
		}

		/**
		* @brief	 Destructor  
		*/
		virtual ~SPList()
		{
			assert(m_nCount == 0);
		}
		
		/**
		* @brief	 Push to back of list
		* @param     [IN] @b node node of data
		* @return     SPVoid
		*/
		SPVoid push_back(const T& data)
		{
			SP_LIST_NODE* node = alloc();

			node->data = data;
			if (m_nCount == 0)
			{
				node->prev	= SPNULL;
				node->next  = SPNULL;

				m_pHead = node;
				m_pTail = node;
			}
			else
			{
				node->prev		= m_pTail;
				node->next		= SPNULL;

				m_pTail->next	= node;			
				m_pTail			= node;
			}
			m_nCount++;
		}

		/**
		* @brief	 Push to back of list
		* @param     [IN] @b node node of data
		* @return     SPVoid
		*/
		SPVoid push_back(SP_LIST_NODE* node)
		{
			if (m_nCount == 0)
			{
				node->prev	= SPNULL;
				node->next  = SPNULL;

				m_pHead = node;
				m_pTail = node;
			}
			else
			{
				node->prev		= m_pTail;
				node->next		= SPNULL;

				m_pTail->next	= node;			
				m_pTail			= node;
			}
			m_nCount++;
		}

		/**
		* @brief	 pop pop the first node
		* @return    SP_LIST_NODE*	first item
		*/
		SP_LIST_NODE* pop()
		{
			SP_LIST_NODE* node = m_pHead;
			if (node != SPNULL)
				erase(node);

			return node;
		}

		/**
		* @brief	 pop pop the first node
		* @return    SP_LIST_NODE*	first item
		*/
		SP_LIST_NODE* pop(T& data)
		{
			SP_LIST_NODE* node = m_pHead;
			if (node != SPNULL)
			{
				data = node->data;
				erase(node);
				deAlloc(node);
			}

			return node;
		}

		/**
		* @brief	 erase Erase a item in list
		* @param     [IN] @b node node for erase (no deallocation, just cutting off item from list)
		* @return    SP_LIST_NODE*	next item
		*/
		SP_LIST_NODE* erase(SP_LIST_NODE* node)
		{
			if (node == m_pHead)
			{
				m_pHead	= node->next;

				if (m_pHead == SPNULL)
					m_pTail = SPNULL;
				else
					m_pHead->prev	= SPNULL;
			}
			else
			{
				node->prev->next = node->next;

				if (node == m_pTail)
				{
					m_pTail			= node->prev;
					m_pTail->next	= SPNULL;
				}
				else
				{
					node->next->prev = node->prev;
				}
			}
			m_nCount--;

			return node->next;
		}

		/**
		* @brief	 move Move a item to destination list
		* @param     [IN] @b dstList destination list
		* @param     [IN] @b node node to move
		* @return    SP_LIST_NODE*	next item
		*/
		SP_LIST_NODE* move(SPList* dstList, SP_LIST_NODE* node)
		{
			SP_LIST_NODE* nextNode = erase(node);
			dstList->push_back(node);

			return nextNode;
		}

		/**
		* @brief	 allocate interface for list
		* @return    SP_LIST_NODE<T>*
		*/
		SP_LIST_NODE* alloc()
		{
			SP_LIST_NODE* listNode = new SP_LIST_NODE;
			assert(listNode != SPNULL);
			return listNode;
		}

		/**
		* @brief     deAlloc node
		* @return    SPVoid
		*/
		SPVoid deAlloc(SP_LIST_NODE* node)
		{
			delete node;
		}

		/**
		* @brief	 clear Clear all item in list
		* @return    SPVoid
		*/
		SPVoid clear()
		{
			SP_LIST_NODE* node;
			while ((node = pop())!= SPNULL)
			{
				deAlloc(node);
			}
		}

		SPUInt size()
		{
			return m_nCount;
		}

	public:
		SP_LIST_NODE* m_pHead;	//!< Head
		SP_LIST_NODE* m_pTail;	//!< Trail

		SPUInt m_nCount;	//!< Count
	};
}

#endif