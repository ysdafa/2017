/**
* @file SPGradient.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_GRADIENT_H_
#define _SP_GRADIENT_H_

#include "SPDefines.h"

#include "SPField2DTemplate.h"
#include "SPFaceGrid2D.h"

namespace SPhysics
{
	/**
	* @brief     Calculate the gradient
	* @param     [IN] @b  gradientField gradient field
	* @param     [IN] @b  scalarField scalar field
	* @return     SPVoid
	*/
	template<typename T>
	SPVoid calculateGradient( SPField2DTemplate<SPVec2t >& gradientField, const SPField2DTemplate<T>& scalarField )
	{
		const SPVec2i res = scalarField.getResolution();
		const SPVec2d cellSize = scalarField.getCellSize();
		const SPVec2d cellSize2 = 2.0*cellSize;

		SPInt i0, i1, j0, j1;
		T dx, dy;
		for( SPInt j=0; j<res.y; ++j )
		{
			for( SPInt i=0; i<res.x; ++i )
			{

				if( i==0 )            { i0 = i;   i1 = i+1; dx = (T)cellSize.x;  }
				else if( i==res.x-1 ) { i0 = i-1; i1 = i;   dx = (T)cellSize.x;  }
				else                  { i0 = i-1; i1 = i+1; dx = (T)cellSize2.x; }

				if( j==0 )            { j0 = j;   j1 = j+1; dy = (T)cellSize.y;  }
				else if( j==res.y-1 ) { j0 = j-1; j1 = j;   dy = (T)cellSize.y;  }
				else                  { j0 = j-1; j1 = j+1; dy = (T)cellSize2.y; }

				gradientField(i,j).x = (scalarField(i1,j)-scalarField(i0,j)) / dx;
				gradientField(i,j).y = (scalarField(i,j1)-scalarField(i,j0)) / dy;

			}
		}
	}

	/**
	* @brief     Calculate the gradient
	* @param     [IN] @b  grad grid
	* @param     [IN] @b  scalarField scalar field
	* @return     SPVoid
	*/
	template<typename T>
	SPVoid calculateGradient( SPFaceGrid2D<T>& grad, SPField2DTemplate<T>& scalarField )
	{
		// 	if( !DefinedAtNode( grad ) || !DefinedAtNode( scalar ) ) {
		// 		std::cout<<"Error@calculateGradient(): Invalid location."<<std::endl;
		// 		return;
		// 	}

		const SPVec2i resolution = grad.getResolution();
		const SPVec2d cellSize = grad.getCellSize();
		const SPVec2d gridSize = grad.getDimension();

		for( SPInt j=1; j<resolution.y-1; ++j )
		{
			for( SPInt i=1; i<resolution.x-1; ++i )
			{

			// 		if( i==0 )       { i0 = idx;          i1 = eCELL2D(idx); dx=m_Dx;  }
			// 		else if( i==m_Nx-1 ) { i0 = wCELL2D(idx); i1 = idx;          dx=m_Dx;  }
			// 		else             { i0 = wCELL2D(idx); i1 = eCELL2D(idx); dx=m_Dx2; }
			// 		
			// 		if( j==0 )       { j0 = idx;          j1 = nCELL2D(idx); dy=m_Dy;  }
			// 		else if( j==m_Ny-1 ) { j0 = sCELL2D(idx); j1 = idx;          dy=m_Dy;  }
			// 		else             { j0 = sCELL2D(idx); j1 = nCELL2D(idx); dy=m_Dy2; }

	// 			grad(i,j).x = 
	// 				( scalarField(i,j-1) - scalarField(i-1,j-1) 
	// 				+ scalarField(i,j) - scalarField(i-1,j) ) / 2.0*cellSize.x;
	// 
	// 			grad(i,j).y = 
	// 				( scalarField(i-1,j) - scalarField(i-1,j-1)
	// 				+ scalarField(i,j) - scalarField(i,j-1) ) / 2.0*cellSize.y;
			}
		}
	}
}
#endif //_SP_GRADIENT_H_