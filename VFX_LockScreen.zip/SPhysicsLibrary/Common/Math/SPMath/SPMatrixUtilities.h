/**
* @file SPMatrix2x2.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_MATRIX_UTILITIES_H_
#define _SP_MATRIX_UTILITIES_H_

#include "SPDefines.h"
#include <glm.hpp>
#include <gtc/matrix_transform.hpp>

namespace SPhysics
{
	/**
	* @class SPMatrixUtilities
	* @brief utilities for matrix
	*/
	template <typename T>
	class SPMatrixUtilities
	{
	public:

		static SPMat2x2t getRotationMatrix2(const T& radians)
		{
			return SPMat2x2t(glm::rotate(SPMat4x4t(), radians, glm::vec3(0.0f, 0.0f, 1.0f)));
		}

		/**
		* @brief     Calculate the rotation Matrix3X3
		* @param     [IN] @b  a angle
		* @return     SPMatrix3x3
		*/
		static SPMat3x3t getRotationMatrix3(const T& radians)
		{
			return SPMat3x3t(glm::rotate(SPMat4x4t(), radians, glm::vec3(0.0f, 0.0f, 1.0f)));
		}
	};// class
}

#endif //_SP_MATRIX_UTILITIES_H_

