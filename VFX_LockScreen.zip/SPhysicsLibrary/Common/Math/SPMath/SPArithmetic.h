/**
* @file SPArithmetic.h
* @brief This file provides arithmatic calculation method.
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_ARITHMETIC_H_
#define _SP_ARITHMETIC_H_

#include "SPDefines.h"

#include <math.h>

namespace SPhysics
{
	/**
	* @brief     Calculate the floor
	* @param     [IN] @b x input   value
	* @return    SPInt
	 */	
	template <typename T>
	inline SPInt floor( const T& x )
	{
		return ( (SPInt)x-(x<0&&x!=(SPInt)x) );
	}

	/**
	* @brief	 Calculate the ceiling
	* @param     [IN] @b x input   value
	* @return    SPInt
	 */
	template <typename T>
	inline SPInt ceil( const T& x )
	{
		return ( (SPInt)x+(x>0&&x!=(SPInt)x) );
	}

	/**
	* @brief     Calculate division
	* @param     [IN] @b x input   value
	* @param     [IN] @b y input   value
	* @param     [IN] @b quotient quotient of division
	* @param     [IN] @b remainder remainder of division
	* @return    SPVoid
	 */	
	template <typename T>
	inline SPVoid divide( const T& x, const T& y, SPInt& quotient, T& remainder )
	{
		quotient = (SPInt)(x/y);
		remainder = x - quotient * y;
	}

	/**
	* @brief     Calculate the remainder
	* @param     [IN] @b x input   value
	* @param     [IN] @b y input   value
	* @return    T
	 */
	template <typename T>
	inline T remainder( const T& x, const T& y ) // x / y 
	{
		SPInt quotient = (SPInt)(x/y);
		return ( x - quotient * y );
	}

	/**
	* @brief     Calculate the power of 2
	* @param     [IN] @b x input   value
	* @return    T
	 */
	template <typename T>
	inline T pow2( const T& x )
	{
		return ( x*x );
	}

	/**
	* @brief     Calculate the power of 3
	* @param     [IN] @b  x input   value
	* @return    T
	 */
	template <typename T>
	inline T pow3( const T& x )
	{
		return ( x*x*x );
	}

	/**
	* @brief     Calculate the power of 4
	* @param     [IN] @b x input   value
	* @return    T
	 */
	template <typename T>
	inline T pow4( const T& x )
	{
		T x2 = x*x;
		return ( x2*x2 );
	}

	/**
	* @brief     Calculate the power of 5
	* @param     [IN] @b x input   value
	* @return    T
	 */
	template <typename T>
	inline T pow5( const T& x )
	{
		T x2 = x*x;
		return ( x2*x2*x );
	}

	/**
	* @brief     Calculate the power of 6
	* @param     [IN] @b x input   value
	* @return    T
	 */
	template <typename T>
	inline T pow6( const T& x )
	{
		T x3 = x*x*x;
		return ( x3*x3 );
	}
		
	/**
	* @brief     Calculate a square root of 'x' 
	* @param     [IN] @b x input   value
	* @return    T
	 */
	template <typename T>
	inline T squareRootX( const T& x )
	{
		if(x<0) { return (T)0;       }
		else    { return (T)sqrt(x); }
	}

	/**
	* @brief     Calculate a square root
	* @param     [IN] @b val input   value
	* @return    T
	 */
	template <typename T>
	inline T squareRoot( const T val )
	{
		union
		{
			SPInt i;
			T value;
		} u;

		u.value = val;
		u.i = ( 1 << 29 ) + ( u.i >> 1 ) - ( 1 << 22 ); 
		return u.value;
	}

	/**
	* @brief     Calculate the power of 2 
	* @param     [IN] @b n size of loop
	* @return    SPInt
	 */
	inline SPInt powerOf2( const SPInt& n )
	{
		SPInt result = 1;
		for( SPInt i=0; i<n; ++i )
		{
			result *= 2;
		}
		return result;
	}
		
	/**
	* @brief     Calculate the log2 of number
	* @param     [IN] @b n input   value
	* @return    T
	 */
	template<typename T>
	T Log2( const T& n ) {  
		return log( n ) / log( (T)2.0 );  
	}
		
	/**
	* @brief     Calculate the factorial (x!)
	* @param     [IN] @b x input   value
	* @return    SPDouble
	 */
	inline SPDouble factorial( SPInt x )
	{
		if( x <= 0 ) { return 1.0; }		// 0! = 1

		SPDouble result = 1;

		while(1)
		{
			result *= x--;
			if( x <= 0 ) { break; }
		}

		return result;
	}
}

#endif //_SP_ARITHMETIC_H_

