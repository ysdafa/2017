/**
* @file SPRandom.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_RANDOM_H_
#define _SP_RANDOM_H_

#include "SPDefines.h"

#include <time.h>
#include "SPConstant.h"
#include <stdlib.h>
#include <limits.h>

namespace SPhysics
{
	/**
	* @brief     Generate the seed for Random values
	* @param     [IN] @b  seed seed data , time
	* @return     SPVoid
	*/
	inline SPVoid seed( SPUInt seed=time(SPNULL) )
	{
		srand( seed );
	}

	/**
	* @brief     Generate the Random values , 0~1
	* @return     SPDouble
	*/
	inline SPDouble random() // 0~1
	{
		return ( rand()*ONE_OVER_RAND_MAX );
	}

	/**
	* @brief     Generate the Random values , 0~x	
	* @param     [IN] @b  x input
	* @return     T
	*/
	template <typename T>
	inline T random( const T& x=1 ) // 0~x
	{
		return (T)( x*rand()*ONE_OVER_RAND_MAX );
	}

	/**
	* @brief     Generate the Random values , min~max
	* @param     [IN] @b  min set minimum
	* @param     [IN] @b  max set maximum
	* @return     T
	*/
	template <typename T>
	inline T random( const T& min, const T& max ) // min~max
	{
		return (T)((max-min)*rand()*ONE_OVER_RAND_MAX+min);
	}

	/**
	* @brief     Generate the Random values
	* @param     [IN] @b  a two dimensional vector
	* @param     [IN] @b  b two dimensional vector
	* @return     SPVec2t
	*/
	template <typename T>
	inline SPVec2t random( const SPVec2t& a, const SPVec2t& b )
	{
		return SPVec2t( random( a.x, b.x ), random( a.y, b.y ) );
	}

	/**
	* @brief     Generate the Random values
	* @param     [IN] @b  a three dimensional vector
	* @param     [IN] @b  b three dimensional vector
	* @return     SPVec3t
	*/
	template <typename T>
	inline SPVec3t random( const SPVec3t& a, const SPVec3t& b )
	{
		return SPVec3t( random( a.x, b.x ), random( a.y, b.y ), random( a.z, b.z ) );
	}

	/**
	* @brief     Generate the Random values
	* @param     [IN] @b  a four dimensional vector
	* @param     [IN] @b  b four dimensional vector
	* @return     SPVec4t
	*/
	template <typename T>
	inline SPVec4t random( const SPVec4t& a, const SPVec4t& b )
	{
		return SPVec4t( random( a.x, b.x ), random( a.y, b.y ), random( a.z, b.z ), random( a.w, b.w ) );
	}

	// transforms even the sequence 0,1,2,3,... into random numbers in [0,1]
	/**
	* @brief     Generate the Random values , transforms even the sequence 0,1,2,3,... into random numbers in [0,1]
	* @param     [IN] @b  seed set seed
	* @return     SPDouble
	*/
	inline SPDouble Rand( const SPUInt& seed )
	{
		SPUInt i = (seed^12345391u)*2654435769u;
		i ^= (i<<6)^(i>>26);
		i *= 2654435769u;
		i += (i<<5)^(i>>12);
		return ( i / (SPDouble)UINT_MAX );
	}

	// transforms even the sequence 0,1,2,3,... into random numbers in [a,b]
	/**
	* @brief     Generate the Random values , transforms even the sequence 0,1,2,3,... into random numbers in [a,b]
	* @param     [IN] @b  seed set seed value
	* @param     [IN] @b  a input
	* @param     [IN] @b  b input
	* @return     T
	*/
	template <typename T>
	inline T Rand( const SPUInt& seed, const T& a, const T& b )
	{
		#ifdef DEBUGGING
		 VERIFY(a<b);
		#endif

		return ( (b-a)*(T)Rand(seed) + a );
	}

	// -1 ~ +1
	/**
	* @brief     Generate the Gaussian Noise , -1 ~ +1
	* @return     SPDouble
	*/
	inline SPDouble gaussian()
	{
		SPDouble v1, v2;
		SPDouble s = 0;

		do {

			v1 = 2*random()-1; // -1 ~ +1
			v2 = 2*random()-1; // -1 ~ +1
			s = v1*v1 + v2*v2;

		} while( s >= 1 || s == 0 );

		s = sqrt( ( -2 * log(s) ) / s );
		return ( v1*s );

	}

	// for Perlin noise generation 
	// return value's range: [-1,+1]
	/**
	* @brief     Generate the Noise for Perlin noise
	* @param     [IN] @b x input
	* @param     [IN] @b seed seed
	* @return     SPDouble
	*/
	inline SPDouble generateNoise1( SPInt x, SPInt seed=0 )
	{
		SPInt n = x;
		n = (n<<13)^n;
		return (1-((n*(n*n*15731+789221)+1376312589)&0x7fffffff)/1073741824.f);
	}

	/**
	* @brief     Generate the Noise for Perlin noise
	* @param     [IN] @b x integer input
	* @param     [IN] @b y integer input
	* @param     [IN] @b  seed seed
	* @return     SPDouble
	*/
	inline SPDouble generateNoise2( SPInt x, SPInt y, SPInt seed=0 )
	{
		SPInt n = x+(y*57)+seed;
		n = (n<<13)^n;
		return (1-((n*(n*n*15731+789221)+1376312589)&0x7fffffff)/1073741824.f);
	}

	/**
	* @brief     Generate the Noise for Perlin noise
	* @param     [IN] @b x integer input
	* @param     [IN] @b y integer input
	* @param     [IN] @b z integer input
	* @param     [IN] @b seed seed
	* @return     SPDouble
	*/
	inline SPDouble generateNoise3( SPInt x, SPInt y, SPInt z, SPInt seed=0 )
	{
		SPInt n = x+(y*47)+(z*13)+seed;
		n = (n<<13)^n;
		return (1-((n*(n*n*15731+789221)+1376312589)&0x7fffffff)/1073741824.f);
	}
}
#endif //_SP_RANDOM_H_
