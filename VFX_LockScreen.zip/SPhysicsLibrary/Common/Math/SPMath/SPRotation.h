/**
* @file SPRotation.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_ROTATION_H_
#define _SP_ROTATION_H_

#include "SPDefines.h"
#include "SPOperations.h"
#include <glm.hpp>

namespace SPhysics
{
	/**
	* @brief     Convert quaternion to rotation matrix, Caution) q must be normalized
	* @param     [IN] @b  q quaternion
	* @return     SPMat3x3t
	*/
	template <typename T>
	inline SPMat3x3t quaternionToMatrix( SPVec4t const& q )
	{
		#ifdef DEBUGGING
		 VERIFY(isAlmostSame(glm::length(q),(T)1));
		#endif

		T xx = q.x*q.x, yy = q.y*q.y, zz = q.z*q.z;
		T xy = q.x*q.y, xz = q.x*q.z, yz = q.y*q.z;
		T wx = q.w*q.x, wy = q.w*q.y, wz = q.w*q.z;

		return SPMat3x3t( 1-2*(yy+zz), 2*(xy-wz),   2*(xz+wy),
							 2*(xy+wz),   1-2*(xx+zz), 2*(yz-wx),
							 2*(xz-wy),   2*(yz+wx),   1-2*(xx+yy) );
	}

	/**
	* @brief     Convert quaternion to rotation matrix
	* @param     [IN] @b  q quaternion
	* @param     [IN] @b  R four dimensional matrix
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid quaternionToMatrix( SPVec4t const& q, SPMat4x4t& R )
	{
		R.identity();
		R.set( quaternionToMatrix(q) );
	}

	/**
	* @brief     Convert quaternion to rotational axis, q must be normalized

	* @param     [IN] @b  q quaternion
	* @return     SPVec3t
	*/
	template <typename T>
	inline SPVec3t quaternionToRotationAxis( SPVec4t const& q )
	{
		T scale = (T)sin( acos(q.w) );
		if( isAlmostZero(scale) ) {
			return SPVec3t();
		} else {
			return SPVec3t( q.x/scale, q.y/scale, q.z/scale );
		}
	}

	/**
	* @brief     Convert rotational axis to rotation matrix
	* @param     [IN] @b Axis axis
	* @param     [IN] @b angle radian
	* @return     SPMat3x3t
	*/
	template <typename T>
	inline SPMat3x3t rotationAxisToMatrix( SPVec3t const& Axis, const T angle )
	{
		T c = (T)cos(angle);
		T s = (T)sin(angle);
		T t = 1 - c;

		SPVec3t axis( Axis );
		axis.normalize();

		T xx = axis.x*axis.x, yy = axis.y*axis.y, zz = axis.z*axis.z;
		T xy = axis.x*axis.y, yz = axis.y*axis.z, zx = axis.z*axis.x;
		T sx = s*axis.x,      sy = s*axis.y,      sz = s*axis.z;

		return SPMat3x3t( t*xx+c,  t*xy-sz, t*zx+sy,
							 t*xy+sz, t*yy+c,  t*yz-sx,
							 t*zx-sy, t*yz+sx, t*zz+c  );
	}

	/**
	* @brief     Convert rotational axis to rotation matrix
	* @param     [IN] @b  axis axis
	* @param     [IN] @b  angle radian
	* @param     [IN] @b  R three dimensional matrix
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid rotationAxisToMatrix( SPVec3t const& axis, const T angle, SPMat4x4t& R )
	{
		R.identity();
		R.set( RotationAxistoMatrix( axis, angle ) );
	}

	/**
	* @brief     rotate p to p' by rotational matrix R
	* @param     [IN] @b R three dimensional matrix
	* @param     [IN] @b p three dimensional vector
	* @return     SPVec3t
	*/
	template <typename T>
	inline SPVec3t rotate( SPMat3x3t const& R, SPVec3t const& p )
	{
		return multiply( R, p );
	}

	// by rotational axis
	/**
	* @brief     rotate p to p' by rotational axis
	* @param     [IN] @b axis
	* @param     [IN] @b p vector
	* @return     SPVec3t
	*/
	template <typename T>
	inline SPVec3t rotate( SPVec3t const& axis, SPVec3t const& p )
	{
		T angle = glm::length(axis);
		SPVec3t n = glm::normalize(axis);

		SPVec3t np;
		cross( np, n, p );

		n *= dot(n,p);

		return ( n + ( p - n ) * SPFloat(cos(angle)) + np * SPFloat(sin(angle)));
	}

	// by quaternion
	/**
	* @brief     rotate p to p' by quaternion
	* @param     [IN] @b q quaternion
	* @param     [IN] @b p vector
	* @return     SPVec3t
	*/
	template <typename T>
	inline SPVec3t rotate( SPVec4t const& q, SPVec3t const& p )
	{
		SPVec4t Qp( p, (T)0 );
		SPVec4t Qr = q * Qp * q.inversed();
		return SPVec3t( Qr.x, Qr.y, Qr.z );
	}

	// by quaternion
	/**
	* @brief     rotate p to p' by quaternion
	* @param     [IN] @b q quaternion
	* @param     [IN] @b p vector
	* @return     SPVec3t
	*/
	template <typename T>
	inline SPVec3t rotateInverse( SPVec4t const& q, SPVec3t const& p )
	{
		SPVec4t Qp( p, (T)0 );
		SPVec4t Qr = q * Qp * q.inversed();
		Qr.inversed();
		return SPVec3t( Qr.x, Qr.y, Qr.z );
	}

	/**
	* @brief     update on orientation
	* @param     [IN] @b  orientation orientation vector
	* @param     [IN] @b  angularVelocity angular vector
	* @param     [IN] @b  dt dt
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid updateOrientation( SPVec4t& orientation, const SPVec3t& angularVelocity, const T& dt )
	{
		SPVec4t Qvel = (T)0.5 * SPVec4t( angularVelocity, (T)0 ) * orientation;
		orientation += Qvel * dt;
		normalize( orientation );
	}

	/**
	* @brief     update on orientation
	* @param     [IN] @b  orientation orientation vector
	* @param     [IN] @b  angularVelocity angular vector
	* @param     [IN] @b  dt dt
	* @return     SPVoid
	*/
	template <typename T>
	inline SPVoid updateOrientation( SPVec4t& orientation, const SPVec4t& angularVelocity, const T& dt )
	{
		SPVec4t Qvel = (T)0.5 * angularVelocity * orientation;
		orientation += Qvel * dt;
		normalize( orientation );
	}

}
#endif //_SP_ROTATION_H_


