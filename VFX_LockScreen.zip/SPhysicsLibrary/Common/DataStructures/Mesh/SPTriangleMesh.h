/**
* @file SPTriangleMesh.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_TRIANGLE_MESH_H_
#define _SP_TRIANGLE_MESH_H_

#include "SPDefines.h"
#include "SPObject.h"
#include "SPGlobal.h"

#include <vector>
#include <glm.hpp>

namespace SPhysics
{
	/**
	* @class     SPTriangleMesh
	* @brief     Triangle mesh
	*/
	template<typename T>
	class SPTriangleMesh : public SPObject
	{
	public:
		// TODO - Move to private array - follow encapsulation rule or remove setters/getters method
		std::vector<SPVec3u > m_Triangles;	//!< Triangles
		std::vector<SPVec3t > m_Positions;		//!< Positions
		std::vector<SPVec3t > m_Velocities;		//!< Velocities
		std::vector<SPVec3t > m_Normals;			//!< Normals

		SPInt m_ChannelBits;			//!< Channel bits
		//BoundingBox<T> m_bbox;

	public:
		/**
		* @brief     Constructor		
		*/
		SPTriangleMesh();
		/**
		* @brief     Copy Constructor
		*/
		SPTriangleMesh(const SPTriangleMesh<T> &t);
		/**
		* @brief     Destructor
		*/
		~SPTriangleMesh();

		//const BoundingBox<T>& getBoundingBox() const;
		//BoundingBox<T>& computeBoundingBox();
		/**
		* @brief	Get the number of vertices     
		* @return     SPUInt
		*/
		SPUInt getNumVertices() const;

		/**
		* @brief    Get the number of triangles
		* @return     SPUInt
		*/
		SPUInt getNumTriangles() const;

		/**
		* @brief     Add triangle data to mesh
		* @param     [IN] @b t add mesh
		* @return     SPUInt
		*/
		SPUInt addTriangleMesh(const SPTriangleMesh<T> &t);

		/**
		* @brief     Add channel data to mesh 
		* @param     [IN] @b bits channel 
		* @return     SPInt
		*/
		SPInt addChannel(const SPInt bits);

		/**
		* @brief     add triangle data to mesh
		* @param     [IN] @b tri triangle index
		* @return     SPUInt
		*/
		SPUInt addTriangle(const SPVec3u &tri);

		/**
		* @brief     add vertex data to mesh
		* @param     [IN] @b vert vertex poisition
		* @return     SPUInt
		*/
		SPUInt addVertex(const SPVec3t &vert);

		/**
		* @brief     Add velocity data to mesh
		* @param     [IN] @b vel velocity
		* @return     SPUInt
		*/
		SPUInt addVelocity(const SPVec3t &vel);

		/**
		* @brief     Add normal data to mesh
		* @param     [IN] @b normal normal
		* @return     SPUInt
		*/
		SPUInt addNormal(const SPVec3t &normal);

		/**
		* @brief     Set triangles of mesh
		* @param     [IN] @b tris triangles
		* @return     SPVoid
		*/
		SPVoid setTriangles(const std::vector<SPVec3u >& tris);

		/**
		* @brief     Set vertices of mesh
		* @param     [IN] @b verts vertices 
		* @return     SPVoid
		*/
		SPVoid setVertices(const std::vector<SPVec3t > &verts);

		/**
		* @brief     Set velocities of mesh
		* @param     [IN] @b vels velocities
		* @return     SPVoid
		*/
		SPVoid setVelocities(const std::vector<SPVec3t > &vels);

		/**
		* @brief     Set normals of mesh
		* @param     [IN] @b norms normals
		* @return     SPVoid
		*/
		SPVoid setNormals(const std::vector<SPVec3t > &norms);


		/**
		* @brief     Get vertex data of mesh
		* @param     [IN] @b i index
		* @return     SPVec3t&
		*/
		SPVec3t& vertex(const SPUInt i) { return m_Positions[i]; }

		/**
		* @brief     Get velocity data of mesh
		* @param     [IN] @b i index 
		* @return     SPVec3t&
		*/		
		SPVec3t& velocity(const SPUInt i) { return m_Velocities[i]; }


		/**
		* @brief     Get normal data of mesh
		* @param     [IN] @b i index 
		* @return     SPVec3t&
		*/
		SPVec3t& normal(const SPUInt i) { return m_Normals[i]; }

		/**
		* @brief     Set vertex data of mesh
		* @param     [IN] @b i index 
		* @param     [IN] @b data data for setting
		* @return     SPVoid
		*/
		SPVoid setVertex(const SPUInt i, const SPVec3t& data)	{ m_Positions[i] = data; }


		/**
		* @brief     Set velocity data of mesh
		* @param     [IN] @b i index 
		* @param     [IN] @b data data for setting
		* @return     SPVoid
		*/
		SPVoid setVelocity(const SPUInt i, const SPVec3t& data)	{ m_Velocities[i] = data; }


		/**
		* @brief     Set normal data of mesh
		* @param     [IN] @b i index 
		* @param     [IN] @b data data for setting
		* @return     SPVoid
		*/
		SPVoid setNormal(const SPUInt i, const SPVec3t& data)	{ m_Normals[i] = data; }

		/**
		* @brief     Get the channel data of mesh
		* @return     SPInt
		*/
		SPInt getChannel() const;

		/**
		* @brief     Get the triangle data of mesh
		* @param     [IN] @b i index 
		* @return     const SPVec3u&
		*/
		const SPVec3u& getTriangle(const SPUInt i) const;

		/**
		* @brief     Get the vertice data of mesh
		* @return     const std::vector<SPVec3t>&
		*/
		const std::vector<SPVec3t >& getVertices() const;

		/**
		* @brief     Get the vertex data
		* @param     [IN] @b i index 
		* @return     const SPVec3u&
		*/
		const SPVec3t& getVertex(const SPUInt i) const;

		/**
		* @brief     Get the velocity data
		* @param     [IN] @b i index 
		* @return     const SPVec3u&
		*/	
		const SPVec3t& getVelocity(const SPUInt i) const;

		/**
		* @brief     Get the normal data
		* @param     [IN] @b i index 
		* @return     const SPVec3u&
		*/
		const SPVec3t& getNormal(const SPUInt i) const;

		/**
		* @brief     Return true if mesh has a vertex
		* @return     SPBool
		*/
		SPBool hasVertex() const { return (m_ChannelBits & SPE_POSITION)>0;    }


		/**
		* @brief     Return true if mesh has a velocity
		* @return     SPBool
		*/
		SPBool hasVelocity() const { return (m_ChannelBits & SPE_VELOCITY)>0;    }


		/**
		* @brief     Return true if mesh has a normal data
		* @return     SPBool
		*/
		SPBool hasNormal() const { return (m_ChannelBits & SPE_NORMAL)>0;      }

		/**
		* @brief     Compute vertex normal
		* @return     SPVoid
		*/
		SPVoid computeVertexNormal();

		/**
		* @brief	Initialize mesh data     
		* @return     SPVoid
		*/
		SPVoid init();

	};
}
#endif //_SP_TRIANGLE_MESH_H_