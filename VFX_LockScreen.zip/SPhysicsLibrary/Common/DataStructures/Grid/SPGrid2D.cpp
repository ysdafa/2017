/**
* @file SPGrid2D.cpp
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPGrid2D.h"
#include "SPComparison.h"

namespace SPhysics
{
	
	SPVoid SPGrid2D::reset() {

		m_Nx = m_Ny = 0;
		m_Lx = m_Ly = 0;
		m_Dx = m_Dy = 0;
		m_NumCells = m_NumNodes = 0;
		m_NumUFaces = m_NumVFaces = 0;
		m_NumXEdges = m_NumYEdges = 0;
		m_NxPlus1 = 0;
		m_NyPlus1 = 0;
		m_NxMinus1 = 0;
		m_NyMinus1 = 0;
		m_NxNy = 0;
		m_DxHalf = m_DyHalf = 0;
		m_Dx2 = m_Dy2 = 0;
		m_Dx2Dy2 = 0;
		m_MinDxDy = m_MaxDxDy = 0;
		m_DiagonalLength = 0;
		m_Epsilon = 0;
		m_LxMinusEps = 0;
		m_LyMinusEps = 0;
	
	}

	
	SPVoid SPGrid2D::setGrid( const SPInt&   nx, const SPInt&   ny,
						  const SPDouble& lx, const SPDouble& ly ) {

		if( nx<=0 || ny<=0 )
		{
			std::cout<<"Error@SPGrid2D::setGrid2D(): Invalid resolution."<<std::endl;
			return;
		}

		if( lx<=0 || ly<=0 )
		{
			std::cout<<"Error@SPGrid2D::setGrid2D(): Invalid dimension."<<std::endl;
			return;
		}

		reset();

		m_Nx = nx;
		m_Ny = ny;

		m_Lx = lx;
		m_Ly = ly;

		m_Dx = m_Lx / (SPDouble)m_Nx;
		m_Dy = m_Ly / (SPDouble)m_Ny;

		m_DxHalf = (SPDouble)0.5 * m_Dx;
		m_DyHalf = (SPDouble)0.5 * m_Dy;

		m_Dx2 = m_Dx*m_Dx;
		m_Dy2 = m_Dy*m_Dy;

		m_Dx2Dy2 = m_Dx2*m_Dy2;

		m_MinDxDy = minimum( m_Dx, m_Dy );
		m_MaxDxDy = maximum( m_Dx, m_Dy );

		m_DiagonalLength = sqrt( m_Dx2 + m_Dy2 );

		m_Epsilon = (SPDouble)0.001 * minimum(m_Dx,m_Dy);

		m_LxMinusEps = m_Lx - m_Epsilon;
		m_LyMinusEps = m_Ly - m_Epsilon;

		m_NxPlus1  = m_Nx+1;
		m_NyPlus1  = m_Ny+1;
		m_NxMinus1 = m_Nx-1;
		m_NyMinus1 = m_Ny-1;
		m_NxNy     = m_Nx*m_Ny;

		m_NumCells  = m_Nx      * m_Ny     ;
		m_NumUFaces = m_NxPlus1 * m_Ny     ;
		m_NumVFaces = m_Nx      * m_NyPlus1;
		m_NumXEdges = m_Nx      * m_NyPlus1;
		m_NumYEdges = m_NxPlus1 * m_Ny     ;
		m_NumNodes  = m_NxPlus1 * m_NyPlus1;

	} 

	
	SPVoid SPGrid2D::setGrid( const SPVec2i& resolution, const SPVec2d& size ) 
	{
		this->setGrid(resolution.x,resolution.y, size.x,size.y);
	} 

	
	SPVoid SPGrid2D::copy( const SPGrid2D& g ) {

		reset();
		SPObject::copy( g );

		m_Nx = g.m_Nx;
		m_Ny = g.m_Ny;

		m_Lx = g.m_Lx;
		m_Ly = g.m_Ly;

		//TODO - passing class members as an argument to member function is useless
		setGrid( m_Nx,m_Ny, m_Lx,m_Ly );

	}

	
	SPVoid SPGrid2D::getNodesOfCell( const SPInt& i, const SPInt& j, SPInt outputNode[4] )
	{
		// TODO - passing by value
		outputNode[0] = node(i,j);
		outputNode[1] = eNode( outputNode[0] );
		outputNode[2] = nNode( outputNode[1] );
		outputNode[3] = wNode( outputNode[2] );

	}

}