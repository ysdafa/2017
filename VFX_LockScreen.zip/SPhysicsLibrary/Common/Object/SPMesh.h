/**
* @file      SPMesh.h
* @brief     This file includes module that has information about mesh

* @date      2013-05-22 
* @author    Graphics Lab. Animation Physics 
* @see 
* * Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
 */



#ifndef _SP_MESH_VERTEX_H_
#define _SP_MESH_VERTEX_H_

#include "SPDefines.h"

#include <vector>
#include <glm.hpp>


namespace SPhysics
{
	typedef std::vector<SPVec3f > POINT3D_ARRAY;	//!< 3D float array
	typedef std::vector<SPVec4f > POINT4D_ARRAY;	//!< 4D float array
	typedef std::vector<SPVec2f > POINT2D_ARRAY;	//!< 2D float array
	typedef std::vector<SPFloat>			  POINT_ARRAY;		//!< float array
	typedef std::vector<SPUShort>			  INDEX3D_ARRAY;	//!< unsigned short array
	typedef std::vector<SPUInt>				  INDEX3D_ARRAY16;	//!< unsigned int array
	typedef std::vector<SPVec3i >   FACE3D_ARRAY;	//!< 3D int array

	/**
	* @class     SPMesh
	* @brief     This class manages object's 3d-polygon(mesh) data
	*/
	class SPMesh
	{
		/* Methods */
	public:
		SPMesh();
		~SPMesh();

		/**
		* @brief     Get size of m_tVertex
		* @return     SPInt
		*/
		SPInt getNumOfVertex();
		/**
		* @brief     Get size of m_tVertexIndex
		* @return     SPInt
		*/
		SPInt getNumOfVertexIndex();
		/**
		* @brief     Reset information of an object 
		* @return     SPVoid
		*/
		SPVoid reset();

		/**
		* @brief     Get vertex array
		* @return     POINT3D_ARRAY *
		*/
		POINT3D_ARRAY* getVertex()		{ return &m_tVertex; }

		/**
		* @brief     Get 2D vertex array
		* @return     POINT2D_ARRAY *
		*/
		POINT2D_ARRAY* getVertex2D()	{ return &m_tVertex2D; }

		/**
		* @brief     Get normal array
		* @return     POINT3D_ARRAY *
		*/
		POINT3D_ARRAY* getNormal()		{ return &m_tNormal; }
		/**
		* @brief     Get height array
		* @return     POINT3D_ARRAY *
		*/
		POINT3D_ARRAY* getHeight()		{ return &m_tHeight; }
		/**
		* @brief     Get tangent array
		* @return     POINT3D_ARRAY *
		*/
		POINT3D_ARRAY* getTangent()		{ return &m_tTangent; }
		/**
		* @brief     Get texture UV array
		* @return     POINT3D_ARRAY *
		*/
		POINT3D_ARRAY* getTextureUV()	{ return &m_tTextureUV; }
		/**
		* @brief     Get color array
		* @return     POINT4D_ARRAY *
		*/
		POINT4D_ARRAY* getColor()		{ return &m_tColor; }
		/**
		* @brief     Get vertex index array
		* @return     INDEX3D_ARRAY *
		*/
		INDEX3D_ARRAY* getVertexIndex()	{ return &m_tVertexIndex; }

		/**
		* @brief     Set vertex
		* @param     [IN] @b _index
		* @param     [IN] @b _v
		* @return     SPVoid
		*/
		SPVoid setVertex(const SPInt _index, const SPVec3f& _v){ m_tVertex[_index] = _v; }
		/**
		* @brief     Set normal
		* @param     [IN] @b _index
		* @param     [IN] @b _v
		* @return     SPVoid
		*/
		SPVoid setNormal(const SPInt _index, const SPVec3f& _v){ m_tNormal[_index] = _v; }
		/**
		* @brief     Set height
		* @param     [IN] @b _index
		* @param     [IN] @b _v
		* @return     SPVoid
		*/
		SPVoid setHeight(const SPInt _index, const SPVec3f& _v){ m_tHeight[_index] = _v; }
		/**
		* @brief     Set tangent
		* @param     [IN] @b _index
		* @param     [IN] @b _v
		* @return     SPVoid
		*/
		SPVoid setTangent(const SPInt _index, const SPVec3f& _v){ m_tTangent[_index] = _v; }
		/**
		* @brief     Set texture UV
		* @param     [IN] @b _index
		* @param     [IN] @b _v
		* @return     SPVoid
		*/
		SPVoid setTextureUV(const SPInt _index, const SPVec3f& _v){ m_tTextureUV[_index] = _v; }
		/**
		* @brief     Set texture color
		* @param     [IN] @b _index
		* @param     [IN] @b _v
		* @return     SPVoid
		*/
		SPVoid setTextureColor(const SPInt _index, const SPVec4f& _v){ m_tColor[_index] = _v; }
		/**
		* @brief     Set texture vertex index
		* @param     [IN] @b _index
		* @param     [IN] @b _v
		* @return     SPVoid
		*/
		SPVoid setTextureVertexIndex(const SPInt _index, const SPShort& _v){ m_tVertexIndex[_index] = _v; }

		/**
		* @brief     Push back vertex
		* @param     [IN] @b _v
		* @return     SPVoid
		*/
		SPVoid pushbackVertex(const SPVec3f& _v)	{m_tVertex.push_back(_v);}
		/**
		* @brief     Push back normal
		* @param     [IN] @b _v
		* @return     SPVoid
		*/
		SPVoid pushbackNormal(const SPVec3f& _v)	{m_tNormal.push_back(_v);}
		/**
		* @brief     Push back height
		* @param     [IN] @b _v
		* @return     SPVoid
		*/
		SPVoid pushbackHeight(const SPVec3f& _v)	{m_tHeight.push_back(_v);}
		/**
		* @brief     push back tangent
		* @param     [IN] @b _v
		* @return     SPVoid
		*/
		SPVoid pushbackTangent(const SPVec3f& _v)	{m_tTangent.push_back(_v);}
		/**
		* @brief     push back texture UV
		* @param     [IN] @b _v
		* @return     SPVoid
		*/
		SPVoid pushbackTextureUV(const SPVec3f& _v)	{m_tTextureUV.push_back(_v);}
		/**
		* @brief     Push back color
		* @param     [IN] @b _v
		* @return     SPVoid
		*/
		SPVoid pushbackColor(const SPVec4f& _v)		{m_tColor.push_back(_v);}
		/**
		* @brief     Push back vertex index
		* @param     [IN] @b _v
		* @return     SPVoid
		*/
		SPVoid pushbackVertexIndex(const SPShort& _v)			{m_tVertexIndex.push_back(_v);}

	protected:
	private:

		/* Member Variables */
	public:
		POINT3D_ARRAY m_tVertex;			//!< Array containing vertex position vector
		POINT2D_ARRAY m_tVertex2D;			//!< Array containing vertex position vector		
		POINT3D_ARRAY m_tNormal;			//!< Array containing vertex normal vector
		POINT3D_ARRAY m_tHeight;			//!< Array containing vertex Height Field vector
		POINT3D_ARRAY m_tTangent;			//!< Array containing vertex tangent vector
		POINT3D_ARRAY m_tBitangent;			//!< Array containing vertex bitangent vector
		POINT3D_ARRAY m_tTextureUV;		    //!< Array containing vertex textures UV vector

		POINT4D_ARRAY m_tColor;				//!< Array containing vertex color vector
		INDEX3D_ARRAY m_tVertexIndex;		//!< Array containing polygons vertex position index with unsigned short
		INDEX3D_ARRAY16 m_tVertexIndex16;   //!< Array containing polygons vertex position index with unsigned int


		FACE3D_ARRAY  m_tFaceVertexIdx;		//!< Array containing polygons vertex position index
		FACE3D_ARRAY  m_tFaceNorIdx;		//!< Array containing polygons vertex position index
		FACE3D_ARRAY  m_tFaceTexIdx;		//!< Array containing polygons vertex position index

		POINT_ARRAY   m_tCustom;			//!< Array containing custom value

	protected:
	private:




	};

}  //namespace SPhysics

#endif // _SP_MESH_VERTEX_H_

