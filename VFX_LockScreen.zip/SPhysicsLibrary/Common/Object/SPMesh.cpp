/**
* @file SPMesh.cpp
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPMesh.h"
#include "SPLog.h"

namespace SPhysics
{
	SPMesh::SPMesh()
	{

	}
	SPMesh::~SPMesh()
	{
		reset();
	}
	SPInt SPMesh::getNumOfVertex()
	{
		return m_tVertex.size();
	}
	SPInt SPMesh::getNumOfVertexIndex()
	{
		return m_tVertexIndex.size();
	}
	SPVoid SPMesh::reset()
	{
		if(m_tVertex.size() != 0)
			m_tVertex.clear(); 

		if(m_tVertex2D.size() != 0)
			m_tVertex2D.clear(); 

		if(m_tHeight.size() !=0)
			m_tHeight.clear();

		if(m_tColor.size() !=0)
			m_tColor.clear();

		if(m_tNormal.size() != 0)
			m_tNormal.clear();

		if(m_tTangent.size() != 0)
			m_tTangent.clear();

		if(m_tTextureUV.size() != 0)
			m_tTextureUV.clear();

		if(m_tVertexIndex.size() != 0)
			m_tVertexIndex.clear();

		if(m_tFaceVertexIdx.size() != 0)
			m_tFaceVertexIdx.clear();

		if(m_tFaceNorIdx.size() != 0)
			m_tFaceNorIdx.clear();

		if(m_tFaceTexIdx.size() != 0)
			m_tFaceTexIdx.clear();
	}
} // namespace SPhysics 

