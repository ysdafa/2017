/**
* @file SPMotionCurve.h
* @brief This file includes module that generate mesh
*
* @date 2013-05-22
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/
#ifndef _SP_MOTION_CURVE_H_
#define _SP_MOTION_CURVE_H_

#include "SPDefines.h"
#include "SPMesh.h"

#include <glm.hpp>

namespace SPhysics
{
	// Range 0.0f ~ 1.0f

	//QuintOut
	namespace QuintOut50 {
		/**
		* @brief     Get interpolation
		*/
		SPFloat getInterpolation(SPFloat input);
	};
	namespace QuintOut80 {
		/**
		* @brief     Get interpolation
		*/
		SPFloat getInterpolation(SPFloat input);
	};
	//SineIn
	namespace SineIn33 {
		/**
		* @brief     Get interpolation
		*/
		SPFloat getInterpolation(SPFloat input);
	};

	//SineInOut
	namespace SineInOut33 {

		/**
		* @brief     Get interpolation
		*/
		SPFloat getInterpolation(SPFloat input);
	};
	namespace SineInOut50 {

		/**
		* @brief     Get interpolation
		*/
		SPFloat getInterpolation(SPFloat input);
	};
	namespace SineInOut60 {

		/**
		* @brief     Get interpolation
		*/
		SPFloat getInterpolation(SPFloat input);
	};
	namespace SineInOut70 {

		/**
		* @brief     Get interpolation
		*/
		SPFloat getInterpolation(SPFloat input);
	};
	namespace SineInOut80 {

		/**
		* @brief     Get interpolation
		*/
		SPFloat getInterpolation(SPFloat input);
	};
	namespace SineInOut90 {

		/**
		* @brief     Get interpolation
		*/
		SPFloat getInterpolation(SPFloat input);
	};
	//SineOut
	namespace SinOut33 {

		/**
		* @brief     Get interpolation
		*/
		SPFloat getInterpolation(SPFloat input);
	};
	
}

#endif