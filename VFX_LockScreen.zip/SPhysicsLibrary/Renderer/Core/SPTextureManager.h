/**
* @file SPTextureManager.h
* @brief This file includes module which is related  with texturing
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_TEXTURE_MANAGER_H_
#define _SP_TEXTURE_MANAGER_H_

#include "SPDefines.h"
#include "SPNonCopyable.h"

#include <vector>


namespace SPhysics
{
#if (!ANDROID_PORTING_MODE)
	// Forward declaration
	class SPImageLoader;
#endif

	//! @brief option for texture wrap mode
	typedef enum _TEX_WRAP
	{
		WRAP_REPEAT = GL_REPEAT,			/*!< repeat */
		WRAP_CRAMP = GL_CLAMP_TO_EDGE,		/*!< cramp to edge */
		WRAP_MIRRORED_REPEAT = GL_MIRRORED_REPEAT	/*!< mirrored repeat */
	}TEX_WRAP;

	//! @brief option for texture magnitude filter
	typedef enum _TEX_MFILTER
	{
		MFILTER_NEAREST			= GL_NEAREST,		/*!< texture magnitude filter option :: Nearest*/
		MFILTER_LINEAR			= GL_LINEAR		    /*!< texture magnitude filter option :: Linear*/
	}TEX_MFILTER;

	//! @brief option for texture pixel format
	typedef enum _TEX_PFORMAT
	{
		PFORMAT_DEPTH			= GL_DEPTH_COMPONENT,		
		PFORMAT_A				= GL_ALPHA,		    
		PFORMAT_RGB				= GL_RGB,		    
		PFORMAT_RGBA			= GL_RGBA,		    
		PFORMAT_LUMINANCE		= GL_LUMINANCE,
		PFORMAT_LUMINANCE_A		= GL_LUMINANCE
	}TEX_PFORMAT;

	//! @brief option for texture data type
	typedef enum _TEX_DTYPE
	{
		DTYPE_BYTE				= GL_BYTE,             
		DTYPE_UBYTE				= GL_UNSIGNED_BYTE,    
		DTYPE_SHORT				= GL_SHORT,            
		DTYPE_USHORT			= GL_UNSIGNED_SHORT,   
		DTYPE_INT				= GL_INT,              
		DTYPE_UINT				= GL_UNSIGNED_INT,     
		DTYPE_FLOAT				= GL_FLOAT,            
		DTYPE_FIXED				= GL_FIXED            
	}TEX_DTYPE;

	/**
	* @struct     _TEXTURE_CONTEXT
	* @brief     Pairs that consists of Texture id and file name
	*/
	typedef struct _TEXTURE_CONTEXT
	{
		SPUInt TextureId;		//!< Texture ID
		SPChar FileName[128];	//!< File name
	}TEXTURE_CONTEXT;	//!< Texture context

	/**
	* @struct     _TEXTURE_COLOR_BUFFER
	* @brief     Specifies the Buffer's properties after loading Image file
	*/
	typedef struct _TEXTURE_COLOR_BUFFER
	{
		SPInt ImgWidth;			//!< Image width
		SPInt ImgHeight;		//!< Image height
		SPUChar* ImgData;		//!< Image data
		SPChar FileName[128];	//!< File name
		SPInt ImgSize;			//!< Image size
		SPInt PixelSize;		//!< Pixel size
	}TEXTURE_COLOR_BUFFER;	//!< Texture color buffer

	/**
	* @class     SPTextureManager
	* @brief     This class provides the functions that load images file and maintains.
	*/
	class SPTextureManager: NonCopyable
	{
	public:

		/**
		* @brief     Singleton instance
		* @return     SPTextureManager * Return Singleton instance
		*/
		static SPTextureManager *getInstancePtr();

		/**
		* @brief     Release singleton instance explicitly.
		* @return     SPVoid
		*/
		static SPVoid ReleaseInstance();

#if (!ANDROID_PORTING_MODE)

		/**
		* @brief     with this set, File open changed
		* @return    SPVoid
		*/
		SPVoid enableSDCardFilePath();

		/**
		* @brief     with this set, File open changed
		* @return    SPVoid
		*/
		SPVoid disableSDCardFilePath();

		/**
		* @brief     Loads image file and generate texture id.
		* @param     [IN] @b fileName Specifies image file name
		* @param     [IN] @b isMipMapMode The flag whether to use mipmap
		* @return     SPUInt return Return generated Texture ID
		*/
		SPUInt loadTexture( const SPChar *fileName, SPBool isMipMapMode = SPFALSE);

		/**
		* @brief     Loads image file and return rgb buffer's contents
		* @param     [IN] @b fileName Specifies image file name
		* @return     TEXTURE_COLOR_BUFFER * Return Buffer's specific contents.
		*/
		TEXTURE_COLOR_BUFFER* loadTextureColor( const SPChar *fileName );

		/**
		* @brief     Loads image file and generate cubemap texture id.
		* @param     [IN] @b xPos Specifies image file name
		* @param     [IN] @b xNeg Specifies image file name
		* @param     [IN] @b yPos Specifies image file name
		* @param     [IN] @b yNeg Specifies image file name
		* @param     [IN] @b zPos Specifies image file name
		* @param     [IN] @b zNeg Specifies image file name
		* @return     SPUInt Return cubemap texture id
		*/
		SPUInt loadCubeTexture( const SPChar* xPos, const SPChar* xNeg, const SPChar* yPos, const SPChar* yNeg, const SPChar* zPos, const SPChar* zNeg, SPBool isMipMapMode = SPFALSE);

#endif
		/**
		* @brief     generate the Texture ID with Img Info
		* @param     [IN] @b imgbuff
		* @return     SPUInt Return generated texture id
		*/
		SPUInt generateTexture(TEXTURE_COLOR_BUFFER* imgBuff, SPBool isMipMapMode);


		/**
		* @brief     generate the Cube Texture ID with Img Info
		* @param     [IN] @b imgbuff
		* @return     SPUInt Return generated texture id
		*/
		SPVoid generateCubeTexture(TEXTURE_COLOR_BUFFER* imgBuff, SPUInt mapType , SPUInt textureID);

		/**
		* @brief     This method supports Java when setting images.
		* @param     [IN] @b name Specifies Image file's name
		* @param     [IN] @b data Buffer's data
		* @param     [IN] @b width Buffer's width size
		* @param     [IN] @b height Buffer's height size
		* @see	JNI Code
		* @return     SPVoid
		*/
		SPUInt setTexture(const SPChar* name, SPVoid* data, SPInt width, SPInt height);

		/**
		* @brief     replace the pixel color data of generated texture.
		* @param     [IN] @b data Buffer's data
		* @param     [IN] @b width Buffer's width size
		* @param     [IN] @b height Buffer's height size
		* @see	JNI Code
		* @return     SPVoid
		*/
		SPVoid replaceTextureData(const SPUInt& texID, SPVoid* data, SPInt width, SPInt height);

		/**
		* @brief     This method supports when setting images.
		* @param     [IN] @b name Specifies Image file's name
		* @param     [IN] @b data Buffer's data
		* @param     [IN] @b width Buffer's width size
		* @param     [IN] @b height Buffer's height size
		* @see	JNI Code
		* @return     SPVoid
		*/
		SPVoid setTextureColor(const SPChar* name, SPVoid* data, SPInt width, SPInt height);

		/**
		* @brief     Query texture id using file name
		* @param     [IN] @b fileName Specifies file name as search key.
		* @return     SPUInt
		*/
		SPUInt getTextureID(const SPChar *fileName);

		/**
		* @brief     Query texture id using file name
		* @param     [IN] @b fileName Specifies file name as search key.
		* @return     SPUInt
		*/
		TEXTURE_COLOR_BUFFER* getTextureColor(const SPChar *fileName);

		/**
		* @brief     delete texture id using file name
		* @param     [IN] @b fileName Specifies file name as search key.
		* @return     SPUInt
		*/
		SPVoid deleteTexture(const SPChar *fileName);

		/**
		* @brief	 set a property of the texture generation
		* @param     [IN] @b dataType = a property of the texture data type \n
		*                    (options :  DT_BYTE             = GL_BYTE,             
		*								 DT_UNSIGNED_BYTE    = GL_UNSIGNED_BYTE,    
		*							     DT_SHORT            = GL_SHORT,            
		*								 DT_UNSIGNED_SHORT   = GL_UNSIGNED_SHORT,   
		*								 DT_INT              = GL_INT,              
		*							     DT_UNSIGNED_INT     = GL_UNSIGNED_INT,     
		*								 DT_FLOAT            = GL_FLOAT,            
		*								 DT_FIXED            = GL_FIXED  )
		*
		*
		* @param     [IN] @b pixelFormat = set a property of the texture pixel format \n
		*					 (options : PF_DEPTH = GL_DEPTH_COMPONENT,		
		*					            PF_A = GL_ALPHA,		    
		*					            PF_RGB = GL_RGB,		    
		*					            PF_RGBA = GL_RGBA,		    
		*					            PF_LUMINANCE = GL_LUMINANCE,
		*					            PF_LUMINANCE_A = GL_LUMINANCE)
		*
		*
		* @param     [IN] @b wrapOption = a property of the texture wrap mode 
		* (options : WRAP_REPEAT = GL_REPEAT, 
		*            WRAP_CRAMP = GL_CLAMP_TO_EDGE, 
		*            WRAP_MIRRORED = GL_MIRRORED_REPEAT)
		*
		*
		* @param     [IN] @b filterOption =   a property of the texture magnitude filter
		*					 (options : MF_NEAREST = GL_NEAREST, MF_LINEAR = GL_LINEAR)
		* @return     SPVoid
		*/
		SPVoid setTextureParameters(const TEX_DTYPE& dataType, const TEX_PFORMAT& pixelFormat, TEX_WRAP wrapOption = WRAP_MIRRORED_REPEAT, TEX_MFILTER filterOption = MFILTER_LINEAR);

		/**
		* @brief     set data type to generate a texture
		* @param     [IN] @b DataType
		* @return     SPVoid
		*/
		SPVoid setTextureDataType(const TEX_DTYPE& dataType);

		/**
		* @brief     set pixel format to generate a texture
		* @param     [IN] @b pixel format
		* @return     SPVoid
		*/
		SPVoid setTexturePixelFormat(const TEX_PFORMAT& pixelFormat);

		/**
		* @brief     set warp option to generate a texture
		* @param     [IN] @b wrap option
		* @return     SPVoid
		*/
		SPVoid setTextureWrapOption(const TEX_WRAP& wrapOption);

		/**
		* @brief     set Mag Filter type to generate a texture
		* @param     [IN] @b Mag Filter type
		* @return     SPVoid
		*/
		SPVoid setTextureMagFilter(const TEX_MFILTER& filterOption);

		/**
		* @brief     create scaled Curl Noise Texture with file image
		* @param     [IN] @b name Specifies Image file's name
		* @param     [IN] @b scaled width
		* @param     [IN] @b scaled height
		* @see	JNI Code
		* @return     SPVoid
		*/
		SPUInt createCurlNoiseTextureFromFile(const SPChar *fileName, const SPFloat& width, const SPFloat& height);


	private:
		/**
		* @brief     Constructor
		*/
		SPTextureManager();

		/**
		* @brief     Destructor
		*/
		~SPTextureManager();
		
	private:
		/**
		* @brief     Add Pairs that consists of Texture id and file name.
		* @param     [IN] @b fileName Specifies file name
		* @param     [IN] @b TexID Specifies generated texture id
		* @return     SPVoid
		*/
		SPVoid addTextureContext(const SPChar *fileName, SPUInt TexID);
		
		/**
		* @brief     Check whether same file is loaded and return texture id
		* @param     [IN] @b fileName Specifies file name that want to check
		* @return     SPUInt Return generated texture id
		*/
		SPUInt checkSameTexture(const SPChar *fileName);
		
		/**
		* @brief     Check whether same file is loaded and return rgb buffer's contents
		* @param     [IN] @b fileName Specifies image file name
		* @return     TEXTURE_COLOR_BUFFER * Return Buffer's specific contents.
		*/
		TEXTURE_COLOR_BUFFER*  checkSameTextureColor(const SPChar *fileName);
		
		/**
		* @brief     Copy Texture context
		* @param     [OUT] @b TexRGBBuffer Output rgb texture specific features.
		* @param     [IN] @b Item Source Texture context
		* @return     SPVoid
		*/
		SPVoid CopyTextureContext(TEXTURE_COLOR_BUFFER *TexRGBBuffer, TEXTURE_COLOR_BUFFER *Item);

		/**
		* @brief	initialize the property of the texture
		* @return    SPVoid
		*/
		SPVoid initializeTextureProperty();

	private:
		static SPTextureManager *m_pInstance;
		std::vector <TEXTURE_COLOR_BUFFER* > m_vTextureRGBItems;
		std::vector <TEXTURE_CONTEXT> m_vTextureItems;

#if (!ANDROID_PORTING_MODE)
		SPImageLoader* m_pImgLoader;
#endif
		SPUInt m_nTextureWrapOption;
		SPUInt m_nTextureMagFilterOption;
		SPUInt m_nTexturePixelFormat;
		SPUInt m_nTextureDataType;

	};

}	//namespace SPhysics

#endif // _SP_TEXTURE_MANAGER_H_

