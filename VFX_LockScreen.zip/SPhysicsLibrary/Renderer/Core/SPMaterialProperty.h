#ifndef _SP_MATERIAL_PROPERTY_H_
#define _SP_MATERIAL_PROPERTY_H_

#include "SPDefines.h"
#include <glm.hpp>

namespace SPhysics
{

	enum SPShaderType
	{
		SP_ST_BLINN = 0,
		SP_ST_PHONG
	};

	/**
	 * @class  SPMaterialProperty
	 * @brief  Material properties (diffuse, ambient, specular, etc.)
	 */
	class SPMaterialProperty
	{
	public:
		SPMaterialProperty();
		~SPMaterialProperty();

		/**
		* @brief     Set ambient color
		*/
		SPVoid setAmbientColor(SPVec4f& _v){ m_MaterialAmbientColor = _v; }
		/**
		* @brief     Set diffuse color
		*/
		SPVoid setDiffuseColor(SPVec4f& _v){ m_MaterialDiffuseColor = _v; }
		/**
		* @brief     Set specular color
		*/
		SPVoid setSpecularColor(SPVec4f& _v){ m_MaterialSpecularColor = _v; }
		/**
		* @brief     Set exponent
		*/
		SPVoid setExponent(SPFloat _v){ m_MaterialExponent = _v; }

		/**
		* @brief     Set ambient color
		*/
		SPVoid setAmbientColor(SPFloat _r, SPFloat _g, SPFloat _b, SPFloat _a){ m_MaterialAmbientColor.r = _r; m_MaterialAmbientColor.g = _g; m_MaterialAmbientColor.b = _b; m_MaterialAmbientColor.a = _a;}
		/**
		* @brief     Set diffuse color
		*/
		SPVoid setDiffuseColor(SPFloat _r, SPFloat _g, SPFloat _b, SPFloat _a){ m_MaterialDiffuseColor.r = _r; m_MaterialDiffuseColor.g = _g; m_MaterialDiffuseColor.b = _b; m_MaterialDiffuseColor.a = _a; }
		/**
		* @brief     Set specular color
		*/
		SPVoid setSpecularColor(SPFloat _r, SPFloat _g, SPFloat _b, SPFloat _a){ m_MaterialSpecularColor.r = _r; m_MaterialSpecularColor.g = _g; m_MaterialSpecularColor.b = _b; m_MaterialSpecularColor.a = _a;}

		/**
		* @brief     Set shininess
		*/
		SPVoid setShininess(SPFloat shininess) { m_Shininess = shininess; }
		/**
		* @brief     Set reflectivity
		*/
		SPVoid setReflectivity(SPFloat reflectivity) { m_Reflectivity = reflectivity; }
		/**
		* @brief     Set transparency
		*/
		SPVoid setTransparency(SPFloat transparency) { m_Transparency = transparency; }
		/**
		* @brief     Set index of refraction
		*/
		SPVoid setIndexOfRefraction(SPFloat indexOfRefraction) { m_IndexOfRefraction = indexOfRefraction; }
		/**
		* @brief     Set cast shadow
		*/
		SPVoid setCastShadow(SPBool castShadow) { m_CastShadow = castShadow; }
		/**
		* @brief     Set shader type
		*/
		SPVoid setShaderType(SPShaderType shaderType) { m_ShaderType = shaderType; }

		/**
		* @brief     Get ambient color
		*/
		SPFloat*	getAmbientColor(){ return (SPFloat*)& m_MaterialAmbientColor; }
		/**
		* @brief     Get diffuse color
		*/
		SPFloat*	getDiffuseColor(){ return (SPFloat*)& m_MaterialDiffuseColor; }
		/**
		* @brief     Get specular color
		*/
		SPFloat*	getSpecularColor(){ return (SPFloat*)& m_MaterialSpecularColor; }
		/**
		* @brief     Get exponent
		*/
		SPFloat		getExponent(){ return m_MaterialExponent;}
		/**
		* @brief     Get shininess
		*/
		SPFloat		getShininess(){ return m_Shininess; }

	private:
		SPVec4f  m_MaterialAmbientColor;
		SPVec4f  m_MaterialDiffuseColor;
		SPVec4f	 m_MaterialSpecularColor;
		SPFloat				 m_MaterialExponent;

		SPFloat m_Shininess;
		SPFloat m_Reflectivity;
		SPFloat m_Transparency;
		SPFloat m_IndexOfRefraction;
		SPBool m_CastShadow;
		SPShaderType m_ShaderType;

	};
}

#endif