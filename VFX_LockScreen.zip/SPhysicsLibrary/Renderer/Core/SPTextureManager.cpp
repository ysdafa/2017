/**
* @file SPTextureManager.cpp
* @brief
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/
#ifdef _WIN32
#	pragma  warning(disable:4996)
#endif

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include "SPTextureManager.h"
#include "SPLog.h"

#if (!ANDROID_PORTING_MODE)
#include "SPImageLoader.h"
#endif

namespace SPhysics
{
	SPTextureManager *SPTextureManager::m_pInstance = SPNULL;


	SPTextureManager::SPTextureManager()
	{

#if (!ANDROID_PORTING_MODE)
		m_pImgLoader = new SPImageLoader;
#endif
		// intialize texture property
		initializeTextureProperty();
	}

	SPTextureManager::~SPTextureManager()
	{

#if (!ANDROID_PORTING_MODE)
		// finalize
		if(NULL != m_pImgLoader)
			delete m_pImgLoader;
		m_pImgLoader = NULL;
#endif 

		std::vector <TEXTURE_CONTEXT>::iterator iter;
		for(iter = m_vTextureItems.begin(); iter != m_vTextureItems.end(); ++iter)
		{
			if(iter->TextureId != 0)
			{
				glDeleteTextures(1, &iter->TextureId);
			}
		}
		m_vTextureItems.clear();

		std::vector <TEXTURE_COLOR_BUFFER* >::iterator iter1;
		for(iter1 = m_vTextureRGBItems.begin(); iter1 != m_vTextureRGBItems.end(); ++iter1)
		{
			if((*iter1)->ImgData != 0)
			{
				delete[] (*iter1)->ImgData;
			}
			delete *iter1;
		}
		m_vTextureRGBItems.clear();
	}


	SPTextureManager * SPTextureManager::getInstancePtr()
	{
		if(!m_pInstance)
		{
			m_pInstance = new SPTextureManager();
		}

		return m_pInstance;
	}

	SPVoid SPTextureManager::ReleaseInstance()
	{
		if(m_pInstance != SPNULL)
		{
			delete m_pInstance;
			m_pInstance = SPNULL;
		}
	}

#if (!ANDROID_PORTING_MODE)

	SPVoid SPTextureManager::enableSDCardFilePath()
	{
		assert(NULL != m_pImgLoader);
#if defined(__ANDROID__)
		m_pImgLoader->enableSDCardFilePath();
#endif
	}

	SPVoid SPTextureManager::disableSDCardFilePath()
	{
		assert(NULL != m_pImgLoader);
#if defined(__ANDROID__)
		m_pImgLoader->disableSDCardFilePath();
#endif
	}

	SPUInt SPTextureManager::loadTexture( const SPChar *fileName, SPBool isMipMapMode /*= SPFALSE*/ )
	{
		SPUInt textureID = 0;
		textureID = checkSameTexture(fileName);

		if(textureID != 0)
		{
			return textureID;
		}

		assert(NULL != m_pImgLoader);

		TEXTURE_COLOR_BUFFER* imgBuffer = (TEXTURE_COLOR_BUFFER*)m_pImgLoader->loadColorBuffer(fileName);

		if ( SPNULL != imgBuffer )
		{
			if(imgBuffer->ImgData != SPNULL)
			{
				textureID = generateTexture(imgBuffer, isMipMapMode);
			}
		}

		addTextureContext(fileName, textureID);

		// reset texture property
		initializeTextureProperty();

		return textureID;
	}

	TEXTURE_COLOR_BUFFER* SPTextureManager::loadTextureColor( const SPChar *fileName )
	{
		TEXTURE_COLOR_BUFFER* tmpBuffer = NULL;

		tmpBuffer = checkSameTextureColor(fileName);

		if(tmpBuffer != 0)
		{
			return tmpBuffer;
		}

		assert(NULL != m_pImgLoader);

		tmpBuffer = (TEXTURE_COLOR_BUFFER*)m_pImgLoader->loadColorBuffer(fileName);

		m_vTextureRGBItems.push_back(tmpBuffer);

		return tmpBuffer;
	}

	SPUInt SPTextureManager::loadCubeTexture( const SPChar* xPos, const SPChar* xNeg, const SPChar* yPos, const SPChar* yNeg, const SPChar* zPos, const SPChar* zNeg, SPBool isMipMapMode)
	{
		assert(NULL != m_pImgLoader);

		SPUInt textureID;
		glGenTextures(1, &textureID);
		TEXTURE_COLOR_BUFFER* imgBuffer;

		//m_pImgLoader->loadCubeTexture(xPos, GL_TEXTURE_CUBE_MAP_POSITIVE_X, textureID);
		imgBuffer = (TEXTURE_COLOR_BUFFER*)m_pImgLoader->loadColorBuffer(xPos);
		if ( SPNULL != imgBuffer )
		{
			if(imgBuffer->ImgData != SPNULL)
			{
				generateCubeTexture(imgBuffer, GL_TEXTURE_CUBE_MAP_POSITIVE_X, textureID);
			}
		}
		//m_pImgLoader->loadCubeTexture(xNeg, GL_TEXTURE_CUBE_MAP_NEGATIVE_X, textureID);
		imgBuffer = (TEXTURE_COLOR_BUFFER*)m_pImgLoader->loadColorBuffer(xNeg);
		if ( SPNULL != imgBuffer )
		{
			if(imgBuffer->ImgData != SPNULL)
			{
				generateCubeTexture(imgBuffer, GL_TEXTURE_CUBE_MAP_NEGATIVE_X, textureID);
			}
		}
		//m_pImgLoader->loadCubeTexture(yPos, GL_TEXTURE_CUBE_MAP_POSITIVE_Y, textureID);
		imgBuffer = (TEXTURE_COLOR_BUFFER*)m_pImgLoader->loadColorBuffer(yPos);
		if ( SPNULL != imgBuffer )
		{
			if(imgBuffer->ImgData != SPNULL)
			{
				generateCubeTexture(imgBuffer, GL_TEXTURE_CUBE_MAP_POSITIVE_Y, textureID);
			}
		}
		//m_pImgLoader->loadCubeTexture(yNeg, GL_TEXTURE_CUBE_MAP_NEGATIVE_Y, textureID);
		imgBuffer = (TEXTURE_COLOR_BUFFER*)m_pImgLoader->loadColorBuffer(yNeg);
		if ( SPNULL != imgBuffer )
		{
			if(imgBuffer->ImgData != SPNULL)
			{
				generateCubeTexture(imgBuffer, GL_TEXTURE_CUBE_MAP_NEGATIVE_Y, textureID);
			}
		}
		//m_pImgLoader->loadCubeTexture(zPos, GL_TEXTURE_CUBE_MAP_POSITIVE_Z, textureID);
		imgBuffer = (TEXTURE_COLOR_BUFFER*)m_pImgLoader->loadColorBuffer(zPos);
		if ( SPNULL != imgBuffer )
		{
			if(imgBuffer->ImgData != SPNULL)
			{
				generateCubeTexture(imgBuffer, GL_TEXTURE_CUBE_MAP_POSITIVE_Z, textureID);
			}
		}

		//m_pImgLoader->loadCubeTexture(zNeg, GL_TEXTURE_CUBE_MAP_NEGATIVE_Z, textureID);
		imgBuffer = (TEXTURE_COLOR_BUFFER*)m_pImgLoader->loadColorBuffer(zNeg);
		if ( SPNULL != imgBuffer )
		{
			if(imgBuffer->ImgData != SPNULL)
			{
				generateCubeTexture(imgBuffer, GL_TEXTURE_CUBE_MAP_NEGATIVE_Z, textureID);
			}
		}

		glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, (isMipMapMode == SPTRUE)?GL_LINEAR_MIPMAP_LINEAR : m_nTextureMagFilterOption);
		glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, m_nTextureMagFilterOption);
		if(isMipMapMode == SPTRUE)
			glGenerateMipmap(GL_TEXTURE_CUBE_MAP);

		glBindTexture(GL_TEXTURE_CUBE_MAP, 0);


		addTextureContext(xPos, textureID);

		// reset texture property
		initializeTextureProperty();

		return textureID;
	}

#endif

	SPUInt SPTextureManager::generateTexture( TEXTURE_COLOR_BUFFER* imgBuff, SPBool isMipMapMode )
	{
		SPUInt textureID = 0;
		SPUInt RGBformat = GL_RGBA;

		if(imgBuff->PixelSize == 3)
		{
			RGBformat = GL_RGB;
		}

		glPixelStorei ( GL_UNPACK_ALIGNMENT, 1 );

		// Texture
		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, (isMipMapMode)? GL_LINEAR_MIPMAP_LINEAR : m_nTextureMagFilterOption);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, m_nTextureMagFilterOption);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, m_nTextureWrapOption);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, m_nTextureWrapOption);

		glTexImage2D(GL_TEXTURE_2D, 0, RGBformat, imgBuff->ImgWidth, imgBuff->ImgHeight, 0, RGBformat, m_nTextureDataType, (SPUChar *)imgBuff->ImgData);


		if(isMipMapMode == SPTRUE)
			glGenerateMipmap(GL_TEXTURE_2D);

		delete[] imgBuff->ImgData;
		delete imgBuff;
		//imgBuff = SPNULL; //Assignment of function parameter has no effect outside the function.

		return textureID;
	}

	SPVoid SPTextureManager::generateCubeTexture( TEXTURE_COLOR_BUFFER* imgBuff, SPUInt mapType , SPUInt textureID )
	{
		SPUInt RGBformat = GL_RGBA;
		if(imgBuff->PixelSize == 3)
		{
			RGBformat = GL_RGB;
		}

		// Texture
		glBindTexture(GL_TEXTURE_CUBE_MAP, textureID);
		glTexImage2D(mapType, 0, RGBformat, imgBuff->ImgWidth, imgBuff->ImgHeight, 0, RGBformat, m_nTextureDataType, (SPUChar *)imgBuff->ImgData);

		delete[] imgBuff->ImgData;
		delete imgBuff;
		//imgBuff = SPNULL; //Assignment of function parameter has no effect outside the function.
	}

	SPUInt SPTextureManager::setTexture( const SPChar* name, SPVoid* data, SPInt width, SPInt height )
	{
		SPUInt textureID = 0;
		SPBool bOverwrite = SPTRUE;

		if(m_nTexturePixelFormat == PFORMAT_LUMINANCE)
			glPixelStorei(GL_UNPACK_ALIGNMENT,1);

		textureID = checkSameTexture(name);

		// if the texture id exist than just overwrite
		if(textureID == 0)
		{
			glGenTextures(1, &textureID);
			bOverwrite = SPFALSE;
		}

		glBindTexture(GL_TEXTURE_2D, textureID);

		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, m_nTextureWrapOption);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, m_nTextureWrapOption);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, m_nTextureMagFilterOption);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, m_nTextureMagFilterOption);

		glTexImage2D(GL_TEXTURE_2D, 0, m_nTexturePixelFormat, width, height, 0, m_nTexturePixelFormat, m_nTextureDataType, data);


		if(textureID != 0 && bOverwrite != SPTRUE)
		{
			addTextureContext(name, textureID);
		}
		
		// reset texture property
		initializeTextureProperty();

		return textureID;
	}

	SPVoid SPTextureManager::replaceTextureData(const SPUInt& texID, SPVoid* data, SPInt width, SPInt height)
	{
		if(m_nTexturePixelFormat == PFORMAT_LUMINANCE)
			glPixelStorei(GL_UNPACK_ALIGNMENT,1);

		glBindTexture(GL_TEXTURE_2D, texID);
		glTexImage2D(GL_TEXTURE_2D, 0, m_nTexturePixelFormat, width, height, 0, m_nTexturePixelFormat, m_nTextureDataType, data);
		//glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, width, height, m_nTexturePixelFormat, m_nTextureDataType, data );

		// reset texture property
		initializeTextureProperty();
	}

	SPVoid SPTextureManager::setTextureColor( const SPChar* name, SPVoid* data, SPInt width, SPInt height )
	{
		SPBool bOverwrite = SPTRUE;

		TEXTURE_COLOR_BUFFER* sRGBBuffer = checkSameTextureColor(name);

		// if the color buffer exist than just overwrite
		if(sRGBBuffer == SPNULL)
		{
			sRGBBuffer = new TEXTURE_COLOR_BUFFER();
			bOverwrite = SPFALSE;
		}

		sRGBBuffer->ImgWidth = width;
		sRGBBuffer->ImgHeight = height;
		sRGBBuffer->ImgSize = width * height * 4;
		sRGBBuffer->PixelSize = 4;

		strcpy(sRGBBuffer->FileName, name);

		sRGBBuffer->ImgData = new SPUChar[sRGBBuffer->ImgSize];
		memcpy (sRGBBuffer->ImgData, data, sRGBBuffer->ImgSize);

		if(bOverwrite != SPTRUE)
		{
			m_vTextureRGBItems.push_back(sRGBBuffer);
		}
	}

	SPUInt SPTextureManager::getTextureID( const SPChar *fileName )
	{
		SPUInt texID = 0;

		texID = checkSameTexture(fileName);

		return texID;
	}

	TEXTURE_COLOR_BUFFER* SPTextureManager::getTextureColor( const SPChar *fileName )
	{
		TEXTURE_COLOR_BUFFER* tmpBuffer = checkSameTextureColor(fileName);
		return tmpBuffer;
	}

	SPVoid SPTextureManager::deleteTexture( const SPChar *fileName )
	{
		SP_LOGE("TextureManager::deleteTexture is called");

		std::vector <TEXTURE_CONTEXT>::iterator iter;
		for(iter = m_vTextureItems.begin(); iter != m_vTextureItems.end(); ++iter)
		{
			if(!strcmp(iter->FileName,fileName))
			{
				glDeleteTextures(1, &iter->TextureId);
				iter = m_vTextureItems.erase(iter);
				break;
			}
		}
	}

	SPVoid SPTextureManager::setTextureParameters( const TEX_DTYPE& dataType, const TEX_PFORMAT& pixelFormat, TEX_WRAP wrapOption /*= WRAP_MIRRORED_REPEAT*/, TEX_MFILTER filterOption /*= MFILTER_LINEAR*/ )
	{
		if(dataType != SPNULL)
		{
			m_nTextureDataType = dataType;
		}
		
		if(pixelFormat != SPNULL)
		{
			m_nTexturePixelFormat = pixelFormat;
		}
		
		if(wrapOption != SPNULL)
		{
			m_nTextureWrapOption = wrapOption;
		}
		
		if(filterOption != SPNULL)
		{
			m_nTextureMagFilterOption = filterOption;
		}
	}

	SPVoid SPTextureManager::setTextureDataType( const TEX_DTYPE& dataType )
	{
		m_nTextureDataType = dataType;
	}

	SPVoid SPTextureManager::setTexturePixelFormat( const TEX_PFORMAT& pixelFormat )
	{
		m_nTexturePixelFormat = pixelFormat;
	}

	SPVoid SPTextureManager::setTextureWrapOption( const TEX_WRAP& wrapOption )
	{
		m_nTextureWrapOption = wrapOption;
	}

	SPVoid SPTextureManager::setTextureMagFilter( const TEX_MFILTER& filterOption )
	{
		m_nTextureMagFilterOption = filterOption;
	}
//sea0709

#if (!ANDROID_PORTING_MODE)

	SPUInt SPTextureManager::createCurlNoiseTextureFromFile(const SPChar *fileName, const SPFloat& width, const SPFloat& height)
	{
		TEXTURE_COLOR_BUFFER* buf = loadTextureColor(fileName);

		if (buf == NULL)
		{
			SP_LOGI("%s failed to load texture %s", __func__, fileName);
			return 0;
		}

		SPInt texture_resolution_x = SPInt(buf->ImgWidth + 2);
		SPInt texture_resolution_y = SPInt(buf->ImgHeight + 2);

		std::vector<SPFloat> noise_scalar;
		noise_scalar.resize(texture_resolution_x * texture_resolution_y, 0);
		std::vector<SPFloat> curl_velocity_x;
		std::vector<SPFloat> curl_velocity_y;

		curl_velocity_x.resize(texture_resolution_x * texture_resolution_y, 0);
		curl_velocity_y.resize(texture_resolution_x * texture_resolution_y, 0);

		static auto idx = [=](const SPInt& i, const SPInt& j) -> SPInt
		{return ( texture_resolution_x * j + i ); };

		// rgb avg.
		const SPFloat inverseDiv = 1.f / (3.f * 255.f);
		for(SPInt y = 0; y < buf->ImgHeight; ++y)
		{
			const SPInt j = (buf->ImgHeight - y - 1);
			for(SPInt x = 0; x < buf->ImgWidth; ++x)
			{
				const SPInt img_index = (j*buf->ImgWidth+x) * buf->PixelSize;
				noise_scalar[idx(x,y)] = inverseDiv *
					(buf->ImgData[img_index] +
					buf->ImgData[ img_index + 1] +
					buf->ImgData[ img_index + 2]);
			}
		}

		// Curl-Noise
		for(SPInt y = 1; y < buf->ImgHeight - 1; ++y)
		{
			for(SPInt x = 1; x < buf->ImgWidth - 1; ++x)
			{
				curl_velocity_x[idx(x,y)] =  noise_scalar[idx(x, y + 1)] - noise_scalar[idx(x, y - 1)];
				curl_velocity_y[idx(x,y)] = -noise_scalar[idx(x + 1, y)] + noise_scalar[idx(x - 1, y)];

				if (width < height) {
					curl_velocity_y[idx(x,y)] *= 0.5625;
				} else if (width > height) {
					curl_velocity_x[idx(x,y)] *= 0.5625;
				}
			}
		}

		delete [] buf->ImgData;
		buf->ImgData = SPNULL;

		std::vector<SPUChar> texture;
		const SPUInt size = noise_scalar.size();
		texture.resize(size * 3);
		for(SPUInt i = 0; i < size; ++i)
		{
			texture[i * 3 + 0] = SPUChar((curl_velocity_x[i] + 0.5f) * 255.f);
			texture[i * 3 + 1] = SPUChar((curl_velocity_y[i] + 0.5f) * 255.f);
			texture[i * 3 + 2] = SPUChar(0.f);
		}

		SPUInt texID = 0;
		glGenTextures(1, &texID);

		glBindTexture(GL_TEXTURE_2D, texID);
		glPixelStorei(GL_UNPACK_ALIGNMENT,1);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, texture_resolution_x, texture_resolution_y, 0, GL_RGB, GL_UNSIGNED_BYTE, &texture[0]);
		glBindTexture(GL_TEXTURE_2D, 0);

		return texID;
	}

#endif

	SPVoid SPTextureManager::addTextureContext(const SPChar *fileName, SPUInt TexID )
	{
		TEXTURE_CONTEXT sContext;
		sContext.TextureId = TexID;
		int filenameLen = strlen(fileName);
		if( filenameLen < 128)
		{
			strcpy(sContext.FileName, fileName);
		}
		else
		{
			strncpy(sContext.FileName, fileName, 127);
			sContext.FileName[127] = '\0';
		}

		m_vTextureItems.push_back(sContext);
	}

	SPUInt SPTextureManager::checkSameTexture(const SPChar *fileName )
	{
		SPUInt TexID = 0;
		std::vector <TEXTURE_CONTEXT>::iterator iter;
		for(iter = m_vTextureItems.begin(); iter != m_vTextureItems.end(); ++iter)
		{
			if(!strcmp(iter->FileName,fileName))
			{
				TexID = iter->TextureId;
				break;
			}
		}

		return TexID;
	}

	TEXTURE_COLOR_BUFFER* SPTextureManager::checkSameTextureColor( const SPChar *fileName )
	{
		TEXTURE_COLOR_BUFFER* tmpBuff = SPNULL;

		std::vector <TEXTURE_COLOR_BUFFER* >::iterator iter;
		for(iter = m_vTextureRGBItems.begin(); iter != m_vTextureRGBItems.end(); ++iter)
		{
			if(!strcmp((*iter)->FileName,fileName))
			{
				return (*iter);
			}
		}

		return tmpBuff;
	}

	SPVoid SPTextureManager::CopyTextureContext( TEXTURE_COLOR_BUFFER *TexRGBBuffer, TEXTURE_COLOR_BUFFER *Item )
	{
		strcpy(TexRGBBuffer->FileName, Item->FileName);

		TexRGBBuffer->ImgData = Item->ImgData;
		TexRGBBuffer->ImgWidth = Item->ImgWidth;
		TexRGBBuffer->ImgHeight = Item->ImgHeight;
		TexRGBBuffer->ImgSize = Item->ImgSize;
		TexRGBBuffer->PixelSize = Item->PixelSize;
	}

	SPVoid SPTextureManager::initializeTextureProperty()
	{
		m_nTextureWrapOption = WRAP_MIRRORED_REPEAT;
		m_nTextureMagFilterOption = MFILTER_LINEAR;
		m_nTexturePixelFormat = PFORMAT_RGBA;
		m_nTextureDataType = GL_UNSIGNED_BYTE;
	}

}  //namespace SPhysics
