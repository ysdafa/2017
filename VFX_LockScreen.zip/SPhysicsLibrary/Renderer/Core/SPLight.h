/**
* @file SPLight.h
* @brief Data related to lighting in the scene
*
* @date 2014-01-29
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_LIGHT_H_
#define _SP_LIGHT_H_

#include "SPDefines.h"

#include <vector>
#include <glm.hpp>

namespace SPhysics
{

	/**
	* @class     SPLight
	* @brief     This class manages and specifies light properties
	*/
	class SPLight
	{
	public:

		/**
		* @brief  Constructor.
		*/
		SPLight();

		/**
		* @enum    SP_LIGHT_TYPE
		* @brief   enumerate Light Type
		*/
		enum SP_LIGHT_TYPE
		{
			SP_LIGHT_DIRECTIONAL,
			SP_LIGHT_POINT
		};

		/**
		* @brief     Get light type
		*/
		SP_LIGHT_TYPE              getLightType();
		/**
		* @brief     Get color
		*/
		const SPVec3f& getColor();
		/**
		* @brief     Get direction
		*/
		const SPVec3f& getDirection();
		/**
		* @brief     Get position
		*/
		const SPVec3f& getPosition();
		/**
		* @brief     Get multiplier
		*/
		SPFloat                    getMultipler();
		/**
		* @brief     Get attenuation parameters
		*/
		const SPVec3f& getParamsAttenuation();
		/**
		* @brief     Get having shadows flag
		*/
		SPBool                     getHasShadows();

		/**
		* @brief     Set light type
		*/
		SPVoid setLightType         (SP_LIGHT_TYPE lightType);
		/**
		* @brief     Set color
		*/
		SPVoid setColor             (const SPVec3f& color);
		/**
		* @brief     Set direction
		*/
		SPVoid setDirection         (const SPVec3f& direction);
		/**
		* @brief     Set position
		*/
		SPVoid setPosition          (const SPVec3f& position);
		/**
		* @brief     Set multiplier
		*/
		SPVoid setMultipler         (SPFloat multipler);
		/**
		* @brief     Set attenuation params
		*/
		SPVoid setParamsAttenuation (const SPVec3f& paramsAttenuation);
		/**
		* @brief     Set having shadows flag
		*/
		SPVoid setHasShadows        (SPBool hasShadows);

	private:
		SP_LIGHT_TYPE m_LightType;
		SPVec3f m_Color;
		SPVec3f m_Vector;
		SPFloat m_Multipler;
		SPVec3f m_ParamsAttenuation;
		SPBool m_HasShadows;
	}; // class SPLight

} //namespace SPhysics

#endif // _SP_LIGHT_H_
