/**
* @file SPLightProperty.h
* @brief 
*
* @date 2013-05-04
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPLightProperty.h"


namespace SPhysics
{
	SPLightProperty::SPLightProperty()
	{
		//���� ���� �� �ʱ�ȭ
		m_stLightValue.position[0] = 0.0f;
		m_stLightValue.position[1] = 0.0f;
		m_stLightValue.position[2] = 2.0f;

		m_stLightValue.ambientColor[0] = 0.2f;
		m_stLightValue.ambientColor[1] = 0.2f;
		m_stLightValue.ambientColor[2] = 0.2f;
		m_stLightValue.ambientColor[3] = 1.0f;

		m_stLightValue.diffuseColor[0] = 0.8f;
		m_stLightValue.diffuseColor[1] = 0.8f;
		m_stLightValue.diffuseColor[2] = 0.8f;
		m_stLightValue.diffuseColor[3] = 1.0f;

		m_stLightValue.specularColor[0] = 1.0f;
		m_stLightValue.specularColor[1] = 1.0f;
		m_stLightValue.specularColor[2] = 1.0f;
		m_stLightValue.specularColor[3] = 1.0f;

		m_stLightValue.lightdirection[0] = 0.0f;
		m_stLightValue.lightdirection[0] = 0.0f;
		m_stLightValue.lightdirection[0] = -2.0f;

		m_stLightValue.cutoffangle = 5.0f;
		m_stLightValue.spotexponent = 5.0f;

		m_stAttenuationValue.constantAttenuation = 1.0f;
		m_stAttenuationValue.linearAttenuation = 0.7f;
		m_stAttenuationValue.quadraticAttenuation = 1.8f;

		m_eLightType = DIRECTIONAL_LIGHT;
	}


	SPLightProperty::~SPLightProperty()
	{
		m_eLightType = DIRECTIONAL_LIGHT;
	}

	SPVoid SPLightProperty::setLightPosition( const SPFloat x, const SPFloat y, const SPFloat z )
	{
		m_stLightValue.position[0] = x;
		m_stLightValue.position[1] = y;
		m_stLightValue.position[2] = z;
	}

	SPVoid SPLightProperty::setLightAmbientColor( const SPFloat r, const SPFloat g, const SPFloat b, const SPFloat a )
	{
		m_stLightValue.ambientColor[0] = r;
		m_stLightValue.ambientColor[1] = g;
		m_stLightValue.ambientColor[2] = b;
		m_stLightValue.ambientColor[3] = a;
	}

	SPVoid SPLightProperty::setLightDiffuseColor( const SPFloat r, const SPFloat g, const SPFloat b, const SPFloat a )
	{
		m_stLightValue.diffuseColor[0] = r;
		m_stLightValue.diffuseColor[1] = g;
		m_stLightValue.diffuseColor[2] = b;
		m_stLightValue.diffuseColor[3] = a;
	}

	SPVoid SPLightProperty::setLightSpecularColor( const SPFloat r, const SPFloat g, const SPFloat b, const SPFloat a )
	{
		m_stLightValue.specularColor[0] = r;
		m_stLightValue.specularColor[1] = g;
		m_stLightValue.specularColor[2] = b;
		m_stLightValue.specularColor[3] = a;
	}

	SPVoid SPLightProperty::setLightDirection(const SPFloat x, const SPFloat y, const SPFloat z)
	{
		m_stLightValue.lightdirection[0] = x;
		m_stLightValue.lightdirection[1] = y;
		m_stLightValue.lightdirection[2] = z;
	}

	SPVoid SPLightProperty::setLightCutoffAngle(const SPFloat angle)
	{
		m_stLightValue.cutoffangle = angle;
	}
	SPVoid SPLightProperty::setLightSpotExp(const SPFloat exp)
	{
		m_stLightValue.spotexponent = exp;
	}

	SPVoid SPLightProperty::setAttenuationProperty(const SPFloat constant, const SPFloat linear, const SPFloat quadratic)
	{
		m_stAttenuationValue.constantAttenuation = constant;
		m_stAttenuationValue.linearAttenuation = linear;
		m_stAttenuationValue.quadraticAttenuation = quadratic;
	}
	
} //namespace SPhysics