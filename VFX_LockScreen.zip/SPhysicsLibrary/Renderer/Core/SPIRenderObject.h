/**
* @file SPIRenderObject.h
* @brief Render Object Interface makes connection between object add renderers
*
* @date 2014-08-
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_I_RENDER_OBJECT_H_
#define _SP_I_RENDER_OBJECT_H_

#include "SPObjectData.h"
#include "SPIRenderer.h"
#include "SPMaterialProperty.h"

#include <vector>

namespace SPhysics
{

	/**
	* @class     SPIRenderObject
	* @brief    Render Object interface
	*/
	class SPIRenderObject
	{
	  
	public:
		/**
		* @brief     Constructor
		*/
		SPIRenderObject();
		
		/**
		* @brief     Destructor
		*/
		~SPIRenderObject();

		/**
		* @brief     Set object data
		*/
		SPVoid setObjectData(SPObjectData *objectData);
		/**
		* @brief     Get object data
		*/
		SPObjectData* getObjectData();

		/**
		* @brief     Get pointer to material properties
		*/
		SPMaterialData *getMaterialPtr();

		/**
		* @brief     Add renderer
		*/
		SPVoid addRenderer(SPIRenderer* renderer);

		/**
		* @brief     Draw object
		*/
		SPVoid draw();

		// data members
		SPMaterialData mMaterial;	//!< Material data

	protected:
		SPObjectData *mObjectData;				//!< Object data
		//SPMaterialProperty mMaterial;
		std::vector<SPIRenderer*> mRenderers;	//!< Array of assigned renderers
	};

} //namespace SPhysics

#endif //_SP_I_RENDER_OBJECT_H_
