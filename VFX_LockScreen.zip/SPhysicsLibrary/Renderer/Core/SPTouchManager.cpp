/**
* @file SPTouchManager.cpp
* @brief 
*
* @date 
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/


#include <math.h>
#include <stdio.h> 

#include "SPLog.h"
#include "SPTouchManager.h"


namespace SPhysics
{

	SPTouchManager::SPTouchManager() : m_nTouchNum(0)
	{
		m_stCurrTouchPos.resize(MAX_TOUCH_NUM);
		m_stPrevTouchPos.resize(MAX_TOUCH_NUM);
		m_stRunningTouchID.resize(MAX_TOUCH_NUM);
		m_stTouchEventType.resize(MAX_TOUCH_NUM);
	}

	SPTouchManager::~SPTouchManager()
	{
		m_stCurrTouchPos.clear();
		m_stPrevTouchPos.clear();

		m_stRunningTouchID.clear();
		m_stTouchEventType.clear();
	}

	SPVoid SPTouchManager::setTouchEvent( SPInt eventType, SPInt xPos, SPInt yPos )
	{
		switch(eventType)
		{
		case TOUCH_DOWN:
			{
				m_stCurrTouchPos[0] = SPVec2i(xPos, yPos);
				m_stPrevTouchPos[0] = m_stCurrTouchPos[0];

				m_stTouchEventType[0] = TOUCH_DOWN;
			}
			break;
		case TOUCH_MOVE:
			{
				m_stPrevTouchPos[0] = m_stCurrTouchPos[0];

				m_stCurrTouchPos[0] = SPVec2i(xPos, yPos);

				m_stTouchEventType[0] = TOUCH_MOVE;
			}
			break;
		case TOUCH_UP:
			{
				m_stCurrTouchPos[0] = SPVec2i(xPos, yPos);
				m_stPrevTouchPos[0] = m_stCurrTouchPos[0];

				m_stTouchEventType[0] = TOUCH_UP;
			}
			break;
		}
	}

	SPVoid SPTouchManager::setMultiTouchEvent( SPInt touchID, SPInt touchNum, SPInt eventType, SPInt *xPos, SPInt *yPos )
	{
		switch(eventType)
		{
		case TOUCH_DOWN:
			{
				m_stTouchEventType[touchID] = TOUCH_DOWN;
				m_nTouchNum = touchNum;

				m_stCurrTouchPos[touchID] = SPVec2i(xPos[touchID], yPos[touchID]);
				m_stPrevTouchPos[touchID] = m_stCurrTouchPos[touchID];

				m_stRunningTouchID[touchNum - 1] = touchID;
			}
			break;

		case TOUCH_MOVE:
			{
				m_stTouchEventType[touchID] = TOUCH_MOVE;
				m_nTouchNum = touchNum;

				SPInt idx = 0;
				for(int i = 0; i < touchNum; i++)
				{
					idx = m_stRunningTouchID[i];

					m_stPrevTouchPos[idx] = m_stCurrTouchPos[idx];
					m_stCurrTouchPos[idx] = SPVec2i(xPos[idx], yPos[idx]);
				}
			}
			break;

		case TOUCH_UP:
			{
				m_stTouchEventType[touchID] = TOUCH_UP;
				m_nTouchNum = touchNum-1;

				// save the touch position
				m_stCurrTouchPos[touchID] = SPVec2i(xPos[touchID], yPos[touchID]);
				m_stPrevTouchPos[touchID] = m_stCurrTouchPos[touchID];

				SPBool bShift = SPFALSE;
				for(int i = 0; i < touchNum - 1; i++)
				{
					if(m_stRunningTouchID[i] == touchID)
					{
						bShift = SPTRUE;
					}

					if(bShift == SPTRUE)
					{
						m_stRunningTouchID[i] = m_stRunningTouchID[i+1];
					}
				}
			}
			break;
		}
	}

	SPVec2i SPTouchManager::getPrevTouchPosition(SPInt touchIdx/*= 0*/)
	{
		return m_stPrevTouchPos[touchIdx];
	}

	SPVec2i SPTouchManager::getTouchPosition(SPInt touchIdx/*= 0*/)
	{
		return m_stCurrTouchPos[touchIdx];
	}

	SPInt SPTouchManager::getTouchEventType(SPInt touchIdx/*= 0*/)
	{
		return m_stTouchEventType[touchIdx];
	}

	SPInt SPTouchManager::getTouchNum()
	{
		return m_nTouchNum;
	}

	SPInt SPTouchManager::getRunningTouchID( SPInt index )
	{
		return m_stRunningTouchID[index];
	}

}//namespace SPhysics