/**
* @file SPIRenderer.cpp
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPTextureManager.h"
#include "SPIRenderer.h"
#include "SPVBOManager.h"
#include <assert.h> // temporary include during Fireworks effect integration

namespace SPhysics
{
	SPIRenderer::SPIRenderer() : 
       m_pRenderMesh(SPNULL), 
	   m_pRenderMVP(SPNULL), 
	   m_pRenderShader(SPNULL),
	   m_pVBOManager(SPNULL),
	   m_ScreenWidth(0),
	   m_ScreenHeight(0),
	   m_SimulationWidth(0),
	   m_SimulationHeight(0),
	   m_NumTexture(0),
	   m_ConvertModelView(SPFALSE),
	   m_IsDrawArray(SPFALSE),
	   m_DrawingOption(0),
	   m_bVisisble(SPTRUE),
	   m_bBlend(SPTRUE),
	   m_bDepthTest(SPFALSE),
	   m_DepthFunc(GL_LESS),
	   m_DepthMask(SPTRUE),
	   m_bCullFace(SPFALSE),
	   m_CullFace(GL_BACK),
	   m_FrontFace(GL_CCW),
	   m_pCustomTriangleIndices(SPNULL),
	   m_nCustomNumIndices(0),
	   m_nCustomNumVertex(0),
	   m_bIsCustomDraw(SPFALSE)

	{
		m_ColorMask[0] = m_ColorMask[1] = m_ColorMask[2] = m_ColorMask[3] = SPTRUE;
	}

	SPIRenderer::~SPIRenderer()
	{
		SP_SAFE_DELETE(m_pRenderMVP);
		SP_SAFE_DELETE(m_pRenderShader);
		SP_SAFE_DELETE(m_pVBOManager);
	}

	SPVoid SPIRenderer::initialize(SPFloat width, SPFloat height)
	{
		// Initialize member variables
		m_ObjectColor = SPVec4f(1.0f, 1.0f, 1.0f, 1.0f);
		m_ObjectTranslate = SPVec3f();
		m_ObjectRotate = SPVec4f();
		m_ObjectScale = SPVec3f(1.0f, 1.0f, 1.0f);

		// set screen size with dummy value
		m_ScreenWidth = 720.0f;
		m_ScreenHeight = 1280.0f;

		m_SimulationWidth = width;
		m_SimulationHeight = height;

		m_ConvertModelView = SPFALSE;

		// initialize drawing method
		m_IsDrawArray = SPTRUE;
		m_DrawingOption = DRAW_TRIANGLES;


		// init number of texture during drawing
		m_NumTexture = 0;

		// init Default Blend Option
		m_BlendOption = SPVec4u(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

		if(m_pRenderMVP == SPNULL)
			m_pRenderMVP = new SPMVPManager();

		// Call the initRender which is in child render class
		initRender(width, height);
	}

	SPVoid SPIRenderer::draw()
	{

		if(m_bVisisble == SPFALSE)
			return;

		updateMVPMtrix();
				
		if(m_bDepthTest == SPTRUE)
		{
			glEnable(GL_DEPTH_TEST);
			glDepthFunc(m_DepthFunc);
		}
		else
		{
			glDisable(GL_DEPTH_TEST);
		}

		if(m_bCullFace)
		{
			glEnable(GL_CULL_FACE);
			glCullFace(m_CullFace);
			glFrontFace(m_FrontFace);
		}
		else
		{
			glDisable(GL_CULL_FACE);
		}
		
		if(m_bBlend)
		{
 			glEnable(GL_BLEND);
 			glBlendFuncSeparate(m_BlendOption.x, m_BlendOption.y, m_BlendOption.z, m_BlendOption.w);
		}
		else
		{
			glDisable(GL_BLEND);
		}

		glColorMask(m_ColorMask[0], m_ColorMask[1], m_ColorMask[2], m_ColorMask[3]);
		glDepthMask(m_DepthMask);

		glUseProgram(m_pRenderShader->getProgram());

		// Call the drawRender which is in child render class
		drawRender();
		
		if(m_bIsCustomDraw == SPTRUE)
		{
			this->runCustomDraw();
		}else
		{
			this->runMeshDraw();
		}

		resetShaderParameters();
	}

	SPVoid SPIRenderer::setScreenSize( SPFloat width, SPFloat height )
	{
		m_ScreenWidth = width;
		m_ScreenHeight = height;
	}

	SPhysics::SPVoid SPIRenderer::setMesh( SPMesh* mesh )
	{
		m_pRenderMesh = mesh;
	}

	SPMesh* SPIRenderer::getMesh()
	{
		return m_pRenderMesh;
	}

	SPVoid SPIRenderer::setOrthogonalCameraView( SPFloat left, SPFloat right, SPFloat bottom, SPFloat top, SPFloat nearZ, SPFloat farZ )
	{
		if(m_pRenderMVP == SPNULL)
			m_pRenderMVP = new SPMVPManager();

		m_pRenderMVP->setOrtho( left, right, bottom, top, nearZ, farZ);
	}

	SPVoid SPIRenderer::setPerspectiveCameraView( SPFloat fovy, SPFloat aspect, SPFloat nearZ, SPFloat farZ )
	{
		if(m_pRenderMVP == SPNULL)
			m_pRenderMVP = new SPMVPManager();

		m_pRenderMVP->setPerspective(fovy, aspect, nearZ, farZ);
	}

	SPVoid SPIRenderer::setFrustumCameraView( SPFloat left, SPFloat right, SPFloat bottom, SPFloat top, SPFloat nearZ, SPFloat farZ )
	{
		if(m_pRenderMVP == SPNULL)
			m_pRenderMVP = new SPMVPManager();

		m_pRenderMVP->setFrustum(left, right, bottom, top, nearZ, farZ);
	}

	SPVoid SPIRenderer::setLookAt( SPFloat eyex, SPFloat eyey, SPFloat eyez, SPFloat centerx, SPFloat centery, SPFloat centerz, SPFloat upx, SPFloat upy, SPFloat upz )
	{
		if(m_pRenderMVP == SPNULL)
			m_pRenderMVP = new SPMVPManager();

		m_pRenderMVP->setLookAt(eyex, eyey, eyez, centerx, centery, centerz, upx, upy, upz);
	}

	SPVoid SPIRenderer::setViewMatrix(const SPFloat *viewMatrix)
	{
		if(m_pRenderMVP == SPNULL)
			m_pRenderMVP = new SPMVPManager();

		m_pRenderMVP->setViewMatrix(viewMatrix);
	}

	SPVoid SPIRenderer::createShaderProgram( const SPChar* vertexShader, const SPChar* fragmentShader )
	{
		if(m_pRenderShader == SPNULL)
			m_pRenderShader = new SPShaderManager();

		m_pRenderShader->reset();

		// create the shader location handler and linked program object
		m_pRenderShader->createProgram(vertexShader, fragmentShader);
	}

	SPVoid SPIRenderer::setShaderArrayMeshVertex( const SPChar* name )
	{
		if(m_pRenderMesh->m_tVertex.size() == 0)
			return;

		if(m_pRenderShader->getProgram() == SPNULL)
			return;

		SPUInt attributeLoc = m_pRenderShader->getAttributeLoc(name);

		m_vAttributeItems.push_back(attributeLoc);

		glVertexAttribPointer(attributeLoc, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(SPFloat), &m_pRenderMesh->m_tVertex[0]);
		glEnableVertexAttribArray(attributeLoc);

// 		SPUInt VboID = SPVBOManager::getInstancePtr()->getVertexBufferID();
// 		glBindBuffer(GL_ARRAY_BUFFER, VboID);
// 		glBufferData(GL_ARRAY_BUFFER, m_pRenderMesh->getNumOfVertex() * 3 * 4, &m_pRenderMesh->m_tVertex[0], GL_STATIC_DRAW);
// 		glVertexAttribPointer(attributeLoc, 3, GL_FLOAT, SPFALSE, 0, 0);
// 		glEnableVertexAttribArray(attributeLoc);
// 		glBindBuffer(GL_ARRAY_BUFFER, 0);
	}

	SPVoid SPIRenderer::setShaderArrayMeshVertex2D( const SPChar* name )
	{
		if(m_pRenderMesh->m_tVertex.size() == 0)
			return;

		if(m_pRenderShader->getProgram() == SPNULL)
			return;

		SPUInt attributeLoc = m_pRenderShader->getAttributeLoc(name);

		m_vAttributeItems.push_back(attributeLoc);

		glVertexAttribPointer(attributeLoc, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(SPFloat), &m_pRenderMesh->m_tVertex2D[0]);
		glEnableVertexAttribArray(attributeLoc);
	}

	SPVoid SPIRenderer::setShaderArrayMeshNormal( const SPChar* name )
	{

		if(m_pRenderMesh->m_tNormal.size() == 0)
			return;

		if(m_pRenderShader->getProgram() == SPNULL)
			return;

		SPUInt attributeLoc = m_pRenderShader->getAttributeLoc(name);

		m_vAttributeItems.push_back(attributeLoc);

		glVertexAttribPointer(attributeLoc, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(SPFloat), &m_pRenderMesh->m_tNormal[0]);
		glEnableVertexAttribArray(attributeLoc);

// 		SPUInt VboID = SPVBOManager::getInstancePtr()->getNormalBufferID();
// 		glBindBuffer(GL_ARRAY_BUFFER, VboID);
// 		glBufferData(GL_ARRAY_BUFFER, m_pRenderMesh->getNumOfVertex() * 3 * 4, &m_pRenderMesh->m_tNormal[0], GL_STATIC_DRAW);
// 		glVertexAttribPointer(attributeLoc, 3, GL_FLOAT, SPFALSE, 0, 0);
// 		glEnableVertexAttribArray(attributeLoc);
// 		glBindBuffer(GL_ARRAY_BUFFER, 0);
	}

	SPVoid SPIRenderer::setShaderArrayMeshHeight( const SPChar* name )
	{
		if(m_pRenderMesh->m_tHeight.size() == 0)
			return;

		if(m_pRenderShader->getProgram() == SPNULL)
			return;

		SPUInt attributeLoc = m_pRenderShader->getAttributeLoc(name);

		m_vAttributeItems.push_back(attributeLoc);

		glVertexAttribPointer(attributeLoc, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(SPFloat), &m_pRenderMesh->m_tHeight[0]);
		glEnableVertexAttribArray(attributeLoc);

// 		SPUInt VboID = SPVBOManager::getInstancePtr()->getHeightBufferID();
// 		glBindBuffer(GL_ARRAY_BUFFER, VboID);
// 		glBufferData(GL_ARRAY_BUFFER, m_pRenderMesh->getNumOfVertex() * 3 * 4, &m_pRenderMesh->m_tHeight[0], GL_STATIC_DRAW);
// 		glVertexAttribPointer(attributeLoc, 3, GL_FLOAT, SPFALSE, 0, 0);
// 		glEnableVertexAttribArray(attributeLoc);
// 		glBindBuffer(GL_ARRAY_BUFFER, 0);
	}

	SPVoid SPIRenderer::setShaderArrayMeshCustom( const SPChar* name )
	{
		if(m_pRenderMesh->m_tCustom.size() == 0)
			return;

		if(m_pRenderShader->getProgram() == SPNULL)
			return;

		SPUInt attributeLoc = m_pRenderShader->getAttributeLoc(name);

		m_vAttributeItems.push_back(attributeLoc);

		glVertexAttribPointer(attributeLoc, 1, GL_FLOAT, GL_FALSE, sizeof(SPFloat), &m_pRenderMesh->m_tCustom[0]);
		glEnableVertexAttribArray(attributeLoc);
	}

	SPVoid SPIRenderer::setShaderArrayMeshTangent( const SPChar* name )
	{
		if(m_pRenderMesh->m_tTangent.size() == 0)
			return;

		if(m_pRenderShader->getProgram() == SPNULL)
			return;

		SPUInt attributeLoc = m_pRenderShader->getAttributeLoc(name);

		m_vAttributeItems.push_back(attributeLoc);

		glVertexAttribPointer(attributeLoc, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(SPFloat), &m_pRenderMesh->m_tTangent[0]);
		glEnableVertexAttribArray(attributeLoc);

// 		SPUInt VboID = SPVBOManager::getInstancePtr()->getTangentBufferID();
// 		glBindBuffer(GL_ARRAY_BUFFER, VboID);
// 		glBufferData(GL_ARRAY_BUFFER, m_pRenderMesh->getNumOfVertex() * 3 * 4, &m_pRenderMesh->m_tTangent[0], GL_STATIC_DRAW);
// 		glVertexAttribPointer(attributeLoc, 3, GL_FLOAT, SPFALSE, 0, 0);
// 		glEnableVertexAttribArray(attributeLoc);
// 		glBindBuffer(GL_ARRAY_BUFFER, 0);
	}

	SPVoid SPIRenderer::setShaderArrayMeshUV( const SPChar* name )
	{
		if(m_pRenderMesh->m_tTextureUV.size() == 0)
			return;

		if(m_pRenderShader->getProgram() == SPNULL)
			return;

		SPUInt attributeLoc = m_pRenderShader->getAttributeLoc(name);

		m_vAttributeItems.push_back(attributeLoc);

		glVertexAttribPointer(attributeLoc, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(SPFloat), &m_pRenderMesh->m_tTextureUV[0]);
		glEnableVertexAttribArray(attributeLoc);

// 		SPUInt VboID = SPVBOManager::getInstancePtr()->getUVBufferID();
// 		glBindBuffer(GL_ARRAY_BUFFER, VboID);
// 		glBufferData(GL_ARRAY_BUFFER, m_pRenderMesh->getNumOfVertex() * 3 * 4, &m_pRenderMesh->m_tTextureUV[0], GL_STATIC_DRAW);
// 		glVertexAttribPointer(attributeLoc, 3, GL_FLOAT, SPFALSE, 0, 0);
// 		glEnableVertexAttribArray(attributeLoc);
// 		glBindBuffer(GL_ARRAY_BUFFER, 0);
	}

	SPVoid SPIRenderer::setShaderArrayMeshColor( const SPChar* name )
	{
		if(m_pRenderMesh->m_tColor.size() == 0)
			return;

		if(m_pRenderShader->getProgram() == SPNULL)
			return;

		SPUInt attributeLoc = m_pRenderShader->getAttributeLoc(name);

		m_vAttributeItems.push_back(attributeLoc);

		glVertexAttribPointer(attributeLoc, 4, GL_FLOAT, GL_FALSE, 4 * sizeof(SPFloat), &m_pRenderMesh->m_tColor[0]);
		glEnableVertexAttribArray(attributeLoc);

// 		SPUInt VboID = SPVBOManager::getInstancePtr()->getColorBufferID();
// 		glBindBuffer(GL_ARRAY_BUFFER, VboID);
// 		glBufferData(GL_ARRAY_BUFFER, m_pRenderMesh->getNumOfVertex() * 4 * 4, &m_pRenderMesh->m_tColor[0], GL_STATIC_DRAW);
// 		glVertexAttribPointer(attributeLoc, 3, GL_FLOAT, SPFALSE, 0, 0);
// 		glEnableVertexAttribArray(attributeLoc);
// 		glBindBuffer(GL_ARRAY_BUFFER, 0);
	}

	SPVoid SPIRenderer::setShaderArrayVector( const SPChar* name, SPFloat* value, SPUInt dimension )
	{
		if(m_pRenderShader->getProgram() == SPNULL)
			return;

		SPUInt attributeLoc = m_pRenderShader->getAttributeLoc(name);

		m_vAttributeItems.push_back(attributeLoc);

		glVertexAttribPointer(attributeLoc, dimension, GL_FLOAT, GL_FALSE, dimension * sizeof(SPFloat), value);
		glEnableVertexAttribArray(attributeLoc);
	}

	SPVoid SPIRenderer::setShaderArrayVector( const SPChar* name, SPFloat* value, SPUInt dimension, SPUInt stride )
	{
		if(m_pRenderShader->getProgram() == SPNULL)
			return;

		SPUInt attributeLoc = m_pRenderShader->getAttributeLoc(name);

		m_vAttributeItems.push_back(attributeLoc);

		glVertexAttribPointer(attributeLoc, dimension, GL_FLOAT, GL_FALSE, stride, value);
		glEnableVertexAttribArray(attributeLoc);
	}
	
	SPVoid SPIRenderer::bindVertexBufferArray( const SPChar* name, SPFloat* value, SPUInt dimension, SPUInt count )
	{
		if(m_pRenderShader->getProgram() == SPNULL)
			return;

		if(m_pVBOManager == SPNULL)
		{
			m_pVBOManager = new SPVBOManager();
		}

		//glUseProgram(m_pRenderShader->getProgram());

		SPUInt attributeLoc = m_pRenderShader->getAttributeLoc(name);
		m_vVBOAttributeItems.push_back(attributeLoc);


		SPUInt VboID = m_pVBOManager->getVertexBufferObject(name);
		glBindBuffer(GL_ARRAY_BUFFER, VboID);
		glBufferData(GL_ARRAY_BUFFER, count * dimension * 4, value, GL_STATIC_DRAW);
		glVertexAttribPointer(attributeLoc, 3, GL_FLOAT, SPFALSE, 0, 0);
		glEnableVertexAttribArray(attributeLoc);


		//m_bIsBindVertexBuffer = SPTRUE;
		//glBindBuffer(GL_ARRAY_BUFFER, 0);
	}

	SPVoid SPIRenderer::unBindVertexBufferArray()
	{
		// disable vertex attribute array
		for(SPUInt i = 0; i < m_vVBOAttributeItems.size(); i++)
		{
			glDisableVertexAttribArray(m_vVBOAttributeItems[i]);
		}

		m_vVBOAttributeItems.clear();

		glBindBuffer(GL_ARRAY_BUFFER, 0);
	}

	SPVoid SPIRenderer::bindIndexBufferArray( const SPChar* name, SPUShort* value, SPUInt count )
	{
		if(m_pRenderShader->getProgram() == SPNULL)
			return;

		if(m_pVBOManager == SPNULL)
		{
			m_pVBOManager = new SPVBOManager();
		}

		//glUseProgram(m_pRenderShader->getProgram());

		SPUInt VboID = m_pVBOManager->getIndexBufferObject(name);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, VboID);
		glBufferData(GL_ELEMENT_ARRAY_BUFFER,  count * sizeof(SPUShort), value, GL_STATIC_DRAW);

		//m_bIsBindIndexBuffer = SPTRUE;
	}

	SPVoid SPIRenderer::unBindIndexBufferArray()
	{
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
	}

	SPVoid SPIRenderer::setShaderUniformMVPMatrix( const SPChar* name )
	{
		if(m_pRenderShader->getProgram() == SPNULL)
			return;

		SPInt uniformLoc = m_pRenderShader->getUniformLoc(name);

		glUniformMatrix4fv(uniformLoc, 1, GL_FALSE, m_pRenderMVP->getMVPMatrix());
	}

	SPVoid SPIRenderer::setShaderUniformMVMatrix( const SPChar* name )
	{
		if(m_pRenderShader->getProgram() == SPNULL)
			return;

		SPInt uniformLoc = m_pRenderShader->getUniformLoc(name);

		glUniformMatrix4fv(uniformLoc, 1, GL_FALSE, m_pRenderMVP->getMVMatrix());
	}

	SPVoid SPIRenderer::setShaderUniformMMatrix( const SPChar* name )
	{
		if(m_pRenderShader->getProgram() == SPNULL)
			return;

		SPInt uniformLoc = m_pRenderShader->getUniformLoc(name);

		glUniformMatrix4fv(uniformLoc, 1, GL_FALSE, m_pRenderMVP->getModelMatrix());
	}

	SPVoid SPIRenderer::setShaderUniformITMMatrix( const SPChar* name )
	{
		if(m_pRenderShader->getProgram() == SPNULL)
			return;

		SPInt uniformLoc = m_pRenderShader->getUniformLoc(name);

		glUniformMatrix4fv(uniformLoc, 1, GL_FALSE, m_pRenderMVP->getITModelMatrix());
	}
	
	SPVoid SPIRenderer::setShaderUnifromTexture( const SPChar* name, SPUInt TextureID )
	{
		if(m_pRenderShader->getProgram() == SPNULL)
			return;

		// Bind the base map
		//glActiveTexture ( GL_TEXTURE0 );
		glActiveTexture ( GL_TEXTURE0 + m_NumTexture );
		glBindTexture ( GL_TEXTURE_2D, TextureID );

		SPInt uniformLoc = m_pRenderShader->getUniformLoc(name);

		// Set the base map sampler to texture unit to 0
		glUniform1i( uniformLoc, m_NumTexture );

		m_NumTexture++;
	}

	SPVoid SPIRenderer::setShaderUniformCubeMapTexture( const SPChar* name, SPUInt TextureID )
	{
		if(m_pRenderShader->getProgram() == SPNULL)
			return;

		// Bind the base map
		//glActiveTexture ( GL_TEXTURE0 );
		glActiveTexture ( GL_TEXTURE0 + m_NumTexture );
		glBindTexture ( GL_TEXTURE_CUBE_MAP, TextureID );

		SPInt uniformLoc = m_pRenderShader->getUniformLoc(name);

		// Set the base map sampler to texture unit to 0
		glUniform1i( uniformLoc, m_NumTexture );

		m_NumTexture++;
	}


	SPVoid SPIRenderer::setShaderUniformValue( const SPChar* name, SPFloat value)
	{
		if(m_pRenderShader->getProgram() == SPNULL)
			return;

		SPInt uniformLoc = m_pRenderShader->getUniformLoc(name);

		// Set a special float value to uniform name
		glUniform1f(uniformLoc, value);
	}

	SPVoid SPIRenderer::setShaderUniformVector( const SPChar* name, SPFloat* value, SPUInt dimension, SPUInt count)
	{
		if(m_pRenderShader->getProgram() == SPNULL)
			return;

		SPInt uniformLoc = m_pRenderShader->getUniformLoc(name);

		// Set a special float value to uniform name
		switch(dimension)
		{
		case 1:
			glUniform1fv(uniformLoc, count, value);
			break;
		case 2:
			glUniform2fv(uniformLoc, count, value);
			break;
		case 3:
			glUniform3fv(uniformLoc, count, value);
			break;
		case 4:
			glUniform4fv(uniformLoc, count, value);
			break;
		}
	}

	SPVoid SPIRenderer::setShaderUniformMatrix( const SPChar* name, const SPFloat* value, SPUInt dimension, SPUInt count)
	{
		if(m_pRenderShader->getProgram() == SPNULL)
			return;

		SPInt uniformLoc = m_pRenderShader->getUniformLoc(name);

		// Set a special float value to uniform name
		switch(dimension)
		{
		case 2:
			glUniformMatrix2fv(uniformLoc, count, false, value);
			break;
		case 3:
			glUniformMatrix3fv(uniformLoc, count, false, value);
			break;
		case 4:
			glUniformMatrix4fv(uniformLoc, count, false, value);
			break;
		default:
			assert(false);
			// wrong value for matrix dimension
		}
	}

	SPVoid SPIRenderer::setShaderUnformColor( const SPChar* name )
	{
		if(m_pRenderShader->getProgram() == SPNULL)
			return;

		SPInt uniformLoc = m_pRenderShader->getUniformLoc(name);

		glUniform4fv(uniformLoc, 1, (SPFloat*)&m_ObjectColor[0]);
	}

	SPVoid SPIRenderer::setDrawElementsWithOption( SPUInt option )
	{
		m_IsDrawArray = SPFALSE;

		m_DrawingOption = option;
	}

	SPVoid SPIRenderer::setDrawArraysWithOption( SPUInt option )
	{
		m_IsDrawArray = SPTRUE;

		m_DrawingOption = option;
	}

	SPVoid SPIRenderer::runMeshDraw()
	{
		if(m_IsDrawArray == SPTRUE)
		{
			//glDrawArrays(GL_TRIANGLES, 0, m_pRenderMesh->getNumOfVertex());
			glDrawArrays(m_DrawingOption, 0, m_pRenderMesh->getNumOfVertex());
		}
		else
		{
			//glDrawElements(GL_TRIANGLE_STRIP, 4, GL_UNSIGNED_SHORT, &m_pRenderMesh->m_tVertexIndex[0]);
			glDrawElements(m_DrawingOption, m_pRenderMesh->getNumOfVertexIndex(), GL_UNSIGNED_SHORT, &m_pRenderMesh->m_tVertexIndex[0]);
		}
	}

	SPVoid SPIRenderer::setCustomDrawElement( SPUShort* pIndices, SPUInt count, SPUInt option )
	{
		m_bIsCustomDraw = SPTRUE;

		m_IsDrawArray = SPFALSE;
		m_DrawingOption = option;

		m_pCustomTriangleIndices = pIndices;
		m_nCustomNumIndices = count;

	}

	SPVoid SPIRenderer::setCustomDrawArrays( SPUInt count, SPUInt option )
	{
		m_bIsCustomDraw = SPTRUE;

		m_IsDrawArray = SPTRUE;
		m_DrawingOption = option;

		m_nCustomNumVertex = count;
	}

	SPVoid SPIRenderer::runCustomDraw()
	{
		if(m_IsDrawArray == SPTRUE)
		{
			glDrawArrays(m_DrawingOption, 0, m_nCustomNumVertex);
		}
		else
		{
			glDrawElements(m_DrawingOption, m_nCustomNumIndices, GL_UNSIGNED_SHORT, &m_pCustomTriangleIndices[0]);
		}

		m_bIsCustomDraw = SPFALSE;
	}

	SPVoid SPIRenderer::setColor( SPFloat red, SPFloat green, SPFloat blue, SPFloat alpha )
	{
		m_ObjectColor = SPVec4f(red, green, blue, alpha);
	}

	SPVec4f SPIRenderer::getColor()
	{
		return m_ObjectColor;
	}

	SPVoid SPIRenderer::setTranslate( SPFloat x, SPFloat y, SPFloat z )
	{
		m_ObjectTranslate = SPVec3f(x, y, z);
	}

	SPVec3f SPIRenderer::getPosition()
	{
		return m_ObjectTranslate;
	}

	SPVoid SPIRenderer::setRotate( SPFloat angle, SPFloat x, SPFloat y, SPFloat z )
	{
		m_ObjectRotate = SPVec4f(angle, x, y, z);
	}

	SPVec4f SPIRenderer::getRotate()
	{
		return m_ObjectRotate;
	}

	SPVoid SPIRenderer::setScale( SPFloat xScale, SPFloat yScale, SPFloat zScale )
	{
		m_ObjectScale = SPVec3f(xScale, yScale, zScale);
	}

	SPVec3f SPIRenderer::getScale()
	{
		return m_ObjectScale;
	}

	SPVoid SPIRenderer::convertModelMatrix( SPFloat* matrix )
	{
		m_pRenderMVP->setModelMatrix(matrix);

		m_ConvertModelView = SPTRUE;
	}


	SPFloat* SPIRenderer::getViewMatrix()
	{
		return m_pRenderMVP->getViewMatrix();
	}

	SPFloat* SPIRenderer::getProjMatrix()
	{
		return m_pRenderMVP->getProjMatrix();
	}

	SPFloat* SPIRenderer::getVPMatrix()
	{
		return m_pRenderMVP->getViewProjMatrix();
	}

	SPFloat* SPIRenderer::getMVPMatrix()
	{
		return m_pRenderMVP->getMVPMatrix();
	}

	SPVoid SPIRenderer::updateMVPMtrix()
	{
		if(m_pRenderMVP != SPNULL && m_ConvertModelView != SPTRUE)
		{
			m_pRenderMVP->setTranslate(m_ObjectTranslate.x, m_ObjectTranslate.y, m_ObjectTranslate.z);
			m_pRenderMVP->setRotate(m_ObjectRotate.x, m_ObjectRotate.y, m_ObjectRotate.z, m_ObjectRotate.w);
			m_pRenderMVP->setScale(m_ObjectScale.x, m_ObjectScale.y, m_ObjectScale.z);
		}
	}

	SPVoid SPIRenderer::resetShaderParameters()
	{
		// disable vertex attribute array
		for(SPUInt i = 0; i < m_vAttributeItems.size(); i++)
		{
			glDisableVertexAttribArray(m_vAttributeItems[i]);
		}

		m_vAttributeItems.clear();

		// reset the variable about the texture number
		m_NumTexture = 0;

		m_ConvertModelView = SPFALSE;
	}

	SPVoid SPIRenderer::setVisible( SPBool visible)
	{
		m_bVisisble = visible;
	}

	SPBool SPIRenderer::getVisible()
	{
		return m_bVisisble;
	}

	SPVoid SPIRenderer::setDepthTest(SPBool bEnable)
	{
		m_bDepthTest = bEnable;
	}

	SPVoid SPIRenderer::setDepthTestOption(SPUInt aDepthFunc)
	{
		m_DepthFunc = aDepthFunc;
	}

	SPVoid SPIRenderer::setBlend(SPBool bEnable)
	{
		m_bBlend = bEnable;
	}

	SPVoid SPIRenderer::setColorMask(SPBool bEnable)
	{
		m_ColorMask[0] = m_ColorMask[1] = m_ColorMask[2] = m_ColorMask[3] = bEnable;
	}

	SPVoid SPIRenderer::setColorMask(SPBool aR, SPBool aG, SPBool aB, SPBool aA)
	{
		m_ColorMask[0] = aR;
		m_ColorMask[1] = aG;
		m_ColorMask[2] = aB;
		m_ColorMask[3] = aA;
	}

	SPVoid SPIRenderer::setDepthMask(SPBool bEnable)
	{
		m_DepthMask = bEnable;
	}

	SPVoid SPIRenderer::setCullFace(SPBool bEnable)
	{
		m_bCullFace = bEnable;
	}

	SPVoid SPIRenderer::setCullFaceOption(SPUInt aCullFace, SPUInt aFrontFace)
	{
		m_CullFace = aCullFace;
		m_FrontFace = aFrontFace;
	}

	SPBool SPIRenderer::getDepthTest()
	{
		return m_bDepthTest;
	}

	SPVoid SPIRenderer::MoveCameraZ(float _fDist)
	{
		if ( _fDist == 0.f )
			return ;
		// Assume that we use only world-oriented transformation.
		SPVec3f newPos = m_pRenderMVP->m_CameraPos;
		SPVec3f dir = glm::normalize(m_pRenderMVP->m_CameraTgt - m_pRenderMVP->m_CameraPos );
		dir *= _fDist;
		newPos += dir;

		m_pRenderMVP->setLookAt(newPos, m_pRenderMVP->m_CameraTgt, m_pRenderMVP->m_CameraUp);
	}

	SPVoid SPIRenderer::MoveCameraX(float _fDist)
	{
		if ( _fDist == 0.f )
			return ;
		// Assume that we use only world-oriented transformation.
		SPVec3f newPos = m_pRenderMVP->m_CameraPos;
		SPVec3f newTgt = m_pRenderMVP->m_CameraTgt;
		SPVec3f upVec = m_pRenderMVP->m_CameraUp;

		SPVec3f zDir = glm::normalize(m_pRenderMVP->m_CameraTgt - m_pRenderMVP->m_CameraPos );
		SPVec3f sideDir = glm::normalize(glm::cross(upVec, zDir));

		sideDir *= -_fDist;
		newPos += sideDir;
		newTgt += sideDir;

		// Camera position update
		m_pRenderMVP->setLookAt(newPos, newTgt, m_pRenderMVP->m_CameraUp);
	}

	SPVoid SPIRenderer::MoveCameraY(float _fDist)
	{
		if ( _fDist == 0.f )
			return ;
		// Assume that we use only world-oriented transformation.
		SPVec3f newPos = m_pRenderMVP->m_CameraPos;
		SPVec3f dir = glm::normalize(m_pRenderMVP->m_CameraUp);
		SPVec3f newTgt = m_pRenderMVP->m_CameraTgt;

		dir *= _fDist;
		newPos += dir;
		newTgt += dir;
		m_pRenderMVP->setLookAt(newPos, newTgt, m_pRenderMVP->m_CameraUp);
	}

	SPVoid SPIRenderer::setBlendOption( const SPUInt& sfactor, const SPUInt& dfactor )
	{
		m_BlendOption = SPVec4u(sfactor, dfactor, sfactor, dfactor);
	}

	SPVoid SPIRenderer::setBlendOption( const SPUInt& srcRGB, const SPUInt& dstRGB, const SPUInt& srcAlpha, const SPUInt& dstAlpha )
	{
		m_BlendOption = SPVec4u(srcRGB, dstRGB, srcAlpha, dstAlpha);
	}

}//namespace SPhysics
