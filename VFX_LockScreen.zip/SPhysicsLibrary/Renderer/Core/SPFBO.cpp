/**
* @file SPFBO.cpp
* @brief
*
* @date
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include <stdio.h>
#include <assert.h>
#include "SPLog.h"
#include "SPFBO.h"

namespace SPhysics
{
	SPFBO::SPFBO()
	{
		m_bEnableDepthBuffer = SPFALSE;
		m_nTextureWrapOption = WRAP_CRAMP;
		m_nTextureMagFilterOption = MFILTER_LINEAR;
		m_nTextureDataType = DTYPE_UBYTE;

		m_nFBOWidth = 0;
		m_nFBOHeight = 0;

		m_nFBOHandler = 0;
		m_nFBOTexture = 0;
		m_nFBODepthTexture = 0;

		m_tClearColor = SPVec4f();
	}

	SPFBO::~SPFBO()
	{
		destroyFBOSurface();
	}

	SPVoid SPFBO::createFBOSurface(const SPUInt& width, const SPUInt& height)
	{
		m_nFBOWidth = width;
		m_nFBOHeight = height;

		glGenTextures(1, &m_nFBOTexture);
		bindFBOTexture(m_nFBOTexture);

		glGenFramebuffers(1, &m_nFBOHandler);
		glBindFramebuffer(GL_FRAMEBUFFER, m_nFBOHandler);

		glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, m_nFBOTexture, 0);


		if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
			assert(false);

		clearFBOSurface();

		glBindFramebuffer(GL_FRAMEBUFFER, 0);
	}

	SPVoid SPFBO::resizeFBOSurface(const SPUInt& width, const SPUInt& height)
	{
		if (m_nFBOWidth == width && m_nFBOHeight == height)
			return;

		m_nFBOWidth = width;
		m_nFBOHeight = height;

		bindFBOTexture(m_nFBOTexture);

		if (m_bEnableDepthBuffer)
		{
			bindFBODepthTexture(m_nFBODepthTexture);
			glBindFramebuffer(GL_FRAMEBUFFER, m_nFBOHandler);
			glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_COMPONENT, GL_TEXTURE_2D, m_nFBODepthTexture, 0);
		}
	}

	SPVoid SPFBO::bindFBOSurface()
	{
		glBindFramebuffer(GL_FRAMEBUFFER, m_nFBOHandler);
		glViewport(0, 0, m_nFBOWidth, m_nFBOHeight);
	}

	SPVoid SPFBO::unbindFBOSurface(const SPUInt& viewWidth, const SPUInt& viewHeight)
	{
		glBindFramebuffer(GL_FRAMEBUFFER, 0);
		glViewport(0, 0, viewWidth, viewHeight);
	}

	SPVoid SPFBO::clearFBOSurface()
	{
		glClearColor(m_tClearColor.r, m_tClearColor.g, m_tClearColor.b, m_tClearColor.a);
		if (m_bEnableDepthBuffer == SPTRUE)
		{
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		}
		else
		{
			glClear(GL_COLOR_BUFFER_BIT);
		}
	}

	SPVoid SPFBO::setClearColor( const SPFloat& r, const SPFloat& g, const SPFloat& b, const SPFloat& a )
	{
		m_tClearColor = SPVec4f(r,g,b,a);
	}

	SPVoid SPFBO::destroyFBOSurface()
	{
		if (m_nFBOHandler != 0)
		{
			glDeleteFramebuffers(1, &m_nFBOHandler);
			m_nFBOHandler = 0;
		}

		if (m_nFBOTexture != 0)
		{
			glDeleteTextures(1, &m_nFBOTexture);
			m_nFBOTexture = 0;
		}

		if (m_nFBODepthTexture != 0)
		{
			glDeleteTextures(1, &m_nFBODepthTexture);
			m_nFBODepthTexture = 0;
		}
	}

	SPVoid SPFBO::setFBOClearColor(const SPFloat& red, const SPFloat& green, const SPFloat& blue, const SPFloat& alpha)
	{
		m_tClearColor = SPVec4f(red, green, blue, alpha);
	}

	SPUInt SPFBO::getFBOTexture()
	{
		return m_nFBOTexture;
	}

	SPUInt SPFBO::getFBODepthTexture()
	{
		return m_nFBODepthTexture;
	}

	SPUInt SPFBO::getFBOHandler()
	{
		return m_nFBOHandler;
	}

	SPVoid SPFBO::enableFBODepthBuffer()
	{
		m_bEnableDepthBuffer = SPTRUE;

		glBindFramebuffer(GL_FRAMEBUFFER, m_nFBOHandler);
		// Create depth buffer if it has not been created yet
		if (m_nFBODepthTexture==0)
		{
			glGenTextures(1, &m_nFBODepthTexture);
			bindFBODepthTexture(m_nFBODepthTexture);
		}
		glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, m_nFBODepthTexture, 0);
		glBindFramebuffer(GL_FRAMEBUFFER, 0);
	}

	SPVoid SPFBO::disableFBODepthBuffer()
	{
		m_bEnableDepthBuffer = SPFALSE; // disable flag
		glBindFramebuffer(GL_FRAMEBUFFER, m_nFBOHandler);
		glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, 0); // detach depth buffer from frame buufer
		glBindFramebuffer(GL_FRAMEBUFFER, 0);
	}

	SPVoid SPFBO::setFBOTextureWrapOption(const TEX_WRAP& wrapOption)
	{
		m_nTextureWrapOption = wrapOption;
	}

	SPVoid SPFBO::setFBOTextureMagFilterOption(const TEX_MFILTER& filterOption)
	{
		m_nTextureMagFilterOption = filterOption;
	}

	SPVoid SPFBO::setFBOTextureDataType(const TEX_DTYPE& dataType)
	{
		m_nTextureDataType = dataType;
	}

	SPVoid SPFBO::bindFBOTexture(const SPUInt& texID)
	{
		glBindTexture(GL_TEXTURE_2D, texID);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, m_nTextureWrapOption);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, m_nTextureWrapOption);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, m_nTextureMagFilterOption);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, m_nTextureMagFilterOption);

		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, m_nFBOWidth, m_nFBOHeight, 0, GL_RGBA, m_nTextureDataType, 0);
	}

	SPVoid SPFBO::bindFBODepthTexture(const SPUInt& texID)
	{
		glBindTexture(GL_TEXTURE_2D, m_nFBODepthTexture);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

		glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT, m_nFBOWidth, m_nFBOHeight, 0, GL_DEPTH_COMPONENT, GL_UNSIGNED_SHORT, 0);
	}
}//namespace SPhysics