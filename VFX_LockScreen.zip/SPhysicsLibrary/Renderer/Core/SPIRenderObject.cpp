/**
* @file SPIRenderObject.cpp
* @brief Render Object Interface makes connection between object add renderers
*
* @date 2014-08-
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPIRenderObject.h"

namespace SPhysics
{
//--------------------------------------------------------------------------------------------------
SPIRenderObject::SPIRenderObject():
	mObjectData(NULL)
{
	//mMaterial.setAmbientColor(0.3f, 0.3f, 0.3f, 1);
	//mMaterial.setDiffuseColor(0.7f, 0.7f, 0.7f, 1);
	//mMaterial.setSpecularColor(1, 1, 1, 1);
	//mMaterial.setShininess(20);
	mMaterial.mIsVisible = true;
	mMaterial.mLightDiffuse = 1;
	mMaterial.mLightAmbient = 1;
	mMaterial.mLightSpecular = 1;
	mMaterial.mOpacity = 20;
	mMaterial.mRenderMode = Default;

	//mGlRenderMode = GL_TRIANGLES;
}
//--------------------------------------------------------------------------------------------------
SPIRenderObject::~SPIRenderObject()
{
	mRenderers.clear();
}
//--------------------------------------------------------------------------------------------------
SPVoid SPIRenderObject::setObjectData(SPObjectData *objectData)
{
	mObjectData = objectData;
}
//--------------------------------------------------------------------------------------------------
SPObjectData* SPIRenderObject::getObjectData()
{
	return mObjectData;
}
//--------------------------------------------------------------------------------------------------
SPMaterialData* SPIRenderObject::getMaterialPtr()
{
	return &mMaterial;
}
//--------------------------------------------------------------------------------------------------
SPVoid SPIRenderObject::addRenderer(SPIRenderer* renderer)
{
	mRenderers.push_back(renderer);
}
//--------------------------------------------------------------------------------------------------
SPVoid SPIRenderObject::draw()
{
	for (SPUInt i=0; i<mRenderers.size(); ++i)
	{
		mRenderers[i]->setMesh(mObjectData);
		mRenderers[i]->convertModelMatrix(/*(SPFloat*)*/&mObjectData->getModelMatrix()[0][0]);
		mRenderers[i]->draw();
	}
}
//--------------------------------------------------------------------------------------------------
} //namespace SPhysics
