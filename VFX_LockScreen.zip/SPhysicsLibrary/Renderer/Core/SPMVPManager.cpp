/**
* @file SPMVPManager.cpp
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/


#include <math.h>
#include <stdio.h> 
//#include <stdlib.h>
#include <string.h>

#include "SPLog.h"
#include "SPMVPManager.h"
#include "gtc/type_ptr.hpp"


namespace SPhysics
{
	const SPFloat PI = 3.1415926535897932384626433832795f;

	SPMVPManager::SPMVPManager()
	{
		setIdentityMatrix(&m_stMVPMatrix);
		setIdentityMatrix(&m_stMVMatrix);
		setIdentityMatrix(&m_stViewMatrix);
		setIdentityMatrix(&m_stProjMatrix);
		setIdentityMatrix(&m_stModelMatrix);
		// initialize view matrix
		//setLookAt(0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f);
		// initialize translate, scale, rotate vector
		m_Translate = SPVec3f(0.0f, 0.0f, 0.0f);
		m_Scale = SPVec3f(1.0f, 1.0f, 1.0f);
		m_Rotate = SPVec4f(0.0f, 0.0f, 0.0f, 0.0f);
	}
	SPMVPManager::~SPMVPManager()
	{
	}
	SPVoid SPMVPManager::setLookAt(SPFloat eyex, SPFloat eyey, SPFloat eyez, SPFloat centerx, SPFloat centery, SPFloat centerz,	SPFloat upx, SPFloat upy, SPFloat upz)
	{
		setIdentityMatrix(&m_stViewMatrix);
		getLookAtMatrix(&m_stViewMatrix, eyex, eyey, eyez, centerx, centery, centerz, upx, upy, upz);

		m_CameraPos = SPVec3f(eyex, eyey, eyez);
		m_CameraTgt = SPVec3f(centerx, centery, centerz);
	}
	SPVoid SPMVPManager::setLookAt(SPVec3f& eye, SPVec3f& at, SPVec3f& up)
	{
		setIdentityMatrix(&m_stViewMatrix);
		getLookAtMatrix(&m_stViewMatrix, eye.x, eye.y, eye.z, at.x, at.y, at.z, up.x, up.y, up.z);

		m_CameraPos = SPVec3f(eye.x, eye.y, eye.z);
		m_CameraTgt = SPVec3f(at.x, at.y, at.z);
	}
	SPVoid SPMVPManager::setFrustum( SPFloat left, SPFloat right, SPFloat bottom, SPFloat top, SPFloat nearZ, SPFloat farZ )
	{
		setIdentityMatrix(&m_stProjMatrix);
		getFrustumMatrix(&m_stProjMatrix, left, right, bottom, top, nearZ, farZ);
	}

	SPVoid SPMVPManager::setPerspective( SPFloat fovy, SPFloat aspect, SPFloat nearZ, SPFloat farZ )
	{
		setIdentityMatrix(&m_stProjMatrix);
		getPerspectiveMatrix(&m_stProjMatrix, fovy, aspect, nearZ, farZ);
	}

	SPVoid SPMVPManager::setOrtho( SPFloat left, SPFloat right, SPFloat bottom, SPFloat top, SPFloat nearZ, SPFloat farZ )
	{
		setIdentityMatrix(&m_stProjMatrix);
		getOrthoMatrix(&m_stProjMatrix, left, right, bottom, top, nearZ, farZ);
	}

	SPVoid SPMVPManager::setModelTransform(SPMat4x4f& matrix)
	{
		m_stModelMatrix = matrix;
	}

	SPVoid SPMVPManager::setViewMatrix(const SPMat4x4f& matrix)
	{
		m_stViewMatrix = matrix;
	}

	SPVoid SPMVPManager::setViewMatrix(const SPFloat *matrix)
	{
		memcpy(glm::value_ptr(m_stViewMatrix), matrix, sizeof(SPFloat) * 16);
	}

	SPVoid SPMVPManager::setTranslate( SPFloat x, SPFloat y, SPFloat z )
	{
		m_Translate = SPVec3f(x, y, z);
		setIdentityMatrix(&m_stModelMatrix);
		//calculate model matrix
		translateMatrix(&m_stModelMatrix, m_Translate.x, m_Translate.y, m_Translate.z);
		rotateMatrix(&m_stModelMatrix, m_Rotate.x, m_Rotate.y, m_Rotate.z, m_Rotate.w);
		scaleMatrix(&m_stModelMatrix, m_Scale.x, m_Scale.y, m_Scale.z);
	}

	SPVoid SPMVPManager::setRotate( SPFloat angle, SPFloat x, SPFloat y, SPFloat z )
	{
		m_Rotate = SPVec4f(angle, x, y, z);

		setIdentityMatrix(&m_stModelMatrix);

		//calculate model matrix
		translateMatrix(&m_stModelMatrix, m_Translate.x, m_Translate.y, m_Translate.z);
		rotateMatrix(&m_stModelMatrix, m_Rotate.x, m_Rotate.y, m_Rotate.z, m_Rotate.w);
		scaleMatrix(&m_stModelMatrix, m_Scale.x, m_Scale.y, m_Scale.z);
	}

	SPVoid SPMVPManager::setScale( SPFloat x, SPFloat y, SPFloat z )
	{
		m_Scale = SPVec3f(x, y, z);
		setIdentityMatrix(&m_stModelMatrix);
		//calculate model matrix
		translateMatrix(&m_stModelMatrix, m_Translate.x, m_Translate.y, m_Translate.z);
		rotateMatrix(&m_stModelMatrix, m_Rotate.x, m_Rotate.y, m_Rotate.z, m_Rotate.w);
		scaleMatrix(&m_stModelMatrix, m_Scale.x, m_Scale.y, m_Scale.z);
	}

	SPVoid SPMVPManager::setModelMatrix(const SPFloat* matrix )
	{
		memcpy(glm::value_ptr(m_stModelMatrix), matrix, sizeof(SPFloat) * 16);
	}

	SPFloat* SPMVPManager::getMVPMatrix()
	{
		multiplyMatrix(&m_stMVMatrix, &m_stModelMatrix, &m_stViewMatrix);
		multiplyMatrix(&m_stMVPMatrix, &m_stMVMatrix, &m_stProjMatrix);

		return (SPFloat*)&m_stMVPMatrix;
	}

	SPFloat* SPMVPManager::getMVMatrix()
	{
		multiplyMatrix(&m_stMVMatrix, &m_stModelMatrix, &m_stViewMatrix);
		return (SPFloat*)&m_stMVMatrix;
	}

	SPFloat* SPMVPManager::getProjMatrix()
	{
		return (SPFloat*)&m_stProjMatrix;
	}

	SPFloat* SPMVPManager::getModelMatrix()
	{
		return (SPFloat*)&m_stModelMatrix;
	}

	SPFloat* SPMVPManager::getViewMatrix()
	{
		return (SPFloat*)&m_stViewMatrix;
	}

	SPFloat* SPMVPManager::getViewProjMatrix()
	{
		setIdentityMatrix(&m_stVPMatrix);

		multiplyMatrix(&m_stVPMatrix, &m_stViewMatrix, &m_stProjMatrix);
		return (SPFloat*) &m_stVPMatrix;
	}

	SPFloat* SPMVPManager::getITModelMatrix()
	{
		setIdentityMatrix(&m_stITModelMatrix);

		SPMat3x3f ret;
		for(SPUInt i = 0; i < 3; ++i)
		{
			for(SPUInt j = 0; j < 3; ++j)
			{
				ret[i][j] = m_stModelMatrix[i][j];
			}
		}

		ret = glm::inverse(ret);
		ret = glm::transpose(ret);

		for(SPUInt i = 0; i < 3; ++i)
		{
			for(SPUInt j = 0; j < 3; ++j)
			{
				m_stITModelMatrix[i][j] = ret[i][j];
			}
		}

		return (SPFloat*)&m_stITModelMatrix;
	}

	SPVec3f SPMVPManager::getCameraPosition()
	{
		return m_CameraPos;
	}

	void SPMVPManager::setCameraPosition(SPVec3f _pos)
	{
		m_CameraPos = _pos;
	}


	SPVoid SPMVPManager::getLookAtMatrix( SPMat4x4f *result, SPFloat eyex, SPFloat eyey, SPFloat eyez, SPFloat centerx, SPFloat centery, SPFloat centerz, SPFloat upx, SPFloat upy, SPFloat upz )
	{
				//ESMatrix result;
		SPFloat x[3], y[3], z[3];
		SPFloat mag, revMag;

		/* Make rotation matrix */

		/* Z vector */
		z[0] = eyex - centerx;
		z[1] = eyey - centery;
		z[2] = eyez - centerz;
		mag = sqrt(z[0] * z[0] + z[1] * z[1] + z[2] * z[2]);
		if (mag) {          /* mpichler, 19950515 */
			revMag = 1/ mag;
		#if 0
			z[0] /=  mag;
			z[1] /=  mag;
			z[2] /=  mag;
		#endif
			z[0] *=  revMag;
			z[1] *=  revMag;
			z[2] *=  revMag;
		}

		/* Y vector */
		y[0] = upx;
		y[1] = upy;
		y[2] = upz;

		/* X vector = Y cross Z */
		x[0] = y[1] * z[2] - y[2] * z[1];
		x[1] = -y[0] * z[2] + y[2] * z[0];
		x[2] = y[0] * z[1] - y[1] * z[0];

		/* Recompute Y = Z cross X */
		y[0] = z[1] * x[2] - z[2] * x[1];
		y[1] = -z[0] * x[2] + z[2] * x[0];
		y[2] = z[0] * x[1] - z[1] * x[0];

		/* mpichler, 19950515 */
		/* cross product gives area of parallelogram, which is < 1.0 for
		 * non-perpendicular unit-length vectors; so normalize x, y here
		 */

		mag = sqrt(x[0] * x[0] + x[1] * x[1] + x[2] * x[2]);
		if (mag) {
			revMag = 1/ mag;
	
			x[0] *= revMag;
			x[1] *= revMag;
			x[2] *= revMag;
		}

		mag = sqrt(y[0] * y[0] + y[1] * y[1] + y[2] * y[2]);
		if (mag) {
			revMag = 1/ mag;

			y[0] *= revMag;
			y[1] *= revMag;
			y[2] *= revMag;
		}

		// add
		m_CameraUp = SPVec3f(y[0], y[1], y[2]);

	#ifndef DOXYGEN_SKIP
	#define M(row,col)  (*result)[col][row] //!< m[col*4+row]
	#endif //DOXYGEN_SKIP
		M(0, 0) = x[0];
		M(0, 1) = x[1];
		M(0, 2) = x[2];
		M(0, 3) = 0.0;
		M(1, 0) = y[0];
		M(1, 1) = y[1];
		M(1, 2) = y[2];
		M(1, 3) = 0.0;
		M(2, 0) = z[0];
		M(2, 1) = z[1];
		M(2, 2) = z[2];
		M(2, 3) = 0.0;
		M(3, 0) = 0.0;
		M(3, 1) = 0.0;
		M(3, 2) = 0.0;
		M(3, 3) = 1.0;
	#undef M
		//glMultMatrixf(m);

		/* Translate Eye to Origin */
		translateMatrix(result, -eyex, -eyey, -eyez);
		//glTranslatef(-eyex, -eyey, -eyez);
	}

	SPVoid SPMVPManager::getFrustumMatrix( SPMat4x4f *result, SPFloat left, SPFloat right, SPFloat bottom, SPFloat top, SPFloat nearZ, SPFloat farZ )
	{
		SPFloat       deltaX = right - left;
		SPFloat       deltaY = top - bottom;
		SPFloat       deltaZ = farZ - nearZ;
		SPMat4x4f    frust;

		if ( (nearZ <= 0.0f) || (farZ <= 0.0f) ||
			(deltaX <= 0.0f) || (deltaY <= 0.0f) || (deltaZ <= 0.0f) )
			return;

		frust[0][0] = 2.0f * nearZ / deltaX;
		frust[0][1] = frust[0][2] = frust[0][3] = 0.0f;

		frust[1][1] = 2.0f * nearZ / deltaY;
		frust[1][0] = frust[1][2] = frust[1][3] = 0.0f;

		frust[2][0] = (right + left) / deltaX;
		frust[2][1] = (top + bottom) / deltaY;
		frust[2][2] = -(nearZ + farZ) / deltaZ;
		frust[2][3] = -1.0f;


		//frust[3][0] = -(right + left) / deltaX;
		//frust[3][1] =  -(top + bottom) / deltaY;
		frust[3][2] = -2.0f * nearZ * farZ / deltaZ;
		frust[3][0] = frust[3][1] = frust[3][3] = 0.0f;

		multiplyMatrix(result, &frust, result);
	}

	SPVoid SPMVPManager::getPerspectiveMatrix( SPMat4x4f *result, SPFloat fovy, SPFloat aspect, SPFloat nearZ, SPFloat farZ )
	{
		SPFloat frustumW, frustumH;

		frustumH = tanf( fovy / 360.0f * (SPFloat)PI ) * nearZ;
		frustumW = frustumH * aspect;

		getFrustumMatrix( result, -frustumW, frustumW, -frustumH, frustumH, nearZ, farZ );
	}

	SPVoid SPMVPManager::getOrthoMatrix( SPMat4x4f *result, SPFloat left, SPFloat right, SPFloat bottom, SPFloat top, SPFloat nearZ, SPFloat farZ )
	{
		SPFloat       deltaX = right - left;
		SPFloat       deltaY = top - bottom;
		SPFloat       deltaZ = farZ - nearZ;
		SPMat4x4f    ortho;

		if ( (deltaX == 0.0f) || (deltaY == 0.0f) || (deltaZ == 0.0f) )
			return;

		setIdentityMatrix(&ortho);

		ortho[0][0] = 2.0f / deltaX;
		ortho[3][0] = -(right + left) / deltaX;
		ortho[1][1] = 2.0f / deltaY;
		ortho[3][1] = -(top + bottom) / deltaY;
		ortho[2][2] = -2.0f / deltaZ;
		ortho[3][2] = -(nearZ + farZ) / deltaZ;

		multiplyMatrix(result, &ortho, result);
	}

	SPVoid SPMVPManager::scaleMatrix( SPMat4x4f *result, SPFloat sx, SPFloat sy, SPFloat sz )
	{
		(*result)[0][0] *= sx;
		(*result)[0][1] *= sx;
		(*result)[0][2] *= sx;
		(*result)[0][3] *= sx;

		(*result)[1][0] *= sy;
		(*result)[1][1] *= sy;
		(*result)[1][2] *= sy;
		(*result)[1][3] *= sy;

		(*result)[2][0] *= sz;
		(*result)[2][1] *= sz;
		(*result)[2][2] *= sz;
		(*result)[2][3] *= sz;
	}

	SPVoid SPMVPManager::translateMatrix( SPMat4x4f *result, SPFloat tx, SPFloat ty, SPFloat tz )
	{
		(*result)[3][0] += ((*result)[0][0] * tx + (*result)[1][0] * ty + (*result)[2][0] * tz);
		(*result)[3][1] += ((*result)[0][1] * tx + (*result)[1][1] * ty + (*result)[2][1] * tz);
		(*result)[3][2] += ((*result)[0][2] * tx + (*result)[1][2] * ty + (*result)[2][2] * tz);
		(*result)[3][3] += ((*result)[0][3] * tx + (*result)[1][3] * ty + (*result)[2][3] * tz);
	}

	SPVoid SPMVPManager::rotateMatrix( SPMat4x4f *result, SPFloat angle, SPFloat x, SPFloat y, SPFloat z )
	{
		SPFloat sinAngle, cosAngle;
		SPFloat mag = sqrtf(x * x + y * y + z * z);

		sinAngle = sinf ( angle * (SPFloat)PI / 180.0f );
		cosAngle = cosf ( angle * (SPFloat)PI / 180.0f );
		if ( mag > 0.0f )
		{
			SPFloat xx, yy, zz, xy, yz, zx, xs, ys, zs;
			SPFloat oneMinusCos;
			SPMat4x4f rotMat;

			x /= mag;
			y /= mag;
			z /= mag;

			xx = x * x;
			yy = y * y;
			zz = z * z;
			xy = x * y;
			yz = y * z;
			zx = z * x;
			xs = x * sinAngle;
			ys = y * sinAngle;
			zs = z * sinAngle;
			oneMinusCos = 1.0f - cosAngle;

			rotMat[0][0] = (oneMinusCos * xx) + cosAngle;
			rotMat[0][1] = (oneMinusCos * xy) + zs;
			rotMat[0][2] = (oneMinusCos * zx) - ys;
			rotMat[0][3] = 0.0f; 

			rotMat[1][0] = (oneMinusCos * xy) - zs;
			rotMat[1][1] = (oneMinusCos * yy) + cosAngle;
			rotMat[1][2] = (oneMinusCos * yz) + xs;
			rotMat[1][3] = 0.0f;

			rotMat[2][0] = (oneMinusCos * zx) + ys;
			rotMat[2][1] = (oneMinusCos * yz) - xs;
			rotMat[2][2] = (oneMinusCos * zz) + cosAngle;
			rotMat[2][3] = 0.0f; 

			rotMat[3][0] = 0.0f;
			rotMat[3][1] = 0.0f;
			rotMat[3][2] = 0.0f;
			rotMat[3][3] = 1.0f;

			multiplyMatrix( result, &rotMat, result );
		}
	}

	SPVoid SPMVPManager::multiplyMatrix( SPMat4x4f *result, SPMat4x4f *srcA, SPMat4x4f *srcB )
	{
		SPMat4x4f    tmp;
		SPInt         i;

		for (i=0; i<4; i++)
		{
			tmp[i][0] =	((*srcA)[i][0] * (*srcB)[0][0]) +
						((*srcA)[i][1] * (*srcB)[1][0]) +
						((*srcA)[i][2] * (*srcB)[2][0]) +
						((*srcA)[i][3] * (*srcB)[3][0]) ;

			tmp[i][1] =	((*srcA)[i][0] * (*srcB)[0][1]) + 
						((*srcA)[i][1] * (*srcB)[1][1]) +
						((*srcA)[i][2] * (*srcB)[2][1]) +
						((*srcA)[i][3] * (*srcB)[3][1]) ;

			tmp[i][2] =	((*srcA)[i][0] * (*srcB)[0][2]) + 
						((*srcA)[i][1] * (*srcB)[1][2]) +
						((*srcA)[i][2] * (*srcB)[2][2]) +
						((*srcA)[i][3] * (*srcB)[3][2]) ;

			tmp[i][3] =	((*srcA)[i][0] * (*srcB)[0][3]) + 
						((*srcA)[i][1] * (*srcB)[1][3]) +
						((*srcA)[i][2] * (*srcB)[2][3]) +
						((*srcA)[i][3] * (*srcB)[3][3]) ;
		}
		memcpy(result, &tmp, sizeof(SPMat4x4f));
	}

	SPVoid SPMVPManager::setIdentityMatrix( SPMat4x4f *result )
	{
		memset(result, 0x0, sizeof(SPMat4x4f));
		(*result)[0][0] = 1.0f;
		(*result)[1][1] = 1.0f;
		(*result)[2][2] = 1.0f;
		(*result)[3][3] = 1.0f;
	}

}//namespace SPhysics