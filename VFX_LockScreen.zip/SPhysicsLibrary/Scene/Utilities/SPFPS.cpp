/**
* @file SPFPS.cpp
* @brief 
*
* @date 2013-05-01
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPFPS.h"

namespace SPhysics
{

	SPFPS::SPFPS() : m_nFrameCnt(0), m_nFPS(0), m_nIntervalFrameCnt(50), m_pDrawText(SPNULL)
	{
#ifdef _WIN32
		m_lStartTickValue = 0;
#endif 
	}

	SPFPS::~SPFPS()
	{		
		SP_SAFE_DELETE(m_pDrawText);
	}

	SPVoid SPFPS::initApp(SPInt width, SPInt height)
	{		
		m_nFrameCnt = 0;
		m_nFPS = 0;

		m_nIntervalFrameCnt = 50;

		if(m_pDrawText == SPNULL)
			m_pDrawText = new SPDrawText();

		m_pDrawText->initialize(width, height);

		m_pDrawText->setTranslate(10.0f, height - 100.0f, 0.0f);

		m_pDrawText->setColor(1.0f, 0.0f, 0.0f, 1.0f);

		m_pDrawText->setFontSize(25.0);

		m_sStringFPS.clear();
		//m_pDrawText->setText("FPS : ");

		// calculate initialize time
#ifdef _WIN32
		m_lStartTickValue = GetTickCount(); // msec
#endif

#if defined(__ANDROID__) || defined(TIZEN)
		gettimeofday(&m_sStartTime, SPNULL);
#endif

	}

	SPVoid SPFPS::updateApp()
	{		
#if SRJ_TASK_PARALLEL_ENABLE && !defined(_WIN32) 
		drawApp();
#endif
	}	

	SPVoid SPFPS::drawApp()
	{			
		m_nFrameCnt++;

		SPChar numString[]=
		{
			"0123456789"
		};

#ifdef _WIN32

// 		if(m_nFrameCnt == 1)
// 			m_lStartTickValue = GetTickCount(); // msec

		if(m_nFrameCnt == m_nIntervalFrameCnt)
		{
			m_nFrameCnt = 0;

			SPULong CurTickValue = GetTickCount(); // msec

			//SPInt fps = (SPInt)((CurTickValue - m_lStartTickValue) / 100000);
			//SPInt fps = (SPInt)(100000 / (CurTickValue - m_lStartTickValue));
			m_nFPS = (SPInt)(m_nIntervalFrameCnt * 1000 / (CurTickValue - m_lStartTickValue));


			m_lStartTickValue = CurTickValue;

		}
#endif

#if defined(__ANDROID__) || defined(TIZEN)

// 		if(m_nFrameCnt == 1)
// 		{
// 			gettimeofday(&m_sStartTime, SPNULL);
// 		}
		if(m_nFrameCnt == m_nIntervalFrameCnt)
		{
			m_nFrameCnt = 0;

			gettimeofday(&m_sEndTime, SPNULL);
			SPLong st = m_sStartTime.tv_sec* 1000000 + m_sStartTime.tv_usec;
			SPLong et = m_sEndTime.tv_sec* 1000000 + m_sEndTime.tv_usec;
			//SPInt fps = (SPInt)((SPFloat)100*1000000 / (SPFloat)(et-st));
			m_nFPS = (SPInt)((SPFloat)m_nIntervalFrameCnt*1000000 / (SPFloat)(et-st));

//			SP_LOGE("JOOOOON   %d", m_nFPS);

			//DBGOUTPUT("+ <<JOON>> FPS = %d--- End", fps);

// 			SPInt Num10 = (SPInt)(fps / 10);
// 			memcpy(g_Str+6, g_NumStr+Num10, sizeof(WCHAR));
// 
// 			SPInt Num9 = (SPInt)(fps % 10);
// 			memcpy(g_Str+7, g_NumStr+Num9, sizeof(WCHAR));
// 
// 			g_Str[8] = L'\0';


			m_sStartTime = m_sEndTime;

		}
#endif

		//SP_LOGE("Native FPS:   %d", m_nFPS);
		m_sStringFPS.clear();
		m_sStringFPS = "FPS : ";

// 		if(m_nFPS >= 100)
// 			m_nFPS = m_nFPS % 100;


		SPInt currFPS = m_nFPS;


		SPInt FourthNum = currFPS / 1000;
		currFPS -= FourthNum * 1000;

		SPInt ThirdNum = currFPS / 100;
		currFPS -= ThirdNum * 100;

		SPInt SecondNum = currFPS / 10;
		currFPS -= SecondNum * 10;

		SPInt FirstNum = currFPS % 10;
 
		m_sStringFPS += numString[FourthNum];
		m_sStringFPS += numString[ThirdNum];
		m_sStringFPS += numString[SecondNum];
		m_sStringFPS += numString[FirstNum];
 		

		m_pDrawText->setText(m_sStringFPS.c_str());
		m_pDrawText->draw();

	}

	SPVoid SPFPS::onEventTouch(TOUCH_TYPE eventType, SPInt xPos, SPInt yPos)
	{

	}

	SPVoid SPFPS::onEventSensor(SENSOR_TYPE sensorType, SPFloat xValue, SPFloat yValue, SPFloat zValue)
	{
	}

	SPVoid SPFPS::onEventKey(KEY_TYPE keyID)
	{
	}

	SPVoid SPFPS::resetApp()
	{
	}

	SPVoid SPFPS::setForceApp()
	{
	}
}
//namespace SPhysics
