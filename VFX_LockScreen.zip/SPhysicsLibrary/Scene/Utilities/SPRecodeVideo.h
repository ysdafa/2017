/**
* @file SPRecodeVideo.h
* @brief This file includes module which is related  with texturing
*
* @date 2014-02-18
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_RECODE_VIDEO_H_
#define _SP_RECODE_VIDEO_H_

#include "SPDefines.h"
#include <string>
#include <vector>

#ifdef __linux__
#include <inttypes.h>
#define __int64 int64_t
#define _popen popen
#define _pclose pclose
#endif

#ifdef __MINGW32__
#include <inttypes.h>
#define _popen popen
#define _pclose pclose
#endif

namespace SPhysics
{
	class SPRecodeVideo
	{		
	public:
		SPRecodeVideo()
		{
			path          = "..\\..\\CommonUtilities\\ffmpeg\\ffmpeg.exe ";
			fps           = "-r 60 ";
			input_format  = "-f rawvideo ";
			pixel_format  = "-pix_fmt rgba ";
			resolution    = "-s 720x1280 ";
			input         = "-i - ";
			thread        = "-threads 0 ";		
			preset        = "-preset fast ";
			quality       = "-sameq ";
			crf           = "-crf 21 ";
			overwrite     = "-y ";
			vertical_flip = "-vf vflip ";
			output_path   = "..\\..\\VideoOut\\";
			output_name   = "output";
			output_format = ".mp4";

			ffmpeg        = SPNULL;
			screen_width  = 0;
			screen_height = 0;
			buffer		  = std::vector<SPInt>();
		}
		~SPRecodeVideo()
		{

		}

		std::string path;
 		std::string fps;
		std::string input_format;
 		std::string pixel_format;
		std::string resolution;
		std::string input;
		std::string thread;
		std::string preset;
		std::string quality;
		std::string crf;
		std::string overwrite;
		std::string vertical_flip;
		std::string output_path;
		std::string output_name;
		std::string output_format;
		
		
		FILE* ffmpeg;
		SPUInt screen_width;
		SPUInt screen_height;
		std::vector<SPInt> buffer;

		// �����
		// init
		// recode ĸ���� Draw ���������� ȣ��
		// deinit 
		// ������ ȣ��

		SPVoid init(const SPUInt& width, const SPUInt& height, const SPChar* outputFileName, const SPChar* outputFileFormat = "mp4")
		{
			screen_width = width;
			screen_height = height;

			buffer.resize(width * height, 0);
			#ifdef _MSC_VER
			resolution = "-s " + std::to_string((__int64)width) + "x" + std::to_string((__int64)height) + " ";
			#endif
			output_format = std::string(".") + outputFileFormat;
			std::string cmd = path + fps + input_format + pixel_format + quality + crf + resolution + thread + input + preset + overwrite + vertical_flip + output_path + outputFileName + output_format;

			ffmpeg = _popen(cmd.data(), "wb");
		}

		SPVoid recode()
		{
			glReadPixels(0, 0, screen_width, screen_height, GL_RGBA, GL_UNSIGNED_BYTE, &buffer[0]);
			fwrite(&buffer[0], screen_width * screen_height * 4, 1, ffmpeg);
		}

		SPVoid deinit()
		{
			_pclose(ffmpeg);
		}
	};
}	//namespace SPhysics

#endif // _SP_RECODE_VIDEO_H_
