/**
* @file SPBGChanger.cpp
* @brief 
*
* @date 2013-07-01
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPBGChanger.h"
#include "SPTextureManager.h"
#include "SPComparison.h"

namespace SPhysics
{

	SPBGChanger::SPBGChanger() : 
	m_nScreenWidth(0), 
	m_nScreenHeight(0), 
	m_pDrawCurrBG(SPNULL), 
	m_pDrawUnderBG(SPNULL), 
	m_pDrawMixedBG(SPNULL), 
	m_pFBO(SPNULL),
	m_bTransitionMode(SPFALSE), 
	m_nTransitionAlpha(1.0f), 
	m_nTransitionScale(0.97f),
	m_bBlurMode(SPFALSE),
	m_nTotTextureNum(0),
	m_nNextTexidx(1)
	{

	}

	SPBGChanger::~SPBGChanger()
	{	
		SP_SAFE_DELETE(m_pDrawCurrBG);
		SP_SAFE_DELETE(m_pDrawUnderBG);
		SP_SAFE_DELETE(m_pDrawMixedBG);
		SP_SAFE_DELETE(m_pFBO);

		m_vTextureBuff.clear();
		m_vBlurTextureBuff.clear();
	}

	SPVoid SPBGChanger::initApp(SPInt width, SPInt height)
	{
		m_nScreenWidth = width;
		m_nScreenHeight = height;

		m_fHalfWidth = m_nScreenWidth * 0.5f;
		m_fHalfHeight = m_nScreenHeight * 0.5f;

		m_bTransitionMode = SPFALSE;

		m_fAlphaStep = 1.0 / 80.0f;
		m_fScaleStep = 0.03 / 80.0f;

		if(m_pFBO == SPNULL)
		{
			m_pFBO = new SPFBO();
			m_pFBO->createFBOSurface(m_nScreenWidth, m_nScreenHeight);
		}

		m_pDrawCurrBG = new SPDrawImage();
		m_pDrawCurrBG->enableFBOImageDraw();
		m_pDrawCurrBG->initialize(width, height);
		//m_pDrawCurrBG->setRectAlign(RECT_ALIGN_CENTER);


		m_pDrawUnderBG = new SPDrawImage();
		m_pDrawUnderBG->enableFBOImageDraw();
		m_pDrawUnderBG->initialize(width, height);
		m_pDrawUnderBG->setRectAlign(RECT_ALIGN_CENTER);


		m_pDrawMixedBG = new SPDrawImage();
		m_pDrawMixedBG->initialize(width, height);

		m_nNextTexidx = 1;

	}

	SPVoid SPBGChanger::updateApp()
	{	
		if(m_bTransitionMode == SPTRUE)
		{
			if(m_nTransitionAlpha > 0.0f)
			{
				m_nTransitionAlpha -= m_fAlphaStep;
				m_nTransitionScale += m_fScaleStep;
			}else
			{
				changeCurrentTexture();

				m_nTransitionAlpha = 1.0f;
				m_nTransitionScale = 0.97f;

				m_bTransitionMode = SPFALSE;
			}
		}

		m_pDrawCurrBG->setColor(1.0f, 1.0f, 1.0f, m_nTransitionAlpha);
		m_pDrawUnderBG->setScale(m_nTransitionScale, m_nTransitionScale, 0.0f);
		m_pDrawUnderBG->setTranslate(m_fHalfWidth, m_fHalfHeight, 0.0f);
	}

	SPVoid SPBGChanger::drawApp()
	{		
		if(m_bTransitionMode == SPTRUE)
		{
			m_pFBO->bindFBOSurface();
			m_pFBO->clearFBOSurface();

			m_pDrawUnderBG->setTextureID(m_UnderTexID);
			m_pDrawUnderBG->draw();

			m_pDrawCurrBG->setTextureID(m_CurrentTexID);
			m_pDrawCurrBG->draw();

			m_pFBO->unbindFBOSurface(m_nScreenWidth, m_nScreenHeight);
		}
	}

	SPVoid SPBGChanger::onEventKey(KEY_TYPE keyID)
	{
		switch((int)keyID)
		{
		case KEY_TYPE_VOLUME_DOWN:
		case 'c':
		case 'C':
			startBGTransition();
			break;
		}
	}

	SPVoid SPBGChanger::addTexture( const SPChar *fileName )
	{
		SPUInt tmpTexID;

#if (ANDROID_PORTING_MODE)
		tmpTexID = SPTextureManager::getInstancePtr()->getTextureID(fileName);
#else
		tmpTexID = SPTextureManager::getInstancePtr()->loadTexture(fileName);
#endif
		m_vTextureBuff.push_back(tmpTexID);

		if(m_bBlurMode == SPTRUE)
		{
			tmpTexID = genBlurTexture(fileName);
			m_vBlurTextureBuff.push_back(tmpTexID);
		}

		m_nTotTextureNum = m_vTextureBuff.size();

		switch(m_nTotTextureNum)
		{
		case 1:
			{
				m_CurrentTexID = m_vTextureBuff[0];
				if(m_bBlurMode == SPTRUE)
				{
					m_CurrentBlurTexID = m_vBlurTextureBuff[0];
				}
			}
			break;
		case 2:
			{
				m_UnderTexID = m_vTextureBuff[1];
				if(m_bBlurMode == SPTRUE)
				{
					m_UnderBlurTexID = m_vBlurTextureBuff[1];
				}
			}
			break;
		default:
			break;
		}
	}


	SPUInt SPBGChanger::getCurrentBG()
	{
		SPUInt currentTextureID;
		if(m_bTransitionMode == SPTRUE)
		{
			currentTextureID = m_pFBO->getFBOTexture();
		}else
		{
			currentTextureID = m_CurrentTexID;
		}

		return currentTextureID;
	}

	SPUInt SPBGChanger::getCurrentBlurBG()
	{
		return m_CurrentBlurTexID;
	}

	SPVoid SPBGChanger::startBGTransition()
	{
		if(m_nTotTextureNum > 1)
		{
			m_bTransitionMode = SPTRUE;
		}
	}

	SPVoid SPBGChanger::changeCurrentTexture()
	{
		//SPUInt tmpID;

		//tmpID = m_CurrentTexID;
		m_CurrentTexID = m_UnderTexID;
		if(m_bBlurMode == SPTRUE)
		{
			m_CurrentBlurTexID = m_UnderBlurTexID;
		}

		if((SPInt)m_nNextTexidx == m_nTotTextureNum - 1 )
		{
			m_nNextTexidx = 0;
			m_UnderTexID = m_vTextureBuff[m_nNextTexidx];
			if(m_bBlurMode == SPTRUE)
			{
				m_UnderBlurTexID = m_vBlurTextureBuff[m_nNextTexidx];
			}
		}else
		{
			m_nNextTexidx++;
			m_UnderTexID = m_vTextureBuff[m_nNextTexidx];
			if(m_bBlurMode == SPTRUE)
			{
				m_UnderBlurTexID = m_vBlurTextureBuff[m_nNextTexidx];
			}
		}
	}

	SPVoid SPBGChanger::enableBlurMode()
	{
		m_bBlurMode = SPTRUE;
	}

	SPUInt SPBGChanger::genBlurTexture( const SPChar *fileName )
	{

		SPUInt tempTextureID;

		/// BLUR
#if (ANDROID_PORTING_MODE)
		TEXTURE_COLOR_BUFFER* buf = SPTextureManager::getInstancePtr()->getTextureColor(fileName);
#else
		TEXTURE_COLOR_BUFFER* buf = SPTextureManager::getInstancePtr()->loadTextureColor(fileName);
#endif

		const SPInt image_scaler = 20;
		const SPVec2i blurred_image_size(buf->ImgWidth/image_scaler, buf->ImgHeight/image_scaler);
		std::vector<SPUChar> texture(blurred_image_size.x*blurred_image_size.y * buf->PixelSize);

		for(SPInt j=0; j<blurred_image_size.y; ++j)
		{ 
			for(SPInt i=0; i<blurred_image_size.x; ++i)
			{
				const int dst_index = (j*blurred_image_size.x + i) * buf->PixelSize;
				const int src_index = (j*blurred_image_size.x*image_scaler + i) * image_scaler * buf->PixelSize;

				for(SPInt p=0; p<buf->PixelSize; ++p) 
				{
					texture[dst_index + p] = buf->ImgData[src_index + p];
				}
			} 
		}

		// blur /////////////////////////////////////////////////////////////////////////////////////////////

		// nombre d'octets par pixel
		const SPInt bp = buf->PixelSize;//mBpp/8;
		SPUChar* temp=new SPUChar[blurred_image_size.x*blurred_image_size.y*bp];

		const SPFloat radius = 2.0f;
		const SPFloat sigma2=radius*radius;
		const SPInt size=2;//good approximation of filter

		SPVec4f pixel;

		//blurs x components
		for(SPInt y=0;y<blurred_image_size.y;y++)
		{
			for(SPInt x=0;x<blurred_image_size.x;x++)
			{
				//process a pixel
				SPFloat sum=0;
				pixel = SPVec4f();

				//accumulate colors
				for(SPInt i=maximum(0,x-size);i<=minimum(blurred_image_size.x-1,x+size);++i)
				{
					const SPFloat factor=exp(-(i-x)*(i-x)/(2*sigma2));
					sum += factor;
					for(SPInt c=0;c<bp;c++)
					{
						pixel[c] += factor * texture[(i+y*blurred_image_size.x)*bp+c];
					}
				}
				//copy a pixel
				for(SPInt c=0;c<bp;c++)
				{
					temp[(x+y*blurred_image_size.x)*bp+c] = pixel[c]/sum;
				}
			}
		}

		//blurs x components
		for(SPInt y=0;y<blurred_image_size.y;y++)
		{
			for(SPInt x=0;x<blurred_image_size.x;x++)
			{
				//process a pixel
				SPFloat sum=0;
				pixel = SPVec4f();

				//accumulate colors
				for(SPInt i=maximum(0,y-size);i<=minimum(blurred_image_size.y-1,y+size);++i)
				{
					const SPFloat factor = exp(-(i-y)*(i-y)/(2*sigma2));
					sum += factor;
					for(SPInt c=0;c<bp;c++)
					{
						pixel[c] += factor * temp[(x+i*blurred_image_size.x)*bp+c];
					}
				}

				//copy a pixel
				for(SPInt c=0;c<bp;c++)
				{
					texture[(x+y*blurred_image_size.x)*bp+c] = pixel[c]/sum;
				}
			}
		}

		delete[] temp;
		glGenTextures(1, &tempTextureID);
		glBindTexture(GL_TEXTURE_2D, tempTextureID); 		
		glPixelStorei(GL_UNPACK_ALIGNMENT,1);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
		if(buf->PixelSize == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, blurred_image_size.x, blurred_image_size.y, 0, GL_RGBA, GL_UNSIGNED_BYTE, &texture[0]);
		else
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, blurred_image_size.x, blurred_image_size.y, 0, GL_RGB, GL_UNSIGNED_BYTE, &texture[0]);
		glBindTexture(GL_TEXTURE_2D, 0);

		texture.clear();

		//delete [] buf->ImgData;

		return tempTextureID;

	}

}
//namespace SPhysics
