/**
* @file SPBGChanger.h
* @brief 
*
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/


#ifndef _SP_BG_CHANGER_H_
#define _SP_BG_CHANGER_H_

#include "SPDefines.h"
#include "SPISceneComponent.h"

#include "SPDrawImage.h"
#include "SPFBO.h"


namespace SPhysics
{

	class SPBGChanger : public SPISceneComponent
	{
	public:
		/**
		* @brief     Constructor
		*/
		SPBGChanger();

		/**
		* @brief     Destructor
		*/
		virtual ~SPBGChanger();

	public:
		/**
		* @brief     Application initialization
		* @param     [IN] @b  width
		* @param     [IN] @b  height
		* @return     SPVoid
		*/
		SPVoid initApp(SPInt width, SPInt height);
		/**
		* @brief     Update application \n
						(event processing, updating Simulation, Generating Rendering meshes, etc.)
		* @return     SPVoid
		*/
		SPVoid updateApp();
		/**
		* @brief     Drawing scene
		* @return     SPVoid
		*/
		SPVoid drawApp();
		/**
		* @brief     Key event handling
		* @param     [IN] @b  keyID key event id
		* @return     SPVoid
		*/
		SPVoid onEventKey(KEY_TYPE keyID);
		/**
		* @brief     single-touch event handling
		* @param     [IN] @b  eventType event type of the single touch event (TOUCH_DOWN, TOUCH_MOVE, TOUCH_UP)
		* @param     [IN] @b  xPos x position of touch
		* @param     [IN] @b  yPos x position of touch
		* @return     SPVoid
		*/
		SPVoid onEventTouch(TOUCH_TYPE eventType, SPInt xPos, SPInt yPos){};
		/**
		* @brief     multi-touch event handling
		* @param     [IN] @b  touchID a id of finger which is moving
		* @param     [IN] @b  touchNum number of finger which is touched on (Max : 10)
		* @param     [IN] @b  eventType event type of the touch event (TOUCH_DOWN, TOUCH_MOVE, TOUCH_UP)
		* @param     [IN] @b  *xPos array of x position of multi-touch (Array size : 10)
		* @param     [IN] @b  *yPos array of x position of multi-touch (Array size : 10)
		* @return     SPVoid
		*/
		SPVoid onEventMultiTouch(TOUCH_TYPE eventType, SPInt touchID, SPInt touchNum, SPInt *xPos, SPInt *yPos){};
		/**
		* @brief     Sensor event handling
		* @param     [IN] @b  sensorType type of the sensor such as gyro, gravity ..
		* @param     [IN] @b  xValue a sensor value of X-axis
		* @param     [IN] @b  yValue a sensor value of Y-axis
		* @param     [IN] @b  zValue a sensor value of Z-axis
		* @return     SPVoid
		*/
		SPVoid onEventSensor(SENSOR_TYPE sensorType, SPFloat xValue, SPFloat yValue, SPFloat zValue){};
		/**
		* @brief     Reset application 
		* @return     SPVoid
		*/
		SPVoid resetApp(){};

		/**
		* @brief     add texture image 
		* @param     [IN] @b  fileName name of the image file
		* @return     SPVoid
		*/
		SPVoid addTexture(const SPChar *fileName);

		/**
		* @brief     return current texture id
		* @return     ID of texture
		*/
		SPUInt getCurrentBG();

		/**
		* @brief     return current blur texture id
		* @return     ID of blur texture
		*/
		SPUInt getCurrentBlurBG();

		/**
		* @brief     enable the blur flag to generate blur texture
		* @return     ID of blur texture
		*/
		SPVoid enableBlurMode();


	private:
		/**
		* @brief     run the transtion effect
		* @return    SPVoid
		*/
		SPVoid startBGTransition();

		/**
		* @brief     after finish the transtion, change the texture id
		* @return    SPVoid
		*/
		SPVoid changeCurrentTexture();

		/**
		* @brief     generate the blur texture
		* @param     [IN] @b  fileName name of the image file
		* @return     ID of blur texture
		*/
		SPUInt genBlurTexture(const SPChar *fileName);

	public:
		SPInt				m_nScreenWidth;
		SPInt				m_nScreenHeight;

		SPFloat				m_fHalfWidth;
		SPFloat				m_fHalfHeight;


		SPDrawImage*		m_pDrawCurrBG;
		SPDrawImage*		m_pDrawUnderBG;
		SPDrawImage*		m_pDrawMixedBG;

		SPFBO*				m_pFBO;


		SPUInt				m_CurrentTexID;
		SPUInt				m_CurrentBlurTexID;
		SPUInt				m_UnderTexID;
		SPUInt				m_UnderBlurTexID;

		// for alpha map animation
		std::vector<SPUInt> m_vTextureBuff;
		std::vector<SPUInt> m_vBlurTextureBuff;

		SPBool				m_bTransitionMode;


		SPFloat				m_nTransitionAlpha;
		SPFloat				m_nTransitionScale;

		SPFloat				m_fAlphaStep;
		SPFloat				m_fScaleStep;

		SPBool				m_bBlurMode;

		SPInt				m_nTotTextureNum;

	public:
		SPUInt				m_nNextTexidx;
	};

}//namespace SPhysics

#endif //_SP_BG_CHANGER_H_