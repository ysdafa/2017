/**
* @file SPRecodeVideoApp.h
* @brief 
*
* @date 2014-03-06
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/


#ifndef _SP_RECODE_VIDEO_APP_H_
#define _SP_RECODE_VIDEO_APP_H_

#include "SPISceneComponent.h"
#include "SPRecodeVideo.h"

namespace SPhysics
{

	class SPRecodeVideoApp : public SPISceneComponent
	{
	public:
		SPRecodeVideoApp();
		virtual ~SPRecodeVideoApp();

	public:		
		SPVoid initApp(SPInt width, SPInt height);
		SPVoid updateApp();
		SPVoid drawApp();
		SPVoid onEventKey(KEY_TYPE keyID);
		SPVoid onEventTouch(TOUCH_TYPE eventType, SPInt xPos, SPInt yPos);
		SPVoid onEventMultiTouch(TOUCH_TYPE eventType, SPInt touchID, SPInt touchNum, SPInt *xPos, SPInt *yPos){};
		SPVoid onEventSensor(SENSOR_TYPE sensorType, SPFloat xValue, SPFloat yValue, SPFloat zValue);
		SPVoid resetApp();
		SPVoid setForceApp();	
		
	private:				
		SPRecodeVideo m_cRecodeVideo;

	};

}//namespace SPhysics

#endif //_SP_FPS_H_