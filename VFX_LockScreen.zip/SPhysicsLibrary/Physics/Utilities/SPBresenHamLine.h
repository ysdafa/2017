/**
* @file SPBresenHamLine.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_BRESENHAM_LINE_H_
#define _SP_BRESENHAM_LINE_H_

#include "SPDefines.h"
#include "SPObject.h"

#include <list>
#include <glm.hpp>

namespace SPhysics
{
	/**
	* @class     SPBresenHamLine
	* @brief     make line with bresenham algorithm
	*/
	class SPBresenHamLine : public SPObject
	{
	public:
		/**
		* @brief     Constructor
		*/
		SPBresenHamLine(){}
		
		/**
		* @brief     Destructor
		*/
		~SPBresenHamLine(){}

		/**
		* @brief     Generate
		*/
		std::list<SPVec2i > generate(const glm::vec2& previousMouse, const glm::vec2& currentMouse) const
		{
			return generate(SPVec2i(previousMouse.x, previousMouse.y), SPVec2i(currentMouse.x, currentMouse.y));
		}

		/**
		* @brief     Generate BresenHamLine
		* @param     [IN] @b previousMouse A of line AB
		* @param     [IN] @b currentMouse B of line AB
		* @return     points
		*/
		std::list<SPVec2i > generate(const SPVec2i& previousMouse, const SPVec2i& currentMouse ) const
		{		
			std::list<SPVec2i > positionList;

			const SPInt xs = previousMouse.x;
			const SPInt ys = previousMouse.y;
			const SPInt xe = currentMouse.x;
			const SPInt ye = currentMouse.y;

			//previousMouse = currentMouse;

			SPInt dx = xe - xs;
			SPInt dy = ye - ys;

			SPInt xj = 1, yj = 1;

			if(xe < xs)
			{
				dx = -dx;
				xj = -1;
			}

			if(ye < ys)
			{
				dy = -dy;
				yj = -1;
			}

			if(dx >= dy)
			{
				SPInt d = SPInt( dy - (dx*0.5) );

				SPInt incE = dy;
				SPInt incNE = dy - dx;

				SPInt x = xs;
				SPInt y = ys;

				for (SPInt k = 1; k < dx; k++)
				{
					if(d <= 0)
					{
						d += incE;
						x += xj;
					} else {
						d += incNE;
						x += xj;
						y += yj;
					}
					positionList.push_back( SPVec2i(x,y) );
				}
			}

			if(dx < dy)
			{
				SPInt d = SPInt( dx - (dy*0.5) );

				SPInt incE = dx;
				SPInt incNE = dx - dy;

				SPInt x = xs;
				SPInt y = ys;

				for (SPInt k = 1; k < dy; k++)
				{
					if(d <= 0)
					{
						d += incE;
						y += yj;
					} else {
						d += incNE;
						x += xj;
						y += yj;
					}
					positionList.push_back( SPVec2i(x,y) );
				}
			}
			return positionList;
		}
	};
}
#endif //_SP_BRESENHAM_LINE_H_