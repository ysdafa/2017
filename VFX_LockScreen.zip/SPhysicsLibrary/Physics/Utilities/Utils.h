/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   Utils.h
 * @brief  Different utility functions and macros
 * @author Author (a.vysotskyi@samsung.com)
 */

#ifndef _UTILS_H_
#define _UTILS_H_

#include <string.h>

namespace SPhysics
{

/**
 * Declaration only. Used in COUNT_OF macro.
 */
template<typename T, unsigned int N>
char(*__CountOf(T(&)[N]))[N];

/**
 * Safe macro to retreive count of elements in array declared as T theArray[N]
 */
#define COUNT_OF(A) (sizeof(*__CountOf(A)))

/**
 * Copy array of elements
 * @param aDst pointer to destination buffer
 * @param aStr pointer to source buffer, contains elements of T types
 * @param aCount number of elements to copy from source to destination buffer
 */
template<typename T1, typename T2>
void memCopy(T1* aDst, const T2* aSrc, unsigned int aCount)
{
    assert(sizeof(T1) == sizeof(T2));
	memcpy(aDst, aSrc, aCount * sizeof(T2));
}

}
#endif
