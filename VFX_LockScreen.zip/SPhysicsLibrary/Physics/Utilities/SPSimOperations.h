/**
* @file SPSimOperations.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_SIM_OPERATIONS_H_
#define _SP_SIM_OPERATIONS_H_

#include "SPDefines.h"

#include "SPConstant.h"
#include "SPComparison.h"
#include "SPTest.h"
#include "Operations2D.h"

namespace SPhysics
{

	/**
	* @brief     Decide a time step
	* @param     [IN] @b target_time target time
	* @param     [IN] @b current_time current time
	* @param     [IN] @b frame_rate frame rate
	* @param     [IN] @b max_velocity max velocity of grid velocities
	* @param     [IN] @b CFL CFL condition
	* @param     [IN] @b cellSize cell size of grid
	* @return     SPDouble
	*/
	SPDouble decideTimeStep( const SPDouble& target_time, const SPDouble& current_time, const SPDouble& frame_rate, const SPDouble& max_velocity, const SPDouble& CFL, const SPDouble& cellSize ) {

		SPDouble dt = (SPDouble)1;

		if( max_velocity<EPSILON || (!(max_velocity>=(SPDouble)0)&&!(max_velocity<(SPDouble)0)) )
			dt = (SPDouble)1/frame_rate;
		else
			dt = minimum( cellSize/max_velocity*CFL, (SPDouble)1/frame_rate );

		if( current_time+dt > target_time )
		{
			dt = target_time-current_time;
		}
		return dt;
	}

	/**
	* @brief    Compute a current time 
	* @param     [IN] @b target_time target time
	* @param     [IN] @b current_time current time
	* @param     [IN] @b dt time step
	* @return     SPDouble
	*/
	SPDouble computeCurrentTime( const SPDouble& target_time, const SPDouble& current_time, const SPDouble& dt )
	{
		SPDouble result_current_time = current_time + dt;
		if( abs(target_time - result_current_time) < (SPDouble)1e-5 ) result_current_time=target_time;
		return result_current_time;
	}

	/**
	* @brief	 Convert face to Center
	* @param     [IN] @b input face grid
	* @param     [IN] @b cs grid cell states
	* @param     [IN] @b output
	* @return     SPVoid
	*/
	SPVoid faceToCenter(SPFaceGrid2D<SPDouble>& input, SPField2DTemplate<SPChar>& cs, SPField2DTemplate<SPVec2d >& output)
	{
		const SPVec2i center_grid_resolution = output.getResolution(); 

		for( SPInt i=0; i<center_grid_resolution.x; ++i )
		{
			for( SPInt j=0; j<center_grid_resolution.y; ++j )
			{
				output(i,j) = input.getCenterValue(i,j);	
			}
		}  
	}

	/**
	 * @brief  Convert center to face
	 */
	SPVoid centerToFace(SPField2DTemplate<SPVec2d >& input, SPField2DTemplate<SPChar>& state, SPFaceGrid2D<SPDouble>& output)
	{
	/*	PRE_NODE2D(output);

		for( SPInt j=0; j<m_Ny; ++j ) {
		for( SPInt i=0; i<m_NxPlus1; ++i ) { 

			const SPInt i0 = CLAMP<SPInt>(i-1,0,m_Nx-1);
			const SPInt i1 = CLAMP<SPInt>(i  ,0,m_Nx-1);

	// 		if( state(i0,j)==NEUMANN || state(i1,j)==NEUMANN ) { output.setUFace(i,j, 0); }
	// 		else {
				const SPDouble x_face = 0.5 * ( input(i0,j).x + input(i1,j).x );
				output.setUFace(i,j, x_face);
	//		}

		}}

		for( SPInt j=0; j<m_NyPlus1; ++j ) { 
		for( SPInt i=0; i<m_Nx; ++i ) { 

			const SPInt j0 = CLAMP<SPInt>(j-1,0,m_Ny-1);
			const SPInt j1 = CLAMP<SPInt>(j  ,0,m_Ny-1);

			if( state(i,j0)==NEUMANN || state(i,j1)==NEUMANN ) { output.setVFace(i,j, 0); }
			else {
				const SPDouble y_face = 0.5 * ( input(i,j0).y + input(i,j1).y );
				output.setVFace(i,j, y_face);
			}

		}}
		*/

	}
}

#endif //_SP_SIM_OPERATIONS_H_