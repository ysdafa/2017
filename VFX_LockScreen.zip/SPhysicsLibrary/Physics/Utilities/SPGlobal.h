/**
* @file SPGlobal.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_GLOBAL_H_
#define _SP_GLOBAL_H_


namespace SPhysics
{

	/**
	 * @enum   FMM_STATE
	 * @brief  FMM State
	 */
	enum FMM_STATE { FMM_STATE_FAR, FMM_STATE_INTERFACE, FMM_STATE_UPDATED, FMM_STATE_TRIAL }; 

	// common
	#define SPE_NONE			0	//!< None
	
	// particle's attributes
	#define SPE_ID			0x000001				//!< unique ID
	#define SPE_POSITION	0x000002				//!< position
	#define SPE_VELOCITY	0x000004				//!< velocity
	#define SPE_NORMAL		0x000008				//!< normal
 	#define SPE_FORCE		0x000010				//!< force
 	#define SPE_VORTICITY	0x000020				//!< vorticity
 	#define SPE_ORIENTATION	0x000040				//!< orientation
 	#define SPE_MASS		0x000080				//!< radius
 	#define SPE_RADIUS		0x000100				//!< radius
 	#define SPE_OPACITY		0x000200				//!< opacity
 	#define SPE_DENSITY		0x000400				//!< density
 	#define SPE_TEMPERATURE	0x000800				//!< temperature
 	#define SPE_LIFESPAN	0x001000				//!< lifespan
	#define SPE_TYPE		0x002000				//!< type
	//#define SIGNEDDIST	0x004000				//!< signed distance(=level set)
	
	// defined location on the grid
	#define atCELL			1014					//!< cell center
	#define atUFACE			1015					//!< u-face center
	#define atVFACE			1016					//!< v-face center
	#define atWFACE			1017					//!< w-face center
	#define atXEDGE			1018					//!< x-edge center
	#define atYEDGE			1019					//!< y-edge center
	#define atZEDGE			1020					//!< z-edge center
	#define atNODE			1021					//!< node
		

	// method for semi-Lagrangian interpolation
 	#define SPE_LINEAR		1041				//!< semi-Lagrangian with linear
	#define SPE_RK2			1042				//!< semi-Lagrangian with 2nd order Runge-Kutta
	#define SPE_RK3			1043				//!< semi-Lagrangian with 2nd order Runge-Kutta
	#define SPE_RK4			1044				//!< semi-Lagrangian with 2nd order Runge-Kutta
//	#define BFECC			1045				//!< Back and Forth Error Compensation and Correction

	// kernel
 	#define SPE_CONSTANT	1054	//!< SPE constant
 	#define POLY3			1055	//!< Poly3
 	#define POLY5			1056	//!< Poly5
 	#define POLY6			1057	//!< Poly6
 	#define GAUSSIAN		1058	//!< Gaussian
 	#define SPIKY			1059	//!< Spiky
 	#define FRESNEL			1060	//!< Fresnel
	// LINEAR are already defined.


#if 0
	// domain boundary
	#define X0SIDE			0x000001
	#define X1SIDE			0x000002
	#define Y0SIDE			0x000004
	#define Y1SIDE			0x000008
	#define Z0SIDE			0x000010
	#define Z1SIDE			0x000020

	// for region specification
	#define NEUMANN			107 					// Neumann boundary region
	#define DIRICHLET		108 					// Dirichlet boundary region
	#define INTERIOR		109 					// interior region
	
	// surface mesh display mode
	#define DISPLAY_MODE_POINTS			1010					// points
	#define DISPLAY_MODE_WIRE			1011					// wire frame
	#define DISPLAY_MODE_SURFACE		1012					// solid surface
	#define DISPLAY_MODE_WIRESURFACE	1013					// wire frame + solid surface

	// simulation mode
	#define SMOKE			1022					// smoke simulation
	#define LIQUID			1023					// free surface simulation
	#define TWOPHASE		1024					// two phase fluid simulation

	// boundary condition
	#define FREESLIP		1025					// free slip boundary condition
	#define NOSLIP			1026					// no slip boundary condition
	#define OPEN			1027					// open boundary condition

	// particle species
	#define SPLASH			1028					// splash particles
	#define BUBBLE			1029					// bubble particles
	#define FOAM			1030					// foam   particles

	// method for re-distancing
	#define FSM				1031					// fast sweeping method
	#define FMM				1032					// fast marching method

	// method for surfacing particles
	#define RADIAL			1033					// particle-to-grid by radial basis function
	#define SMOOTH			1034					// particle-to-grid by smooth kernel

	#define ACCUMULATE		1035					// particle-to-grid by accumulation
	#define OVERWRITE		1036					// particle-to-grid by overwriting
	#define MINIMUM			1037					// particle-to-grid by setting minimum value
	#define MAXIMUM			1038					// particle-to-grid by setting maximum value
	#define AVERAGE         1039					// particle-to-grid by adding noise
	#define MULTIPLY        1040					// particle-to-grid by adding noise
	
	
	// method for solving linear system
	#define CG				1046					// conjugate gradient
	#define PCG				1047					// preconditioned conjugate gradient
	#define JACOBI			1048					// Jacobi iteration
	#define GAUSS_SEIDEL	1049					// Gauss-Seidel iteration
	#define SOR				1060					// Successive over-relaxation
	#define RED_BLACK_GS	1061					// Red-Black Gauss-Seidel
	#define MG				1062					// Multi-grid solver with Red-Black Gauss-Seidel
	#define MGPCG			1063					// PCG with MG preconditioner

	// method for generating turbulence field
	#define KOLMOGOROV		1050					// Kolmogorov spectrum
	#define PERLIN			1051					// Perlin noise

	// method for outside grid
	#define EXTENSION		1052					// clamping boudnary condition
	#define PERIODIC		1053					// periodic boundary condition
#endif
}


#endif //_SP_GLOBAL_H_
