/**
* @file SPImplicitLine.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_IMPLICIT_LINE_H_
#define _SP_IMPLICIT_LINE_H_

#include "SPDefines.h"

#include "SPImplicitPrimitive2D.h"

namespace SPhysics
{
	/**
	* @class     SPImplicitHorizontalLine
	* @brief     Implicit horizontal line
	*/
	template<typename T>
	class SPImplicitHorizontalLine : public SPImplicitPrimitive2D<T>
	{
	private:

		T y;
		SPBool  upward;

	public:
		/**	
		* @brief     Constructor
		*/
		SPImplicitHorizontalLine();
		
		/**	
		* @brief     Constructor
		*/		
		SPImplicitHorizontalLine(const T& y_, const SPBool upward_ );
		
		/**	
		* @brief     Destructor
		*/
		virtual ~SPImplicitHorizontalLine();
		
		/**
		* @brief     Get Signed Distance
		* @param     [IN] @b position
		* @return     T
		*/
		virtual T getSignedDist( const SPVec2t& position ) const;
	};

	//TODO - use initializer list instead of assignment operator
	template<typename T>
	SPImplicitHorizontalLine<T>::SPImplicitHorizontalLine(): y(0), upward(SPTRUE)
	{

	};

	template<typename T>
	SPImplicitHorizontalLine<T>::SPImplicitHorizontalLine( const T& y_, const SPBool upward_ ) {

		y = y_;
		upward = upward_;

	}

	template<typename T>
	SPImplicitHorizontalLine<T>::~SPImplicitHorizontalLine() {
	}
		
	template<typename T>
	T SPImplicitHorizontalLine<T>::getSignedDist( const SPVec2t& position ) const {

		T dist = ( (upward)?(1):(-1) ) * ( position.y - y );
		if( isAlmostZero(dist) ) dist = -(T)EPSILON;
		return dist;

	}
}
#endif //_SP_IMPLICIT_LINE_H_