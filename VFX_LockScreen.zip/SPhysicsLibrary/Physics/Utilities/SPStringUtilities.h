/**
* @file SPStringUtilities.h
* @brief 
*
* @date 2013-02-13
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_STRING_UTILITIES_H_
#define _SP_STRING_UTILITIES_H_

#include "SPDefines.h"
#include "stdio.h"

#include <stdarg.h>

namespace SPhysics
{
	/**
	* @brief     vsprintf
	* @param     [IN] @b format string
	* @param     [IN] @b ap ap
	* @return     std::string
	*/
	inline std::string string_vsprintf(const SPChar* format, va_list ap)
	{
		static SPChar buffer[1024];

		vsprintf( buffer, format, ap );

		return buffer;
	}

	/**
	* @brief     sprintf
	* @param     [IN] @b format string
	* @return     std::string
	*/
	inline std::string string_sprintf(const SPChar* format,...)
	{
		va_list marker;
		va_start( marker, format );
		std::string result = string_vsprintf( format, marker );
		return result;
	}

	/**
	* @brief     Return true if target includes searching Strings
	* @param     [IN] @b fromString string
	* @param     [IN] @b searchString word for searching
	* @return     SPBool
	*/
	inline SPBool string_search(const std::string& fromString, const std::string& searchString)
	{
		std::string::size_type pos = 0;
		if( fromString.find( searchString, pos ) != std::string::npos ) return SPTRUE;
		return SPFALSE;
	}
}
#endif

