/**
* @file SPHermiteSpline.h
* @brief 
*
* @date 2014-07-07
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_HERMITE_SPLINE_H_
#define _SP_HERMITE_SPLINE_H_

#include "SPDefines.h"
#include "SPMesh.h"
#include <glm.hpp>

namespace SPhysics
{	
	/**
	* @class     SPHermiteSpline
	* @brief     Hermite Spline Interpolation
	*/
	template <typename T>
	class SPHermiteSpline /*: public SPObject*/
	{
	public:
		/**
		* @brief     Constructor
		*/
		SPHermiteSpline()
			: mPointsInited(0), mIsActive(SPFALSE)
		{
			for (SPInt i=0; i<3; ++i)
			{
				mPoints[i] = glm::vec3();
				mTangents[i] = glm::vec3();
			}
		}

		/**
		* @brief     Destructor
		*/
		~SPHermiteSpline(){}

		/**
		* @brief     Add next control point
		*/
		SPVoid nextPoint(const glm::vec3& nextPoint)
		{
			if(!mIsActive)
			{
				mIsActive = SPTRUE; // this is first call after inactive state
				mPointsInited = 0; // reset initialized points counter
			}
			mPoints[0] = mPoints[1];
			mPoints[1] = mPoints[2];
			mPoints[2] = nextPoint;
			mTangents[0] = mTangents[1];

			if (mPointsInited < 3)
				mPointsInited++;

			if (mPointsInited == 3)
				mTangents[1] = T(0.5) * (mPoints[2] - mPoints[0]); // tangent of middle control point
			else if (mPointsInited == 2)
				mTangents[1] = (mPoints[2] - mPoints[1]); // tangent of first control point
		}

		/**
		* @brief     Finalize the line to make possible to interpolate the last segment
		*/
		SPVoid finalize()
		{
			if (!mIsActive)
				return; // protection from duplicate call
			mPoints[0] = mPoints[1];
			mPoints[1] = mPoints[2];
			//mPoints[2] == mPoints[1]; // mPoints[2] becomes equal to mPoints[1], don't need to update
			mTangents[0] = mTangents[1];
			mTangents[1] = (mPoints[1] - mPoints[0]); // tangent of last control point
			mIsActive = SPFALSE;
		}

		/**
		* @brief     Calculate interpolated line
		* @param     [IN] @b numberPoints number of points (including second control point(p1), not including first control point(p0))
		* p[0] < i[1] < i[2] < ... < i[n-1] < i[n]==p[1]
		* p[0], p[1] - control points, i[1] ... i[n] - interpolated points, i[n]==p[1]
		* @return     SPMesh
		*/
		SPMesh interpolate(SPInt numberPoints)
		{
			if (mPointsInited<3) // possible to interpolate only when there are 3 points
				return SPMesh();

			SPMesh mesh;
			mesh.m_tVertex.reserve(numberPoints); // optimization of push_back

			for (SPInt i=1; i<=numberPoints; ++i)
			{
				T t = T(i) / numberPoints;

				T b0 =  2 * t * t * t - 3 * t * t + 1;
				T b1 = -2 * t * t * t + 3 * t * t;
				T b2 = t * t * t - 2 * t * t + t;
				T b3 = t * t * t - t * t;

				T x = b0 * mPoints[0].x + b1 * mPoints[1].x + b2 * mTangents[0].x + b3 * mTangents[1].x ;
				T y = b0 * mPoints[0].y + b1 * mPoints[1].y + b2 * mTangents[0].y + b3 * mTangents[1].y ;
				T z = b0 * mPoints[0].z + b1 * mPoints[1].z + b2 * mTangents[0].z + b3 * mTangents[1].z ;

				mesh.m_tVertex.push_back(SPVec3t(x, y, z));
			}

			return mesh;
		}

	private:
		SPInt mPointsInited; // count of initialized points
		SPBool mIsActive; // indication
		glm::vec3 mPoints[3]; // control points
		glm::vec3 mTangents[3]; // tangents at control points
	};

} //namespace SPhysics

#endif //_SP_HERMITE_SPLINE_H_