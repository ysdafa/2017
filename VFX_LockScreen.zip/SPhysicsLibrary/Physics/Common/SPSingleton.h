/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPSingleton.h
 * @brief  Finalized singleton template class
 * @author Author (a.vysotskyi@samsung.com)
 */

#ifndef _SPSINGLETON_H_
#define _SPSINGLETON_H_

#include "SPNonCopyable.h"

namespace SPhysics
{

/**
 * Forward declations.
 */
template<class T> class SPSingleton;
template<class T> class DestroyableSingleton;

/**
 * Class that declare it's template parameter as class
 */
template<class T> struct TypeWrapper
{
	typedef T ClassT;	//!< Template parameter type
};

/**
 * Class used as finalizator for singleton
 */
template <class T>
class Final
{
#ifdef __clang__
protected:
	virtual ~Final() {};
#else
private:
	virtual ~Final() {};
#endif
private:
	Final();
	friend class SPSingleton<T>;
	friend class DestroyableSingleton<T>;
#ifdef _MSC_VER
	friend TypeWrapper<T>::ClassT;
#elif __clang__
	friend T;
#else
	friend class TypeWrapper<T>::ClassT;
#endif
};

/**
 * Singleton template.
 * Inherit your class from T from Singleton<T> to prevent
 * directly creating instances of T, and make T NOT inheritable.
 * Class T should have public default constructor
 * No other requirements to T are applied.
 * Virtual inheritance from Final<T> prevent T from inheritance.
 */
template <class T>
class SPSingleton : virtual protected Final<T>
{
	/**
	 * Allow access to declaration of Holder from class Final
	 */
	friend class Final<T>;

public:
	/**
	 * Create (if required) and return instance of class T
	 */
	static T& getInstance();

private:
	/**
	 * Fake pure virtual function. Make class T abstract and prevent T from instantiation
	 */
	virtual void __foo() = 0;

protected:
	/**
	 * Protected delete. Prevent "delete &getInstance()"
	 */
	void operator delete(void* aPtr);

	/**
	 * Protected array delete. Prevent "delete[] &getInstance()"
	 */
	void operator delete[](void* aPtr);

private:
	/**
	 * This class contains implementation of pure virtual function, to allow instantiation this class.
	 */
	class Proxy : public T
	{
	private:
		/**
		 * Implementation of fake virtual function. Make class Proxy NOT abstract and allow instantiation
		 */
		virtual void __foo();
	};

	/**
	 * Class that contains pointer to singleton object
	 * and allow delete it at program exit if it was not destroyed directly
	 */
	class Holder
	{
	public:
		Holder(); /**<Holder constructor.  */
		~Holder(); /**<Holder destructor. Delete instance of singleton if exists  */
		Proxy* mInstance; /**<Instance of singleton (T).  */
	};

protected:
	static Holder mHolder; /**<Holder of single instance of Proxy (T). Operates as auto-pointer */
};


/**
 * Singleton with destroy method template
 */
template<class T>
class DestroyableSingleton : public SPSingleton<T>
{
public:
	/**
	 * Delete Singleton object
	 */
	static void destroy();
};

#include "SPSingleton.inl"
}

#endif // _SPSINGLETON_H_
