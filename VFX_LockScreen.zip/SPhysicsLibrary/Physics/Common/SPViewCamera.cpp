/*
 * Copyright (c) 2000~2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 */

/**
 * @file   SPViewCamera.cpp
 * @brief  File Object
 * @author Andrii Burevych (a.burevych@samsung.com)
 */

#include "SPViewCamera.h"
#include <gtx/transform.hpp>

namespace SPhysics
{

glm::mat4 SPViewCamera::mViewMatrix;
glm::mat4 SPViewCamera::mProjectionMatrix;
glm::vec3 SPViewCamera::mCameraPos = glm::vec3(20.f, 20.f, 20.f);
glm::vec3 SPViewCamera::mCameraDir = glm::vec3(0.f, 0.f, 1.f);
glm::vec3 SPViewCamera::mCameraNormal = glm::vec3(1.f, 0.f, 0.f);
glm::vec3 SPViewCamera::mCameraVertical = glm::vec3(0.f, 1.f, 0.f);

void SPViewCamera::makePerspectiveProjection(const float aFov, const float aRatio, const float aNearZ,
		const float aFarZ)
{
	mProjectionMatrix = glm::perspective(aFov, aRatio, aNearZ, aFarZ);
}

void SPViewCamera::makeOrthogonalProjection(const float aLeft, const float aRight, const float aBottom,
		const float aTop, const float aNearZ, const float aFarZ)
{
	mProjectionMatrix = glm::ortho(aLeft, aRight, aBottom, aTop, aNearZ, aFarZ);
}

void SPViewCamera::setViewCamera(const glm::vec3& aEye, const glm::vec3& aCenter, const glm::vec3& aUp)
{
	mViewMatrix = glm::lookAt(aEye, aCenter, aUp);
}

void SPViewCamera::setCameraPosition(const glm::vec3& aCameraPosition)
{
	mCameraPos = aCameraPosition;
}

void SPViewCamera::setCameraLookAt(const glm::vec3& aLookAtPoint)
{
	glm::vec3 dir = aLookAtPoint - mCameraPos;

	if (glm::length(dir) > 0.00001f)
	{
		mCameraDir = glm::normalize(dir);
		mCameraNormal = glm::normalize(glm::cross(mCameraDir, glm::vec3(0.f, 1.f, 0.f)));
		mCameraVertical = glm::normalize(glm::cross(mCameraNormal, mCameraDir));
	}
}

void SPViewCamera::setCameraRotate(float aAlpha, float aBeta)
{
	glm::mat3 rotateY = glm::mat3(glm::rotate(glm::radians(aBeta), glm::vec3(0.f, 1.f, 0.f)));
	mCameraDir = glm::normalize(rotateY * mCameraDir);
	mCameraNormal = glm::normalize(rotateY * mCameraNormal);
	mCameraVertical = glm::normalize(rotateY * mCameraVertical);
	glm::mat3 rotateX = glm::mat3(glm::rotate(glm::radians(aAlpha), mCameraNormal));
	mCameraDir = glm::normalize(rotateX * mCameraDir);
	mCameraNormal = glm::normalize(rotateX * mCameraNormal);
	mCameraVertical = glm::normalize(rotateX * mCameraVertical);
}

const glm::vec3& SPViewCamera::getCameraPosition()
{
	return mCameraPos;
}

const glm::vec3& SPViewCamera::getCameraDirectVector()
{
	return mCameraDir;
}

const glm::vec3& SPViewCamera::getCameraNormalVector()
{
	return mCameraNormal;
}

glm::vec3 SPViewCamera::getCameraVerticalVector()
{
	return mCameraVertical;
}

void SPViewCamera::updateViewCamera()
{
	SPViewCamera::setViewCamera(mCameraPos, mCameraPos + mCameraDir);
}

const glm::mat4& SPViewCamera::getViewMatrix()
{
	return mViewMatrix;
}

const glm::mat4& SPViewCamera::getProjectionMatrix()
{
	return mProjectionMatrix;
}

} /* namespace SPhysics */

