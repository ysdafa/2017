/**
* @file SPDrawTileRotate.cpp
* @brief
*
* @date 2014-04-08
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPDrawTileRotate.h"
#include "SPTextureManager.h"
#include "SPOperations.h"
#include "SPMotionCurve.h"
#include "gtx/transform.hpp"

#include "SPLog.h"

namespace SPhysics
{
//--------------------------------------------------------------------------------------------------
// public methods
//--------------------------------------------------------------------------------------------------
SPDrawTileRotate::SPDrawTileRotate()
	: mScale(1.0f), mTiles(SPNULL), m_bEnableFBODraw(SPFALSE)
{
	// set 1
	uRadiusTreshold = 35.0f;
	uCoefX = 20.0f;
	uCoefY = 0.2f;

	// set 2
	//uRadiusTreshold = 45.0f;
	//uCoefX = 20.0f;
	//uCoefY = 0.4f;

	// set 3
	//uRadiusTreshold = 50.0f;
	//uCoefX = 20.0f;
	//uCoefY = 0.8f;

}
//--------------------------------------------------------------------------------------------------
SPVoid SPDrawTileRotate::initRender(SPFloat width, SPFloat height)
{
	SPChar VertexShader[] =  
		"uniform mat4 uMVPMatrix;		\n"
		"attribute vec4 aPosition;		\n"
		"attribute vec2 aOffset;		\n"
		"attribute float aRotate;		\n"
		"attribute vec2 aTexUV;			\n"
		"varying vec2 vTexUV;			\n"
		"varying float vRotate;			\n"
		"varying vec3 vPos;				\n"

		"void main()					\n"
		"{								\n"
		"    vTexUV = aTexUV;			\n"
		"    vRotate = aRotate;			\n"
		"    vPos = aPosition.xyz;		\n"

		"    vec4 pos = aPosition + vec4(aOffset, 0.0, 0.0);\n"
		"    pos = uMVPMatrix * pos;	\n"
		"    gl_Position = pos;			\n"
		"}								\n";

	SPChar FragmentShader[] =  
		"precision mediump float;		\n"
		"uniform sampler2D uTexMap;		\n"
		"varying vec2 vTexUV;			\n"
		"varying float vZ;				\n"
		"varying float vRotate;			\n"
		"varying vec3 vPos;				\n"

		"uniform float uRadiusTreshold;	\n"
		"uniform float uCoefX;			\n"
		"uniform float uCoefY;			\n"

		"void main()\n"
		"{\n"
		"    vec3 color = vec3(0.0);\n"
		//"    vec3 color = vec3(cos(vRotate));\n"

		"    if (cos(vRotate)>0.0)\n" // don't render if plane is on back side
		"    {\n"
		"        color = texture2D( uTexMap, vTexUV ).rgb;\n"

		"        if (vPos.z < 49.9)\n" // shadow if point is lower than cube height in initial position
		"        {\n"
		"            float cx = uCoefX;\n"
		"            float cy = uCoefY;\n"

		"            float a = sqrt(cx*(50.0-vPos.z)*(50.0-vPos.z) + cy*vPos.y*vPos.y);\n" // ellipse shape shadow
		//"            float a = sqrt(cx*(50.0-vPos.z)*(50.0-vPos.z));\n" // linear shadow

		"            float b = 0.0;\n"
		"            float rt = uRadiusTreshold;\n"
		"            if (a>rt)\n"
		"            {\n"
		"                b = a - rt;\n"
		"            }\n"
		"            b = b / 50.0;\n"

		//"            color = color * (1.0-b/2.5);\n" // two different formulas for shadow attenuation
		"            color = color / (1.0+b);\n" // two different formulas for shadow attenuation

		"        }\n"
		"    }\n"

		"    gl_FragColor.rgb = color;						\n"
		"    gl_FragColor.a = 1.0;							\n"
		//"    gl_FragColor = vec4(0.0, 0.5, 0.0, 1.0);		\n"
		"}                                                  \n";


	SPFloat angleView = 30.0f;
	SPFloat viewShift = mBlocksHeight * 100.0f / 2 / tan(angleView / 2.0f * float(PI) / 180.0f);
	SPFloat ratio = (SPFloat)mBlocksWidth / mBlocksHeight;

	setLookAt(0, 0, 50 + viewShift,  0, 0, 50,  0, 1, 0);
	//setPerspectiveCameraView(angleView, ratio, 1, 5000);
	setPerspectiveCameraView(angleView, ratio, viewShift-50, viewShift+150); // 2000 - 2200 (reduce Z range for better accuracy of depth test)

	//setOrthogonalCameraView( -0.5f*mBlocksWidth*width, 0.5f*mBlocksWidth*width, -0.5f*mBlocksHeight*height, 0.5f*mBlocksHeight*height, -5000.0f, 5000.0f);
	createShaderProgram(VertexShader, FragmentShader);
}
//--------------------------------------------------------------------------------------------------
SPVoid SPDrawTileRotate::drawRender()
{
	setMesh(&mMeshTransform);

	setShaderUniformMVPMatrix("uMVPMatrix");
	setShaderUnifromTexture("uTexMap", mTextureId);

	// for debug
	setShaderUniformValue("uRadiusTreshold", uRadiusTreshold);
	setShaderUniformValue("uCoefX", uCoefX);
	setShaderUniformValue("uCoefY", uCoefY);
	//setShaderUniformValue("uShiftX", uShiftX);

	setShaderArrayMeshVertex("aPosition");
	setShaderArrayVector("aOffset", &mOffset[0][0], 2);
	setShaderArrayVector("aRotate", &mRotate[0], 1);

	setShaderArrayMeshUV("aTexUV");

	//setDrawArraysWithOption(/*DRAW_OPTION::*/DRAW_TRIANGLES);
	setDrawElementsWithOption(/*DRAW_OPTION::*/DRAW_TRIANGLES);
}
//--------------------------------------------------------------------------------------------------
SPVoid SPDrawTileRotate::setFBOUV()
{
	m_bEnableFBODraw = SPTRUE;
}
//--------------------------------------------------------------------------------------------------
SPVoid SPDrawTileRotate::setTextureId(SPUInt texId)
{
	mTextureId = texId;
}
//--------------------------------------------------------------------------------------------------
SPVoid SPDrawTileRotate::initMesh(SPFloat width, SPFloat height, SPFloat z, SPUInt blocksWidth, SPUInt blocksHeight)
{
	mMesh.m_tVertex.clear();
	mMesh.m_tVertexIndex.clear();
	mMesh.m_tTextureUV.clear();
	mOffset.clear();
	mRotate.clear();
	mBlocksWidth = blocksWidth;
	mBlocksHeight = blocksHeight;

	SPUShort curBlockNum = 0;
	for (SPUInt i=0; i<blocksHeight; ++i)
	{
		for (SPUInt j=0; j<blocksWidth; ++j)
		{
			// vertices ----------------------------------------------
			SPVec3f vertex;

			vertex = SPVec3f(-width*0.5f, -height*0.5f, z); // 0
			mMesh.m_tVertex.push_back(vertex);

			vertex = SPVec3f(width*0.5f, -height*0.5f, z); // 1
			mMesh.m_tVertex.push_back(vertex);

			vertex = SPVec3f(-width*0.5f, height*0.5f, z); // 2
			mMesh.m_tVertex.push_back(vertex);

			vertex = SPVec3f(width*0.5f, height*0.5f, z); // 3
			mMesh.m_tVertex.push_back(vertex);

			// indices -----------------------------------------------
			SPUShort ind0 = 4 * curBlockNum;
			SPUShort indArr[] = {(SPUShort)(0 + ind0), (SPUShort)(1u + ind0), (SPUShort)(2u + ind0),  (SPUShort)(2u + ind0), (SPUShort)(1u + ind0), (SPUShort)(3u + ind0)};
			mMesh.m_tVertexIndex.insert(mMesh.m_tVertexIndex.begin(), indArr, indArr+6);

			// texture UV --------------------------------------------
			SPVec3f textureUV;

			SPFloat u0 = (SPFloat)j / blocksWidth, u1 = (SPFloat)(j+1) / blocksWidth;
			SPFloat v0 = (SPFloat)i / blocksHeight, v1 = (SPFloat)(i+1) / blocksHeight;

			if (m_bEnableFBODraw)
			{
				// vertically flipped UV
				textureUV = SPVec3f(u0, 1 - v1, 0.0f); // 0 : 0,1
				mMesh.m_tTextureUV.push_back(textureUV);

				textureUV = SPVec3f(u1, 1 - v1, 0.0f); // 1 : 1,1
				mMesh.m_tTextureUV.push_back(textureUV);

				textureUV = SPVec3f(u0, 1 - v0, 0.0f); // 2 : 0,0
				mMesh.m_tTextureUV.push_back(textureUV);

				textureUV = SPVec3f(u1, 1 - v0, 0.0f); // 3 : 1,0
				mMesh.m_tTextureUV.push_back(textureUV);
			}
			else
			{
				// usual UV
				textureUV = SPVec3f(u0, v1, 0.0f); // 0 : 0,1
				mMesh.m_tTextureUV.push_back(textureUV);

				textureUV = SPVec3f(u1, v1, 0.0f); // 1 : 1,1
				mMesh.m_tTextureUV.push_back(textureUV);

				textureUV = SPVec3f(u0, v0, 0.0f); // 2 : 0,0
				mMesh.m_tTextureUV.push_back(textureUV);

				textureUV = SPVec3f(u1, v0, 0.0f); // 3 : 1,0
				mMesh.m_tTextureUV.push_back(textureUV);
			}

			//--
			curBlockNum++;
		}
	}
	SPVec2f vec2(0.0f, 0.0f);
	mOffset.insert(mOffset.end(), blocksHeight * blocksWidth * 4, vec2);
	mRotate.insert(mRotate.end(), blocksHeight * blocksWidth * 4, 0.0f);

	for (SPUInt i=0, vId=0; i<mBlocksHeight; ++i)
	{
		for (SPUInt j=0; j<mBlocksWidth; ++j)
		{
			for (SPUInt k=0; k<4; ++k, ++vId)
			{
				mOffset[vId].x = -(100.0f*mBlocksWidth/2.0f-50.0f) + j*100.f;
				mOffset[vId].y = +(100.0f*mBlocksHeight/2.0f-50.0f) - i*100.f;
			}
		}
	}

	mMeshTransform = mMesh;
}
//--------------------------------------------------------------------------------------------------
SPVoid SPDrawTileRotate::setTileData(SPTileItem tiles[TILE_NUM_H][TILE_NUM_W])
{
	mTiles = tiles;
}
//--------------------------------------------------------------------------------------------------
SPVoid SPDrawTileRotate::setTransform(SPFloat baseRotate, SPUInt cubeAnimationLength)
{
	SPUInt vId = 0;
	for (SPUInt i=0; i<mBlocksHeight; ++i)
	{
		for (SPUInt j=0; j<mBlocksWidth; ++j)
		{
			SPFloat angle = baseRotate;
			if (mTiles[i][j].mStartDelay==0)
				//angle += 180.0f * mTiles[i][j].mCurrentStep / cubeAnimationLength; // linear
				angle += 180.0f * SineInOut33::getInterpolation((SPFloat)mTiles[i][j].mCurrentStep / cubeAnimationLength); // curve

			// for debug
			#ifdef TILE_DEBUG
			if (i!=9 || j!=1)
				angle = 0.0f; // other tiles except of selected one are not rotated
			#endif

			SPMat4x4f tileMatr = glm::rotate(glm::radians(-angle), glm::vec3(0.0f, 1.0f, 0.0f));

			for (SPUInt k=0; k<4; ++k)
			{
				SPVec3f &v3 = mMesh.m_tVertex[vId];
				SPVec4f v4(v3.x, v3.y, v3.z, 1.0f);

				SPVec4f v4m = multiply(tileMatr, v4);

				//v4m.x += -(100.0f*mBlocksWidth/2.0f-50.0f) + j*100.f; // shift the tile on corresponding position
				//v4m.y += +(100.0f*mBlocksHeight/2.0f-50.0f) - i*100.f; // shift the tile on corresponding position

				mMeshTransform.m_tVertex[vId] = SPVec3f(v4m.x, v4m.y, v4m.z);

				mRotate[vId] = angle * (SPFloat)PI / 180.0f;

				vId++;
			}
		}
	}
}
//--------------------------------------------------------------------------------------------------
void SPDrawTileRotate::adjustRadiusTreshold(float delta)
{
	uRadiusTreshold += delta;
	SP_LOGI("uRadiusTreshold %.1f", uRadiusTreshold);
}
void SPDrawTileRotate::adjustCoefX(float delta)
{
	uCoefX += delta;
	SP_LOGI("uCoefX %.1f", uCoefX);
}
void SPDrawTileRotate::adjustCoefY(float delta)
{
	uCoefY += delta;
	SP_LOGI("uCoefY %.2f", uCoefY);
}
//--------------------------------------------------------------------------------------------------
// private methods
//--------------------------------------------------------------------------------------------------


} //namespace SPhysics