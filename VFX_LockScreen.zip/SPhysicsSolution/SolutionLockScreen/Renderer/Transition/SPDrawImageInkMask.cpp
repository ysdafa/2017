/**
* @file SPDrawImageInkMask.cpp
* @brief 
*
* @date 2013-05-08
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPTextureManager.h"
#include "SPDrawImageInkMask.h"


namespace SPhysics
{
	SPDrawImageInkMask::SPDrawImageInkMask() : m_pMesh(SPNULL), m_TextureId(-1), m_nRectAlign(1), m_fRectWidth(720.0f), m_fRectHeight(1280.0f), m_bEnableFBODraw(SPFALSE)
	{
	}

	SPDrawImageInkMask::~SPDrawImageInkMask()
	{
		SP_SAFE_DELETE(m_pMesh);
	}

	SPVoid SPDrawImageInkMask::initRender(SPFloat width, SPFloat height)
	{
		// Shader Program for DrawRect
		SPChar VertexShader[] =  
			"uniform mediump mat4 uMVPMatrix;				\n"
			"attribute vec4 aPosition;						\n"
			"attribute vec2 aTexUV;						\n"
			"varying vec2 v_texUV;							\n"
			"void main()									\n"
			"{												\n"
			"   v_texUV = aTexUV;							\n"
			"   gl_Position = uMVPMatrix * aPosition;		\n"
			"}												\n";

		SPChar FragmentShader[] =  
			"precision mediump float;                           \n"
			"uniform sampler2D uTexMap;                        \n"
			"varying vec2 v_texUV;								\n"
			"void main()                                        \n"
			"{                                                  \n"
			"  vec4 TexColor = texture2D( uTexMap, v_texUV );  \n"
			"  gl_FragColor = TexColor;				\n"
			//"  gl_FragColor = TexColor;				\n"
			//"  gl_FragColor = vec4(1.0, 0.0, 0.0, 1.0);				\n"
			"}                                                  \n";


		setOrthogonalCameraView( 0.0f, width, 0, height, -5000.0f, 5000.0f);
		createShaderProgram(VertexShader, FragmentShader);

		m_fRectWidth = width;
		m_fRectHeight = height;
		createRectVertex(width, height);
		createTextureUV();
	}

	SPVoid SPDrawImageInkMask::drawRender()
	{
		setMesh(m_pMesh);

		//setBlendOption(GL_ONE, GL_DST_ALPHA, GL_ONE, GL_DST_ALPHA);

		setShaderArrayMeshVertex("aPosition");
		setShaderArrayMeshUV("aTexUV");
		setShaderUniformMVPMatrix("uMVPMatrix");
		setShaderUnifromTexture("uTexMap", m_TextureId);
		
		setDrawElementsWithOption(DRAW_TRIANGLES_STRIP);
	}

	// API for control the rect size
	SPVoid SPDrawImageInkMask::setSize( SPFloat width, SPFloat height )
	{
		m_fRectWidth = width;
		m_fRectHeight = height;

		m_pMesh->m_tVertex.clear();
		m_pMesh->m_tVertex.resize(4);

		// case Center Align Rect Vertex
		m_pMesh->m_tVertex[0] = SPVec3f(-width*0.5f, -height*0.5f, 0.0f);		// point 1
		m_pMesh->m_tVertex[1] = SPVec3f(width*0.5f, -height*0.5f, 0.0f);		// point 2
		m_pMesh->m_tVertex[2] = SPVec3f(-width*0.5f, height*0.5f, 0.0f);		// point 3
		m_pMesh->m_tVertex[3] = SPVec3f(width*0.5f, height*0.5f, 0.0f);		// point 4
	}

	SPVoid SPDrawImageInkMask::enableFBOImageDraw()
	{
		m_bEnableFBODraw = SPTRUE;

		createFBOTextureUV();
	}

	SPVoid SPDrawImageInkMask::setTexture( const SPChar *fileName )
	{
#if (!ANDROID_PORTING_MODE)
		m_TextureId = SPTextureManager::getInstancePtr()->loadTexture(fileName);
#else
		m_TextureId = SPTextureManager::getInstancePtr()->getTextureID(fileName);
#endif
	}

	SPhysics::SPVoid SPDrawImageInkMask::setTextureID( SPUInt texID )
	{
		m_TextureId = texID;
	}

	// private Method
	SPVoid SPDrawImageInkMask::createRectVertex(SPFloat width, SPFloat height)
	{
		if(m_pMesh == SPNULL)
			m_pMesh = new SPMesh();

		// Rect Vertex
		//     P3                  P4
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1                  P2

		// create rect vertex position
		m_pMesh->m_tVertex.clear();
		m_pMesh->m_tVertex.resize(4);

		// case Center Align Rect Vertex
		
		m_pMesh->m_tVertex[0] = SPVec3f(-width*0.5f, -height*0.5f, 0.0f);		// point 1
		m_pMesh->m_tVertex[1] = SPVec3f(width*0.5f, -height*0.5f, 0.0f);		// point 2
		m_pMesh->m_tVertex[2] = SPVec3f(-width*0.5f, height*0.5f, 0.0f);		// point 3
		m_pMesh->m_tVertex[3] = SPVec3f(width*0.5f, height*0.5f, 0.0f);		// point 4


		m_pMesh->m_tVertexIndex.clear();
		//create rect vertex index
		m_pMesh->m_tVertexIndex.push_back(0);
		m_pMesh->m_tVertexIndex.push_back(1);
		m_pMesh->m_tVertexIndex.push_back(2);
		m_pMesh->m_tVertexIndex.push_back(3);
	}

	SPVoid SPDrawImageInkMask::createTextureUV()
	{

		if(m_bEnableFBODraw == SPTRUE)
		{
			createFBOTextureUV();
			return;
		}

		if(m_pMesh == SPNULL)
			m_pMesh = new SPMesh();

		m_pMesh->m_tTextureUV.clear();
		m_pMesh->m_tTextureUV.resize(4);

		// Rect Vertex
		//     P3(0,0)            P4(1,0)
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1(0,1)            P2(1.1)

		m_pMesh->m_tTextureUV[0] = SPVec3f(0.0f, 1.0f, 0.0f);		// point 1
		m_pMesh->m_tTextureUV[1] = SPVec3f(1.0f, 1.0f, 0.0f);		// point 2
		m_pMesh->m_tTextureUV[2] = SPVec3f(0.0f, 0.0f, 0.0f);		// point 3
		m_pMesh->m_tTextureUV[3] = SPVec3f(1.0f, 0.0f, 0.0f);		// point 4
	}

	SPVoid SPDrawImageInkMask::createFBOTextureUV()
	{
		if(m_pMesh == SPNULL)
			m_pMesh = new SPMesh();

		m_pMesh->m_tTextureUV.clear();
		m_pMesh->m_tTextureUV.resize(4);

		// Rect Vertex
		//     P3(0,0)            P4(1,0)
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1(0,1)            P2(1.1)

		m_pMesh->m_tTextureUV[0] = SPVec3f(0.0f, 0.0f, 0.0f);		// point 1
		m_pMesh->m_tTextureUV[1] = SPVec3f(1.0f, 0.0f, 0.0f);		// point 2
		m_pMesh->m_tTextureUV[2] = SPVec3f(0.0f, 1.0f, 0.0f);		// point 3
		m_pMesh->m_tTextureUV[3] = SPVec3f(1.0f, 1.0f, 0.0f);		// point 4
	}


}//namespace SPhysics
