/**
* @file SPDrawImageInk.cpp
* @brief 
*
* @date 2013-05-08
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPTextureManager.h"
#include "SPDrawImageInk.h"


namespace SPhysics
{
	SPDrawImageInk::SPDrawImageInk() : m_pMesh(SPNULL), m_fRectWidth(720.0f), m_fRectHeight(1280.0f), m_bEnableFBODraw(SPFALSE)
	{
		m_nCurrentTextureId = 0;
		m_nNextTextureId = 0;
		m_nMaskMapTextureId = 0;
		m_nNoiseTexID = 0;
	}

	SPDrawImageInk::~SPDrawImageInk()
	{
		SP_SAFE_DELETE(m_pMesh);
	}

	SPVoid SPDrawImageInk::initRender(SPFloat width, SPFloat height)
	{
		// Shader Program for DrawRect
		SPChar VertexShader[] =  
			"uniform mediump mat4 uMVPMatrix;												\n"
			"attribute vec4 aPosition;														\n"
			"attribute vec2 aTexUV;															\n"
			"attribute vec2 aMaskTexUV;														\n"
			"varying vec2 vTexUV;															\n"
			"varying vec2 vMasktexUV;														\n"
			"void main()																	\n"
			"{																				\n"
			"   vTexUV = aTexUV;															\n"
			"   vMasktexUV = aMaskTexUV;													\n"
			"   gl_Position = uMVPMatrix * aPosition;										\n"
			"}																				\n";

		SPChar FragmentShader[] =  
			"precision mediump float;														\n"
			"uniform sampler2D uCurrTexMap;													\n"
			"uniform sampler2D uNextTexMap;													\n"
			"uniform sampler2D uMaskTexMap;													\n"
			"uniform sampler2D uNoiseTexMap;												\n"
			"varying vec2	   vTexUV;														\n"
			"varying vec2	   vMasktexUV;													\n"
			"void main()																	\n"
			"{																				\n"
			// calculate the direction vector
			// direction vector can calculate using texture UV
			"  vec2 dirVec = vTexUV - vec2(0.5, 0.5);										\n"  // 0.5 and 0.5 is center of texture UV vector
			// get color vector of background and foreground images
			"  vec3 currColor = texture2D( uCurrTexMap, vTexUV ).rgb;						\n"
			"  vec3 nextColor = texture2D( uNextTexMap, vTexUV ).rgb;						\n"
			// get noise value from noise image
			"  float noiseWeight = (1.0 - texture2D( uNoiseTexMap, vTexUV ).r) * 0.4;				\n"
			// calculate uv vector for uv animation using direction and noise
			"  vec2 aniVec = (dirVec * noiseWeight) * 0.4;									\n"
			"  float maskAlpha = texture2D( uMaskTexMap, vMasktexUV + aniVec ).a;			\n"
// 			"  if(maskAlpha > 0.01){														\n"
// 			"     maskAlpha = clamp(maskAlpha + noiseWeight * 0.1, 0.0, 1.0);				\n"
// 			"  }																			\n"
			// calculate the direction vector for animation of mask
			"  gl_FragColor.rgb = mix(currColor, nextColor, maskAlpha);						\n"
			"  gl_FragColor.a = 1.0;														\n"
			"}																				\n";


		setOrthogonalCameraView( 0.0f, width, 0, height, -5000.0f, 5000.0f);
		createShaderProgram(VertexShader, FragmentShader);

		m_fRectWidth = width;
		m_fRectHeight = height;

		createRectVertex(width, height);
		createTextureUV();
	}

	SPVoid SPDrawImageInk::drawRender()
	{
		setMesh(m_pMesh);

		setShaderArrayMeshVertex("aPosition");
		setShaderArrayMeshUV("aTexUV");
		setShaderUniformMVPMatrix("uMVPMatrix");

		setShaderArrayVector("aMaskTexUV",(SPFloat*)&m_tMaskTexUV[0],3);

		// 
		setShaderUnifromTexture("uCurrTexMap", m_nCurrentTextureId);
		setShaderUnifromTexture("uNextTexMap", m_nNextTextureId);
		setShaderUnifromTexture("uMaskTexMap", m_nMaskMapTextureId);
		setShaderUnifromTexture("uNoiseTexMap", m_nNoiseTexID);

		setDrawElementsWithOption(DRAW_TRIANGLES_STRIP);
	}

	// API for control the rect size
	SPVoid SPDrawImageInk::setSize( SPFloat width, SPFloat height )
	{
		m_fRectWidth = width;
		m_fRectHeight = height;

		m_pMesh->m_tVertex.clear();
		m_pMesh->m_tVertex.resize(4);

		// Default LeftTop Align Rect Vertex
		m_pMesh->m_tVertex[0] = SPVec3f(0.0f, 0.0f, 0.0f);			// point 1
		m_pMesh->m_tVertex[1] = SPVec3f(width, 0.0f, 0.0f);		// point 2
		m_pMesh->m_tVertex[2] = SPVec3f(0.0f, height, 0.0f);		// point 3
		m_pMesh->m_tVertex[3] = SPVec3f(width, height, 0.0f);		// point 4
	}

	SPVoid SPDrawImageInk::setFBOUV()
	{
		m_bEnableFBODraw = SPTRUE;

		createFBOTextureUV();
	}

	SPVoid SPDrawImageInk::scaleMaskUV( SPFloat value )
	{
		SPFloat scaleValue = (value - 1.0f) * 0.5f;
		SPFloat maxUV = 1.0f - scaleValue;
		SPFloat minUV = 0.0f + scaleValue;

		for(SPUInt idx = 0; idx < 4; idx++)
		{
			if(m_pMesh->m_tTextureUV[idx].x == 1.0f)
			{
				m_tMaskTexUV[idx].x = maxUV;
			}
			else if(m_pMesh->m_tTextureUV[idx].x == 0.0f)
			{
				m_tMaskTexUV[idx].x = minUV;
			}

			if(m_pMesh->m_tTextureUV[idx].y == 1.0f)
			{
				m_tMaskTexUV[idx].y = maxUV;
			}
			else if(m_pMesh->m_tTextureUV[idx].y == 0.0f)
			{
				m_tMaskTexUV[idx].y = minUV;
			}
		}
	}

	SPVoid SPDrawImageInk::setNoiseTexture( const SPChar *fileName )
	{
#if (!ANDROID_PORTING_MODE)
		m_nNoiseTexID = SPTextureManager::getInstancePtr()->loadTexture(fileName);
#else
		m_nNoiseTexID = SPTextureManager::getInstancePtr()->getTextureID(fileName);
#endif
	}

	SPVoid SPDrawImageInk::setCurrentTextureID( SPUInt texID )
	{
		m_nCurrentTextureId = texID;
	}

	SPVoid SPDrawImageInk::setNextTextureID( SPUInt texID )
	{
		m_nNextTextureId = texID;
	}

	SPVoid SPDrawImageInk::setMaskMapTextureID( SPUInt texID )
	{
		m_nMaskMapTextureId = texID;
	}

	// private Method
	SPVoid SPDrawImageInk::createRectVertex(SPFloat width, SPFloat height)
	{
		if(m_pMesh == SPNULL)
			m_pMesh = new SPMesh();

		// Rect Vertex
		//     P3                  P4
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1                  P2

		m_pMesh->m_tVertex.clear();
		m_pMesh->m_tVertex.resize(4);


		// Default LeftTop Align Rect Vertex
		m_pMesh->m_tVertex[0] = SPVec3f(0.0f, 0.0f, 0.0f);			// point 1
		m_pMesh->m_tVertex[1] = SPVec3f(width, 0.0f, 0.0f);		// point 2
		m_pMesh->m_tVertex[2] = SPVec3f(0.0f, height, 0.0f);		// point 3
		m_pMesh->m_tVertex[3] = SPVec3f(width, height, 0.0f);		// point 4


		m_pMesh->m_tVertexIndex.clear();
		//create rect vertex index
		m_pMesh->m_tVertexIndex.push_back(0);
		m_pMesh->m_tVertexIndex.push_back(1);
		m_pMesh->m_tVertexIndex.push_back(2);
		m_pMesh->m_tVertexIndex.push_back(3);
	}

	SPVoid SPDrawImageInk::createTextureUV()
	{

		if(m_bEnableFBODraw == SPTRUE)
		{
			createFBOTextureUV();
			return;
		}

		if(m_pMesh == SPNULL)
			m_pMesh = new SPMesh();

		m_pMesh->m_tTextureUV.clear();
		m_pMesh->m_tTextureUV.resize(4);

		// Rect Vertex
		//     P3(0,0)            P4(1,0)
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1(0,1)            P2(1.1)

		m_pMesh->m_tTextureUV[0] = SPVec3f(0.0f, 1.0f, 0.0f);		// point 1
		m_pMesh->m_tTextureUV[1] = SPVec3f(1.0f, 1.0f, 0.0f);		// point 2
		m_pMesh->m_tTextureUV[2] = SPVec3f(0.0f, 0.0f, 0.0f);		// point 3
		m_pMesh->m_tTextureUV[3] = SPVec3f(1.0f, 0.0f, 0.0f);		// point 4


		m_tMaskTexUV.clear();
		m_tMaskTexUV.resize(4);
		for(SPUInt idx=0; idx < 4; idx++)
		{
			m_tMaskTexUV[idx] = m_pMesh->m_tTextureUV[idx];
		}
	}

	SPVoid SPDrawImageInk::createFBOTextureUV()
	{
		if(m_pMesh == SPNULL)
			m_pMesh = new SPMesh();

		m_pMesh->m_tTextureUV.clear();
		m_pMesh->m_tTextureUV.resize(4);

		// Rect Vertex
		//     P3(0,0)            P4(1,0)
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1(0,1)            P2(1.1)

		m_pMesh->m_tTextureUV[0] = SPVec3f(0.0f, 0.0f, 0.0f);		// point 1
		m_pMesh->m_tTextureUV[1] = SPVec3f(1.0f, 0.0f, 0.0f);		// point 2
		m_pMesh->m_tTextureUV[2] = SPVec3f(0.0f, 1.0f, 0.0f);		// point 3
		m_pMesh->m_tTextureUV[3] = SPVec3f(1.0f, 1.0f, 0.0f);		// point 4


		m_tMaskTexUV.clear();
		m_tMaskTexUV.resize(4);
		for(SPUInt idx=0; idx < 4; idx++)
		{
			m_tMaskTexUV[idx] = m_pMesh->m_tTextureUV[idx];
		}
	}



}//namespace SPhysics
