/**
* @file SPDrawTileBlend.h
* @brief This file includes module that draws specific Image
*
* @date 2013-05-08
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_DRAW_TILE_BLEND_H_
#define _SP_DRAW_TILE_BLEND_H_

#include "SPDefines.h"
#include "SPIRenderer.h"
#include "SPShaderManager.h"
#include "SPMVPManager.h"
#include "SPMesh.h"
#include <glm.hpp>

namespace SPhysics
{

	/**
	* @class     SPDrawTileBlend
	* @brief     This class is mainly for drawing image.
	*/
	class SPDrawTileBlend : public SPIRenderer
	{

	/**
	* @def     RECT_ALIGN_LEFT_TOP
	* @brief     Rectangle Align Mode
	*/
	#define RECT_ALIGN_LEFT_TOP 0
	/**
	* @def     RECT_ALIGN_CENTER
	* @brief     Rectangle Align Mode
	*/
	#define RECT_ALIGN_CENTER 1

	public:
		/**
		* @brief     Constructor
		*/
		SPDrawTileBlend();
		/**
		* @brief     Destructor
		*/
		virtual ~SPDrawTileBlend();

	public:

		/**
		* @brief     Initialize and Prepare rendering\n 
					(set camera setting, initialize shader , create rectangle mesh)
		* @param     [IN] @b width Clipping Plane's width size
		* @param     [IN] @b height Clipping Plane's height size
		* @return     SPVoid
		*/
		SPVoid initRender(SPFloat width, SPFloat height); // virtual

		/**
		* @brief     Mesh setting & binding shader variables for drawing.
		* @return     SPVoid
		 */
		SPVoid drawRender(); // virtual
		
		/**
		* @brief     Set the textureid to Image Rectangle Meshes.
		* @param     [IN] @b texture id of background texture
		* @return     SPVoid
		*/
		SPVoid setCurrentTextureID(SPUInt texID);

		/**
		* @brief     Set the textureid to Image Rectangle Meshes.
		* @param     [IN] @b texture id of foreground texture
		* @return     SPVoid
		*/
		SPVoid setNextTextureID(SPUInt texID);

		/**
		* @brief     Set the textureid for tile blend animation.
		* @param     [IN] @b texture id of alpha map
		* @return     SPVoid
		*/
		SPVoid setAlphaMapTextureID(SPUInt texID);

		/**
		* @brief     Adjust rectangle mesh size
		* @param     [IN] @b width new rectangle width size
		* @param     [IN] @b height new rectangle height size
		* @return     SPVoid
		*/
		SPVoid setSize( SPFloat width, SPFloat height );

		/**
		* @brief     Set Rectangle Alignment mode \n
					(RECT_ALIGN_CENTER or RECT_ALIGN_LEFT_TOP)
		* @param     [IN] @b align alignment mode
		* @return     SPVoid
		*/
		SPVoid setRectAlign(SPUInt align);

		/**
		* @brief     enable the fbo draw flag for the texture coordinate uv
		* @return     SPVoid
		*/
		SPVoid setFBOUV();


		SPVoid setAlphaBlend(SPFloat value);

	private:
		/**
		* @brief     Create mesh data
		* @param     [IN] @b width Rectangle width size
		* @param     [IN] @b height Rectangle height size
		* @return     SPVoid
		*/
		SPVoid createRectVertex(SPFloat width, SPFloat height);

		/**
		* @brief     Create Texture's UV Coordinates to rendering image
		* @return     SPVoid
		*/
		SPVoid createTextureUV();

		/**
		* @brief     Create Texture's UV Coordinates for the fbo texture image
		* @return     SPVoid
		*/
		SPVoid createFBOTextureUV();

	private:
		SPMesh* m_pMesh;

		SPUInt m_nCurrentTextureId;
		SPUInt m_nNextTextureId;
		SPUInt m_nAlphaMapTextureId;

	    SPUInt m_nRectAlign;

		SPFloat m_fRectWidth;
		SPFloat m_fRectHeight;

		SPFloat m_fAlphaBlend;

		SPBool  m_bEnableFBODraw;
	};

}//namespace SPhysics

#endif //_SP_DRAW_TILE_BLEND_H_
