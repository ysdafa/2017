/**
* @file SPDrawTileRotate.h
* @brief Drawing of several rotating cube plains
*
* @date 2014-04-08
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_DRAW_TILE_ROTATE_H_
#define _SP_DRAW_TILE_ROTATE_H_

#include "SPIRenderer.h"
#include "SPMesh.h"

#define TILE_NUM_W  6
#define TILE_NUM_H  11

//#define TILE_DEBUG 1	// debug with only one rotating tile

namespace SPhysics
{
	struct SPTileItem
	{
		SPUInt mStartDelay;
		SPUInt mCurrentStep;
	};

	class SPDrawTileRotate : public SPIRenderer
	{
	public:
		SPDrawTileRotate();
		//~SPDrawTileRotate();

		/**
		* @brief     Initialize and Prepare rendering\n 
					(set camera setting, initialize shader , create rectangle mesh)
		* @param     [IN] @b width Clipping Plane's width size
		* @param     [IN] @b height Clipping Plane's height size
		* @return     SPVoid
		*/
		SPVoid initRender(SPFloat width, SPFloat height); // virtual

		/**
		* @brief     Mesh setting & binding shader variables for drawing.
		* @return     SPVoid
		 */
		SPVoid drawRender(); // virtual

		/**
		* @brief     enable the fbo draw flag for the texture coordinate uv
		* @return     SPVoid
		*/
		SPVoid setFBOUV();

		// set texture ID for particular rotating tile
		SPVoid setTextureId(SPUInt texId);
		// initialize mesh of rotating tile
		SPVoid initMesh(SPFloat width, SPFloat height, SPFloat z, SPUInt blocksWidth, SPUInt blocksHeight);
		// set data about tiles (starting delay and currrent rotation of each tile)
		SPVoid setTileData(SPTileItem tiles[TILE_NUM_H][TILE_NUM_W]);
		// set transform data - base rotate (which is 0, -90 or -180 degrees) and animation duration (amount of frames)
		SPVoid setTransform(SPFloat baseRotate, SPUInt cubeAnimationLength);

		// for debug
		void adjustRadiusTreshold(float delta);
		void adjustCoefX(float delta);
		void adjustCoefY(float delta);

	private:
		SPMesh mMesh;
		SPMesh mMeshTransform;
		SPUInt mTextureId;
		std::vector<SPVec2f > mOffset;
		std::vector<SPFloat> mRotate;

		std::vector<SPMat4x4f > mRotateMatr;

		SPFloat mScale;
		SPTileItem (*mTiles)[TILE_NUM_W];

		SPUInt mBlocksWidth, mBlocksHeight;

		SPBool				m_bEnableFBODraw;

		// for debug
		float uRadiusTreshold;
		float uCoefX;
		float uCoefY;

	};
} //namespace SPhysics

#endif //_SP_DRAW_TILE_ROTATE_H_