/**
* @file SPDrawAlphaScale.cpp
* @brief 
*
* @date 2013-05-08
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPTextureManager.h"
#include "SPDrawAlphaScale.h"


namespace SPhysics
{
	SPDrawAlphaScale::SPDrawAlphaScale() : m_pMesh(SPNULL), m_nRectAlign(0), m_fRectWidth(720.0f), m_fRectHeight(1280.0f), m_bEnableFBODraw(SPFALSE)
	{
		m_nCurrentTextureId = 0;
		m_nNextTextureId = 0;

		m_fAlphaBlend = 0.0f;
	}

	SPDrawAlphaScale::~SPDrawAlphaScale()
	{
		SP_SAFE_DELETE(m_pMesh);
	}

	SPVoid SPDrawAlphaScale::initRender(SPFloat width, SPFloat height)
	{
		// Shader Program for DrawRect
		SPChar VertexShader[] =  
			"uniform mediump mat4 uMVPMatrix;								\n"
			"attribute vec4 aPosition;										\n"
			"attribute vec2 aCurrTexUV;											\n"
			"attribute vec2 aNextTexUV;											\n"
			"varying vec2 vCurrTexUV;											\n"
			"varying vec2 vNextTexUV;											\n"
			"void main()													\n"
			"{																\n"
			"   vCurrTexUV = aCurrTexUV;											\n"
			"   vNextTexUV = aNextTexUV;											\n"
			"   gl_Position = uMVPMatrix * aPosition;						\n"
			"}																\n";

		SPChar FragmentShader[] =  
			"precision mediump float;										\n"
			"uniform sampler2D uCurrTexMap;									\n"
			"uniform sampler2D uNextTexMap;									\n"
			"uniform float	   uAlphaScale;									\n"
			"varying vec2 vCurrTexUV;											\n"
			"varying vec2 vNextTexUV;											\n"
			"void main()													\n"
			"{																\n"
			"  vec3 currColor = texture2D( uCurrTexMap, vCurrTexUV ).rgb;			\n"
			"  vec3 nextColor = texture2D( uNextTexMap, vNextTexUV ).rgb;			\n"
			"  gl_FragColor.rgb = mix(nextColor, currColor, uAlphaScale);								\n"
//			"  gl_FragColor.rgb = nextColor;								\n"
			"  gl_FragColor.a = 1.0;									\n"
			"}																\n";


		setOrthogonalCameraView( 0.0f, width, 0, height, -5000.0f, 5000.0f);
		createShaderProgram(VertexShader, FragmentShader);

		m_fRectWidth = width;
		m_fRectHeight = height;

		createRectVertex(width, height);
		createTextureUV();
	}

	SPVoid SPDrawAlphaScale::drawRender()
	{
		setMesh(m_pMesh);

		setShaderArrayMeshVertex("aPosition");
		setShaderArrayVector("aCurrTexUV", (SPFloat*)&m_tCurrTexUV[0], 3);
		setShaderArrayVector("aNextTexUV", (SPFloat*)&m_tNextTexUV[0], 3);

		setShaderUniformMVPMatrix("uMVPMatrix");
		setShaderUnifromTexture("uCurrTexMap", m_nCurrentTextureId);
		setShaderUnifromTexture("uNextTexMap", m_nNextTextureId);
		setShaderUniformValue("uAlphaScale", m_fAlphaBlend);

		setDrawElementsWithOption(DRAW_TRIANGLES_STRIP);
	}

	// API for control the rect size
	SPVoid SPDrawAlphaScale::setSize( SPFloat width, SPFloat height )
	{
		m_fRectWidth = width;
		m_fRectHeight = height;

		m_pMesh->m_tVertex.clear();
		m_pMesh->m_tVertex.resize(4);

		SPVec3f vertex;

		// Default Center Align Rect Vertex
		if(m_nRectAlign == RECT_ALIGN_CENTER)
		{
			// case Center Align Rect Vertex
			m_pMesh->m_tVertex[0] = SPVec3f(-width*0.5f, -height*0.5f, 0.0f);	// point 1
			m_pMesh->m_tVertex[1] = SPVec3f(width*0.5f, -height*0.5f, 0.0f);	// point 2
			m_pMesh->m_tVertex[2] = SPVec3f(-width*0.5f, height*0.5f, 0.0f);	// point 3
			m_pMesh->m_tVertex[3] = SPVec3f(width*0.5f, height*0.5f, 0.0f);	// point 4

		}else		// RECT_ALIGN_LEFT_TOP
		{
			// Default LeftTop Align Rect Vertex
			m_pMesh->m_tVertex[0] = SPVec3f(0.0f, 0.0f, 0.0f);	     // point 1
			m_pMesh->m_tVertex[1] = SPVec3f(width, 0.0f, 0.0f);	 // point 2
			m_pMesh->m_tVertex[2] = SPVec3f(0.0f, height, 0.0f);	 // point 3
			m_pMesh->m_tVertex[3] = SPVec3f(width, height, 0.0f);	 // point 4
		}
	}

	SPVoid SPDrawAlphaScale::setRectAlign( SPUInt align )
	{
		if(m_nRectAlign != align)
		{
			m_nRectAlign = align;
			createRectVertex(m_fRectWidth, m_fRectHeight);
		}
	}

	SPVoid SPDrawAlphaScale::setFBOUV()
	{
		m_bEnableFBODraw = SPTRUE;

		createFBOTextureUV();
	}

	SPVoid SPDrawAlphaScale::scaleNextTextureUV( SPFloat value )
	{
		SPFloat scaleValue = (value - 1.0f) * 0.5f;
		SPFloat maxUV = 1.0f - scaleValue;
		SPFloat minUV = 0.0f + scaleValue;

		for(SPUInt idx = 0; idx < 4; idx++)
		{
			if(m_pMesh->m_tTextureUV[idx].x == 1.0f)
			{
				m_tNextTexUV[idx].x = maxUV;
			}
			else if(m_pMesh->m_tTextureUV[idx].x == 0.0f)
			{
				m_tNextTexUV[idx].x = minUV;
			}

			if(m_pMesh->m_tTextureUV[idx].y == 1.0f)
			{
				m_tNextTexUV[idx].y = maxUV;
			}
			else if(m_pMesh->m_tTextureUV[idx].y == 0.0f)
			{
				m_tNextTexUV[idx].y = minUV;
			}
		}
	}

	SPVoid SPDrawAlphaScale::scaleCurrentTextureUV( SPFloat value )
	{
		SPFloat scaleValue = (value - 1.0f) * 0.5f;
		SPFloat maxUV = 1.0f - scaleValue;
		SPFloat minUV = 0.0f + scaleValue;

		for(SPUInt idx = 0; idx < 4; idx++)
		{
			if(m_pMesh->m_tTextureUV[idx].x == 1.0f)
			{
				m_tCurrTexUV[idx].x = maxUV;
			}
			else if(m_pMesh->m_tTextureUV[idx].x == 0.0f)
			{
				m_tCurrTexUV[idx].x = minUV;
			}

			if(m_pMesh->m_tTextureUV[idx].y == 1.0f)
			{
				m_tCurrTexUV[idx].y = maxUV;
			}
			else if(m_pMesh->m_tTextureUV[idx].y == 0.0f)
			{
				m_tCurrTexUV[idx].y = minUV;
			}
		}
	}

	SPVoid SPDrawAlphaScale::setAlphaBlend( SPFloat value )
	{
		m_fAlphaBlend = value;
	}

	SPVoid SPDrawAlphaScale::setCurrentTextureID( SPUInt texID )
	{
		m_nCurrentTextureId = texID;
	}

	SPVoid SPDrawAlphaScale::setNextTextureID( SPUInt texID )
	{
		m_nNextTextureId = texID;
	}

	// private Method
	SPVoid SPDrawAlphaScale::createRectVertex(SPFloat width, SPFloat height)
	{
		if(m_pMesh == SPNULL)
			m_pMesh = new SPMesh();

		// Rect Vertex
		//     P3                  P4
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1                  P2

		m_pMesh->m_tVertex.clear();
		m_pMesh->m_tVertex.resize(4);

		if(m_nRectAlign == RECT_ALIGN_CENTER)
		{
			// case Center Align Rect Vertex
			m_pMesh->m_tVertex[0] = SPVec3f(-width*0.5f, -height*0.5f, 0.0f);		// point 1
			m_pMesh->m_tVertex[1] = SPVec3f(width*0.5f, -height*0.5f, 0.0f);		// point 2
			m_pMesh->m_tVertex[2] = SPVec3f(-width*0.5f, height*0.5f, 0.0f);		// point 3
			m_pMesh->m_tVertex[3] = SPVec3f(width*0.5f, height*0.5f, 0.0f);		// point 4
		}else		// RECT_ALIGN_LEFT_TOP
		{
			// Default LeftTop Align Rect Vertex
			m_pMesh->m_tVertex[0] = SPVec3f(0.0f, 0.0f, 0.0f);						// point 1
			m_pMesh->m_tVertex[1] = SPVec3f(width, 0.0f, 0.0f);					// point 2
			m_pMesh->m_tVertex[2] = SPVec3f(0.0f, height, 0.0f);					// point 3
			m_pMesh->m_tVertex[3] = SPVec3f(width, height, 0.0f);					// point 4
		}


		m_pMesh->m_tVertexIndex.clear();
		//create rect vertex index
		m_pMesh->m_tVertexIndex.push_back(0);
		m_pMesh->m_tVertexIndex.push_back(1);
		m_pMesh->m_tVertexIndex.push_back(2);
		m_pMesh->m_tVertexIndex.push_back(3);
	}

	SPVoid SPDrawAlphaScale::createTextureUV()
	{

		if(m_bEnableFBODraw == SPTRUE)
		{
			createFBOTextureUV();
			return;
		}

		if(m_pMesh == SPNULL)
			m_pMesh = new SPMesh();

		m_pMesh->m_tTextureUV.clear();
		m_pMesh->m_tTextureUV.resize(4);

		// Rect Vertex
		//     P3(0,0)            P4(1,0)
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1(0,1)            P2(1.1)

		m_pMesh->m_tTextureUV[0] = SPVec3f(0.0f, 1.0f, 0.0f);				// point 1
		m_pMesh->m_tTextureUV[1] = SPVec3f(1.0f, 1.0f, 0.0f);				// point 2
		m_pMesh->m_tTextureUV[2] = SPVec3f(0.0f, 0.0f, 0.0f);				// point 3
		m_pMesh->m_tTextureUV[3] = SPVec3f(1.0f, 0.0f, 0.0f);				// point 4

		m_tNextTexUV.clear();
		m_tNextTexUV.resize(4);
		for(SPUInt idx=0; idx < 4; idx++)
		{
			m_tNextTexUV[idx] = m_pMesh->m_tTextureUV[idx];
		}

		m_tCurrTexUV.clear();
		m_tCurrTexUV.resize(4);
		for(SPUInt idx=0; idx < 4; idx++)
		{
			m_tCurrTexUV[idx] = m_pMesh->m_tTextureUV[idx];
		}
	}

	SPVoid SPDrawAlphaScale::createFBOTextureUV()
	{
		if(m_pMesh == SPNULL)
			m_pMesh = new SPMesh();

		m_pMesh->m_tTextureUV.clear();
		m_pMesh->m_tTextureUV.resize(4);

		// Rect Vertex
		//     P3(0,0)            P4(1,0)
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1(0,1)            P2(1.1)

		m_pMesh->m_tTextureUV[0] = SPVec3f(0.0f, 0.0f, 0.0f);				// point 1
		m_pMesh->m_tTextureUV[1] = SPVec3f(1.0f, 0.0f, 0.0f);				// point 2
		m_pMesh->m_tTextureUV[2] = SPVec3f(0.0f, 1.0f, 0.0f);				// point 3
		m_pMesh->m_tTextureUV[3] = SPVec3f(1.0f, 1.0f, 0.0f);				// point 4


		m_tNextTexUV.clear();
		m_tNextTexUV.resize(4);
		for(SPUInt idx=0; idx < 4; idx++)
		{
			m_tNextTexUV[idx] = m_pMesh->m_tTextureUV[idx];
		}

		m_tCurrTexUV.clear();
		m_tCurrTexUV.resize(4);
		for(SPUInt idx=0; idx < 4; idx++)
		{
			m_tCurrTexUV[idx] = m_pMesh->m_tTextureUV[idx];
		}
	}



}//namespace SPhysics
