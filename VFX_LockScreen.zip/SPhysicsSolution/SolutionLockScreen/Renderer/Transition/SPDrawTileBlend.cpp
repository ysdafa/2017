/**
* @file SPDrawTileBlend.cpp
* @brief 
*
* @date 2013-05-08
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPTextureManager.h"
#include "SPDrawTileBlend.h"


namespace SPhysics
{
	SPDrawTileBlend::SPDrawTileBlend() : m_pMesh(SPNULL), m_nRectAlign(0), m_fRectWidth(720.0f), m_fRectHeight(1280.0f), m_bEnableFBODraw(SPFALSE)
	{
		m_nCurrentTextureId = 0;
		m_nNextTextureId = 0;
		m_nAlphaMapTextureId = 0;

		m_fAlphaBlend = 0.0f;
	}

	SPDrawTileBlend::~SPDrawTileBlend()
	{
		SP_SAFE_DELETE(m_pMesh);
	}

	SPVoid SPDrawTileBlend::initRender(SPFloat width, SPFloat height)
	{
		// Shader Program for DrawRect
		SPChar VertexShader[] =  
			"uniform mediump mat4 uMVPMatrix;									\n"
			"attribute vec4 aPosition;											\n"
			"attribute vec2 aTexUV;												\n"
			"varying vec2 vTexUV;												\n"
			"void main()														\n"
			"{																	\n"
			"   vTexUV = aTexUV;												\n"
			"   gl_Position = uMVPMatrix * aPosition;							\n"
			"}																	\n";

		SPChar FragmentShader[] =  
			"precision mediump float;											\n"
			"uniform sampler2D uCurrTexMap;										\n"
			"uniform sampler2D uNextTexMap;										\n"
			"uniform sampler2D uAlphaMap;										\n"
			"uniform float	   uAlphaScale;										\n"
			"varying vec2 vTexUV;												\n"
			"void main()														\n"
			"{																	\n"
			"  vec3 currColor = texture2D( uCurrTexMap, vTexUV ).rgb;			\n"
			"  vec3 nextColor = texture2D( uNextTexMap, vTexUV ).rgb;			\n"
			"  float tileAlpha = texture2D( uAlphaMap, vTexUV ).r;				\n"
			"  tileAlpha = tileAlpha + 0.75 - uAlphaScale;						\n"
			"  tileAlpha = clamp(tileAlpha, 0.0, 1.0);							\n"
			"  gl_FragColor.rgb = mix(nextColor, currColor, tileAlpha);			\n"
			"  gl_FragColor.a = 1.0;											\n"
			"}																	\n";


		setOrthogonalCameraView( 0.0f, width, 0, height, -5000.0f, 5000.0f);
		createShaderProgram(VertexShader, FragmentShader);

		m_fRectWidth = width;
		m_fRectHeight = height;

		createRectVertex(width, height);
		createTextureUV();
	}

	SPVoid SPDrawTileBlend::drawRender()
	{
		setMesh(m_pMesh);

		setShaderArrayMeshVertex("aPosition");
		setShaderArrayMeshUV("aTexUV");
		setShaderUniformMVPMatrix("uMVPMatrix");
		//setShaderUnformColor("uColor");


		setShaderUnifromTexture("uCurrTexMap", m_nCurrentTextureId);
		setShaderUnifromTexture("uNextTexMap", m_nNextTextureId);
		setShaderUnifromTexture("uAlphaMap", m_nAlphaMapTextureId);
		setShaderUniformValue("uAlphaScale", m_fAlphaBlend);
		
		setDrawElementsWithOption(DRAW_TRIANGLES_STRIP);
	}

	// API for control the rect size
	SPVoid SPDrawTileBlend::setSize( SPFloat width, SPFloat height )
	{
		m_fRectWidth = width;
		m_fRectHeight = height;

		m_pMesh->m_tVertex.clear();
		m_pMesh->m_tVertex.resize(4);

		SPVec3f vertex;

		// Default Center Align Rect Vertex
		if(m_nRectAlign == RECT_ALIGN_CENTER)
		{
			// case Center Align Rect Vertex
			m_pMesh->m_tVertex[0] = SPVec3f(-width*0.5f, -height*0.5f, 0.0f);	// point 1
			m_pMesh->m_tVertex[1] = SPVec3f(width*0.5f, -height*0.5f, 0.0f);	// point 2
			m_pMesh->m_tVertex[2] = SPVec3f(-width*0.5f, height*0.5f, 0.0f);	// point 3
			m_pMesh->m_tVertex[3] = SPVec3f(width*0.5f, height*0.5f, 0.0f);	// point 4

		}else		// RECT_ALIGN_LEFT_TOP
		{
			// Default LeftTop Align Rect Vertex
			m_pMesh->m_tVertex[0] = SPVec3f(0.0f, 0.0f, 0.0f);	     // point 1
			m_pMesh->m_tVertex[1] = SPVec3f(width, 0.0f, 0.0f);	 // point 2
			m_pMesh->m_tVertex[2] = SPVec3f(0.0f, height, 0.0f);	 // point 3
			m_pMesh->m_tVertex[3] = SPVec3f(width, height, 0.0f);	 // point 4
		}
	}

	SPVoid SPDrawTileBlend::setRectAlign( SPUInt align )
	{
		if(m_nRectAlign != align)
		{
			m_nRectAlign = align;
			createRectVertex(m_fRectWidth, m_fRectHeight);
		}
	}

	SPVoid SPDrawTileBlend::setFBOUV()
	{
		m_bEnableFBODraw = SPTRUE;

		createFBOTextureUV();
	}

	SPVoid SPDrawTileBlend::setAlphaBlend( SPFloat value )
	{
		m_fAlphaBlend = value;
	}

	SPVoid SPDrawTileBlend::setCurrentTextureID( SPUInt texID )
	{
		m_nCurrentTextureId = texID;
	}

	SPVoid SPDrawTileBlend::setNextTextureID( SPUInt texID )
	{
		m_nNextTextureId = texID;
	}

	SPVoid SPDrawTileBlend::setAlphaMapTextureID( SPUInt texID )
	{
		m_nAlphaMapTextureId = texID;
	}

	// private Method
	SPVoid SPDrawTileBlend::createRectVertex(SPFloat width, SPFloat height)
	{
		if(m_pMesh == SPNULL)
			m_pMesh = new SPMesh();

		// Rect Vertex
		//     P3                  P4
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1                  P2

		m_pMesh->m_tVertex.clear();
		m_pMesh->m_tVertex.resize(4);

		if(m_nRectAlign == RECT_ALIGN_CENTER)
		{
			// case Center Align Rect Vertex
			m_pMesh->m_tVertex[0] = SPVec3f(-width*0.5f, -height*0.5f, 0.0f);		// point 1
			m_pMesh->m_tVertex[1] = SPVec3f(width*0.5f, -height*0.5f, 0.0f);		// point 2
			m_pMesh->m_tVertex[2] = SPVec3f(-width*0.5f, height*0.5f, 0.0f);		// point 3
			m_pMesh->m_tVertex[3] = SPVec3f(width*0.5f, height*0.5f, 0.0f);		// point 4
		}else		// RECT_ALIGN_LEFT_TOP
		{
			// Default LeftTop Align Rect Vertex
			m_pMesh->m_tVertex[0] = SPVec3f(0.0f, 0.0f, 0.0f);						// point 1
			m_pMesh->m_tVertex[1] = SPVec3f(width, 0.0f, 0.0f);					// point 2
			m_pMesh->m_tVertex[2] = SPVec3f(0.0f, height, 0.0f);					// point 3
			m_pMesh->m_tVertex[3] = SPVec3f(width, height, 0.0f);					// point 4
		}


		m_pMesh->m_tVertexIndex.clear();
		//create rect vertex index
		m_pMesh->m_tVertexIndex.push_back(0);
		m_pMesh->m_tVertexIndex.push_back(1);
		m_pMesh->m_tVertexIndex.push_back(2);
		m_pMesh->m_tVertexIndex.push_back(3);
	}

	SPVoid SPDrawTileBlend::createTextureUV()
	{

		if(m_bEnableFBODraw == SPTRUE)
		{
			createFBOTextureUV();
			return;
		}

		if(m_pMesh == SPNULL)
			m_pMesh = new SPMesh();

		m_pMesh->m_tTextureUV.clear();
		m_pMesh->m_tTextureUV.resize(4);

		// Rect Vertex
		//     P3(0,0)            P4(1,0)
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1(0,1)            P2(1.1)

		m_pMesh->m_tTextureUV[0] = SPVec3f(0.0f, 1.0f, 0.0f);				// point 1
		m_pMesh->m_tTextureUV[1] = SPVec3f(1.0f, 1.0f, 0.0f);				// point 2
		m_pMesh->m_tTextureUV[2] = SPVec3f(0.0f, 0.0f, 0.0f);				// point 3
		m_pMesh->m_tTextureUV[3] = SPVec3f(1.0f, 0.0f, 0.0f);				// point 4

	}

	SPVoid SPDrawTileBlend::createFBOTextureUV()
	{
		if(m_pMesh == SPNULL)
			m_pMesh = new SPMesh();

		m_pMesh->m_tTextureUV.clear();
		m_pMesh->m_tTextureUV.resize(4);

		// Rect Vertex
		//     P3(0,0)            P4(1,0)
		//     * ----------------- * 
		//     |                   |
		//     |                   |
		//     * ----------------- *
		//     P1(0,1)            P2(1.1)

		m_pMesh->m_tTextureUV[0] = SPVec3f(0.0f, 0.0f, 0.0f);				// point 1
		m_pMesh->m_tTextureUV[1] = SPVec3f(1.0f, 0.0f, 0.0f);				// point 2
		m_pMesh->m_tTextureUV[2] = SPVec3f(0.0f, 1.0f, 0.0f);				// point 3
		m_pMesh->m_tTextureUV[3] = SPVec3f(1.0f, 1.0f, 0.0f);				// point 4
	}



}//namespace SPhysics
