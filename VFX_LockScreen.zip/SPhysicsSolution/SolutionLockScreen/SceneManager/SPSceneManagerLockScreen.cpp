/**
* @file SPSceneManagerLockScreen.cpp
* @brief 
*
* @date 
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include <stdio.h> 
#include "SPLog.h"
#include "SPSceneManagerLockScreen.h"
#include "SPFPS.h"
#include "SPRecodeVideoApp.h"


#include "Transitions/SPTransitionEffect.h"


namespace SPhysics
{

	SPSceneManagerLockScreen::SPSceneManagerLockScreen() : m_pApp(SPNULL), m_pFPS(SPNULL), m_pRecordVideo(SPNULL)
	{

	}

	SPSceneManagerLockScreen::~SPSceneManagerLockScreen()
	{
		SP_SAFE_DELETE(m_pApp);
		SP_SAFE_DELETE(m_pFPS);
		SP_SAFE_DELETE(m_pRecordVideo);
		
		releaseSingletonInstance();
	}

	void SPSceneManagerLockScreen::makeSceneLayer()
	{
#ifndef _WIN32
		SP_LOGI("SPSceneManagerLockScreen %s", __func__);
#endif	
		
		
		m_pApp = new SPTransitionEffect();		

		
		addSceneLayer(m_pApp);


		//enableFPSViewer();
		//enableRecordVideo();

	}

	SPVoid SPSceneManagerLockScreen::setCurrentScene(int currentScene)
	{
		
	}

	SPVoid SPSceneManagerLockScreen::enableFPSViewer()
	{
		if(m_pFPS == SPNULL)
			m_pFPS = new SPFPS();

		addSceneLayer(m_pFPS);
	}

	SPVoid SPSceneManagerLockScreen::enableRecordVideo()
	{
		if(m_pRecordVideo == SPNULL)
			m_pRecordVideo = new SPRecodeVideoApp();

		addSceneLayer(m_pRecordVideo);
	}

} // namespace SPhysics 




