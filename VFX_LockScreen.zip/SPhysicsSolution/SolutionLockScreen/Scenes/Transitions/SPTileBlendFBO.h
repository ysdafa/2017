/**
* @file SPTileBlendFBO.h
* @brief
*
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_TILE_BLEND_FBO_H_
#define _SP_TILE_BLEND_FBO_H_

#include "SPDefines.h"
#include "SPISceneComponent.h"
#include "SPDrawTileBlend.h"

#include "SPFBO.h"
#include <vector>

namespace SPhysics
{


	class SPTileBlendFBO : public SPISceneComponent
	{
	public:
		SPTileBlendFBO();
		virtual ~SPTileBlendFBO();

	public:
		SPVoid initApp(SPInt width, SPInt height);
		SPVoid updateApp();
		SPVoid drawApp();
		SPVoid onEventKey(KEY_TYPE keyID);
		SPVoid onEventTouch(TOUCH_TYPE eventType, SPInt xPos, SPInt yPos);
		SPVoid onEventMultiTouch(TOUCH_TYPE eventType, SPInt touchID, SPInt touchNum, SPInt *xPos, SPInt *yPos){};
		SPVoid onEventSensor(SENSOR_TYPE sensorType, SPFloat xValue, SPFloat yValue, SPFloat zValue);
		SPVoid resetApp();		


		SPVoid enableBGTransition();
		SPUInt addBackground(const SPChar* fileName);
		SPUInt getCurrentBG();
		SPFloat getCurrentBGScale();
		SPInt getAnimationDurationFrame();
		SPVoid setAutoAnimation(const SPUInt& nFrame);
	private:
		SPVoid updateTransition();
		SPVoid changeCurrentBGTextureID();
		SPVoid initilizeAlphaMap();

	private:
		// Auto Animation
		SPBool				m_bEnableAnimation;
		SPInt		        m_nCurrentFrame;
		SPInt		        m_nAnimationFrame;

		// Render
		SPDrawTileBlend     m_cDrawTileBlend;

		// Texture ID
		SPUInt		        m_nCurrentTexID;
		SPUInt		        m_nNextTexID;
		SPUInt              m_nNextIndex;
		std::vector<SPUInt> m_vTextureID;

		// for alpha map animation
		std::vector<SPUChar> m_vAlphaMap;
		SPUInt				 m_nAlphaMapTexID;

		// FBO
		SPFBO				m_cFBO;

		// Init Render
		SPBool              m_bInit;

		// Transition Mode
		SPBool              m_bTransitionMode;
		SPBool              m_bAlphaTransitionMode;
		SPFloat             m_fTransitionStep;		 // 0.0f ~ 1.0f

		SPFloat				m_fAlphaBlendStep;
	};
}//namespace SPhysics

#endif // _SP_TILE_BLEND_FBO_H_