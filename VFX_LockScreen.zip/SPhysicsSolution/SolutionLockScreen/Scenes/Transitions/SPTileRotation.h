/**
* @file SPTileRotation.h
* @brief
*
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#ifndef _SP_TILE_ROTATION_H_
#define _SP_TILE_ROTATION_H_

#include "SPDefines.h"
#include "SPISceneComponent.h"
#include "SPDrawTileRotate.h"
#include "SPDrawBackground.h"

#include "SPFBO.h"
#include <vector>


namespace SPhysics
{
	class SPTileRotation : public SPISceneComponent
	{
		// typedef control the render mode
		typedef enum _RENDER_MODE
		{
			RENDER_MODE_IDLE,
			RENDER_MODE_ANIMATION
		}RENDER_MODE;

	public:
		SPTileRotation();
		virtual ~SPTileRotation();

	public:
		//SPISceneComponent::virtual
		/**
		* @brief     Application initialization
		* @param     [IN] @b  width Screen width size
		* @param     [IN] @b  height Screen height size
		* @return     SPVoid
		*/
		SPVoid initApp(SPInt width, SPInt height);

		/**
		* @brief     Update application \n
						(event processing, updating Simulation, Generating Rendering meshes, etc.)
		* @return     SPVoid
		*/
		SPVoid updateApp();

		/**
		* @brief     Drawing scene
		* @return     SPVoid
		*/
		SPVoid drawApp();

		/**
		* @brief     Key event handling
		* @param     [IN] @b  keyID key event id
		* @return     SPVoid
		*/
		SPVoid onEventKey(KEY_TYPE keyID);

		/**
		* @brief     single-touch event handling
		* @param     [IN] @b  eventType event type of the single touch event (TOUCH_DOWN, TOUCH_MOVE, TOUCH_UP)
		* @param     [IN] @b  xPos x position of touch
		* @param     [IN] @b  yPos x position of touch
		* @return     SPVoid
		*/
		SPVoid onEventTouch(TOUCH_TYPE eventType, SPInt xPos, SPInt yPos);

		/**
		* @brief     multi-touch event handling
		* @param     [IN] @b  touchID a id of finger which is moving
		* @param     [IN] @b  touchNum number of finger which is touched on (Max : 10)
		* @param     [IN] @b  eventType event type of the touch event (TOUCH_DOWN, TOUCH_MOVE, TOUCH_UP)
		* @param     [IN] @b  *xPos array of x position of multi-touch (Array size : 10)
		* @param     [IN] @b  *yPos array of x position of multi-touch (Array size : 10)
		* @return     SPVoid
		*/
		SPVoid onEventMultiTouch(TOUCH_TYPE eventType, SPInt touchID, SPInt touchNum, SPInt *xPos, SPInt *yPos){};

		/**
		* @brief     Sensor event handling
		* @param     [IN] @b  sensorType type of the sensor such as gyro, gravity ..
		* @param     [IN] @b  xValue a sensor value of X-axis
		* @param     [IN] @b  yValue a sensor value of Y-axis
		* @param     [IN] @b  zValue a sensor value of Z-axis
		* @return     SPVoid
		*/
		SPVoid onEventSensor(SENSOR_TYPE sensorType, SPFloat xValue, SPFloat yValue, SPFloat zValue){};

		/**
		* @brief     Reset application 
		* @return     SPVoid
		*/
		SPVoid resetApp();

		/**
		* @brief     run the transition effect
		* @return     SPVoid
		*/
		SPVoid runTransitionAnimation();

		/**
		* @brief     run the transition effect
		* @return     SPVoid
		*/
		SPVoid enableBGTransition();

		/**
		* @brief     with this API, can the current(original) texture
		* @param     [IN] @b  texID a texture id
		* @return     SPVoid
		*/
		SPVoid setCurrentTexture(const SPChar* fileName);

		/**
		* @brief     with this API, can the Next(to be) texture
		* @param     [IN] @b  texID a texture id
		* @return     SPVoid
		*/
		SPVoid setNextTexture(const SPChar* fileName);

		/**
		* @brief     return the status of the transition animation
		* @return     SPBool
		*/
		SPBool isAnimationStatus();

		/**
		* @brief     return the current animation step
		* @return     SPFloat
		*/
		SPFloat getCurrentAnimationStep();
		
		/**
		* @brief     if this is called, change the texture uv
		* @return     SPVoid
		*/
		SPVoid enableFBODraw();

	private:

		/**
		* @brief    start the transition animation
		* @return     SPVoid
		*/
		SPVoid startAnimation();

		/**
		* @brief     update the transition animation
		* @return     SPVoid
		*/
		SPVoid updateAnimation();

		/**
		* @brief     draw the animated object
		* @return     SPVoid
		*/
		SPVoid drawAnimation();

		/**
		* @brief     stop the transition animation
		* @return     SPVoid
		*/
		SPVoid stopAnimation();

		/**
		* @brief     after finish the animation of the transition effect, change the image texture id
		* @return     SPVoid
		*/
		SPVoid changeImageTextue();

		/**
		* @brief     set the current image texture to the draw unit
		* @return     SPVoid
		*/
		SPVoid setCurrentTexture(SPUInt texID);

		/**
		* @brief     set the next image texture to the draw unit
		* @return     SPVoid
		*/
		SPVoid setNextTexture(SPUInt texID);

		/**
		* @brief     draw a background image
		* @return     SPVoid
		*/
		SPVoid drawIdle();


		// for debug
		void adjustRadiusTreshold(float delta);
		void adjustCoefX(float delta);
		void adjustCoefY(float delta);

	private:
		// Auto Animation
		SPFloat				m_nAnimationFrameCnt;

		SPDrawTileRotate	m_cDraw[3];
		SPDrawBackground	m_cDrawBackground;
		SPFloat				m_nRotateAngle[3];
		SPTileItem			mTiles[TILE_NUM_H][TILE_NUM_W];

		// Texture ID
		SPUInt				m_nCurrentTexID;
		SPUInt				m_nNextTexID;

		// Transition Mode
		SPBool				m_bRenderMode;
		SPBool				m_bEnableFBODraw;

	};
}//namespace SPhysics

#endif // _SP_TILE_ROTATION_H_