/**
* @file SPAlphaScalingFBO.cpp
* @brief
*
* @date 2014-03-27
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPAlphaScalingFBO.h"
#include "SPTextureManager.h"
#include "SPMotionCurve.h"

#define TIME_STEP 0.01111111111111111111111111111111// * 1.3333333333333333333333333333
#define UNDER_SIZE 1.0f
#define CURRENT_SIZE 1.1f
#define NEXT_SIZE 1.2f

#define FBO_RATIO 0.4                         // control the quality of the vfx : Max 1.0, Min 0.1
#define FBO_FADE_START 0.2
#define FBO_FADE_END (1.0 - FBO_FADE_START)

	// TRANSITION EFFECT DURATION
	///////////////////////////////////////////////////////////////////////////////////////
	//0.0         ~     	 FBO_RATIO         ~         FBO_RATIO          ~           1.0     (m_fTransitionStep)
	//					  FBO_FADE_START               FBO_FADE_END
	///////////////////////////////////////////////////////////////////////////////////////
	
namespace SPhysics
{
	SPAlphaScalingFBO::SPAlphaScalingFBO()
	{
	}

	SPAlphaScalingFBO::~SPAlphaScalingFBO()
	{
	}

	SPVoid SPAlphaScalingFBO::initApp(SPInt width, SPInt height)
	{
		m_nScreenWidth = width;
		m_nScreenHeight = height;

		addBackground("Res/bgImg/bgd1.png");
		addBackground("Res/bgImg/bgd2.png");
		addBackground("Res/bgImg/bgd3.png");

		m_cFBO.createFBOSurface(width, height);

		if (m_vTextureID.empty() == SPTRUE)
		{
			SP_LOGE("Please add background image more than 2 before init");
			return;
		}

		resetApp();

		m_cCurrentBG.enableFBOImageDraw();
		m_cCurrentBG.initialize(width, height);
		m_cCurrentBG.setRectAlign(RECT_ALIGN_CENTER);
		m_cCurrentBG.setOrthogonalCameraView(-width * 0.5, width * 0.5, -height * 0.5, height * 0.5, -300.0f, 5000.0f);
		m_cCurrentBG.setTextureID(m_nCurrentTexID);
		m_cCurrentBG.setScale(CURRENT_SIZE, CURRENT_SIZE, 1.0f);

		m_cUnderBG.enableFBOImageDraw();
		m_cUnderBG.initialize(width, height);
		m_cUnderBG.setRectAlign(RECT_ALIGN_CENTER);
		m_cUnderBG.setOrthogonalCameraView(-width * 0.5, width * 0.5, -height * 0.5, height * 0.5, -300.0f, 5000.0f);
		m_cUnderBG.setTextureID(m_nNextTexID);
		m_cUnderBG.setScale(UNDER_SIZE, UNDER_SIZE, 1.0f);
		m_cUnderBG.setColor(1.0f, 1.0f, 1.0f, 1.0f);
	}

	SPVoid SPAlphaScalingFBO::updateApp()
	{
		if (m_bEnableAnimation == SPTRUE && m_nCurrentFrame++ > m_nAnimationFrame)
		{
			enableBGTransition();
			m_nCurrentFrame = -getAnimationDurationFrame();
		}

		updateTransition();
	}

	SPVoid SPAlphaScalingFBO::updateTransition()
	{
		if (m_bTransitionMode == SPTRUE)
		{
			const SPFloat src_alpha = SineInOut33::getInterpolation(1.0f - m_fTransitionStep);
			const SPFloat scale_ratio = SineInOut90::getInterpolation(m_fTransitionStep);
			const SPFloat src_scale = scale_ratio * (NEXT_SIZE - CURRENT_SIZE) + CURRENT_SIZE;
			const SPFloat dst_scale = scale_ratio * (CURRENT_SIZE - UNDER_SIZE) + UNDER_SIZE;

			SPFloat fbo_ratio = 0.0f;

			m_cCurrentBG.setColor(1.0f, 1.0f, 1.0f, src_alpha);
			m_cCurrentBG.setScale(src_scale, src_scale, 1.0f);
			m_cUnderBG.setScale(dst_scale, dst_scale, 1.0f);

			m_fTransitionStep += TIME_STEP;

			if (m_fTransitionStep < FBO_FADE_START)
			{
				fbo_ratio = 1.0 - (m_fTransitionStep / FBO_FADE_START) * (1.0 - FBO_RATIO);
				m_cFBO.resizeFBOSurface(m_nScreenWidth * fbo_ratio, m_nScreenHeight * fbo_ratio);
			}
			else if (m_fTransitionStep > FBO_FADE_END)
			{
				fbo_ratio = FBO_RATIO + ((m_fTransitionStep - FBO_FADE_END) / (1.0 - FBO_FADE_END)) * (1.0 - FBO_RATIO);
				m_cFBO.resizeFBOSurface(m_nScreenWidth * fbo_ratio, m_nScreenHeight * fbo_ratio);
			}
		}
	}

	SPVoid SPAlphaScalingFBO::drawApp()
	{
		if (m_bTransitionMode == SPTRUE || m_bInit == SPTRUE)
		{
			m_cFBO.clearFBOSurface();
			m_cFBO.bindFBOSurface();

			m_cUnderBG.draw();
			m_cCurrentBG.draw();

			m_cFBO.unbindFBOSurface(m_nScreenWidth, m_nScreenHeight);
			m_bInit = SPFALSE;

			if (m_fTransitionStep >= 1.0f)
			{
				changeCurrentBGTextureID();
				m_fTransitionStep = 0.0f;
				m_bTransitionMode = SPFALSE;
			}
		}
	}

	SPVoid SPAlphaScalingFBO::onEventTouch(TOUCH_TYPE eventType, SPInt xPos, SPInt yPos)
	{
	}

	SPVoid SPAlphaScalingFBO::onEventSensor(SENSOR_TYPE sensorType, SPFloat xValue, SPFloat yValue, SPFloat zValue)
	{
	}

	SPVoid SPAlphaScalingFBO::onEventKey(KEY_TYPE keyID)
	{
	}

	SPVoid SPAlphaScalingFBO::resetApp()
	{
		m_bEnableAnimation = SPFALSE;
		m_nCurrentFrame = 0;
		m_nAnimationFrame = 0;

		m_nCurrentTexID = m_vTextureID[0];
		m_nNextTexID = m_vTextureID[1];
		m_nNextIndex = 1;

		m_bInit = SPTRUE;

		m_fTransitionStep = 0.0f;
		m_bTransitionMode = SPFALSE;
	}

	SPVoid SPAlphaScalingFBO::enableBGTransition()
	{
		m_bTransitionMode = SPTRUE;
	}

	SPUInt SPAlphaScalingFBO::getCurrentBG()
	{
		return m_cFBO.getFBOTexture();
	}

	SPUInt SPAlphaScalingFBO::addBackground(const SPChar* fileName)
	{
		SPUInt ret = SPTextureManager::getInstancePtr()->loadTexture(fileName, SPTRUE);

		m_vTextureID.push_back(ret);

		return ret;
	}
		
	SPVoid SPAlphaScalingFBO::changeCurrentBGTextureID()
	{
		//SPUInt tmpID = SPUInt();

		//tmpID = m_nCurrentTexID;
		m_nCurrentTexID = m_nNextTexID;

		if (m_nNextIndex + 1 == m_vTextureID.size())
		{
			m_nNextTexID = m_vTextureID[0];
			m_nNextIndex = 0;
		}
		else
		{
			m_nNextTexID = m_vTextureID[++m_nNextIndex];
		}

		m_cCurrentBG.setTextureID(m_nCurrentTexID);
		m_cUnderBG.setTextureID(m_nNextTexID);
	}

	SPFloat SPAlphaScalingFBO::getCurrentBGScale()
	{
		return CURRENT_SIZE;
	}

	SPInt SPAlphaScalingFBO::getAnimationDurationFrame()
	{
		return 1.0 / TIME_STEP;
	}

	SPVoid SPAlphaScalingFBO::setAutoAnimation(const SPUInt& nFrame)
	{
		m_nAnimationFrame  = nFrame;
		m_bEnableAnimation = SPTRUE;
	}
}
//namespace SPhysics