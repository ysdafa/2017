/**
* @file SPTileRotation.cpp
* @brief
*
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPTileRotation.h"
#include "SPTextureManager.h"
#include <stdlib.h>			// rand()
//#include "SPRandom.h"		// SPhysics::random<T>()
#include <time.h>			// to initialize randomizer with current time

//#define TILE_NUM_W  6		// refer to SPDrawTileRotate.h
//#define TILE_NUM_H  11	// refer to SPDrawTileRotate.h

#define MAX_ANIMATION_FRAME			105	// duration of whole effect
#define MAX_ANIMATION_FRAME_CUBE	45	// duration of rotating one cube, should be less than MAX_ANIMATION_FRAME
#define START_ROTATE_FRAME_RANGE	(MAX_ANIMATION_FRAME - MAX_ANIMATION_FRAME_CUBE)

//#define ENABLE_CONTINUE_TRANSITION	1

namespace SPhysics
{
	//=================================================================================================
	// public methods
	//=================================================================================================
	SPTileRotation::SPTileRotation()
	{
		m_nRotateAngle[0] = 0.0f;
		m_nRotateAngle[1] = -90.0f;
		m_nRotateAngle[2] = -180.0f;

		m_nAnimationFrameCnt = 0.0f;
		m_bEnableFBODraw = SPFALSE;
	}
	//----------------------------------------------------------------------------------------------
	SPTileRotation::~SPTileRotation()
	{
	}
	//----------------------------------------------------------------------------------------------
	SPVoid SPTileRotation::initApp(SPInt width, SPInt height)
	{
		m_nScreenWidth = width;
		m_nScreenHeight = height;

		// for draw background
		m_cDrawBackground.initialize((SPFloat)width, (SPFloat)height);

		if(m_bEnableFBODraw == SPTRUE)
		{
			m_cDrawBackground.setFBOUV();
			for (SPUInt i=0; i<3; ++i)
			{
				m_cDraw[i].setFBOUV();
			}
		}

		for (SPUInt i=0; i<3; ++i)
		{
			m_cDraw[i].setDepthTest(SPTRUE);
			m_cDraw[i].initMesh(100, 100, 50, TILE_NUM_W, TILE_NUM_H);
			m_cDraw[i].initialize((SPFloat)100, (SPFloat)100);
			m_cDraw[i].setTileData(mTiles);
		}

		srand((unsigned)time(NULL));
		resetApp();
	}

	SPVoid SPTileRotation::updateApp()
	{
		updateAnimation();
	}

	SPVoid SPTileRotation::drawApp()
	{
		glEnable(GL_DEPTH_TEST); // not necessary for VFX, but mandatory for WaterColorTransition integration

		switch(m_bRenderMode)
		{
		case RENDER_MODE_ANIMATION:
			drawAnimation();
			break;
		case RENDER_MODE_IDLE:
			drawIdle();
			break;
		}

		glDisable(GL_DEPTH_TEST);
	}

	SPVoid SPTileRotation::onEventKey(KEY_TYPE keyID)
	{
		switch ((char)keyID)
		{
		case '=':
			adjustRadiusTreshold(-1.0f);
			break;
		case '\\':
			adjustRadiusTreshold(1.0f);
			break;
		case '[':
			adjustCoefX(-0.1f);
			break;
		case ']':
			adjustCoefX(0.1f);
			break;
		case ';':
			adjustCoefY(-0.01f);
			break;
		case '\'':
			adjustCoefY(0.01f);
			break;
		case ' ':
			startAnimation();
			break;
		default:
			updateAnimation();
			break;
		}
	}

	SPVoid SPTileRotation::onEventTouch(TOUCH_TYPE eventType, SPInt xPos, SPInt yPos)
	{
		if(eventType == TOUCH_DOWN)
		{
			if(m_bRenderMode == RENDER_MODE_IDLE)
			{
				startAnimation();
			}
		}
	}

	SPVoid SPTileRotation::resetApp()
	{
		m_bRenderMode = RENDER_MODE_IDLE;
		m_nAnimationFrameCnt = 0.0f;
	}

	SPVoid SPTileRotation::runTransitionAnimation()
	{
		if(m_bRenderMode == RENDER_MODE_IDLE)
		{
			startAnimation();
		}
	}

	SPVoid SPTileRotation::enableBGTransition()
	{
		m_bRenderMode = RENDER_MODE_ANIMATION;
	}

	SPVoid SPTileRotation::setCurrentTexture( const SPChar* fileName )
	{

#if (!ANDROID_PORTING_MODE)
		m_nCurrentTexID = SPTextureManager::getInstancePtr()->loadTexture(fileName, SPTRUE);
#else
		m_nCurrentTexID = SPTextureManager::getInstancePtr()->getTextureID(fileName);
#endif

		setCurrentTexture(m_nCurrentTexID);
	}

	SPVoid SPTileRotation::setNextTexture( const SPChar* fileName )
	{

#if (!ANDROID_PORTING_MODE)
		m_nNextTexID = SPTextureManager::getInstancePtr()->loadTexture(fileName, SPTRUE);
#else
		m_nNextTexID = SPTextureManager::getInstancePtr()->getTextureID(fileName);
#endif

		setNextTexture(m_nNextTexID);
	}


	SPBool SPTileRotation::isAnimationStatus()
	{
		SPBool aniStatus = SPFALSE;

		if(m_bRenderMode == RENDER_MODE_ANIMATION)
			aniStatus = SPTRUE;

		return aniStatus;
	}

	SPFloat SPTileRotation::getCurrentAnimationStep()
	{
		return m_nAnimationFrameCnt / MAX_ANIMATION_FRAME;
		//return 0.0f;
	}

	SPVoid SPTileRotation::enableFBODraw()
	{
		m_bEnableFBODraw = SPTRUE;
	}

	//==============================================================================================
	// private members
	//==============================================================================================
	SPVoid SPTileRotation::startAnimation()
	{
		SPUInt k(0);
		for (SPUInt i=0; i<TILE_NUM_H; ++i)
		{
			for (SPUInt j=0; j<TILE_NUM_W; ++j, ++k)
			{
				#ifndef TILE_DEBUG
				//mTiles[i][j].mStartDelay = k/2; // ordered sequence
				//mTiles[i][j].mStartDelay = random<SPUInt>(0, START_ROTATE_FRAME_RANGE); // random sequence, SPhysics function (does not work properly on Android)
				mTiles[i][j].mStartDelay = rand() % START_ROTATE_FRAME_RANGE; // random sequence, standard library function
				#else
				mTiles[i][j].mStartDelay = 0; // debug
				#endif

				mTiles[i][j].mCurrentStep = 0;
			}
		}
		m_bRenderMode = RENDER_MODE_ANIMATION;
	}

	SPVoid SPTileRotation::updateAnimation()
	{
		if (m_bRenderMode != RENDER_MODE_ANIMATION)
			return;

		m_nAnimationFrameCnt += 1.0f;

		//SPBool animationFinished = SPTRUE;
		for (int i=0; i<TILE_NUM_H; ++i)
		{
			for (int j=0; j<TILE_NUM_W; ++j)
			{
				if (mTiles[i][j].mStartDelay)
				{
					mTiles[i][j].mStartDelay--;
					//animationFinished = SPFALSE;
				}
				else
				{
					if (mTiles[i][j].mCurrentStep < MAX_ANIMATION_FRAME_CUBE)
					{
						mTiles[i][j].mCurrentStep++;
						//animationFinished = SPFALSE;
					}
				}
			}
		}

		//if (animationFinished)
		//{
		//	stopAnimation();
		//}
	}

	SPVoid SPTileRotation::drawAnimation()
	{
		// this mixed sequence (0,2,1) of rendering fixes vertical line artifact
		// that appears on left side when decreasing rendering resolution
		// in case of strict forward (0,1,2) or strict backward sequence (2,1,0) artifact happens
		SPUInt ind[] = {0,2,1};

		for (SPUInt i=0; i<3; ++i)
		{
			SPUInt j = ind[i];
			m_cDraw[j].setTransform(m_nRotateAngle[j], MAX_ANIMATION_FRAME_CUBE);
			m_cDraw[j].draw();
		}

		if (m_nAnimationFrameCnt > MAX_ANIMATION_FRAME)
		{
			stopAnimation();
		}
	}

	SPVoid SPTileRotation::stopAnimation()
	{
		m_bRenderMode = RENDER_MODE_IDLE;
		m_nAnimationFrameCnt = 0.0f;
		changeImageTextue();

		#ifdef ENABLE_CONTINUE_TRANSITION
		startAnimation();
		#endif
	}

	SPVoid SPTileRotation::changeImageTextue()
	{
		SPUInt tmpID = m_nCurrentTexID;

		m_nCurrentTexID = m_nNextTexID;
		m_nNextTexID = tmpID;

		m_cDraw[0].setTextureId(m_nCurrentTexID);
		m_cDraw[1].setTextureId(m_nCurrentTexID);
		m_cDraw[2].setTextureId(m_nNextTexID);
		m_cDrawBackground.setTextureID(m_nCurrentTexID);
	}

	SPVoid SPTileRotation::setCurrentTexture( SPUInt texID )
	{
		m_cDrawBackground.setTextureID(texID);
		m_cDraw[0].setTextureId(texID);
		m_cDraw[1].setTextureId(texID);
	}

	SPVoid SPTileRotation::setNextTexture( SPUInt texID )
	{
		m_cDraw[2].setTextureId(texID);
	}

	SPVoid SPTileRotation::drawIdle()
	{
		m_cDrawBackground.draw();
	}

	// for debug
	void SPTileRotation::adjustRadiusTreshold(float delta)
	{
		for (SPUInt i=0; i<3; ++i)
			m_cDraw[i].adjustRadiusTreshold(delta);
	}
	void SPTileRotation::adjustCoefX(float delta)
	{
		for (SPUInt i=0; i<3; ++i)
			m_cDraw[i].adjustCoefX(delta);
	}
	void SPTileRotation::adjustCoefY(float delta)
	{
		for (SPUInt i=0; i<3; ++i)
			m_cDraw[i].adjustCoefY(delta);
	}

}
//namespace SPhysics