/**
* @file SPAlphaScaling.cpp
* @brief
*
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPAlphaScaling.h"
#include "SPTextureManager.h"
#include "SPMotionCurve.h"

#define DESIGNED_SCREEN_WITH			1920.0f			// defined depend on concept movie clip
#define DESIGNED_SCREEN_HEIGHT			1080.0f			// defined depend on concept movie clip

#define IDLE_BG_UV						1.1f			// 110% scale
#define INIT_CURRENT_UV					1.1f			// 110% scale
#define TARGET_CURRENT_UV				1.2f			// 120% scale

#define INIT_NEXT_UV					1.0f			// 100% scale
#define TARGET_NEXT_UV					1.1f			// 110% scale

#define MAX_ANIMATION_FRAME			90.0f				// defined depend on concept movie clip
#define INV_MAX_ANIMATION_FRAME     1.0f / MAX_ANIMATION_FRAME


//#define ENABLE_CONTINUE_TRANSITION  1

namespace SPhysics
{
	SPAlphaScaling::SPAlphaScaling()
	{
		m_fAlphaBlendStep = 1.0f;
		m_fCurrentUVScaleStep = INIT_CURRENT_UV;
		m_fNextUVScaleStep = INIT_NEXT_UV;
		m_nAnimationFrameCnt = 0.0f;
		m_bEnableFBODraw = SPFALSE;
	}

	SPAlphaScaling::~SPAlphaScaling()
	{
	}

	SPVoid SPAlphaScaling::initApp(SPInt width, SPInt height)
	{
		m_nScreenWidth = width;
		m_nScreenHeight = height;

		resetApp();

		//m_cDrawAlphaScale.enableFBOImageDraw();
		m_cDrawAlphaScale.initialize(width, height);

// 		m_cDrawAlphaScale.setCurrentTextureID(m_nCurrentTexID);
// 		m_cDrawAlphaScale.setNextTextureID(m_nNextTexID);

		// for draw background
		m_cDrawBackground.initialize(width, height);
		m_cDrawBackground.scaleTextureUV(IDLE_BG_UV);
// 		m_cDrawBackground.setTextureID(m_nCurrentTexID);
 		

		if(m_bEnableFBODraw == SPTRUE)
		{
			m_cDrawAlphaScale.setFBOUV();
			m_cDrawBackground.setFBOUV();
		}
	}

	SPVoid SPAlphaScaling::updateApp()
	{
		updateAnimation();
	}

	SPVoid SPAlphaScaling::drawApp()
	{
		switch(m_bRenderMode)
		{
		case RENDER_MODE_ANIMATION:
			drawAnimation();
			break;
		case RENDER_MODE_IDLE:
		default:
			drawIdle();
			break;
		}
	}

	SPVoid SPAlphaScaling::onEventTouch(TOUCH_TYPE eventType, SPInt xPos, SPInt yPos)
	{
		if(eventType == TOUCH_DOWN)
		{
			if(m_bRenderMode == RENDER_MODE_IDLE)
			{
				startAnimation();
			}
		}
	}

	SPVoid SPAlphaScaling::resetApp()
	{
		m_nAnimationFrameCnt = 0.0f;

		m_bRenderMode = RENDER_MODE_IDLE;

		m_fAlphaBlendStep = 1.0f;
		m_fCurrentUVScaleStep = INIT_CURRENT_UV;
		m_fNextUVScaleStep = INIT_NEXT_UV;

		m_fScreenScaleValue = (SPFloat)m_nScreenWidth / DESIGNED_SCREEN_WITH;
	}

	SPVoid SPAlphaScaling::runTransitionAnimation()
	{
		if(m_bRenderMode == RENDER_MODE_IDLE)
		{
			startAnimation();
		}
	}

	SPVoid SPAlphaScaling::setCurrentTexture( const SPChar* fileName )
	{
#if (!ANDROID_PORTING_MODE)
		m_nCurrentTexID = SPTextureManager::getInstancePtr()->loadTexture(fileName, SPTRUE);
#else
		m_nCurrentTexID = SPTextureManager::getInstancePtr()->getTextureID(fileName);
#endif


		setCurrentTexture(m_nCurrentTexID);
	}

	SPVoid SPAlphaScaling::setNextTexture( const SPChar* fileName )
	{
#if (!ANDROID_PORTING_MODE)
		m_nNextTexID = SPTextureManager::getInstancePtr()->loadTexture(fileName, SPTRUE);
#else
		m_nNextTexID = SPTextureManager::getInstancePtr()->getTextureID(fileName);
#endif

		setNextTexture(m_nNextTexID);
	}

	SPVoid SPAlphaScaling::enableFBODraw()
	{
		m_bEnableFBODraw = SPTRUE;
	}

	SPBool SPAlphaScaling::isAnimationStatus()
	{
		SPBool aniStatus = SPFALSE;

		if(m_bRenderMode == RENDER_MODE_ANIMATION)
			aniStatus = SPTRUE;

		return aniStatus;
	}

	SPFloat SPAlphaScaling::getCurrentAnimationStep()
	{
		return m_nAnimationFrameCnt / MAX_ANIMATION_FRAME;
	}

	SPVoid SPAlphaScaling::startAnimation()
	{
		m_bRenderMode = RENDER_MODE_ANIMATION;
	}

	SPVoid SPAlphaScaling::updateAnimation()
	{
		if (m_bRenderMode == RENDER_MODE_ANIMATION)
		{
			SPFloat curveAniStep = m_nAnimationFrameCnt / MAX_ANIMATION_FRAME;

			m_nAnimationFrameCnt += 1.0f;

			m_fAlphaBlendStep = SineInOut33::getInterpolation(1.0f - curveAniStep);

			SPFloat scale_ratio = SineInOut90::getInterpolation(curveAniStep);

			m_fCurrentUVScaleStep = INIT_CURRENT_UV + (TARGET_CURRENT_UV - INIT_CURRENT_UV) * scale_ratio;
			m_fNextUVScaleStep = INIT_NEXT_UV + (TARGET_NEXT_UV - INIT_NEXT_UV) * scale_ratio;

		}
	}

	SPVoid SPAlphaScaling::drawAnimation()
	{
		m_cDrawAlphaScale.scaleCurrentTextureUV(m_fCurrentUVScaleStep);
		m_cDrawAlphaScale.scaleNextTextureUV(m_fNextUVScaleStep);
		m_cDrawAlphaScale.setAlphaBlend(m_fAlphaBlendStep);
		m_cDrawAlphaScale.draw();

		if (m_nAnimationFrameCnt > MAX_ANIMATION_FRAME)
		{
			stopAnimation();
		}
	}

	SPVoid SPAlphaScaling::stopAnimation()
	{
		m_bRenderMode = RENDER_MODE_IDLE;

		m_nAnimationFrameCnt = 0.0f;
		m_fAlphaBlendStep = 1.0f;
		m_fCurrentUVScaleStep = INIT_CURRENT_UV;
		m_fNextUVScaleStep = INIT_NEXT_UV;

		changeImageTextue();


#if ENABLE_CONTINUE_TRANSITION
		startAnimation();
#endif
	}

	SPVoid SPAlphaScaling::changeImageTextue()
	{
		SPUInt tmpID = m_nCurrentTexID;

		m_nCurrentTexID = m_nNextTexID;
		m_nNextTexID = tmpID;

		m_cDrawBackground.setTextureID(m_nCurrentTexID);
		m_cDrawAlphaScale.setCurrentTextureID(m_nCurrentTexID);
		m_cDrawAlphaScale.setNextTextureID(m_nNextTexID);
	}

	SPVoid SPAlphaScaling::setCurrentTexture( SPUInt texID )
	{
		m_cDrawBackground.setTextureID(texID);
		m_cDrawAlphaScale.setCurrentTextureID(texID);
	}

	SPVoid SPAlphaScaling::setNextTexture( SPUInt texID )
	{
		m_cDrawAlphaScale.setNextTextureID(texID);
	}

	SPVoid SPAlphaScaling::drawIdle()
	{
		m_cDrawBackground.draw();
	}

	SPFloat SPAlphaScaling::SCALE( SPFloat value )
	{
		return value * m_fScreenScaleValue;
	}
}
//namespace SPhysics