/**
* @file SPTransitionVFXHandler.cpp
* @brief
*
* @date 2014-03-27
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPTransitionVFXHandler.h"

#include "SPAlphaScaling.h"
#include "SPTileRotation.h"
#include "SPTileBlend.h"
#include "SPImageInk.h"

#define		TARGET_MIN_FBO_RATIO   0.4
#define		FBO_FADE_START 0.2
#define		FBO_FADE_END (1.0 - FBO_FADE_START)

namespace SPhysics
{
	SPTransitionVFXHandler::SPTransitionVFXHandler()
	{
		m_pTransitionEffect = SPNULL;

		m_nScreenWidth = 1920;
		m_nScreenHeight = 1080;

		m_nEffectType = 0;

		m_bEnableDepthBuffer = SPFALSE;
		m_bEnableFBO = SPFALSE;
		m_pFBO = SPNULL;
	}

	SPTransitionVFXHandler::~SPTransitionVFXHandler()
	{
		SP_SAFE_DELETE(m_pTransitionEffect);
		SP_SAFE_DELETE(m_pFBO);
	}

	SPVoid SPTransitionVFXHandler::create(SPInt width, SPInt height)
	{
		m_nScreenWidth = width;
		m_nScreenHeight = height;

		//enableFBOImage();
	}

	SPVoid SPTransitionVFXHandler::draw()
	{

		m_pTransitionEffect->updateApp();

		contorlFBOSize();

		if(m_bEnableFBO == SPTRUE)
		{
			// first - bind, second - clear, otherwise depth test is not working
			m_pFBO->bindFBOSurface();
			m_pFBO->clearFBOSurface();
		}

		m_pTransitionEffect->drawApp();

		if(m_bEnableFBO == SPTRUE)
		{
			m_pFBO->unbindFBOSurface(m_nScreenWidth, m_nScreenHeight);
		}
	}

	SPVoid SPTransitionVFXHandler::onEventKey(KEY_TYPE keyID)
	{
		m_pTransitionEffect->onEventKey(keyID);
	}

	SPVoid SPTransitionVFXHandler::onEventTouch(TOUCH_TYPE eventType, SPInt xPos, SPInt yPos)
	{
		m_pTransitionEffect->onEventTouch(eventType, xPos, yPos);
	}

	SPVoid SPTransitionVFXHandler::onEventSensor(SENSOR_TYPE sensorType, SPFloat xValue, SPFloat yValue, SPFloat zValue)
	{
	}

	SPVoid SPTransitionVFXHandler::createEffect( SPUInt type )
	{
		m_nEffectType = type;

		setTransitionVFXType(type);
	}

	SPVoid SPTransitionVFXHandler::changeEffect( SPUInt type )
	{
		m_nEffectType = type;

		setTransitionVFXType(type);
	}

	SPVoid SPTransitionVFXHandler::setCurrentTexture( const SPChar* fileName )
	{
		switch(m_nEffectType)
		{
		case VFX_ALPHA_SCALE:
			{
				((SPAlphaScaling*)m_pTransitionEffect)->setCurrentTexture(fileName);
			}
			break;
		case VFX_TILE_BLEND:
			{
				((SPTileBlend*)m_pTransitionEffect)->setCurrentTexture(fileName);
			}
			break;
		case VFX_TILE_ROTATION:
			{
				((SPTileRotation*)m_pTransitionEffect)->setCurrentTexture(fileName);
			}
			break;
		case VFX_IMAGE_INK:
			{
				((SPImageInk*)m_pTransitionEffect)->setCurrentTexture(fileName);
			}
			break;
		}
	}

	SPVoid SPTransitionVFXHandler::setNextTexture( const SPChar* fileName )
	{
		switch(m_nEffectType)
		{
		case VFX_ALPHA_SCALE:
			{
				((SPAlphaScaling*)m_pTransitionEffect)->setNextTexture(fileName);
			}
			break;
		case VFX_TILE_BLEND:
			{
				((SPTileBlend*)m_pTransitionEffect)->setNextTexture(fileName);
			}
			break;
		case VFX_TILE_ROTATION:
			{
				((SPTileRotation*)m_pTransitionEffect)->setNextTexture(fileName);
			}
			break;
		case VFX_IMAGE_INK:
			{
				((SPImageInk*)m_pTransitionEffect)->setNextTexture(fileName);
			}
			break;
		}
	}

	SPVoid SPTransitionVFXHandler::setTransitionVFXType( SPInt type )
	{
		switch(type)
		{
		case VFX_ALPHA_SCALE:
			createAlphaScaleVFX(m_nScreenWidth, m_nScreenHeight);
			disableDepthBuffer();
			break;
		case VFX_TILE_BLEND:
			createTileBlendVFX(m_nScreenWidth, m_nScreenHeight);
			disableDepthBuffer();
			break;
		case VFX_TILE_ROTATION:
			createTileRotationVFX(m_nScreenWidth, m_nScreenHeight);
			enableDepthBuffer();
			break;
		case VFX_IMAGE_INK:
			createImageInkVFX(m_nScreenWidth, m_nScreenHeight);
			disableDepthBuffer();
			break;
		}
	}

	SPVoid SPTransitionVFXHandler::createAlphaScaleVFX( SPInt width, SPInt height )
	{
		SP_SAFE_DELETE(m_pTransitionEffect);

		m_pTransitionEffect = new SPAlphaScaling();

		if(m_bEnableFBO == SPTRUE)
		{
			((SPAlphaScaling*)m_pTransitionEffect)->enableFBODraw();
		}

		m_pTransitionEffect->initApp(width, height);
	}

	SPVoid SPTransitionVFXHandler::createTileBlendVFX( SPInt width, SPInt height )
	{
		SP_SAFE_DELETE(m_pTransitionEffect);

		m_pTransitionEffect = new SPTileBlend();

		if(m_bEnableFBO == SPTRUE)
		{
			((SPTileBlend*)m_pTransitionEffect)->enableFBODraw();
		}

		m_pTransitionEffect->initApp(width, height);
	}

	SPVoid SPTransitionVFXHandler::createTileRotationVFX( SPInt width, SPInt height )
	{
		SP_SAFE_DELETE(m_pTransitionEffect);

		m_pTransitionEffect = new SPTileRotation();

		if(m_bEnableFBO == SPTRUE)
		{
			((SPTileRotation*)m_pTransitionEffect)->enableFBODraw();
		}

		m_pTransitionEffect->initApp(width, height);
	}

	SPVoid SPTransitionVFXHandler::createImageInkVFX( SPInt width, SPInt height )
	{
		SP_SAFE_DELETE(m_pTransitionEffect);

		m_pTransitionEffect = new SPImageInk();

		if(m_bEnableFBO == SPTRUE)
		{
			((SPImageInk*)m_pTransitionEffect)->enableFBODraw();
		}

		m_pTransitionEffect->initApp(width, height);
	}

	SPVoid SPTransitionVFXHandler::enableDepthBuffer()
	{
		m_bEnableDepthBuffer = SPTRUE;
		m_pFBO->enableFBODepthBuffer();
	}

	SPVoid SPTransitionVFXHandler::disableDepthBuffer()
	{
		m_bEnableDepthBuffer = SPFALSE;
		m_pFBO->disableFBODepthBuffer();
	}

	SPVoid SPTransitionVFXHandler::enableFBOImage()
	{
		m_bEnableFBO = SPTRUE;

		if(m_pFBO == SPNULL)
		{
			m_pFBO = new SPFBO();
			m_pFBO->createFBOSurface(m_nScreenWidth, m_nScreenHeight);
		}
	}

	SPBool SPTransitionVFXHandler::isAnimationStatus()
	{
		SPBool aniStatus = SPFALSE;

		switch(m_nEffectType)
		{
		case VFX_ALPHA_SCALE:
			{
				aniStatus = ((SPAlphaScaling*)m_pTransitionEffect)->isAnimationStatus();
			}
			break;
		case VFX_TILE_BLEND:
			{
				aniStatus = ((SPTileBlend*)m_pTransitionEffect)->isAnimationStatus();
			}
			break;
		case VFX_TILE_ROTATION:
			{
				aniStatus = ((SPTileRotation*)m_pTransitionEffect)->isAnimationStatus();
			}
			break;
		case VFX_IMAGE_INK:
			{
				aniStatus = ((SPImageInk*)m_pTransitionEffect)->isAnimationStatus();
			}
			break;
		}

		return aniStatus;
	}

	SPVoid SPTransitionVFXHandler::runTransitionAnimation()
	{
		switch(m_nEffectType)
		{
		case VFX_ALPHA_SCALE:
			{
				((SPAlphaScaling*)m_pTransitionEffect)->runTransitionAnimation();
			}
			break;
		case VFX_TILE_BLEND:
			{
				((SPTileBlend*)m_pTransitionEffect)->runTransitionAnimation();
			}
			break;
		case VFX_TILE_ROTATION:
			{
				((SPTileRotation*)m_pTransitionEffect)->runTransitionAnimation();
			}
			break;
		case VFX_IMAGE_INK:
			{
				((SPImageInk*)m_pTransitionEffect)->runTransitionAnimation();
			}
			break;
		}
	}

	SPUInt SPTransitionVFXHandler::getCurrentTextureID()
	{
		if(m_bEnableFBO == SPTRUE)
		{
			return m_pFBO->getFBOTexture();
		}

		return 0;
	}

	SPFloat SPTransitionVFXHandler::getCurrentAnimationStep()
	{
		SPFloat aniStep = 0.0f;

		switch(m_nEffectType)
		{
		case VFX_ALPHA_SCALE:
			{
				aniStep = ((SPAlphaScaling*)m_pTransitionEffect)->getCurrentAnimationStep();
			}
			break;
		case VFX_TILE_BLEND:
			{
				aniStep = ((SPTileBlend*)m_pTransitionEffect)->getCurrentAnimationStep();
			}
			break;
		case VFX_TILE_ROTATION:
			{
				aniStep = ((SPTileRotation*)m_pTransitionEffect)->getCurrentAnimationStep();
			}
			break;
		case VFX_IMAGE_INK:
			{
				aniStep = ((SPImageInk*)m_pTransitionEffect)->getCurrentAnimationStep();
			}
			break;
		}

		return aniStep;
	}

	SPVoid SPTransitionVFXHandler::contorlFBOSize()
	{
		if(m_bEnableFBO == SPTRUE)
		{
			if(isAnimationStatus() == SPTRUE)
			{
				SPFloat currAniStep = getCurrentAnimationStep();

				if(currAniStep <= 0.0f)
					return;

				SPFloat scaleV = 1.0f;
				if(currAniStep < FBO_FADE_START)
				{
					//scaleV = 1.0f - currAniStep;
					scaleV = 1.0f - (currAniStep / FBO_FADE_START) * (1.0f - TARGET_MIN_FBO_RATIO);
					m_pFBO->resizeFBOSurface(m_nScreenWidth * scaleV, m_nScreenHeight * scaleV);
				}
				else if(currAniStep > FBO_FADE_END)
				{
					//scaleV = currAniStep;
					scaleV = TARGET_MIN_FBO_RATIO + ((currAniStep - FBO_FADE_END) / (1.0 - FBO_FADE_END)) * (1.0 - TARGET_MIN_FBO_RATIO);
					m_pFBO->resizeFBOSurface(m_nScreenWidth * scaleV, m_nScreenHeight * scaleV);
				}else
				{
					scaleV = TARGET_MIN_FBO_RATIO;
					m_pFBO->resizeFBOSurface(m_nScreenWidth * scaleV, m_nScreenHeight * scaleV);
				}
			}
		}
	}

} // namespace SPhysics