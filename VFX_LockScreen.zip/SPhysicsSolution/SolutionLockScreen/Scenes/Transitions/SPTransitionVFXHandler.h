/**
* @file SPTransitionVFXHandler.h
* @brief 
*
* @date 2014-03-27
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/


#ifndef _SP_TRANSITION_EFFECT_HANDLER_H_
#define _SP_TRANSITION_EFFECT_HANDLER_H_

#include "SPISceneComponent.h"
#include "SPFBO.h"

namespace SPhysics
{
	// typedef of the visual effect
	typedef enum _TRANSITION_VFX_TYPE
	{
		VFX_ALPHA_SCALE = 1,
		VFX_TILE_BLEND,
		VFX_TILE_ROTATION,
		VFX_IMAGE_INK
	}TRANSITION_VFX_TYPE;

	/**
	* @class     SPTransitionVFXHandler
	* @brief     a container to control the Transition Visual Effect
	*/
	class SPTransitionVFXHandler
	{
	public:
		/**
		* @brief     Constructor
		*/
		SPTransitionVFXHandler();

		/**
		* @brief     Destructor
		*/
		~SPTransitionVFXHandler();

	public:		
		/**
		* @brief     Handler initialization
		* @param     [IN] @b  width Screen width size
		* @param     [IN] @b  height Screen height size
		* @return     SPVoid
		*/
		SPVoid create(SPInt width, SPInt height);

		/**
		* @brief     with this API, can draw the transition visual effect
		* @return     SPVoid
		*/
		SPVoid draw();

		/**
		* @brief     with this API, can access the key event
		* @param     [IN] @b  keyID key ID
		* @return     SPVoid
		*/
		SPVoid onEventKey(KEY_TYPE keyID);

		/**
		* @brief     with this API, can access the touch event
		* @param     [IN] @b  eventType event type of the single touch event (TOUCH_DOWN, TOUCH_MOVE, TOUCH_UP)
		* @param     [IN] @b  xPos x position of touch
		* @param     [IN] @b  yPos x position of touch
		* @return     SPVoid
		*/
		SPVoid onEventTouch(TOUCH_TYPE eventType, SPInt xPos, SPInt yPos);

		/**
		* @brief     Sensor event handling
		* @param     [IN] @b  sensorType type of the sensor such as gyro, gravity ..
		* @param     [IN] @b  xValue a sensor value of X-axis
		* @param     [IN] @b  yValue a sensor value of Y-axis
		* @param     [IN] @b  zValue a sensor value of Z-axis
		* @return     SPVoid
		*/
		SPVoid onEventSensor(SENSOR_TYPE sensorType, SPFloat xValue, SPFloat yValue, SPFloat zValue);

		/**
		* @brief     with this API, can choose the visual effect type
		* @param     [IN] @b  type type of the transition vfx
		* @return     SPVoid
		*/
		SPVoid createEffect(SPUInt type);

		/**
		* @brief     with this API, can change the visual effect type in runtime
		* @param     [IN] @b  type type of the transition vfx
		* @return     SPVoid
		*/
		SPVoid changeEffect(SPUInt type);

		/**
		* @brief     with this API, can the current(original) texture
		* @param     [IN] @b  texID a texture id
		* @return     SPVoid
		*/
		SPVoid setCurrentTexture(const SPChar* fileName);

		/**
		* @brief     with this API, can the Next(to be) texture
		* @param     [IN] @b  texID a texture id
		* @return     SPVoid
		*/
		SPVoid setNextTexture(const SPChar* fileName);

		/**
		* @brief     return current texture id which is displayed
		* @return     SPUInt
		*/
		SPUInt getCurrentTextureID();

		/**
		* @brief     enable depth buffer for fbo
		* @return     SPVoid
		*/
		SPVoid enableDepthBuffer();

		/**
		* @brief     disable depth buffer for fbo
		* @return     SPVoid
		*/
		SPVoid disableDepthBuffer();

		/**
		* @brief     enable the fbo mode
		* @return     SPUInt
		*/
		SPVoid enableFBOImage();
		
		/**
		* @brief     return the status of the transition animation
		* @return    SPBool
		*/
		SPBool isAnimationStatus();

		/**
		* @brief     run the transition vfx
		* @return    SPVoid
		*/
		SPVoid runTransitionAnimation();

	private:
		SPVoid setTransitionVFXType(SPInt type);
		SPVoid createAlphaScaleVFX(SPInt width, SPInt height);
		SPVoid createTileBlendVFX(SPInt width, SPInt height);
		SPVoid createTileRotationVFX(SPInt width, SPInt height);
		SPVoid createImageInkVFX(SPInt width, SPInt height);

		/**
		* @brief     return the current animation step
		* @return     SPFloat
		*/
		SPFloat getCurrentAnimationStep();
		SPVoid  contorlFBOSize();


	private:				
		
		SPISceneComponent* m_pTransitionEffect;

		SPFBO* m_pFBO;

		SPInt m_nScreenWidth;
		SPInt m_nScreenHeight;

		SPInt m_nEffectType;
		SPBool m_bEnableDepthBuffer;
		SPBool m_bEnableFBO;
	};

}  //namespace SPhysics

#endif //_SP_TRANSITION_EFFECT_HANDLER_H_