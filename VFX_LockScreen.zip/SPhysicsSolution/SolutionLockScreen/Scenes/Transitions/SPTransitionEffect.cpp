/**
* @file SPTransitionEffect.cpp
* @brief
*
* @date 2014-03-27
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPTransitionEffect.h"

namespace SPhysics
{
	SPTransitionEffect::SPTransitionEffect()
	{
		m_pDrawFBOImg = SPNULL;
		m_bEnableFBODraw = SPFALSE;
	}

	SPTransitionEffect::~SPTransitionEffect()
	{
		SP_SAFE_DELETE(m_pDrawFBOImg);
	}

	SPVoid SPTransitionEffect::initApp(SPInt width, SPInt height)
	{
		// Control the FBO
		m_bEnableFBODraw = SPTRUE;

		m_cTransitionHandler.create(width, height);

		TRANSITION_VFX_TYPE effectType = VFX_ALPHA_SCALE;
		//TRANSITION_VFX_TYPE effectType = VFX_TILE_BLEND;
		//TRANSITION_VFX_TYPE effectType = VFX_IMAGE_INK;
		//TRANSITION_VFX_TYPE effectType = VFX_TILE_ROTATION;

		if(m_bEnableFBODraw == SPTRUE)
		{
			m_cTransitionHandler.enableFBOImage();
			if(m_pDrawFBOImg == SPNULL)
			{
				m_pDrawFBOImg = new SPDrawBackground();
				m_pDrawFBOImg->initialize((SPFloat)width, (SPFloat)height);
			}
		}

		m_cTransitionHandler.createEffect(effectType);

#if (!ANDROID_PORTING_MODE)
		m_cTransitionHandler.setCurrentTexture("Res/bgImg/s5_1l.png");
		m_cTransitionHandler.setNextTexture("Res/bgImg/s5_2l.png");
#else
		m_cTransitionHandler.setCurrentTexture((SPChar*)"PortraitBG");
		m_cTransitionHandler.setNextTexture((SPChar*)"NextPortraitBG");
#endif

	}

	SPVoid SPTransitionEffect::updateApp()
	{
	}

	SPVoid SPTransitionEffect::drawApp()
	{

		m_cTransitionHandler.draw();


		if(m_bEnableFBODraw == SPTRUE)
		{
			SPUInt texID = m_cTransitionHandler.getCurrentTextureID();
			m_pDrawFBOImg->setTextureID(texID);
			m_pDrawFBOImg->draw();
		}
	}

	SPVoid SPTransitionEffect::onEventKey(KEY_TYPE keyID)
	{
		// tizen 3.0 
		switch ((char)keyID)
		{		
		case 49:
		case 111: // top	
			m_cTransitionHandler.createEffect(VFX_ALPHA_SCALE);
			m_cTransitionHandler.setCurrentTexture("Res/bgImg/s5_1l.png");
			m_cTransitionHandler.setNextTexture("Res/bgImg/s5_2l.png");

			m_cTransitionHandler.onEventTouch(TOUCH_DOWN, 0, 0);
			break;
		case 50:
		case 116: // down
			m_cTransitionHandler.createEffect(VFX_TILE_BLEND);
			m_cTransitionHandler.setCurrentTexture("Res/bgImg/s5_1l.png");
			m_cTransitionHandler.setNextTexture("Res/bgImg/s5_2l.png");

			m_cTransitionHandler.onEventTouch(TOUCH_DOWN, 0, 0);
			break;
		case 51:
		case 113: // left
			m_cTransitionHandler.createEffect(VFX_IMAGE_INK);
			m_cTransitionHandler.setCurrentTexture("Res/bgImg/s5_2l.png");
			m_cTransitionHandler.setNextTexture("Res/bgImg/s5_1l.png");

			m_cTransitionHandler.onEventTouch(TOUCH_DOWN, 0, 0);
			break;
		case 52:
		case 114: // right
			m_cTransitionHandler.createEffect(VFX_TILE_ROTATION);
			m_cTransitionHandler.setCurrentTexture("Res/bgImg/s5_2l.png");
			m_cTransitionHandler.setNextTexture("Res/bgImg/s5_1l.png");

			m_cTransitionHandler.onEventTouch(TOUCH_DOWN, 0, 0);
			break;
		case 36: // enter
			break;
		}

		m_cTransitionHandler.onEventKey(keyID);
	}

	SPVoid SPTransitionEffect::onEventTouch(TOUCH_TYPE eventType, SPInt xPos, SPInt yPos)
	{
		m_cTransitionHandler.onEventTouch(eventType, xPos, yPos);
	}

} // namespace SPhysics