/**
* @file SPTileBlend.cpp
* @brief
*
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPTileBlend.h"
#include "SPTextureManager.h"
#include "SPMotionCurve.h"

#define DESIGNED_SCREEN_WITH			720.0f			// defined depend on concept movie clip
#define DESIGNED_SCREEN_HEIGHT			1280.0f			// defined depend on concept movie clip

#define TILE_NUM_W  6
#define TILE_NUM_H  11


#define MAX_ANIMATION_FRAME			90.0f			// defined depend on concept movie clip
#define INIT_ALPHA_ANIMATION		0.0f


//#define ENABLE_CONTINUE_TRANSITION  1

namespace SPhysics
{
	SPTileBlend::SPTileBlend()
	{
		m_fAlphaBlendStep = INIT_ALPHA_ANIMATION;
		m_nAnimationFrameCnt = 0.0f;
		m_bEnableFBODraw = SPFALSE;
	}

	SPTileBlend::~SPTileBlend()
	{
		m_vAlphaMap.clear();
	}

	SPVoid SPTileBlend::initApp(SPInt width, SPInt height)
	{
		m_nScreenWidth = width;
		m_nScreenHeight = height;


		resetApp();

		// create alpha map buffer and texture with initial value
		generateAlphaMap();

		//m_cDrawTileBlend.enableFBOImageDraw();
		m_cDrawTileBlend.initialize(width, height);
//		m_cDrawTileBlend.setCurrentTextureID(m_nCurrentTexID);
//		m_cDrawTileBlend.setNextTextureID(m_nNextTexID);
		m_cDrawTileBlend.setAlphaMapTextureID(m_nAlphaMapTexID);


		// for draw background
		m_cDrawBackground.initialize(width, height);
//		m_cDrawBackground.setTextureID(m_nCurrentTexID);


		if(m_bEnableFBODraw == SPTRUE)
		{
			m_cDrawTileBlend.setFBOUV();
			m_cDrawBackground.setFBOUV();
		}

	}

	SPVoid SPTileBlend::updateApp()
	{
		updateAnimation();
	}

	SPVoid SPTileBlend::drawApp()
	{
		switch(m_bRenderMode)
		{
		case RENDER_MODE_ANIMATION:
			drawAnimation();
			break;
		case RENDER_MODE_IDLE:
		default:
			drawIdle();
			break;
		}
	}

	SPVoid SPTileBlend::onEventTouch(TOUCH_TYPE eventType, SPInt xPos, SPInt yPos)
	{
		if(eventType == TOUCH_DOWN)
		{
			if(m_bRenderMode == RENDER_MODE_IDLE)
			{
				startAnimation();
			}
		}
	}

	SPVoid SPTileBlend::resetApp()
	{
		m_nAnimationFrameCnt = 0.0f;

		m_bRenderMode = RENDER_MODE_IDLE;

		m_fAlphaBlendStep = INIT_ALPHA_ANIMATION;

		m_fScreenScaleValue = (SPFloat)m_nScreenWidth / DESIGNED_SCREEN_WITH;
	}

	SPVoid SPTileBlend::runTransitionAnimation()
	{
		if(m_bRenderMode == RENDER_MODE_IDLE)
		{
			startAnimation();
		}
	}

	SPVoid SPTileBlend::setCurrentTexture( const SPChar* fileName )
	{
#if (!ANDROID_PORTING_MODE)
		m_nCurrentTexID = SPTextureManager::getInstancePtr()->loadTexture(fileName, SPTRUE);
#else
		m_nCurrentTexID = SPTextureManager::getInstancePtr()->getTextureID(fileName);
#endif


		setCurrentTexture(m_nCurrentTexID);
	}

	SPVoid SPTileBlend::setNextTexture( const SPChar* fileName )
	{
#if (!ANDROID_PORTING_MODE)
		m_nNextTexID = SPTextureManager::getInstancePtr()->loadTexture(fileName, SPTRUE);
#else
		m_nNextTexID = SPTextureManager::getInstancePtr()->getTextureID(fileName);
#endif

		setNextTexture(m_nNextTexID);
	}

	SPVoid SPTileBlend::enableFBODraw()
	{
		m_bEnableFBODraw = SPTRUE;
	}

	SPBool SPTileBlend::isAnimationStatus()
	{
		SPBool aniStatus = SPFALSE;

		if(m_bRenderMode == RENDER_MODE_ANIMATION)
			aniStatus = SPTRUE;

		return aniStatus;
	}

	SPFloat SPTileBlend::getCurrentAnimationStep()
	{
		return m_nAnimationFrameCnt / MAX_ANIMATION_FRAME;
	}

	SPVoid SPTileBlend::startAnimation()
	{
		m_bRenderMode = RENDER_MODE_ANIMATION;
	}

	SPVoid SPTileBlend::updateAnimation()
	{
		if (m_bRenderMode == RENDER_MODE_ANIMATION)
		{
			SPFloat curveAniStep = m_nAnimationFrameCnt / MAX_ANIMATION_FRAME;

			m_nAnimationFrameCnt += 1.0f;

			// 1.75 (Alpha Animation Range) = 1.0(alpha map max value) + 0.75f (Weight Alpha Value in the fragment shader)
			//m_fAlphaBlendStep = 1.75f * SineInOut33::getInterpolation(curveAniStep);
			m_fAlphaBlendStep = 1.75f * SineInOut60::getInterpolation(curveAniStep);
			//m_fAlphaBlendStep = 1.75f * SineInOut90::getInterpolation(curveAniStep);

			//m_fAlphaBlendStep += 0.019;
		}
	}

	SPVoid SPTileBlend::drawAnimation()
	{
		m_cDrawTileBlend.setAlphaBlend(m_fAlphaBlendStep);
		m_cDrawTileBlend.draw();

		if (m_nAnimationFrameCnt > MAX_ANIMATION_FRAME)
		{
			stopAnimation();
		}
	}

	SPVoid SPTileBlend::stopAnimation()
	{
		m_bRenderMode = RENDER_MODE_IDLE;

		m_nAnimationFrameCnt = 0.0f;
		m_fAlphaBlendStep = INIT_ALPHA_ANIMATION;

		changeImageTextue();


#if ENABLE_CONTINUE_TRANSITION
		startAnimation();
#endif
	}

	SPVoid SPTileBlend::changeImageTextue()
	{
		SPUInt tmpID = m_nCurrentTexID;

		m_nCurrentTexID = m_nNextTexID;
		m_nNextTexID = tmpID;

		m_cDrawBackground.setTextureID(m_nCurrentTexID);
		m_cDrawTileBlend.setCurrentTextureID(m_nCurrentTexID);
		m_cDrawTileBlend.setNextTextureID(m_nNextTexID);
	}

	SPVoid SPTileBlend::setCurrentTexture( SPUInt texID )
	{
		m_cDrawBackground.setTextureID(texID);
		m_cDrawTileBlend.setCurrentTextureID(texID);
	}

	SPVoid SPTileBlend::setNextTexture( SPUInt texID )
	{
		m_cDrawTileBlend.setNextTextureID(texID);
	}

	SPVoid SPTileBlend::drawIdle()
	{
		m_cDrawBackground.draw();
	}

	SPVoid SPTileBlend::generateAlphaMap()
	{
		if(m_vAlphaMap.size() != 0)
			m_vAlphaMap.clear();

		m_vAlphaMap.resize(TILE_NUM_W * TILE_NUM_H);

		//SPInt totalStep = TILE_NUM_H + TILE_NUM_H - TILE_NUM_W;
		//SPFloat step = 1.0f / TILE_NUM_H;
		SPFloat step = 1.0f / (TILE_NUM_H + TILE_NUM_H - TILE_NUM_W);

		SPUInt idx = 0;
		for(SPUInt i = 0; i < TILE_NUM_H; ++i)
		{
			for(SPUInt j = 0; j < TILE_NUM_W; ++j)
			{
				idx = i * TILE_NUM_W + j;

				SPFloat floatAlpha = 1.0f - step * (TILE_NUM_H - 1 - i + j);

				if(floatAlpha < 0.0f)	floatAlpha = 0.0f;

				floatAlpha = (SPFloat)pow(floatAlpha, 3);

				m_vAlphaMap[idx] = (SPUChar)(floatAlpha * 255.0f);
			}
		}

		// set texture property
		SPTextureManager::getInstancePtr()->setTextureParameters(DTYPE_UBYTE, PFORMAT_LUMINANCE, WRAP_CRAMP, MFILTER_NEAREST);

		// generate texture id
		m_nAlphaMapTexID = SPTextureManager::getInstancePtr()->setTexture("Alphamap.png", &m_vAlphaMap[0], TILE_NUM_W, TILE_NUM_H);
	}

	SPFloat SPTileBlend::SCALE( SPFloat value )
	{
		return value * m_fScreenScaleValue;
	}

}
//namespace SPhysics