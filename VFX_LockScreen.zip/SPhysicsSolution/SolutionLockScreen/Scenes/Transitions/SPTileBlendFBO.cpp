/**
* @file SPTileBlendFBO.cpp
* @brief
*
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPTileBlendFBO.h"
#include "SPTextureManager.h"
#include "SPMotionCurve.h"

#define TILE_NUM_W  6
#define TILE_NUM_H  11

#define TIME_STEP 0.01111111111111111111111111111111// * 1.3333333333333333333333333333
#define UNDER_SIZE 1.0f
#define CURRENT_SIZE 1.1f
#define NEXT_SIZE 1.2f

#define FBO_RATIO 0.4                         // control the quality of the vfx : Max 1.0, Min 0.1
#define FBO_FADE_START 0.2
#define FBO_FADE_END (1.0 - FBO_FADE_START)

// TRANSITION EFFECT DURATION
///////////////////////////////////////////////////////////////////////////////////////
//0.0         ~     	 FBO_RATIO         ~         FBO_RATIO          ~           1.0     (m_fTransitionStep)
//					  FBO_FADE_START               FBO_FADE_END
///////////////////////////////////////////////////////////////////////////////////////

namespace SPhysics
{
	SPTileBlendFBO::SPTileBlendFBO()
	{
		m_nAlphaMapTexID = 0;

		m_fAlphaBlendStep = 0.0f;
	}

	SPTileBlendFBO::~SPTileBlendFBO()
	{
	}

	SPVoid SPTileBlendFBO::initApp(SPInt width, SPInt height)
	{
		m_nScreenWidth = width;
		m_nScreenHeight = height;

		addBackground("Res/bgImg/bgd1.png");
		addBackground("Res/bgImg/bgd2.png");
		addBackground("Res/bgImg/bgd3.png");

		m_cFBO.createFBOSurface(width, height);

		if (m_vTextureID.empty() == SPTRUE)
		{
			SP_LOGE("Please add background image more than 2 before init");
			return;
		}

		resetApp();

		// create alpha map buffer and texture with initial value
		initilizeAlphaMap();

		m_cDrawTileBlend.setFBOUV();
		m_cDrawTileBlend.initialize(width, height);
		m_cDrawTileBlend.setCurrentTextureID(m_nCurrentTexID);
		m_cDrawTileBlend.setNextTextureID(m_nNextTexID);
		m_cDrawTileBlend.setAlphaMapTextureID(m_nAlphaMapTexID);
	}

	SPVoid SPTileBlendFBO::updateApp()
	{
		if (m_bEnableAnimation == SPTRUE && m_nCurrentFrame++ > m_nAnimationFrame)
		{
			enableBGTransition();
			m_nCurrentFrame = -getAnimationDurationFrame();
		}

		updateTransition();
	}

	SPVoid SPTileBlendFBO::updateTransition()
	{
		if (m_bTransitionMode == SPTRUE)
		{
// 			const SPFloat src_alpha = SineInOut33::getInterpolation(1.0f - m_fTransitionStep);
// 			const SPFloat scale_ratio = SineInOut90::getInterpolation(m_fTransitionStep);
// 			const SPFloat src_scale = scale_ratio * (NEXT_SIZE - CURRENT_SIZE) + CURRENT_SIZE;
// 			const SPFloat dst_scale = scale_ratio * (CURRENT_SIZE - UNDER_SIZE) + UNDER_SIZE;

			SPFloat fbo_ratio = 0.0f;

			//m_fAlphaBlendStep += 0.03;
			m_fAlphaBlendStep += 0.015;

			m_fTransitionStep += TIME_STEP;

			if (m_fTransitionStep < FBO_FADE_START)
			{
				fbo_ratio = 1.0 - (m_fTransitionStep / FBO_FADE_START) * (1.0 - FBO_RATIO);
				m_cFBO.resizeFBOSurface(m_nScreenWidth * fbo_ratio, m_nScreenHeight * fbo_ratio);
			}
			else if (m_fTransitionStep > FBO_FADE_END)
			{
				fbo_ratio = FBO_RATIO + ((m_fTransitionStep - FBO_FADE_END) / (1.0 - FBO_FADE_END)) * (1.0 - FBO_RATIO);
				m_cFBO.resizeFBOSurface(m_nScreenWidth * fbo_ratio, m_nScreenHeight * fbo_ratio);
			}
		}
	}

	SPVoid SPTileBlendFBO::drawApp()
	{
		if (m_bTransitionMode == SPTRUE || m_bInit == SPTRUE)
		{
			m_cFBO.clearFBOSurface();
			m_cFBO.bindFBOSurface();

			m_cDrawTileBlend.setAlphaBlend(m_fAlphaBlendStep);
			m_cDrawTileBlend.draw();

			m_cFBO.unbindFBOSurface(m_nScreenWidth, m_nScreenHeight);
			m_bInit = SPFALSE;

			if (m_fTransitionStep >= 1.0f)
			{
				changeCurrentBGTextureID();
				m_fTransitionStep = 0.0f;
				m_bTransitionMode = SPFALSE;

				m_fAlphaBlendStep = 0.3f;
			}
		}
	}

	SPVoid SPTileBlendFBO::onEventTouch(TOUCH_TYPE eventType, SPInt xPos, SPInt yPos)
	{
	}

	SPVoid SPTileBlendFBO::onEventSensor(SENSOR_TYPE sensorType, SPFloat xValue, SPFloat yValue, SPFloat zValue)
	{
	}

	SPVoid SPTileBlendFBO::onEventKey(KEY_TYPE keyID)
	{
	}

	SPVoid SPTileBlendFBO::resetApp()
	{
		m_bEnableAnimation = SPFALSE;
		m_nCurrentFrame = 0;
		m_nAnimationFrame = 0;

		m_nCurrentTexID = m_vTextureID[0];
		m_nNextTexID = m_vTextureID[1];
		m_nNextIndex = 1;

		m_bInit = SPTRUE;

		m_fTransitionStep = 0.0f;
		m_bTransitionMode = SPFALSE;

		m_fAlphaBlendStep = 0.3f;
	}

	SPVoid SPTileBlendFBO::enableBGTransition()
	{
		m_bTransitionMode = SPTRUE;
	}

	SPUInt SPTileBlendFBO::getCurrentBG()
	{
		return m_cFBO.getFBOTexture();
	}

	SPUInt SPTileBlendFBO::addBackground(const SPChar* fileName)
	{
		SPUInt ret = SPTextureManager::getInstancePtr()->loadTexture(fileName, SPTRUE);

		m_vTextureID.push_back(ret);

		return ret;
	}

	SPVoid SPTileBlendFBO::changeCurrentBGTextureID()
	{
		//SPUInt tmpID = SPUInt();

		//tmpID = m_nCurrentTexID;
		m_nCurrentTexID = m_nNextTexID;

		if (m_nNextIndex + 1 == m_vTextureID.size())
		{
			m_nNextTexID = m_vTextureID[0];
			m_nNextIndex = 0;
		}
		else
		{
			m_nNextTexID = m_vTextureID[++m_nNextIndex];
		}

		m_cDrawTileBlend.setCurrentTextureID(m_nCurrentTexID);
		m_cDrawTileBlend.setNextTextureID(m_nNextTexID);
	}

	SPFloat SPTileBlendFBO::getCurrentBGScale()
	{
		return CURRENT_SIZE;
	}

	SPInt SPTileBlendFBO::getAnimationDurationFrame()
	{
		return 1.0 / TIME_STEP;
	}

	SPVoid SPTileBlendFBO::setAutoAnimation(const SPUInt& nFrame)
	{
		m_nAnimationFrame  = nFrame;
		m_bEnableAnimation = SPTRUE;
	}

	SPVoid SPTileBlendFBO::initilizeAlphaMap()
	{
		if(m_vAlphaMap.size() != 0)
			m_vAlphaMap.clear();


		m_vAlphaMap.resize(TILE_NUM_W * TILE_NUM_H);

#if 0
		SPUInt idx = 0;
		for(SPUInt i = 0; i < TILE_NUM_H; ++i)
		{
			for(SPUInt j = 0; j < TILE_NUM_W; ++j)
			{
				idx = i * TILE_NUM_W + j;

				SPUChar temp = random<SPUChar>(0, 255);
				m_vAlphaMap[idx] = temp;
			}
		}
#endif

		SPFloat baseX = 6.0;
		SPFloat baseY = 0.0;

		// initialize the alphamap data
		SPUInt idx = 0;
		for(SPUInt i = 0; i < TILE_NUM_H; ++i)
		{
			for(SPUInt j = 0; j < TILE_NUM_W; ++j)
			{
				idx = i * TILE_NUM_W + j;

				SPFloat tempDist = (SPFloat)sqrt((j - baseX) * (j - baseX) + (i - baseY) * (i - baseY));
				tempDist *= tempDist;

				//tempDist = tempDist / 12.1f;
				tempDist = tempDist / 146.41f;

				//SPUChar temp = random<SPUChar>(0, 255);
				//m_vAlphaMap[idx] = temp;
				m_vAlphaMap[idx] = (SPUChar)(tempDist * 255);
				//m_vAlphaMap[idx] = 255;
			}
		}


		// set texture property
		SPTextureManager::getInstancePtr()->setTextureParameters(DTYPE_UBYTE, PFORMAT_LUMINANCE, WRAP_CRAMP, MFILTER_NEAREST);

		// generate texture id
		m_nAlphaMapTexID = SPTextureManager::getInstancePtr()->setTexture("Alphamap.png", &m_vAlphaMap[0], TILE_NUM_W, TILE_NUM_H);
	}

}
//namespace SPhysics