/**
* @file SPImageInk.cpp
* @brief
*
*
* @see
* Copyright (c) Graphics Lab., DMC R&D Center, Samsung Electronics, Inc., All rights reserved.
*
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information"). You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung Electronics.
*/

#include "SPImageInk.h"
#include "SPTextureManager.h"
#include "SPMotionCurve.h"

#define DESIGNED_SCREEN_WITH			1920.0f			// defined depend on concept movie clip
#define DESIGNED_SCREEN_HEIGHT			1080.0f			// defined depend on concept movie clip


#define MAX_ANIMATION_FRAME			150.0f			// defined depend on concept movie clip


//#define ENABLE_CONTINUE_TRANSITION  1

namespace SPhysics
{
	SPImageInk::SPImageInk()
	{
		m_fMaskUVScaleStep = 1.0f;
		m_nAnimationFrameCnt = 0.0f;
		m_bEnableFBODraw = SPFALSE;
	}

	SPImageInk::~SPImageInk()
	{
	}

	SPVoid SPImageInk::initApp(SPInt width, SPInt height)
	{
		m_nScreenWidth = width;
		m_nScreenHeight = height;

		//m_cMaskFBO.createFBOSurface(width * 0.4f, height * 0.4f);
		// 1920 x 1080 = 777 mA
		// 768 x 432 = 650mA
		// 180 x 320 = 570mA
		m_cMaskFBO.createFBOSurface(180, 320); 

		resetApp();

		//m_cDrawImgInk.enableFBOImageDraw();
		m_cDrawImgInk.initialize(width, height);
//		m_cDrawImgInk.setCurrentTextureID(m_nCurrentTexID);
//		m_cDrawImgInk.setNextTextureID(m_nNextTexID);
		m_cDrawImgInk.setMaskMapTextureID(m_cMaskFBO.getFBOTexture());

		m_cDrawMask.enableFBOImageDraw();
		m_cDrawMask.initialize(width, height);

#if (!ANDROID_PORTING_MODE)
		m_cDrawImgInk.setNoiseTexture("Res/transition/noise.png");
		m_cDrawMask.setTexture("Res/transition/blur.png");
#else
		m_cDrawImgInk.setNoiseTexture("TransitionNoise");
		m_cDrawMask.setTexture("TransitionBlur");
#endif
		//m_cDrawMask.setTexture("Res/transition/blur_5.png");

		// for draw background
		m_cDrawBackground.initialize(width, height);
//		m_cDrawBackground.setTextureID(m_nCurrentTexID);

		if(m_bEnableFBODraw == SPTRUE)
		{
			m_cDrawImgInk.setFBOUV();
			m_cDrawBackground.setFBOUV();
		}


		m_nCreateFBOCnt = 0;

	}

	SPVoid SPImageInk::updateApp()
	{
		updateAnimation();
	}

	SPVoid SPImageInk::drawApp()
	{
		switch(m_bRenderMode)
		{
		case RENDER_MODE_ANIMATION:
			drawAnimation();
			break;
		case RENDER_MODE_IDLE:
		default:
			drawIdle();
			break;
		}
	}

	SPVoid SPImageInk::onEventTouch(TOUCH_TYPE eventType, SPInt xPos, SPInt yPos)
	{
		if(eventType == TOUCH_DOWN)
		{
			if(m_bRenderMode == RENDER_MODE_IDLE)
			{
				startAnimation();
			}
		}
	}

	SPVoid SPImageInk::resetApp()
	{
		m_nAnimationFrameCnt = 0.0f;

		m_bRenderMode = RENDER_MODE_IDLE;

		m_fMaskUVScaleStep = 1.0f;


		m_fScreenScaleValue = (SPFloat)m_nScreenWidth / DESIGNED_SCREEN_WITH;
	}

	SPVoid SPImageInk::runTransitionAnimation()
	{
		if(m_bRenderMode == RENDER_MODE_IDLE)
		{
			startAnimation();
		}
	}

	SPBool SPImageInk::isAnimationStatus()
	{
		SPBool aniStatus = SPFALSE;

		if(m_bRenderMode == RENDER_MODE_ANIMATION)
			aniStatus = SPTRUE;

		return aniStatus;
	}

	SPFloat SPImageInk::getCurrentAnimationStep()
	{
		return m_nAnimationFrameCnt / MAX_ANIMATION_FRAME;
	}

	SPVoid SPImageInk::setCurrentTexture( const SPChar* fileName )
	{
#if (!ANDROID_PORTING_MODE)
		m_nCurrentTexID = SPTextureManager::getInstancePtr()->loadTexture(fileName, SPTRUE);
#else
		m_nCurrentTexID = SPTextureManager::getInstancePtr()->getTextureID(fileName);
#endif


		setCurrentTexture(m_nCurrentTexID);
	}

	SPVoid SPImageInk::setNextTexture( const SPChar* fileName )
	{
#if (!ANDROID_PORTING_MODE)
		m_nNextTexID = SPTextureManager::getInstancePtr()->loadTexture(fileName, SPTRUE);
#else
		m_nNextTexID = SPTextureManager::getInstancePtr()->getTextureID(fileName);
#endif

		setNextTexture(m_nNextTexID);
	}


	SPVoid SPImageInk::enableFBODraw()
	{
		m_bEnableFBODraw = SPTRUE;
	}

	SPVoid SPImageInk::startAnimation()
	{
		m_bRenderMode = RENDER_MODE_ANIMATION;
	}

	SPVoid SPImageInk::updateAnimation()
	{
		if (m_bRenderMode == RENDER_MODE_ANIMATION)
		{
			//SPFloat curveAniStep = m_nAnimationFrameCnt / MAX_ANIMATION_FRAME;

			m_nAnimationFrameCnt += 1.0f;

			//SPFloat scale_ratio = SineInOut90::getInterpolation(curveAniStep);

			//m_fMaskUVScaleStep = 1.0f + 0.7f * scale_ratio;			// 1.0 is equal 100%
			m_fMaskUVScaleStep += 0.005;

			generateMaskTexture();
		}
	}

	SPVoid SPImageInk::drawAnimation()
	{
		m_cDrawImgInk.scaleMaskUV(m_fMaskUVScaleStep);
		m_cDrawImgInk.draw();

		if (m_nAnimationFrameCnt > MAX_ANIMATION_FRAME)
		{
			stopAnimation();
		}
	}

	SPVoid SPImageInk::stopAnimation()
	{
		m_bRenderMode = RENDER_MODE_IDLE;

		m_nAnimationFrameCnt = 0.0f;
		m_fMaskUVScaleStep = 1.0f;

		changeImageTextue();


#if ENABLE_CONTINUE_TRANSITION
		startAnimation();
#endif
	}

	SPVoid SPImageInk::changeImageTextue()
	{
		SPUInt tmpID = m_nCurrentTexID;

		m_nCurrentTexID = m_nNextTexID;
		m_nNextTexID = tmpID;

		m_cDrawBackground.setTextureID(m_nCurrentTexID);
		m_cDrawImgInk.setCurrentTextureID(m_nCurrentTexID);
		m_cDrawImgInk.setNextTextureID(m_nNextTexID);
	}

	SPVoid SPImageInk::setCurrentTexture( SPUInt texID )
	{
		m_cDrawBackground.setTextureID(texID);
		m_cDrawImgInk.setCurrentTextureID(texID);
	}

	SPVoid SPImageInk::setNextTexture( SPUInt texID )
	{
		m_cDrawImgInk.setNextTextureID(texID);
	}

	SPVoid SPImageInk::drawIdle()
	{
		m_cDrawBackground.draw();
	}

	SPVoid SPImageInk::generateMaskTexture()
	{
		// create a FBO texture for the mask animation
		// if recreate the Mask image, 777 mA @ FHD
		// if create the Mask image just once, 420 mA  @ FHD

		SPBool generateFlag = SPFALSE;
		SPBool clearColor = SPFALSE;
		SPFloat translateX = 0.f;
		SPFloat translateY = 0.f;
		SPFloat maskSize = 0.0f;

		if(m_nAnimationFrameCnt == 1.0f)
		{
			translateX = m_nScreenWidth * 0.5f;
			translateY = m_nScreenHeight * 0.5f;
			maskSize = SCALE(600.0f);
			generateFlag = SPTRUE;
			clearColor = SPTRUE;

			m_cDrawMask.setBlendOption(GL_ONE, GL_ONE, GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
		}

		if(m_nAnimationFrameCnt == 25.0f)
		{
			//m_cMaskFBO.bindFBOSurface();
			translateX = m_nScreenWidth * 0.5f + SCALE(20.0f);
			translateY = m_nScreenHeight * 0.5f + SCALE(200.0f);
			maskSize = SCALE(500.0f);
			generateFlag = SPTRUE;
		}

		if(m_nAnimationFrameCnt == 35.0f)
		{
			translateX = m_nScreenWidth * 0.5f - SCALE(20.0f);
			//translateY = m_nScreenHeight * 0.5f - SCALE(200.0f);
			translateY = m_nScreenHeight * 0.5f - SCALE(150.0f);
			maskSize = SCALE(400.0f);
			generateFlag = SPTRUE;
		}

		if(generateFlag == SPTRUE)
		{
			m_cMaskFBO.bindFBOSurface();
			if(clearColor == SPTRUE)
			{
				m_cMaskFBO.clearFBOSurface();
			}

			m_cDrawMask.setSize(maskSize, maskSize);
			m_cDrawMask.setTranslate(translateX, translateY, 0.0f);
			m_cDrawMask.draw();

			m_cMaskFBO.unbindFBOSurface(m_nScreenWidth, m_nScreenHeight);
		}

		m_nCreateFBOCnt++;
	}

	SPFloat SPImageInk::SCALE( SPFloat value )
	{
		return value * m_fScreenScaleValue;
	}

}
//namespace SPhysics